"""Prospective paired macro-policy trials, one search worker at a time."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from compare_batches import policy_identity, same_json
from compare_policy_batches import compare_policy_batches, load_policy_protocol, required_policy_sources
from audit_batch import audit_batch
from decision_data import read_decisions, split_by_seed
from initial_policy import DEFAULT_PRIOR
from probe import ROOT
from run_metadata import atomic_json, file_evidence, metadata
from sample_runs import build_policy, run_one

EXECUTION_AND_AUDIT_SOURCES = ("run_policy_experiment.py", "run_metadata.py", "probe.py",
                               "audit_batch.py", "compare_policy_batches.py", "compare_batches.py")


def preflight(protocol_path):
    """Check concrete policies/artifacts before creating output or starting a game."""
    loaded = load_policy_protocol(protocol_path)
    document = loaded["document"]
    if loaded["created_unix"] > datetime.now(timezone.utc).timestamp():
        raise ValueError("Protocol created_utc is in the future")
    if document["conditions"] != {"character": "Defect", "ascension": 10}:
        raise ValueError("This runner supports only Defect A10")
    sources = [file_evidence(loaded["path"]), file_evidence(DEFAULT_PRIOR)]
    # The prefix fit is registered against a separate collection and its audit.
    # Keep those exact bytes frozen across every paired game, as well as the model.
    for registration in loaded.get("prefix_registrations", {}).values():
        sources.extend(registration["registered_sources"].values())
        sources.extend(registration["feature_sources"].values())
    for arm in document["arms"].values():
        sampling = arm["sampling"]
        for artifact in arm["model_artifacts"]:
            actual = file_evidence(artifact["path"])
            expected = {k: artifact[k] for k in ("path", "sha256", "bytes")}
            if actual != expected:
                raise ValueError("Predeclared model artifact changed or is unavailable")
            model = json.loads(Path(artifact["path"]).read_text(encoding="utf-8"))
            used_seeds = {seed for seeds in model.get("split_seeds", {}).values() for seed in seeds}
            if used_seeds.intersection(document["seeds"]):
                raise ValueError("Prospective experiment seeds overlap the model data splits")
            sources.append(actual)
        policy = build_policy(document["seeds"][0], arm["solver_config"], ascension=10,
            epsilon=sampling["epsilon"], model_path=sampling["model_path"],
            selection_budget=sampling["selection_budget"])
        if not same_json(policy_identity(policy.provenance), arm["policy_identity"]):
            raise ValueError("Constructed policy differs from the predeclared identity")
    versions = metadata("preflight", document["seeds"][0], 10,
        document["arms"]["left"]["solver_config"], {})["versions"]
    for registration in loaded.get("prefix_registrations", {}).values():
        for name, expected in registration["source_runtime"].items():
            if not same_json(versions.get(name), expected):
                raise ValueError("Prefix model original runtime differs before experiment: " + name)
    sources.extend(versions.get(k) for k in ("engine", "solver", "ritsu", "bridge", "cli", "godot"))
    sources.extend(versions["sources"].get(k) for k in (*required_policy_sources(document), *EXECUTION_AND_AUDIT_SOURCES))
    if any(item is None for item in sources):
        raise ValueError("Missing runtime or policy source before experiment")
    return loaded, {item["path"]: item for item in sources}


def verify_frozen_files(sources):
    for path, expected in sources.items():
        if file_evidence(path) != expected:
            raise ValueError("Experiment runtime, model or source changed: " + path)


def finalize_trial(protocol_path, destinations, expected_runs):
    """Close a full trial only after both raw-data audits and paired comparison."""
    target = Path(protocol_path).parent / "comparison.json"
    if target.exists():
        raise FileExistsError(target)
    audits = []
    for key in ("left", "right"):
        audited = audit_batch(destinations[key], expected_runs=expected_runs)
        audits.append({"arm": key, **file_evidence(audited["output_path"]), "passed": audited["passed"]})
    result = compare_policy_batches(destinations["left"], destinations["right"], protocol=protocol_path)
    result["required_full_data_audits"] = audits
    result["data_ready_for_conclusion"] = result["comparable"] and all(row["passed"] for row in audits)
    atomic_json(target, result)
    return {"comparison": file_evidence(target), "data_ready_for_conclusion": result["data_ready_for_conclusion"],
            "errors": result["errors"], "audits": audits, "paired": result["paired"],
            "summaries": {key: result[key]["summary"] for key in ("left", "right")}}


def run(protocol_path):
    protocol_path = Path(protocol_path).resolve()
    loaded, frozen_files = preflight(protocol_path)
    document = loaded["document"]
    arms, seeds = document["arms"], document["seeds"]
    destinations = {key: ROOT / "outputs" / arm["batch"] for key, arm in arms.items()}
    for key, destination in destinations.items():
        if destination.exists() or any((ROOT / "outputs" / f"{arms[key]['batch']}-{i:04d}").exists() for i in range(len(seeds))):
            raise FileExistsError(destination)
    plan = protocol_path.parent / "execution-plan.json"
    if plan.exists():
        raise FileExistsError(plan)
    if (protocol_path.parent / "comparison.json").exists():
        raise FileExistsError(protocol_path.parent / "comparison.json")
    atomic_json(plan, {"protocol": file_evidence(protocol_path), "created_utc": datetime.now(timezone.utc).isoformat(),
        "search_workers_concurrent": 1, "order": "even seed index left/right; odd seed index right/left",
        "preflight_frozen_files": frozen_files})
    reports, records = {key: [] for key in arms}, {key: [] for key in arms}
    for destination in destinations.values():
        destination.mkdir()
    for index, seed in enumerate(seeds):
        for key in (("left", "right") if index % 2 == 0 else ("right", "left")):
            verify_frozen_files(frozen_files)
            arm = arms[key]
            sampling = arm["sampling"]
            name = f"{arm['batch']}-{index:04d}"
            report = run_one(name, seed, ascension=10, settings=arm["solver_config"],
                epsilon=sampling["epsilon"], max_seconds=sampling["max_seconds"],
                max_decisions=sampling["max_decisions"], selection_budget=sampling["selection_budget"],
                model_path=Path(sampling["model_path"]) if sampling["model_path"] else None)
            reports[key].append(report)
            records[key].extend(read_decisions(ROOT / "outputs" / name / "decisions.jsonl"))
            atomic_json(destinations[key] / "reports.json", reports[key])
            print(json.dumps({"arm": key, "completed": len(reports[key]), "planned": len(seeds), **report}), flush=True)
            verify_frozen_files(frozen_files)
    for key in arms:
        splits = split_by_seed(records[key])
        atomic_json(destinations[key] / "split-manifest.json",
            {group: sorted({r["run_id"] for r in rows}) for group, rows in splits.items()})
        atomic_json(destinations[key] / "summary.json", {"runs": len(reports[key]), "reports": reports[key],
            "training_eligible_decisions": sum(r["training_eligible"] for r in records[key]),
            "purpose": "Prospective predeclared Defect A10 macro-policy comparison; all outcomes retained"})
    verify_frozen_files(frozen_files)
    result = finalize_trial(protocol_path, destinations, len(seeds))
    verify_frozen_files(frozen_files)
    print(json.dumps({"completed": True, "protocol": str(protocol_path), **result}), flush=True)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", required=True, type=Path)
    result = run(parser.parse_args().protocol)
    raise SystemExit(0 if result["data_ready_for_conclusion"] else 2)
