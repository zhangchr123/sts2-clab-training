"""Prospective Act-1 survival policy with explicit frozen v3 later-act fallback.

The predictor observes returns from a different frozen follow-up policy. Its
scores are neither causal action values nor calibrated survival probabilities.
No game, subprocess or LLM is invoked; score APIs never draw random numbers.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
from pathlib import Path
import random

from decision_data import (DataContractError, enumerate_candidates, state_hash,
                           DEFAULT_ENUMERATION_LIMIT, LEGACY_ENUMERATION_LIMIT, validate_candidate_set)
from initial_policy import InitialPolicy, POLICY_VERSION as FEATURE_VERSION
from train_act_survival import Act1SurvivalScorer, TARGET, VERSION as MODEL_FORMAT


VERSION = "act1-survival-with-v3-fallback-v1"
TIE_TOLERANCE = 1e-12
CONDITIONS = {"character": "Defect", "ascension": 10, "mode": "standard"}
LIMITATIONS = ["Act1_survival_is_not_A10_victory", "uncalibrated_relative_score",
    "observational_return_is_not_causal_action_value", "changing_policy_changes_the_label_distribution",
    "short_horizon_may_avoid_growth_needed_in_later_acts", "evaluated_unchosen_actions_have_no_labels",
    "incomplete_mechanism_and_route_coverage", "prospective_full_A10_evaluation_required"]


def _require(condition, message):
    if not condition:
        raise DataContractError(message)


class SurvivalPolicy:
    """SelectionPolicy-compatible model ranking in Act 1, v3 rules in Acts 2/3.

    Character and mode come from the caller's declared natural-run settings;
    the CLI state does not carry a stable character ID. Actual state ascension,
    act, noncombat ownership and clean engine recovery are checked every call.
    """
    SCORER_CLASS = Act1SurvivalScorer
    FORMAT = MODEL_FORMAT
    POLICY_ID = VERSION

    def __init__(self, path, *, solver_config, character="Defect", ascension=10,
                 mode="standard", fallback=None, epsilon=.1, seed="survival-policy"):
        _require(character == "Defect" and type(ascension) is int and ascension == 10
                 and mode == "standard", "SurvivalPolicy requires standard Defect A10")
        _require(type(epsilon) in (int, float) and math.isfinite(epsilon) and 0 <= epsilon <= 1,
                 "epsilon must be finite and in [0, 1]")
        _require(isinstance(solver_config, dict) and bool(solver_config),
                 "Explicit predeclared solver_config is required")
        path = Path(path).resolve()
        before = path.read_bytes()
        self.fallback = fallback or InitialPolicy(epsilon=0, random_seed=seed)
        fallback_identity = self.fallback.provenance
        _require(isinstance(self.fallback, InitialPolicy)
                 and fallback_identity.get("origin") == "natural"
                 and fallback_identity.get("kind") == "rules"
                 and fallback_identity.get("id") == "initial-stat-mechanism"
                 and fallback_identity.get("version") == FEATURE_VERSION
                 and fallback_identity.get("llm_involved") is False,
                 "Later-act fallback must be the natural frozen v3 rule policy")
        self.scorer = self.SCORER_CLASS(path, fallback=self.fallback)
        self._model = copy.deepcopy(self.scorer.model)
        _require(path.read_bytes() == before and state_hash(json.loads(before)) == state_hash(self._model),
                 "Model file changed while loading")
        self._source = {"path": str(path), "sha256": hashlib.sha256(before).hexdigest(), "bytes": len(before)}
        _require(self.scorer.source == self._source, "Scorer source differs from the loaded model artifact")
        self._model_hash = state_hash(self._model)
        frozen = self._model.get("frozen_followup")
        _require(isinstance(frozen, dict) and isinstance(frozen.get("solver"), dict)
                 and state_hash(frozen["solver"]) == state_hash(solver_config),
                 "Predeclared solver_config differs from model frozen_followup.solver")
        _require(state_hash(frozen.get("run_conditions")) == state_hash(CONDITIONS),
                 "Frozen follow-up run conditions differ from standard Defect A10")
        self._solver_config = copy.deepcopy(solver_config)
        self._facts = copy.deepcopy(self._model["feature_mechanism_facts"])
        self._prior_sha256 = self._model["feature_prior_sha256"]
        self._fallback_frozen = {key: copy.deepcopy(fallback_identity[key])
            for key in ("origin", "kind", "id", "version", "llm_involved", "prior_sha256", "mechanism_facts")}
        self.epsilon, self.seed = float(epsilon), seed
        self.rng, self.choice_count = random.Random(seed), 0
        self._check_integrity()

    @property
    def sha256(self):
        return self._source["sha256"]

    @property
    def model(self):
        return copy.deepcopy(self._model)

    @property
    def source(self):
        return copy.deepcopy(self._source)

    @property
    def mechanism_source(self):
        return copy.deepcopy(self._facts)

    @property
    def provenance(self):
        return {"origin": "natural", "kind": "model", "id": self.POLICY_ID, "version": self.sha256,
            "llm_involved": False, "epsilon": self.epsilon, "random_seed": self.seed,
            "prior_sha256": self._prior_sha256, "mechanism_facts": self.mechanism_source,
            "feature_policy_version": FEATURE_VERSION, "model_source": self.source,
            "deployment_scope": {**CONDITIONS, "acts": [1, 2, 3]},
            "model_scope": {**CONDITIONS, "act": 1, "target": TARGET},
            "fallback": {**copy.deepcopy(self._fallback_frozen), "acts": [2, 3],
                         "method": "pure_v3_rules_without_Act1_model_call"},
            "selection_method": {"ranking": "pure_model_in_Act1_pure_rules_in_Acts2_3_no_blend",
                "explicit": "epsilon_uniform_all_candidates_plus_uniform_greedy_ties",
                "epsilon_draw": "random_float_threshold", "tie_tolerance": TIE_TOLERANCE,
                "implicit": "requires_external_SelectionPolicy_with_recorded_parameters"},
            "solver_requested_config": copy.deepcopy(self._solver_config),
            "training_followup_sha256": state_hash(self._model["frozen_followup"]),
            "calibrated_probability": False}

    def _check_integrity(self):
        _require(state_hash(self.scorer.model) == self._model_hash and self.scorer.source == self._source
                 and self.scorer.fallback is self.fallback,
                 "Loaded survival scorer changed after model loading")
        actual = self.fallback.provenance
        _require(state_hash({key: actual.get(key) for key in self._fallback_frozen})
                 == state_hash(self._fallback_frozen)
                 and self.fallback.mechanism_source == self._facts
                 and self.fallback.prior.source["sha256"] == self._prior_sha256,
                 "Live fallback facts or prior differ from the frozen model")

    def _act(self, state):
        _require(isinstance(state, dict) and isinstance(state.get("context"), dict),
                 "Missing actual state context")
        context = state["context"]
        act = context.get("act")
        _require(type(act) is int and act in (1, 2, 3)
                 and type(context.get("ascension")) is int and context["ascension"] == 10
                 and context.get("integrity_recovery_used") is False
                 and context.get("combat_in_progress") is False
                 and state.get("type") == "decision" and state.get("decision") != "game_over",
                 "SurvivalPolicy requires actual clean noncombat A10 Act1..3 decisions")
        self._check_integrity()
        return act

    def score(self, state, candidates=None, *, selection_purpose=None):
        self._act(state)
        supplied = validate_candidate_set(candidates) if candidates is not None else None
        actual = enumerate_candidates(state, max_candidates=(
            supplied.get("enumeration_limit", LEGACY_ENUMERATION_LIMIT)
            if supplied is not None else DEFAULT_ENUMERATION_LIMIT))
        _require(actual["complete"], actual.get("reason") or "Incomplete legal action space")
        _require(candidates is None or candidates == actual, "Stale or modified candidates supplied to policy")
        _require(actual.get("representation") != "ordered_selection_implicit_v1",
                 "Implicit selection space requires bounded SelectionPolicy search")
        requests = [row["request"] for row in actual["candidates"]]
        _require(bool(requests), "No action is selectable at a terminal state")
        return self.score_requests(state, requests, selection_purpose=selection_purpose)

    def score_requests(self, state, requests, *, selection_purpose=None):
        act = self._act(state)
        active = act == 1
        if active:
            packet = self.scorer.score_requests(state, requests, character="Defect", mode="standard",
                                                selection_purpose=selection_purpose)
        else:
            # Do not call the Act1 predictor for any later-act request.
            packet = self.fallback.score_requests(state, requests, selection_purpose=selection_purpose)
        packet = copy.deepcopy(packet)
        _require(packet.get("mechanism_facts") == self._facts, "Scored features use different mechanism facts")
        for row in packet["scores"]:
            _require(type(row.get("score")) in (int, float) and math.isfinite(row["score"]),
                     "Nonfinite survival-policy score")
            if active:
                outside = [name for name, lo, hi in zip(self._model["feature_names"],
                    self._model["feature_min"], self._model["feature_max"])
                    if not lo <= row["features"][name] <= hi]
                row["model_coverage"] = {"active": True, "out_of_training_range": outside,
                    "uncertainty_calibrated": False, "unchosen_action_outcome_observed": False}
                row["uncertainty"] = "uncalibrated_observational_Act1_proxy_incomplete_coverage"
            else:
                row["model_coverage"] = {"active": False, "reason": "outside_Act1_model_scope",
                                         "uncertainty_calibrated": False}
        packet.update(policy_id=self.POLICY_ID, policy_version=self.POLICY_ID, feature_policy_version=FEATURE_VERSION,
            effective_scorer=self.FORMAT if active else FEATURE_VERSION,
            model={**self.source, "mode": "act1_survival", "active": active,
                "scope": {**CONDITIONS, "act": 1}, "calibrated_probability": False,
                "inactive_reason": None if active else "outside_Act1_model_scope"},
            policy_limitations=list(LIMITATIONS), calibrated=False)
        if active:
            packet["score_semantics"] = "uncalibrated_Act1_survival_proxy_score_not_A10_win_probability"
        # score_semantics and all v3 uncertainty/missing fields remain untouched
        # on fallback. A loaded but inactive model is not that decision's score.
        return packet

    def choose(self, state, candidates=None, *, selection_purpose=None):
        scoring = self.score(state, candidates, selection_purpose=selection_purpose)
        rows = scoring["scores"]
        best = max(row["score"] for row in rows)
        greedy = [row for row in rows if abs(row["score"] - best) <= TIE_TOLERANCE]
        explored = self.rng.random() < self.epsilon
        chosen = self.rng.choice(rows if explored else greedy)
        probability = self.epsilon / len(rows) + ((1 - self.epsilon) / len(greedy) if chosen in greedy else 0)
        result = {"request": copy.deepcopy(chosen["request"]), "candidate_id": chosen["candidate_id"],
            "scoring": scoring, "policy_provenance": {**self.provenance, "choice_count": self.choice_count},
            "exploration": {"epsilon": self.epsilon, "explored": explored,
                "chosen_probability": probability, "greedy_tie_count": len(greedy),
                "candidate_count": len(rows), "random_seed": self.seed, "choice_count": self.choice_count,
                "probability_semantics": "epsilon_uniform_all_candidates_plus_uniform_greedy_ties",
                "probability_precision": "nominal_float_threshold"}}
        self.choice_count += 1
        return result
