"""Registered synthetic prefix policy evidence; no games, fits or held-out data."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from audit_batch import audit_batch
from decision_data import DataContractError, DecisionJournal, enumerate_candidates, read_decisions, split_by_seed
from prefix_health_policy import PrefixHealthPolicy
from run_metadata import metadata
from selection_context import direct_action_evidence, validate_selection_contexts, validate_prefix_policy_sequence
from selection_policy import SelectionPolicy
from test_prefix_interventions import state
import test_prefix_health_policy as registered_fixtures


def write(path, value):
    path.write_text(json.dumps(value), encoding="utf-8")


def lines(path, values=None):
    if values is None:
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    path.write_text("".join(json.dumps(row) + "\n" for row in values), encoding="utf-8")


class PrefixPolicyAuditTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.artifacts = registered_fixtures.PrefixHealthPolicyTests()
        self.artifacts.directory = self.root / "registered"
        self.artifacts.directory.mkdir()
        # Real source/facts validators, manually constructed numerical weights;
        # do not call the fixture's mocked setup or any trainer.
        self.artifacts.fixture({"action_select_card_reward": 2.})

    def fixture(self, *, implicit=False, fail_last=False):
        rid, seed = "synthetic-prefix-live-0000", "synthetic-prefix-live-seed"
        base = PrefixHealthPolicy(self.artifacts.model_path, protocol_path=self.artifacts.protocol_path,
            solver_config=copy.deepcopy(registered_fixtures.CONFIG), epsilon=0., seed=seed)
        policy = SelectionPolicy(base, max_evaluations=8)
        states = [state("map_select", floor=1), state(floor=2), state(floor=3), state(floor=4)]
        states[-1]["context"]["act"] = 2
        if implicit:
            selected = state("card_select", floor=1)
            selected["context"]["room_type"] = "Event"
            selected.update(cards=[{"index": i, "id": "LEAP", "type": "Skill", "cost": 1,
                                    "stats": {"Block": i + 1}} for i in range(12)], min_select=0, max_select=6)
            states[0] = selected
        final = state("game_over", floor=5, hp=0)
        final.update(victory=False)
        final["context"]["act"] = 2
        info = metadata(rid, seed, 10, copy.deepcopy(registered_fixtures.CONFIG), policy.provenance)
        info["sampling"] = {"epsilon": 0., "max_seconds": 1200, "max_decisions": 500,
            "model_path": str(self.artifacts.model_path), "selection_budget": 8, "hidden_audit_features_used": False}
        directory = self.root / rid
        traces = [{"request": {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": seed},
                   "response": states[0]}]
        policies = []
        failure = {"kind": "timeout", "traceback": "synthetic transport failure"} if fail_last else None
        with DecisionJournal(directory, info) as journal:
            for index, current in enumerate(states):
                picked = policy.choose(current)
                after = states[index + 1] if index + 1 < len(states) else final
                error = failure if index + 1 == len(states) else None
                if error:
                    after = current
                token = journal.begin(current, picked["request"], policy=picked["policy_provenance"])
                policies.append({"decision_id": token, **picked, "selection_context": None})
                journal.complete(token, after, solver_calls=[], environment_error=error,
                    execution={"exploration": picked["exploration"], "selection_purpose": None,
                        "selection_context": None, "direct_action_result": None if error else direct_action_evidence(after)})
                traces.append({"request": picked["request"], "response": None if error else after,
                               **({"transport_error": "TimeoutError('synthetic')"} if error else {})})
            if failure:
                final = states[-1]
            outcome = journal.finalize(final, termination="timeout" if failure else "engine_terminal", environment_error=failure)
        observations = read_decisions(directory / "decisions.jsonl")
        report = {"run_id": rid, "seed": seed, "outcome": outcome["outcome"],
            "decisions": len(states) - bool(failure), "solver_calls": 0, "seconds": 1.,
            "training_eligible_decisions": sum(r["training_eligible"] for r in observations),
            "exclusion_reasons": sorted({e for r in observations for e in r["training_exclusion_reasons"]}),
            "final_context": final["context"], "final_hp": final["player"]["hp"], "error": failure}
        for name, value in (("manifest.json", info), ("state.json", final), ("report.json", report),
                            ("status.json", {"status": "finished", **report})):
            write(directory / name, value)
        lines(directory / "policy.jsonl", policies)
        lines(directory / "trace.jsonl", traces)
        batch = self.root / "batch"
        batch.mkdir()
        write(batch / "reports.json", [report])
        write(batch / "summary.json", {"runs": 1, "reports": [report],
                                       "training_eligible_decisions": report["training_eligible_decisions"]})
        write(batch / "split-manifest.json", {key: sorted({r["run_id"] for r in rows})
                                               for key, rows in split_by_seed(observations).items()})
        return batch, directory, observations, {row["decision_id"]: row for row in policies}

    def test_full_batch_accepts_once_only_119_delta_model_and_later_101_fallback(self):
        batch, _, records, policies = self.fixture()
        packets = [policies[r["decision_id"]]["scoring"] for r in records]
        self.assertEqual([p["model"]["active"] for p in packets], [False, True, False, False])
        self.assertEqual([len(p["scores"][0]["features"]) for p in packets], [101, 119, 101, 101])
        self.assertTrue(validate_selection_contexts(records, policies))
        result = audit_batch(batch)
        self.assertTrue(result["passed"], result["issues"])

    def test_implicit_fallback_preserves_rng_count_and_first_reward_scope(self):
        batch, _, records, policies = self.fixture(implicit=True)
        self.assertNotIn("scope_transition", policies[records[0]["decision_id"]])
        self.assertTrue(policies[records[1]["decision_id"]]["scoring"]["model"]["active"])
        result = audit_batch(batch)
        self.assertTrue(result["passed"], result["issues"])

    def test_features_prediction_skip_reference_and_reopened_scope_tampering_fail(self):
        _, _, records, policies = self.fixture()
        first, later = records[1]["decision_id"], records[2]["decision_id"]
        mutations = [lambda p: p[first]["scoring"]["scores"][0]["features"].update(health_deficit=.123),
            lambda p: p[first]["scoring"]["scores"][0]["model_features"].update(is_skip=3.),
            lambda p: p[first]["scoring"]["scores"][0].update(score=.9),
            lambda p: p[first]["scoring"]["scores"][0].update(model_reference_score=.2),
            lambda p: p[first]["scoring"]["scores"][0].update(rule_score=99.),
            lambda p: p[later]["scoring"]["model"].update(active=True),
            lambda p: p[later]["scoring"]["scores"][0].update(score=99.)]
        for mutate in mutations:
            tampered = copy.deepcopy(policies)
            mutate(tampered)
            with self.subTest(mutation=mutations.index(mutate)):
                with self.assertRaises(DataContractError):
                    validate_prefix_policy_sequence(records, tampered)

    def test_truncated_or_reordered_macro_history_cannot_reopen_scope(self):
        _, _, records, policies = self.fixture()
        for rows in (records[1:], [records[0], records[2], records[1], records[3]]):
            with self.assertRaises(DataContractError):
                validate_prefix_policy_sequence(rows, policies)

    def test_unjournaled_real_reward_action_cannot_be_hidden_from_first_gate_audit(self):
        batch, directory, records, _ = self.fixture()
        traces = lines(directory / "trace.jsonl")
        reward = records[1]["state"]
        skip = next(c for c in enumerate_candidates(reward)["candidates"] if c["is_skip"])
        traces.insert(2, {"request": skip["request"], "response": reward})
        lines(directory / "trace.jsonl", traces)
        result = audit_batch(batch)
        self.assertFalse(result["passed"])
        self.assertIn("prefix_entire_macro_trace_coverage", {issue["check"] for issue in result["issues"]})

    def test_failed_last_intent_keeps_scope_evidence_and_zero_training_labels(self):
        batch, _, records, policies = self.fixture(fail_last=True)
        self.assertTrue(validate_selection_contexts(records, policies))
        result = audit_batch(batch)
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual(result["counts"]["training_eligible_decisions"], 0)

    def test_incomplete_registered_receipt_is_rejected(self):
        _, _, records, policies = self.fixture()
        receipt = json.loads(self.artifacts.receipt_path.read_text())
        receipt["status"] = "fit_started"
        write(self.artifacts.receipt_path, receipt)
        with self.assertRaises((ValueError, DataContractError)):
            validate_prefix_policy_sequence(records, policies)

    def test_re_registered_artifact_with_wrong_live_feature_hash_is_rejected(self):
        _, _, records, policies = self.fixture()
        self.artifacts.model_data["feature_sources"]["interaction_features.py"]["sha256"] = "0" * 64
        self.artifacts.register()
        with self.assertRaisesRegex(ValueError, "feature source drift"):
            validate_prefix_policy_sequence(records, policies)

    def test_paired_feature_packet_cannot_be_relabelled_as_survival_format(self):
        _, _, records, policies = self.fixture()
        for record in records:
            record["metadata"]["provenance"]["id"] = "act1-interaction-survival-with-v3-fallback-v1"
            picked = policies[record["decision_id"]]
            picked["policy_provenance"]["id"] = "act1-interaction-survival-with-v3-fallback-v1"
            picked["scoring"]["policy_id"] = "act1-interaction-survival-with-v3-fallback-v1"
        with self.assertRaisesRegex(DataContractError, "cannot be relabeled"):
            validate_selection_contexts(records, policies)


if __name__ == "__main__":
    unittest.main()
