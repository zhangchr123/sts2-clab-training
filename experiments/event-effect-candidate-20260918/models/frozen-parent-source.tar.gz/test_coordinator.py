"""Frozen real-DLL backend comparisons; artificial fixtures, not training data."""
import copy
import json
import unittest
import uuid

from probe import Bridge, ROOT, replay_basic


class CoordinatorTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.b = Bridge(self.label)
        self.requests = []
        self.send(cmd="start_run", character="Defect", ascension=10, seed="solver-bridge-1")

    def tearDown(self):
        (ROOT / "outputs" / f"{self.label}.json").write_text(json.dumps({
            "provenance": "isolated artificial solver backend comparison; not training data",
            "requests": self.requests, "responses": self.b.rows,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        self.b.close()

    def send(self, **request):
        self.requests.append(copy.deepcopy(request))
        return self.b.send(**request)

    def enter(self, **fixture):
        if fixture:
            self.assertEqual(self.send(cmd="set_player", **fixture)["type"], "ok")
        state = self.send(cmd="enter_room", type="combat", encounter="SHRINKER_BEETLE_WEAK")
        self.assertEqual(state.get("decision"), "combat_play", state)
        return state

    def verified(self, result):
        self.assertEqual(result.get("type"), "solver_result", result)
        settings = result["settings"]
        self.assertIs(settings["search_profile_verified"], True)
        self.assertEqual(settings["profile_semantics"],
                         "configured_base_profile; actual per-stage profiles in search_stages")
        stages, audit = settings["search_stages"], settings["search_stage_audit"]
        self.assertGreater(len(stages), 0)
        self.assertEqual(audit["started_stage_count"], len(stages))
        self.assertEqual(audit["finished_stage_count"], len(stages))
        self.assertIs(audit["hook_verified"], True)
        self.assertEqual(audit["top_level_outcome"], "solver_result")
        self.assertEqual([s["index"] for s in stages], list(range(len(stages))))
        self.assertTrue(all(s["search_profile"]["soft_time_budget_ms"] <= result["budget_ms"] for s in stages))
        self.assertTrue(all(s["policy_snapshot"]["MaxDegreeOfParallelism"] == 1 for s in stages))
        self.assertEqual(audit["observed_expanded_nodes"], sum(s["expanded_nodes"] for s in stages))
        if settings["solver_backend"] == "coordinator":
            self.assertIs(audit["total_nodes_reconciled"], True)
            self.assertEqual(audit["observed_expanded_nodes"], result["summary"]["TotalExpandedNodes"])
            self.assertEqual(settings["hard_timeout_ms"], result["budget_ms"] + 5000)
        return stages

    def test_frozen_pair_and_smart_potion_gradient_replay(self):
        state = self.enter(hp=1, potions=["FIRE_POTION"])
        before = self.send(cmd="branch_audit")
        frozen = {"cmd": "solve", "budget_ms": 5000, "potion_policy": "Smart"}
        beam = self.send(**frozen)  # Omitted backend must remain beam.
        self.verified(beam)
        self.assertEqual(beam["settings"]["solver_backend"], "beam")
        self.assertEqual(self.send(cmd="branch_audit"), before)
        coordinated = self.send(**frozen, solver_backend="coordinator")
        stages = self.verified(coordinated)
        self.assertEqual(self.send(cmd="branch_audit"), before)
        self.assertEqual(stages[0]["effective_potion_policy"], "Disabled")
        self.assertTrue(any(s["effective_potion_policy"] == "RequireAtLeastOne"
                            and s["minimum_potion_uses"] == s["maximum_potion_uses"] == 1
                            for s in stages))
        self.assertTrue(any(a["Kind"] == "UsePotion" for a in coordinated["actions"]))
        final = replay_basic(self.b, state, coordinated)
        self.assertEqual(final["decision"], "card_reward", final)
        self.assertEqual(final["player"]["hp"], coordinated["snapshot"]["PlayerHp"])
        self.assertIs(final["context"]["integrity_recovery_used"], False)

    def test_no_victory_escalation_reports_actual_widened_profile(self):
        self.enter(hp=1, deck=["DEFEND_DEFECT"] * 5, relics=[])
        result = self.send(cmd="solve", solver_backend="coordinator", budget_ms=5000)
        stages = self.verified(result)
        self.assertTrue(result["summary"]["OnlyDeathRoutesFound"])
        self.assertEqual(result["settings"]["search_profile"]["beam_width"], 30)
        self.assertEqual(stages[0]["search_profile"]["beam_width"], 30)
        self.assertTrue(any(s["search_profile"]["beam_width"] == 60
                            and s["search_profile"]["max_expanded_nodes"] == 10000 for s in stages[1:]))
        self.assertTrue(any("NO_VICTORY_ESCALATION start" in e["message"]
                            for e in result["settings"]["search_stage_events"]))

    def test_boss_minimum_beam_is_observed_not_echoed_from_request(self):
        state = self.send(cmd="enter_room", type="combat", encounter="THE_KIN_BOSS")
        self.assertEqual(state.get("decision"), "combat_play", state)
        result = self.send(cmd="solve", solver_backend="coordinator", budget_ms=5000,
                           search_profile={"max_expanded_nodes": 1})
        stages = self.verified(result)
        self.assertEqual(result["settings"]["configured_search_profile"]["beam_width"], 30)
        self.assertEqual(stages[0]["search_profile"]["beam_width"], 45)
        self.assertTrue(any("ACT_ENDING_BOSS_SEARCH_OVERRIDE" in e["message"]
                            for e in result["settings"]["search_stage_events"]))

    def test_top_level_policy_failure_preserves_observed_stage_and_not_verified(self):
        self.enter(hp=35, potions=["AMBERGRIS"])
        result = self.send(cmd="solve", solver_backend="coordinator", budget_ms=5000,
                           potion_policy="RequireAtLeastOne")
        self.assertEqual(result["type"], "error", result)
        self.assertIn("PotionPolicyUnsatisfiedException", result["error"])
        settings = result["settings"]
        self.assertIs(settings["search_profile_verified"], False)
        self.assertEqual(settings["search_stage_audit"]["top_level_outcome"], "error")
        failed = [s for s in settings["search_stages"] if s["status"] == "failed"]
        self.assertTrue(failed)
        self.assertTrue(all(s["effective_potion_policy"] == "RequireAtLeastOne" for s in failed))
        self.assertTrue(all(s["handled_by_coordinator"] is False for s in failed))

    def test_invalid_backend_is_rejected(self):
        self.enter()
        for backend in (None, 1, {}, "session", "Beam"):
            with self.subTest(backend=backend):
                result = self.send(cmd="solve", solver_backend=backend)
                self.assertEqual(result["type"], "error", result)
                self.assertIn("solver_backend", result["error"])


if __name__ == "__main__":
    unittest.main()
