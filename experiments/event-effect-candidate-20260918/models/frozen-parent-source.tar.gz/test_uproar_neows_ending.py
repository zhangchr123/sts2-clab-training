"""Original Uproar/NeowsFury prefixes; diagnostic fixtures, never training games."""
import copy
import importlib.util
from pathlib import Path
import sys
import unittest
import uuid
from unittest.mock import patch

STAGE = Path('D:/sts2-training/staging/public-reference-archetype-321')
ROOT = Path('C:/Users/zhangchr/Documents/code/sts2-solver-bridge')
sys.path.insert(0, str(STAGE / 'sts2-solver-bridge'))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


module = load('uproar_ending_executor', STAGE / 'combat_executor.py')
replay = load('uproar_ending_replay', STAGE / 'replay_evidence.py')
replay.CombatExecutor = module.CombatExecutor
import probe
import test_liquid_memories as helpers
from test_original_return_live import visible
from prefix_interventions import read_json, read_lines, unchanged


class UproarNeowsEndingTests(unittest.TestCase):
    save = helpers.LiquidMemoriesTests.save

    def prefix(self, ending):
        source = ROOT / 'outputs/defect-contextual-parallel-20260914a-g01-c08-s23'
        audit = read_json(ROOT / 'outputs/defect-contextual-parallel-20260914a/generation-01' / (source.name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        parent_index = 216
        solve_index = max(i for i, row in enumerate(rows[:parent_index]) if row['request']['cmd'] == 'solve')
        parent = rows[parent_index]['response']['choice_audit']['parent']
        action = next(a for a in rows[solve_index]['response']['actions'] if a.get('CardId') == 'UPROAR'
                      and a['Turn'] == parent['player_turn'] and a['CardStateKey'] == parent['card_key'])
        label = ('uproar-neows-ending-' if ending else 'uproar-neows-unused-') + uuid.uuid4().hex[:10]
        with patch.object(probe, 'ROOT', STAGE / 'sts2-solver-bridge'):
            bridge, traces, send = helpers.LiquidMemoriesTests.worker(self, label)
        matched = 0
        try:
            for row in rows[:parent_index]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                self.assertEqual(visible(before), visible(row['response']))
                matched += 1
            return dict(bridge=bridge, traces=traces, send=send, label=label, before=before, rows=rows,
                        parent_index=parent_index, solve_index=solve_index, action=action, matched=matched, audit=audit)
        except BaseException:
            bridge.close()
            raise

    def test_actual_ending_binds_original_nested_source_and_stops(self):
        f = self.prefix(True)
        send, traces, before, action = f['send'], f['traces'], f['before'], f['action']
        try:
            # One historical action through the real dispatcher. Its inserted
            # solve envelope is explicitly synthetic, not a fresh search claim.
            class RecordedPlan(module.CombatExecutor):
                def solve(self, state, budget, used=0, setup=False):
                    call = {'request': {'cmd': 'solve'}, 'response': {'type': 'solver_result', 'actions': [copy.deepcopy(action)]}}
                    traces.append(copy.deepcopy(call)); self.solve_calls.append(call)
                    return call['response']
            start = len(traces)
            observer = RecordedPlan(send)
            after = observer.advance(before)
            self.assertEqual(visible(after), visible(f['rows'][-1]['response']))
            self.assertEqual(after['decision'], 'card_reward')
            tail = traces[start:]
            self.assertEqual([r['request']['cmd'] for r in tail], ['solve', 'combat_meta', 'action', 'choice_meta'])
            self.assertEqual(tail[2]['request'], f['rows'][-1]['request'])
            self.assertTrue(replay.validate_replay_evidence(observer.solve_calls, traces)['verified'])
            proof = observer.solve_calls[0]['replay'][0]
            self.assertEqual(proof['kind'], 'planned_choice_not_executed')
            self.assertEqual(proof['selected_cards'], [])
            self.assertTrue(proof['remaining_battle_plan_stopped'])
            self.assertEqual(proof['nested_effect_binding'], 'actual_NeowsFury_callsite_within_original_Uproar_action')
            original = after['choice_audit']['original_returns'][0]
            self.assertEqual(original['source_id'], 'NEOWS_FURY')
            self.assertFalse(original['source_is_actual_parent_object'])
            self.assertTrue(original['nested_source_owner_matches_parent'])
            for key, value in (
                ('source_id', 'SEEKER_STRIKE'), ('nested_parent_card_id', 'STRIKE_DEFECT'),
                ('nested_relation', 'unrelated'), ('nested_source_owner_matches_parent', False),
                ('nested_source_card_key', 'OTHER+0'), ('source_is_actual_parent_object', True),
                ('effect_callsite', 'Unrelated.OnPlay'), ('original_task_completed_successfully', False),
                ('returned_cards', [{'CardId': 'COMPILE_DRIVER'}]), ('returned_count', 1),
                ('selector_pending_after', True), ('selector_invocations_after', 99),
                ('filter_reexecuted_by_observer', True), ('is_over_or_ending_at_entry', False),
                ('player_turn', 99), ('action_id', 9999), ('min_select', 1), ('max_select', 99), ('max_select', True), ('require_manual_confirmation', False), ('nested_source_card_key', 'NEOWS_FURY+0|vars=Cards=1|')):
                with self.subTest(corruption=key):
                    bad = copy.deepcopy(after); bad['choice_audit']['original_returns'][0][key] = value
                    meta = copy.deepcopy(tail[-1]['response']); meta['completion_audit'] = bad['choice_audit']
                    checker = module.CombatExecutor(lambda **_: meta)
                    checker.last_action_request = f['rows'][-1]['request']; checker.solve_calls = [{}]
                    with self.assertRaises(RuntimeError): checker.resolve_ending_choice(before, bad, action)
            self.assertEqual(f['matched'], 128)
            self.assertEqual(original['min_select'], 0)
            self.assertEqual(original['max_select'], 2)
            self.assertTrue(original['require_manual_confirmation'])
            for change in ('empty_context', 'source', 'occurrence', 'replay', 'timing', 'ordering', 'turn_end', 'extra_token'):
                bad_action = copy.deepcopy(action)
                plan = bad_action['NestedChoices'][0]
                if change == 'empty_context': plan['ContextId'] = 'invented'
                elif change == 'source': plan['SourceId'] = ''
                elif change == 'occurrence': plan['Cards'][0]['SourceOccurrence'] = -1
                elif change == 'replay': bad_action['ReplayCount'] = 1
                elif change == 'timing': plan['Timing'] = 'TurnStart'
                elif change == 'ordering': bad_action['NestedChoicesBeforePrimary'] = 0
                elif change == 'turn_end': bad_action['EndsPlayerTurn'] = True
                else: plan['Cards'].append(copy.deepcopy(plan['Cards'][0]))
                checker = module.CombatExecutor(lambda **_: copy.deepcopy(tail[-1]['response']))
                checker.last_action_request = f['rows'][-1]['request']; checker.solve_calls = [{}]
                with self.subTest(plan_corruption=change):
                    try: accepted = checker.resolve_ending_choice(before, after, bad_action)
                    except RuntimeError: accepted = False
                    self.assertFalse(accepted)
            for mutation in ('omit', 'nested', 'selected', 'context'):
                bad = copy.deepcopy(observer.solve_calls)
                if mutation == 'omit': bad[0]['replay'] = []
                elif mutation == 'nested': bad[0]['replay'][0]['nested_effect_binding'] = 'invented'
                elif mutation == 'selected': bad[0]['replay'][0]['selected_cards'] = action['NestedChoices'][0]['Cards']
                else: bad[0]['replay'][0]['context_validation'] = 'actual_rng_verified'
                with self.assertRaises(ValueError): replay.validate_replay_evidence(bad, traces)
            self.save(f['label'], traces, passed=True, origin='original_prefix_with_explicit_recorded_plan_provider',
                      prefix_responses_verified=f['matched'], original_source=f['audit']['actual_source_evidence'],
                      synthetic_solve_indices=[start], solver_calls=observer.solve_calls,
                      full_state_or_rng_equality_claimed=False)
        finally:
            f['bridge'].close()


if __name__ == '__main__': unittest.main()
