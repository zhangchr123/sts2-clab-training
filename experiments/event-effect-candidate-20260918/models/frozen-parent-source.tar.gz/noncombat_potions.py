"""Explicit Fruit Juice actions on noncombat surfaces, with a switchable rule.

The exported MaxHp variable is the base effect, not a promise about all relic
hooks. Actions go through the ordinary journal and actual engine response.
Pending card selections, minigames and combat remain with their own handlers.
"""
import copy
import math

SURFACES = ('card_reward', 'map_select', 'event_choice', 'rest_site', 'shop')
CONTRACT = dict(version='noncombat-fruit-juice-v1', potion_id='POTION.FRUIT_JUICE',
    surfaces=list(SURFACES), target='self', rule='drink_before_other_macro_actions',
    learned_parameters_added=0, actual_gain_predicted=False,
    pending_selection_interruption=False)


def eligible_potions(state):
    from decision_data import DataContractError
    if (state.get('type')!='decision' or state.get('decision') not in SURFACES
            or state.get('context',{}).get('combat_in_progress') is not False):
        return []
    potions=state.get('player',{}).get('potions',[])
    if not isinstance(potions,list):raise DataContractError('Potion inventory must be a list')
    result=[];seen=set()
    for potion in potions:
        if not isinstance(potion,dict):raise DataContractError('Potion inventory entry must be an object')
        index=potion.get('index')
        if type(index) is not int or index<0 or index in seen:
            raise DataContractError('Potion inventory indices must be explicit and unique')
        seen.add(index)
        if potion.get('id')!=CONTRACT['potion_id']:continue
        amount=(potion.get('vars') or {}).get('MaxHp')
        if (potion.get('target_type')!='AnyPlayer' or type(amount) not in (int,float)
                or not math.isfinite(amount) or amount<=0):
            raise DataContractError('Fruit Juice must expose its current positive base MaxHp and AnyPlayer target')
        result.append(copy.deepcopy(potion))
    return result


def configuration(enabled):
    if type(enabled) is not bool:raise ValueError('Fruit Juice switch must be boolean')
    return dict(enabled=enabled,contract=copy.deepcopy(CONTRACT))


def adjust(packet,config):
    """Give the known free action priority without changing learned coordinates.

    The disabled arm keeps all ordinary scores and their tie order unchanged.
    This rule is deliberately a policy hypothesis; it is not a win guarantee.
    """
    from decision_data import DataContractError
    if (not isinstance(config,dict) or type(config.get('enabled')) is not bool
            or config!=configuration(config['enabled'])):
        raise DataContractError('Invalid frozen noncombat potion contract')
    rows=packet['scores']
    ordinary=[r['score'] for r in rows if r['request']['action']!='use_potion']
    priority=(max(ordinary,default=0.)+1. if config['enabled'] else min(ordinary,default=0.)-1.)
    for row in rows:
        if row['request']['action']=='use_potion':
            row['score']=priority
            row['noncombat_potion_rule']=copy.deepcopy(config)
            row['reasons']=[dict(source=CONTRACT['version'],score=priority,
                explanation='Drink Fruit Juice before the next macro choice' if config['enabled']
                else 'Control arm retains the previous policy without noncombat drinking')]
    skip=next((r['score'] for r in rows if r['is_skip']),None)
    for row in rows:row['delta_from_skip']=None if skip is None else row['score']-skip
    packet['noncombat_potion_policy']=copy.deepcopy(config)
    return packet
