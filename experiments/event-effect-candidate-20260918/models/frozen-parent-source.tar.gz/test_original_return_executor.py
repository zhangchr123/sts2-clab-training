"""Pure replay contracts using copied public failure surfaces and synthetic audit events."""
import copy
import json
from pathlib import Path
import unittest

from combat_executor import CombatExecutor
from replay_evidence import validate_replay_evidence


CASES = Path(__file__).parent / "inspection/staging/hologram-auto-choice/observed_cases.json"


def fixture(case):
    source = json.loads(CASES.read_text(encoding="utf-8"))[case]
    before, after, action, request = (copy.deepcopy(source[k]) for k in ("actual_before", "actual_after", "solver_action", "actual_request"))
    audit = after["choice_audit"]
    potion = action["Kind"] == "UsePotion"
    sid = action["PotionId"] if potion else action["CardId"]
    ending, empty = sid == "DAGGER_THROW", sid == "SCAVENGE"
    parent = audit["parent"]
    if potion:
        parent.update(potion_id=sid, potion_slot=action["PotionSlot"], potion_index=request["args"]["potion_index"])
    events = []
    for i in range(1 + action["ReplayCount"]):
        selected = [] if ending or empty or i else [{k:v for k,v in c.items() if k != "Title"} for c in action["Choice"]["Cards"]]
        raw = len(before["hand"]) if potion or ending else 0 if empty or i else 1
        events.append({"schema_version":"original-choice-return-v1", "invocation_index":i,
            "action_id":audit["action_id"], "source_id":sid, "effect":action["Choice"]["Effect"],
            "source_pile":action["Choice"]["SourcePile"], "source_method":"CardSelectCmd.FromCombatPile" if sid == "HOLOGRAM" else "CardSelectCmd.FromHand",
            "effect_callsite":{"HOLOGRAM":"Hologram.OnPlay", "SCAVENGE":"Scavenge.OnPlay", "DAGGER_THROW":"DaggerThrow.OnPlay", "TOUCH_OF_INSANITY":"TouchOfInsanity.OnUse"}[sid],
            "source_is_actual_parent_object":True, "player_id":parent["player_id"], "player_turn":action["Turn"],
            "is_over_or_ending_at_entry":ending, "is_over_or_ending_at_return":ending,
            "combat_active_at_entry":not ending, "combat_active_at_return":not ending,
            "min_select":1,"max_select":1,"require_manual_confirmation":False,
            "filter_is_null":sid in {"SCAVENGE", "DAGGER_THROW"}, "filter_reexecuted_by_observer":False,
            "raw_source_count_at_entry":raw,"raw_source_count_at_return":raw,
            "selector_invocations_before":10,"selector_invocations_after":10,
            "selector_pending_before":False,"selector_pending_after":False,
            "verified":True,"original_task_completed_successfully":True,
            "returned_cards":selected,"returned_count":len(selected),"returned_objects_match_original_source":True,
            "original_returned_collection":"CardModel[]" if ending or i else "List<CardModel>",
            "candidate_basis":"original_implementation_and_completed_return_without_selector"})
    audit["original_returns"] = events
    meta = {"type":"choice_meta", "selection":"none", "cards":[], "completion_audit":copy.deepcopy(audit)}
    call = {"request":{"cmd":"solve"},"response":{"type":"solver_result","actions":[action]}}
    traces = [{"request":{"cmd":"start_run"},"response":before}, copy.deepcopy(call),
        {"request":{"cmd":"combat_meta"},"response":source["actual_before_combat_meta"]},
        {"request":request,"response":after}, {"request":{"cmd":"choice_meta"},"response":meta}]
    return before, after, action, request, meta, call, traces


class OriginalReturnExecutorTests(unittest.TestCase):
    def execute(self, values):
        before, after, action, request, meta, call, traces = values
        requests=[]
        def query(**req):
            requests.append(req)
            self.assertEqual(req, {"cmd":"choice_meta"})
            return copy.deepcopy(meta)
        executor=CombatExecutor(query)
        executor.last_action_request=request
        executor.solve_calls=[copy.deepcopy(call)]
        self.assertTrue(executor.resolve_original_automatic_choice(before,after,action))
        self.assertEqual(requests,[{"cmd":"choice_meta"}])
        return executor.solve_calls, traces

    def test_original_mandatory_and_empty_returns_bind_offline(self):
        for case in json.loads(CASES.read_text(encoding="utf-8")):
            with self.subTest(case=case):
                calls,traces=self.execute(fixture(case))
                result=validate_replay_evidence(calls,traces)
                self.assertEqual(result["replay_count"],1)
                self.assertFalse(calls[0]["replay"][0]["selection_request_sent"])

    def test_no_audit_cannot_accept_a_card_that_merely_appeared_in_hand(self):
        values=fixture("hologram")
        values[1]["choice_audit"].pop("original_returns")
        executor=CombatExecutor(lambda **_: self.fail("no query expected"))
        self.assertFalse(executor.resolve_original_automatic_choice(values[0],values[1],values[2]))

    def test_source_fingerprint_occurrence_and_filter_tampering_rejected(self):
        mutations=[lambda e:e.update(source_id="UNKNOWN"), lambda e:e.update(source_is_actual_parent_object=False),
            lambda e:e.update(filter_reexecuted_by_observer=True), lambda e:e.update(selector_invocations_after=11),
            lambda e:e.update(selector_pending_after=True),lambda e:e.update(original_task_completed_successfully=False),
            lambda e:e["returned_cards"][0].update(StateKey="wrong"),
            lambda e:e["returned_cards"][0].update(SourceOccurrence=1),
            lambda e:e["returned_cards"][0].update(OptionOccurrence=1)]
        for mutate in mutations:
            values=fixture("touch_of_insanity")
            mutate(values[1]["choice_audit"]["original_returns"][0])
            with self.assertRaises(RuntimeError): self.execute(values)

    def test_glam_missing_extra_or_nonempty_second_return_rejected(self):
        for variant in ("missing","extra","nonempty"):
            values=fixture("hologram");events=values[1]["choice_audit"]["original_returns"]
            if variant=="missing": events.pop()
            elif variant=="extra":events.append(copy.deepcopy(events[-1]))
            else:events[-1].update(returned_cards=events[0]["returned_cards"],returned_count=1)
            with self.assertRaises(RuntimeError):self.execute(values)

    def test_wrong_potion_slot_parent_turn_and_context_rejected(self):
        for mutate in (lambda v:v[1]["choice_audit"]["parent"].update(potion_slot=0),
                       lambda v:v[1].update(player_turn=8),
                       lambda v:v[1]["context"].update(encounter_id="OTHER")):
            values=fixture("touch_of_insanity");mutate(values)
            with self.assertRaises(RuntimeError):self.execute(values)

    def test_offline_missing_unknown_and_tampered_proof_or_actual_request_rejected(self):
        calls,traces=self.execute(fixture("touch_of_insanity"))
        for variant in ("missing","unknown","token","request"):
            cs,ts=copy.deepcopy(calls),copy.deepcopy(traces)
            if variant=="missing":cs[0].pop("replay")
            elif variant=="unknown":cs[0]["replay"][0]["kind"]="invented"
            elif variant=="token":cs[0]["replay"][0]["plan"]["Cards"][0]["StateKey"]="invented"
            else:ts[3]["request"]["args"]["potion_index"]=0
            with self.assertRaises(ValueError):validate_replay_evidence(cs,ts)


if __name__=="__main__":unittest.main()
