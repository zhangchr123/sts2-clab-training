"""Whole historical solver envelopes at original public prefixes; not fresh searches."""
import copy
from pathlib import Path
import sys
import unittest
import uuid
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

ROOT_SOURCE = Path('D:/sts2-training/staging/secret-catastrophe-return/sts2-solver-bridge')


class OriginalFullPlans(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def run_plan(self, suffix, generation, card):
        batch = ROOT_SOURCE / 'outputs/defect-contextual-d8-20260914b'
        name = batch.name + '-' + suffix
        source = ROOT_SOURCE / 'outputs' / name
        audit = read_json(batch / f'generation-{generation:02d}' / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'charge-full-' + card.lower() + '-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        executor, matched, passed = None, 0, False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
            real_solve = executor.solve
            supplied = False
            def recorded_then_actual(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied: return real_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded_then_actual
            final = executor.advance(before)
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            proofs = [p for p in executor.solve_calls[0].get('replay', [])
                if p.get('kind') == 'original_choice_return_completed'
                and p['actual_choice_audit']['parent']['card_id'] == card]
            self.assertEqual(len(proofs), 1)
            self.assertFalse(proofs[0]['selection_request_sent'])
            self.assertEqual(proofs[0]['selected_cards'][0]['CardId'], 'DEFEND_DEFECT')
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            self.assertIn(final['decision'], ('card_reward', 'map_select', 'game_over'))
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='recorded_full_solver_envelope_diagnostic',
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                public_prefix_responses_verified=matched, original_source=audit['actual_source_evidence'],
                solver_calls=executor.solve_calls if executor else [], hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_original_charge_full_plan(self):
        self.run_plan('g01-c11-s13', 1, 'CHARGE')

    def test_original_empty_singleton_pair_and_manual_triple(self):
        for count in range(4):
            label = 'charge-boundary-' + str(count) + '-' + uuid.uuid4().hex[:10]
            bridge, traces, send = self.worker(label)
            passed = False
            try:
                send(cmd='start_run', character='Defect', ascension=10, seed='charge-boundary-' + str(count))
                send(cmd='set_player', hp=1000, max_hp=1000, relics=[], potions=[], deck=['CHARGE'] * (5 + count))
                before = send(cmd='enter_room', type='combat', encounter='FOGMOG_NORMAL')
                self.assertEqual(before['draw_pile_count'], count)
                meta = send(cmd='combat_meta')
                key = meta['hand'][0]['key']
                request = {'cmd':'action', 'action':'play_card', 'args':{'card_index':0}}
                after = send(request)
                event = after['choice_audit']['original_returns'][0]
                self.assertEqual(event['source_id'], 'CHARGE')
                self.assertEqual(event['raw_source_count_at_entry'], count)
                if count == 3:
                    self.assertEqual(after['decision'], 'card_select')
                    self.assertEqual(len(after['cards']), 3)
                    self.assertFalse(event['verified'])
                    self.assertFalse(event['original_task_completed_successfully'])
                    after = send(cmd='action', action='select_cards', args={'indices':'0,1'})
                    self.assertEqual(after['decision'], 'combat_play')
                else:
                    cards = [{'CardId':'CHARGE','UpgradeLevel':0,'StateKey':key,
                        'SourceOccurrence':i,'OptionOccurrence':i} for i in range(count)]
                    plan = {'Effect':'Transform','SourcePile':'Draw','SourceId':'','ContextId':'','Timing':'Action','Cards':cards}
                    action = {'Kind':'PlayCard','CardId':'CHARGE','CardStateKey':key,'CardStateOccurrence':0,
                        'Turn':before['player_turn'],'Choice':plan,'NestedChoices':[], 'NestedChoicesBeforePrimary':0,
                        'ReplayCount':0, 'EndsPlayerTurn':False, 'TargetIndex':-1}
                    observer = CombatExecutor(send)
                    observer.last_action_request = request
                    observer.solve_calls = [{'request':{'cmd':'solve'}, 'response':{'type':'solver_result','actions':[action]}}]
                    self.assertTrue(observer.resolve_original_automatic_choice(before, after, action))
                    self.assertEqual(observer.solve_calls[0]['replay'][0]['selected_cards'], cards)
                    synthetic = [{'request':{'cmd':'start_run'},'response':before},
                        copy.deepcopy(observer.solve_calls[0]), {'request':{'cmd':'combat_meta'},'response':meta},
                        {'request':request,'response':after}, traces[-1]]
                    synthetic[1].pop('replay',None)
                    self.assertTrue(validate_replay_evidence(observer.solve_calls, synthetic)['verified'])
                    for field,value in [('original_task_completed_successfully',False),('source_is_actual_parent_object',False),
                            ('min_select',1),('max_select',1),('filter_is_null',True),('selector_invocations_after',-1),
                            ('selector_pending_after',True),('raw_source_count_at_return',count+1)]:
                        bad = copy.deepcopy(after)
                        bad['choice_audit']['original_returns'][0][field] = value
                        with self.subTest(count=count,field=field), self.assertRaises(RuntimeError):
                            observer.resolve_original_automatic_choice(before,bad,action)
                    for index in range(count):
                        for field in ('CardId','StateKey','SourceOccurrence','OptionOccurrence','UpgradeLevel'):
                            bad = copy.deepcopy(after)
                            token = bad['choice_audit']['original_returns'][0]['returned_cards'][index]
                            token[field] = token[field]+1 if type(token[field]) is int else 'UNRELATED'
                            with self.assertRaises(RuntimeError):observer.resolve_original_automatic_choice(before,bad,action)
                    for mutation in ('missing','selected','submitted'):
                        bad = copy.deepcopy(observer.solve_calls)
                        if mutation == 'missing':bad[0]['replay']=[]
                        elif mutation == 'selected':bad[0]['replay'][0]['selected_cards']=[{'CardId':'UNRELATED'}]
                        else:bad[0]['replay'][0]['selection_request_sent']=True
                        with self.assertRaises(ValueError):validate_replay_evidence(bad,synthetic)
                passed = True
            finally:
                self.save(label,traces,passed=passed,origin='synthetic_mandatory_draw_pile_boundary',raw_draw_cards=count,
                    hidden_state_or_rng_equality_claimed=False)
                bridge.close()


if __name__ == '__main__': unittest.main()
