"""Synthetic registered artifacts and public states only; never starts a worker."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from decision_data import DataContractError, enumerate_candidates
from initial_policy import InitialPolicy, POLICY_VERSION
from interaction_features import FEATURE_NAMES, extend_scoring_packet
from prefix_health_policy import PrefixHealthPolicy, VERSION
from prefix_interventions import VERSION as PROTOCOL_VERSION
from run_metadata import file_evidence
from test_prefix_interventions import state
from train_prefix_ranker import FEATURE_SOURCES, LEARNER, VERSION as MODEL_FORMAT, candidate_features, predict


CONFIG = {"solver_backend": "coordinator", "first_budget_ms": 2500,
          "search_profile": {"beam_width": 30, "max_nodes": 5000}}
FACTS = {"version": "synthetic-prefix-facts-v1", "engine_sha256": "a" * 64,
         "registry_sha256": "b" * 64, "coverage": "synthetic fixture, not engine evidence"}


class Draw:
    def __init__(self, coin, index):
        self.coin, self.index = coin, index
        self.pool_sizes = []

    def random(self):
        return self.coin

    def choice(self, rows):
        self.pool_sizes.append(len(rows))
        return rows[self.index]


class PrefixHealthPolicyTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.directory = Path(temp.name)
        for name in ("initial_policy.verified_source", "interaction_features.verified_source"):
            mocked = patch(name, side_effect=lambda *args: copy.deepcopy(FACTS))
            mocked.start()
            self.addCleanup(mocked.stop)

    def write(self, path, data):
        path.write_text(json.dumps(data, allow_nan=False, indent=2), encoding="utf-8")

    def fixture(self, weights=None):
        """Fake values, real validators; no call to fit or a game engine."""
        root = Path(__file__).resolve().parent
        current = state()
        fallback = InitialPolicy()
        candidates = enumerate_candidates(current)["candidates"]
        self.gate = {"gate_id": "synthetic", "seed": "synthetic", "state": current,
                     "candidates": candidates, "source_solver_config": copy.deepcopy(CONFIG)}
        protocol = {"schema_version": PROTOCOL_VERSION, "character": "Defect", "ascension": 10,
            "planned_learner": copy.deepcopy(LEARNER), "provenance": "same_seed_action_prefix_intervention",
            "natural_training_eligible": False, "llm_involved": False, "full_state_equality_verified": False,
            "rng_equality_verified": False, "prospective_A10_win_rate_sample": False,
            "horizon": "first_actual_next_combat_end_under_frozen_rule_suffix",
            "gates": [self.gate], "frozen_sources": [{"fixture": "synthetic-only-no-engine"}]}
        self.protocol_path = self.directory / "protocol.json"
        self.audit_path = self.directory / "TRAINING_AUDIT.json"
        self.model_path = self.directory / "model.json"
        self.receipt_path = self.directory / "training-fit-receipt.json"
        self.write(self.protocol_path, protocol)
        self.write(self.audit_path, {"passed": True, "fixture": "synthetic-only-no-training"})
        self.model_data = {"format": MODEL_FORMAT, "planned_learner": copy.deepcopy(LEARNER),
            "target_semantics": LEARNER["target"], "feature_names": list(FEATURE_NAMES),
            "means": [0.] * len(FEATURE_NAMES), "scales": [1.] * len(FEATURE_NAMES),
            "weights": [0.] + [(weights or {}).get(n, 0.) for n in FEATURE_NAMES],
            "feature_min": [-10.] * len(FEATURE_NAMES), "feature_max": [10.] * len(FEATURE_NAMES),
            "fit_count": 1, "calibrated_probability": False, "A10_victory_model": False,
            "automatic_deployment": False, "natural_run_training": False,
            "exact_state_or_rng_clone": False, "test_used_for_fit_or_tuning": False,
            "feature_sources": {name: file_evidence(root / name) for name in FEATURE_SOURCES},
            "prior_source": fallback.prior.source, "mechanism_facts": fallback.mechanism_source,
            "feature_transform": extend_scoring_packet(current, fallback.score(current))["interaction_feature_source"],
            "source_protocol": file_evidence(self.protocol_path),
            "runtime_and_collection_sources": protocol["frozen_sources"],
            "training_audit": file_evidence(self.audit_path)}
        self.register()

    def register(self):
        self.write(self.model_path, self.model_data)
        self.receipt = {"schema_version": MODEL_FORMAT + ":fit-receipt-v1", "status": "fit_completed",
            "source_protocol": file_evidence(self.protocol_path), "training_audit": file_evidence(self.audit_path),
            "model_output": str(self.model_path), "planned_learner": copy.deepcopy(LEARNER),
            "model": file_evidence(self.model_path)}
        self.write(self.receipt_path, self.receipt)

    def load(self, **kwargs):
        return PrefixHealthPolicy(self.model_path, protocol_path=self.protocol_path,
                                  solver_config=copy.deepcopy(CONFIG), **kwargs)

    def test_scoring_repeats_without_rng_scope_or_state_mutation_and_uses_trainer_delta(self):
        self.fixture({"action_select_card_reward": .25, "is_skip": -.1})
        policy = self.load(seed="synthetic-rng")
        current = state()
        before, rng, identity = copy.deepcopy(current), policy.rng.getstate(), policy.provenance
        first, second = policy.score(current), policy.score(current)
        self.assertEqual(first, second)
        self.assertEqual(current, before)
        self.assertEqual(policy.rng.getstate(), rng)
        self.assertIsNone(policy.gate_use)
        self.assertEqual(policy.choice_count, 0)
        self.assertEqual(policy.provenance, identity)
        expected = candidate_features(self.gate)
        for row in first["scores"]:
            self.assertEqual(row["model_features"], expected[row["candidate_id"]]["features"])
            self.assertEqual(row["score"], predict(policy.model, row["model_features"]))
            self.assertEqual(row["delta_from_skip"], row["score"])
            self.assertEqual(row["reasons"][0]["source"], MODEL_FORMAT)
            self.assertEqual(len(row["model_features"]), 119)
        self.assertEqual(next(r["score"] for r in first["scores"] if r["is_skip"]), 0)
        self.assertFalse(first["calibrated"])
        self.assertFalse(first["model"]["A10_victory_model"])
        self.assertIn("next_combat_HP_difference", first["score_semantics"])

    def test_first_choose_only_consumes_scope_after_success_then_exact_v3_fallback(self):
        self.fixture({"action_select_card_reward": 2})
        policy = self.load(epsilon=0)
        identity = policy.provenance
        first = policy.choose(state())
        self.assertTrue(first["scoring"]["model"]["active"])
        self.assertEqual(first["request"]["action"], "select_card_reward")
        self.assertTrue(first["scope_transition"]["consumed_first_eligible_gate"])
        self.assertFalse(policy.gate_use["engine_execution_verified"])
        second = policy.choose(state(floor=3))
        rule = InitialPolicy().score(state(floor=3))
        self.assertFalse(second["scoring"]["model"]["active"])
        self.assertEqual(second["scoring"]["scores"], rule["scores"])
        self.assertEqual(second["scoring"]["score_semantics"], rule["score_semantics"])
        self.assertEqual(second["scoring"]["effective_scorer"], POLICY_VERSION)
        self.assertEqual(policy.choice_count, 2)
        self.assertEqual(policy.provenance, identity)
        self.assertEqual(first["policy_provenance"]["id"], VERSION)
        # Returned evidence is a copy, never a handle that can reopen scope.
        policy.gate_use.clear()
        policy.model["weights"][0] = 12
        self.assertIsNotNone(policy.gate_use)
        self.assertEqual(policy.model["weights"][0], 0)

    def test_non_target_choices_do_not_consume_gate_or_call_model(self):
        self.fixture()
        policy = self.load()
        cases = []
        for decision in ("event_choice", "rest_site"):
            current = state(decision)
            current["context"]["room_type"] = "Event" if decision == "event_choice" else "RestSite"
            current["options"] = [{"index": 0, "is_locked": False, "is_enabled": True, "id": "REST"}]
            cases.append(current)
        for name, value in (("room_type", "Event"), ("room_type", "Boss"), ("act", 2), ("floor", 9)):
            current = state()
            current["context"][name] = value
            cases.append(current)
        with patch("prefix_health_policy.predict", side_effect=AssertionError("inactive predictor called")):
            for current in cases:
                picked = policy.choose(current)
                self.assertFalse(picked["scoring"]["model"]["active"])
                self.assertEqual(picked["scoring"]["scores"], InitialPolicy().score(current)["scores"])
                self.assertIsNone(policy.gate_use)
        self.assertTrue(policy.choose(state())["scoring"]["model"]["active"])

    def test_partial_requests_include_skip_only_as_reference_not_claimed_coverage(self):
        self.fixture({"action_select_card_reward": 1})
        policy = self.load()
        request = self.gate["candidates"][0]["request"]
        packet = policy.score_requests(state(), [request])
        self.assertEqual(len(packet["scores"]), 1)
        self.assertEqual(packet["candidate_count"], 2)
        self.assertFalse(packet["evaluated_candidates_complete"])
        self.assertEqual(packet["scores"][0]["request"], request)
        self.assertIsNone(policy.gate_use)

    def test_failed_prediction_does_not_consume_first_gate_or_randomness(self):
        self.fixture()
        policy = self.load()
        before = policy.rng.getstate()
        with patch("prefix_health_policy.predict", return_value=float("nan")):
            with self.assertRaises(ValueError):
                policy.choose(state())
        self.assertEqual(policy.rng.getstate(), before)
        self.assertEqual(policy.choice_count, 0)
        self.assertIsNone(policy.gate_use)
        self.assertTrue(policy.choose(state())["scoring"]["model"]["active"])

    def test_near_zero_allowed_means_use_actual_predicted_skip_reference(self):
        self.fixture({"action_select_card_reward": 1e6})
        self.model_data["means"][FEATURE_NAMES.index("action_select_card_reward")] = 5e-13
        self.model_data["weights"][0] = 5e-9
        self.register()
        policy = self.load()
        packet = policy.score(state())
        expected_skip = predict(policy.model, {name: 0. for name in FEATURE_NAMES})
        self.assertNotEqual(expected_skip, policy.model["weights"][0])
        for row in packet["scores"]:
            self.assertEqual(row["model_reference_score"], expected_skip)
            self.assertEqual(row["delta_from_skip"], row["score"] - expected_skip)
        self.assertEqual(next(r["delta_from_skip"] for r in packet["scores"] if r["is_skip"]), 0.)

    def test_invalid_requests_candidates_or_scope_do_not_consume_rng_or_gate(self):
        self.fixture()
        policy = self.load()
        current = state()
        original_rng = policy.rng.getstate()
        candidates = enumerate_candidates(current)
        candidates["candidates"].pop()
        tests = [lambda: policy.choose(current, candidates),
                 lambda: policy.score_requests(current, [{"cmd": "action", "action": "select_card_reward",
                                                        "args": {"card_index": 999}}]),
                 lambda: policy.score_requests(current, [self.gate["candidates"][0]["request"]] * 2),
                 lambda: policy.choose(current, selection_purpose="acquire")]
        for field, value in (("integrity_recovery_used", True), ("combat_in_progress", True), ("ascension", 9)):
            invalid = copy.deepcopy(current)
            invalid["context"][field] = value
            tests.append(lambda invalid=invalid: policy.choose(invalid))
        no_skip = copy.deepcopy(current)
        no_skip["can_skip"] = False
        tests.append(lambda: policy.choose(no_skip))
        for invoke in tests:
            with self.assertRaises(ValueError):
                invoke()
        self.assertEqual(policy.rng.getstate(), original_rng)
        self.assertIsNone(policy.gate_use)
        self.assertEqual(policy.choice_count, 0)

    def test_epsilon_probability_ties_and_base_rng_stream_match(self):
        self.fixture({"action_select_card_reward": 1})
        policy = self.load(epsilon=.2)
        policy.rng = Draw(.1, 1)
        picked = policy.choose(state())
        self.assertEqual(picked["request"]["action"], "skip_card_reward")
        self.assertAlmostEqual(picked["exploration"]["chosen_probability"], .1)
        self.assertEqual(policy.rng.pool_sizes, [2])
        self.fixture()
        policy = self.load(epsilon=.2)
        policy.rng = Draw(.9, 1)
        picked = policy.choose(state())
        self.assertEqual(picked["exploration"]["greedy_tie_count"], 2)
        self.assertEqual(picked["exploration"]["chosen_probability"], .5)
        # Non-target choices have identical rule scores AND the original RNG
        # draws/counters; model loading and score previews consume neither.
        policy, rule = self.load(epsilon=.3, seed="same"), InitialPolicy(epsilon=.3, random_seed="same")
        current = state(floor=9)
        for _ in range(8):
            actual, expected = policy.choose(current), rule.choose(current)
            self.assertEqual(actual["request"], expected["request"])
            for key, value in expected["exploration"].items():
                self.assertEqual(actual["exploration"][key], value)
        self.assertEqual(policy.rng.getstate(), rule.rng.getstate())

    def test_unregistered_or_tampered_fit_source_is_rejected(self):
        for field, value in (("status", "fit_started"), ("model", {"sha256": "0" * 64}),
                             ("model_output", "unregistered-model.json"), ("source_protocol", {}),
                             ("training_audit", {}), ("schema_version", "other-fit")):
            self.fixture()
            self.receipt[field] = value
            self.write(self.receipt_path, self.receipt)
            with self.assertRaises(ValueError, msg=field):
                self.load()
        self.fixture()
        self.model_data["weights"][1] = 77
        self.write(self.model_path, self.model_data)  # matching format is not a registered SHA
        with self.assertRaises(ValueError):
            self.load()

    def test_illegal_model_origin_feature_source_solver_and_live_drift_rejected(self):
        for field, value in (("natural_run_training", True), ("A10_victory_model", True),
                             ("format", "defect-act1-survival-ridge-v1"), ("feature_sources", {}),
                             ("mechanism_facts", {}), ("prior_source", {})):
            self.fixture()
            self.model_data[field] = value
            self.register()  # even a matching receipt cannot authorize wrong semantics/source
            with self.assertRaises(ValueError, msg=field):
                self.load()
        self.fixture()
        with self.assertRaises(ValueError):
            PrefixHealthPolicy(self.model_path, protocol_path=self.protocol_path,
                               solver_config={**CONFIG, "first_budget_ms": 999})
        policy = self.load()
        self.receipt["status"] = "fit_started"
        self.write(self.receipt_path, self.receipt)
        with self.assertRaises(ValueError):
            policy.score(state())
        self.register()
        policy = self.load()
        policy.fallback.origin = "llm_assisted"
        with self.assertRaises(ValueError):
            policy.score(state())

    def test_matching_receipt_does_not_authorize_llm_or_natural_collection_source(self):
        for field, value in (("llm_involved", True), ("natural_training_eligible", True),
                             ("provenance", "natural_run"), ("character", "Ironclad")):
            self.fixture()
            protocol = json.loads(self.protocol_path.read_text(encoding="utf-8"))
            protocol[field] = value
            self.write(self.protocol_path, protocol)
            self.model_data["source_protocol"] = file_evidence(self.protocol_path)
            self.register()
            with self.assertRaises(ValueError, msg=field):
                self.load()


if __name__ == "__main__":
    unittest.main()
