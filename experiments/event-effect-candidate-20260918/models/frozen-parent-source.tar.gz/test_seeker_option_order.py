"""Original historical prefix plus explicitly synthetic single-action replay envelope."""
import copy
import json
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence
from run_metadata import file_evidence


class SeekerOptionOrderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root = Path('C:/Users/zhangchr/Documents/code/sts2-solver-bridge')
        batch = root / 'outputs/defect-contextual-parallel-20260914a'
        name = batch.name + '-g03-c00-s16'
        source = root / 'outputs' / name
        original = read_json(batch / 'generation-03' / (name + '-audit.json'))
        assert original['audit_passed'] and unchanged(original['actual_source_evidence'])
        rows = read_lines(source / 'trace.jsonl')
        historical = next(r for r in reversed(rows) if r['request']['cmd'] == 'solve')
        cls.action = next(a for a in historical['response']['actions'] if (a.get('Choice') or {}).get('ContextId', '').startswith('seeker:173:'))
        gate = max(i for i, r in enumerate(rows) if r['request']['cmd'] == 'action')
        cls.plan = copy.deepcopy(cls.action['Choice'])
        call = copy.deepcopy(historical)
        call['response']['actions'] = [copy.deepcopy(cls.action)]
        call['response']['turn_setup_choices'] = []
        label = 'seeker-option-order-' + uuid.uuid4().hex[:12]
        bridge = Bridge(label)
        cls.addClassCleanup(bridge.close)
        traces, calls = [], []
        def send(**request):
            response = bridge.send(**request)
            traces.append({'request': copy.deepcopy(request), 'response': copy.deepcopy(response)})
            assert response.get('type') != 'error', response
            return response
        matched = 0
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                state = send(**row['request'])
                assert checked_public(state) == checked_public(row['response']), matched
                matched += 1
            # This packet is a declared single-action contract, not a new search.
            traces.append(copy.deepcopy(call))
            send(cmd='combat_meta')
            pending = send(**rows[gate]['request'])
            assert checked_public(pending) == checked_public(rows[gate]['response'])
            matched += 1
            cls.pending = copy.deepcopy(pending)
            cls.query = len(traces)
            executor = CombatExecutor(send)
            executor.solve_calls = [call]
            after = executor.resolve(pending, [cls.plan])
            calls.extend(executor.solve_calls)
            cls.meta = copy.deepcopy(traces[cls.query]['response'])
            cls.after = copy.deepcopy(after)
            cls.selection = copy.deepcopy(traces[cls.query + 1]['request'])
            assert validate_replay_evidence(calls, traces)['verified']
            cls.mapping_calls, cls.mapping_traces = copy.deepcopy((calls, traces))
            post = send(cmd='combat_meta')
            cls.post_meta = copy.deepcopy(post)
            stale = send(cmd='choice_meta')
            assert 'seeker_choice' not in stale, stale
            manifest = read_json(source / 'manifest.json')
            fresh = CombatExecutor(send, manifest['solver_requested_config'])
            final = fresh.advance(after)
            calls.extend(fresh.solve_calls)
            cls.fresh_calls = copy.deepcopy(fresh.solve_calls)
            cls.final = copy.deepcopy(final)
            assert cls.fresh_calls and validate_replay_evidence(calls, traces)['verified']
            assert unchanged(original['actual_source_evidence'])
            cls.matched = matched
        finally:
            with (ROOT / 'outputs' / (label + '.json')).open('x', encoding='utf-8') as handle:
                json.dump({'training_eligible': False, 'natural_win_rate_sample': False,
                    'synthetic_single_action_envelope': call, 'original_solver_response': historical['response'],
                    'fresh_continuation_uses_original_solver': True, 'original_training_result_modified': False,
                    'hidden_state_or_rng_equality_claimed': False, 'public_prefix_responses_verified': matched,
                    'original_sources': original['actual_source_evidence'],
                    'cli': file_evidence(ROOT.parent / 'sts2-cli/src/Sts2Headless/bin/Debug/net9.0/Sts2Headless.dll'),
                    'host': file_evidence(ROOT / 'runtime/host/bin/Debug/net9.0/SolverBridge.dll'),
                    'traces': traces, 'solver_calls': calls}, handle, indent=2)

    def test_original_sample_is_mapped_to_same_cost_one_card_and_solver_continues(self):
        self.assertEqual(self.matched, 425)
        self.assertEqual(self.selection, {'cmd': 'action', 'action': 'select_cards', 'args': {'indices': '1'}})
        with self.assertRaises(RuntimeError):
            CombatExecutor.card_choice_indices(self.plan, self.meta['cards'])
        data = self.meta['seeker_choice']
        self.assertEqual([c['ui_index'] for c in data['sample_cards']], [2, 1, 0])
        self.assertEqual(data['sample_cards'][1]['SourceOccurrence'], 0)
        self.assertEqual(data['sample_cards'][1]['OptionOccurrence'], 1)
        self.assertEqual(data['sample_cards'][1]['StateKey'], self.plan['Cards'][0]['StateKey'])
        self.assertTrue(any(c['key'] == self.plan['Cards'][0]['StateKey'] for c in self.post_meta['hand']))
        self.assertEqual(self.after['decision'], 'combat_play')
        self.assertGreater(len(self.fresh_calls), 0)
        self.assertIn(self.final['decision'], ('card_reward', 'map_select', 'game_over'))

    def test_missing_stale_source_task_filter_and_counter_evidence_rejected(self):
        data = self.meta['seeker_choice']
        for key, value in data.items():
            for missing in (False, True):
                with self.subTest(key=key, missing=missing):
                    meta = copy.deepcopy(self.meta)
                    if missing: del meta['seeker_choice'][key]
                    else:
                        meta['seeker_choice'][key] = not value if type(value) is bool else value + 1 if type(value) is int else [] if isinstance(value, list) else 'wrong'
                    with self.assertRaises(RuntimeError):
                        CombatExecutor.seeker_choice_indices(self.pending, self.plan, meta)
        for variant in ('missing', 'extra', 'parent', 'capture'):
            meta = copy.deepcopy(self.meta)
            if variant == 'missing': del meta['seeker_choice']
            elif variant == 'extra': meta['seeker_choice']['unknown'] = True
            elif variant == 'parent': meta['completion_audit']['parent']['card_key'] = 'wrong'
            else: meta['completion_audit']['action_id'] += 1
            with self.subTest(variant=variant), self.assertRaises(RuntimeError):
                CombatExecutor.seeker_choice_indices(self.pending, self.plan, meta)

    def test_both_occurrences_and_full_state_must_identify_sampled_original_object(self):
        for key in ('StateKey', 'SourceOccurrence', 'OptionOccurrence', 'UpgradeLevel', 'CardId'):
            plan = copy.deepcopy(self.plan)
            value = plan['Cards'][0][key]
            plan['Cards'][0][key] = value + 1 if type(value) is int else 'wrong'
            with self.subTest(key=key), self.assertRaises(RuntimeError):
                CombatExecutor.seeker_choice_indices(self.pending, plan, self.meta)
        for key in self.meta['seeker_choice']['sample_cards'][1]:
            meta = copy.deepcopy(self.meta)
            value = meta['seeker_choice']['sample_cards'][1][key]
            meta['seeker_choice']['sample_cards'][1][key] = value + 1 if type(value) is int else 'wrong'
            with self.subTest(sample_key=key), self.assertRaises(RuntimeError):
                CombatExecutor.seeker_choice_indices(self.pending, self.plan, meta)

    def test_identical_state_keys_still_use_both_original_occurrences(self):
        # Pure contract fixture: make the two actual sample identities share a key.
        meta = copy.deepcopy(self.meta)
        data = meta['seeker_choice']
        a, b = data['sample_cards'][:2]
        data['source_cards'][a['source_index']]['StateKey'] = b['StateKey']
        a['StateKey'] = b['StateKey']
        meta['cards'][a['ui_index']]['key'] = b['StateKey']
        self.assertEqual(CombatExecutor.seeker_choice_indices(self.pending, self.plan, meta), [1])
        other = copy.deepcopy(self.plan)
        other['Cards'][0].update(SourceOccurrence=a['SourceOccurrence'], OptionOccurrence=a['OptionOccurrence'])
        self.assertEqual(CombatExecutor.seeker_choice_indices(self.pending, other, meta), [2])

    def test_offline_omissions_wrong_indices_and_unbound_parent_rejected(self):
        for variant in ('missing', 'duplicate', 'extra', 'wrong_index', 'source', 'plan', 'parent', 'metadata_missing'):
            calls, traces = copy.deepcopy((self.mapping_calls, self.mapping_traces))
            proof = calls[0]['replay'][0]
            if variant == 'missing': calls[0]['replay'] = []
            elif variant == 'duplicate': calls[0]['replay'].append(copy.deepcopy(proof))
            elif variant == 'extra': proof['claimed'] = True
            elif variant == 'wrong_index': traces[self.query + 1]['request']['args']['indices'] = '2'
            elif variant == 'source': proof['actual_choice_metadata']['seeker_choice']['source_is_original_card_object'] = False
            elif variant == 'plan': proof['plan']['Cards'][0]['SourceOccurrence'] = 1
            elif variant == 'parent': traces[self.query - 1]['request']['args']['card_index'] = -1
            elif variant == 'metadata_missing': del traces[self.query]['response']['seeker_choice']
            with self.subTest(variant=variant), self.assertRaises(ValueError):
                validate_replay_evidence(calls, traces)

    def test_real_invalid_action_invalidates_pending_mapping_without_resolving_choice(self):
        source = Path('C:/Users/zhangchr/Documents/code/sts2-solver-bridge/outputs/defect-contextual-parallel-20260914a-g03-c00-s16')
        rows = read_lines(source / 'trace.jsonl')
        bridge = Bridge('seeker-stale-' + uuid.uuid4().hex[:12])
        self.addCleanup(bridge.close)
        for row in rows[:-1]:
            if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
            state = bridge.send(**row['request'])
            self.assertEqual(checked_public(state), checked_public(row['response']))
        self.assertIsNotNone(bridge.send(cmd='choice_meta').get('seeker_choice'))
        failed = bridge.send(cmd='action', action='play_card', args={'card_index': -1})
        self.assertEqual(failed.get('type'), 'error')
        meta = bridge.send(cmd='choice_meta')
        self.assertEqual(meta['selection'], 'card_select')
        self.assertNotIn('seeker_choice', meta)
        with self.assertRaises(RuntimeError):
            CombatExecutor.seeker_choice_indices(state, self.plan, meta)


if __name__ == '__main__': unittest.main()
