"""One isolated controller session; combat actions always come from CombatSolver."""
import argparse
import json
import os
from pathlib import Path
import re
import time
import traceback

from probe import Bridge, ROOT
from combat_executor import CombatExecutor, solver_config
from decision_data import DecisionJournal
from run_metadata import atomic_json, metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-name", required=True)
    parser.add_argument("--seed", default="handoff-defect-1")
    parser.add_argument("--ascension", type=int, default=10, choices=range(11))
    parser.add_argument("--solver-config", type=Path)
    parser.add_argument("--resume", action="store_true")
    config = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", config.run_name):
        parser.error("Invalid run name")
    if config.resume:
        parser.error("Automatic resume is disabled: no verified exact branch restoration")
    out = ROOT / "outputs" / config.run_name
    if out.exists():
        parser.error("Run directory already exists; choose a new name")
    policy = {"origin": "debug", "kind": "human", "id": "external_controller",
              "version": "1", "llm_involved": False}
    settings = solver_config(config.solver_config)
    out.mkdir(parents=True)
    manifest = metadata(config.run_name, config.seed, config.ascension, settings, policy)
    atomic_json(out / "manifest.json", manifest)
    journal = DecisionJournal(out, manifest)
    start = time.monotonic()
    calls = 0
    state = {"type": "initializing"}
    bridge = None
    pending = None
    termination = "stopped"
    failure = None
    trace = (out / "trace.jsonl").open("x", encoding="utf-8")

    def send(**request):
        nonlocal calls
        before = time.monotonic()
        calls += int(request["cmd"] == "solve")
        try:
            response = bridge.send(**request)
        except Exception as exc:
            trace.write(json.dumps({"elapsed": time.monotonic() - start, "request": request,
                "response": None, "transport_error": repr(exc), "seconds": time.monotonic() - before}) + "\n")
            trace.flush()
            raise
        trace.write(json.dumps({"elapsed": time.monotonic() - start, "request": request,
            "response": response, "seconds": time.monotonic() - before}, ensure_ascii=False) + "\n")
        trace.flush()
        return response

    def publish(value, status="waiting"):
        atomic_json(out / "state.json", value)
        atomic_json(out / "status.json", {"status": status, "pid": os.getpid(),
            "seed": config.seed, "ascension": config.ascension, "elapsed": time.monotonic() - start,
            "solver_calls": calls, "decision": value.get("decision"), "context": value.get("context")})

    executor = CombatExecutor(send, settings, lambda value: publish(value, "combat"))
    try:
        bridge = Bridge(config.run_name)
        state = send(cmd="start_run", character="Defect", ascension=config.ascension, seed=config.seed)
        while True:
            state = executor.advance(state)
            if pending:
                journal.complete(pending, state, solver_calls=executor.solve_calls)
                pending = None
            if state.get("type") == "error":
                raise RuntimeError(json.dumps(state))
            if state.get("decision") == "game_over":
                termination = "engine_terminal"
                break
            publish(state)
            request_file = out / "command.json"
            while not request_file.exists():
                time.sleep(.15)
            request = json.loads(request_file.read_text(encoding="utf-8-sig"))
            request_file.unlink()
            if request.get("cmd") == "stop":
                break
            if request.get("cmd") == "get_map":
                atomic_json(out / "map.json", send(**request))
                continue
            if request.get("cmd") != "action":
                raise ValueError("Controller permits action/get_map/stop only")
            pending = journal.begin(state, request, policy=policy)
            publish(state, "combat")
            state = send(**request)
        publish(state, "finished")
    except Exception:
        failure = {"kind": "environment_error", "traceback": traceback.format_exc()}
        state = getattr(executor, "last_state", None) or state
        termination = "environment_error"
        (out / "error.txt").write_text(failure["traceback"], encoding="utf-8")
        if pending:
            journal.complete(pending, state, solver_calls=executor.solve_calls, environment_error=failure)
            pending = None
        publish(state, "blocked")
        request_file = out / "command.json"
        while True:
            if request_file.exists():
                request = json.loads(request_file.read_text(encoding="utf-8-sig"))
                request_file.unlink()
                if request.get("cmd") == "stop":
                    break
            time.sleep(.2)
        publish(state, "finished")
    finally:
        journal.finalize(state, termination=termination, environment_error=failure)
        if bridge:
            bridge.close()
        trace.close()


if __name__ == "__main__":
    main()

