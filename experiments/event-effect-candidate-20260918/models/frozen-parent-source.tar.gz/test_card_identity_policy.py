"""Identity learning contracts, sampler integration and raw evidence rejection."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import card_identity_features as features
import card_identity_policy as identity
import contextual_policy as original
from card_identity_vocabulary import CARD_IDS, COVERAGE_SOURCE
from decision_data import DataContractError
from initial_policy import InitialPolicy
from run_metadata import file_evidence
from sample_runs import build_policy
import sample_runs
from selection_policy import SelectionPolicy
from test_initial_policy import card, state
from test_selection_policy import selection_state
from audit_batch import _Audit
from whole_run_audit import validate_whole_run_choices


class CardIdentityTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.config = json.loads((identity.ROOT/'configs/defect-v3-base.json').read_text(encoding='utf-8'))

    def model(self, parameters, label, module=identity):
        artifact = module.make_artifact(parameters,self.config,training={'synthetic_test_only':True})
        p = self.root/(label+'.json')
        p.write_text(json.dumps(artifact),encoding='utf-8')
        cls = identity.CardIdentityPolicy if module is identity else original.ContextualPolicy
        return SelectionPolicy(cls(p,solver_config=self.config,seed='identity-test',epsilon=.31),max_evaluations=256)

    def test_vocabulary_covers_every_training_offer_without_outcome_filter(self):
        self.assertEqual(file_evidence(COVERAGE_SOURCE['path']),COVERAGE_SOURCE)
        coverage = json.loads(Path(COVERAGE_SOURCE['path']).read_text(encoding='utf-8'))
        self.assertFalse(coverage['reserved_evaluation_read'])
        self.assertEqual(coverage['run_count'],96)
        self.assertEqual(CARD_IDS,tuple(sorted(coverage['cards'])))
        self.assertEqual(len(identity.PARAMETERS),227)
        for item in coverage['identical_vector_pairs_in_same_decision']:
            a,b = item['cards']
            self.assertNotEqual(features.ID_PARAMETERS[a],features.ID_PARAMETERS[b])

    def test_nonzero_original_weights_zero_extension_preserves_all_scores_and_rng(self):
        weights = {name:(i % 13 - 6)/3 for i,name in enumerate(original.PARAMETERS)}
        old = self.model(weights,'old',original)
        new = self.model(features.zero_extend(weights),'new')
        for act in (1,2,3):
            # Every vocabulary identity, multiple duplicate/upgrade/cost states.
            for start in range(0,len(CARD_IDS),3):
                current = state([card(cid,cost=i,current_upgrade_level=i%2)
                    for i,cid in enumerate(CARD_IDS[start:start+3])])
                current['context']['act'] = act
                a,b = old.choose(current),new.choose(current)
                self.assertEqual(a['request'],b['request'])
                self.assertEqual(a['exploration'],b['exploration'])
                self.assertEqual([r['score'] for r in a['scoring']['scores']],
                                 [r['score'] for r in b['scoring']['scores']])

    def test_different_identical_legacy_vectors_can_learn_independent_ranking(self):
        current = state([card('CLAW',damage=3,cost=0),card('SWEEPING_BEAM',damage=6,cost=1)])
        current['context']['act']=1
        base = dict.fromkeys(identity.PARAMETERS,0.)
        zero = self.model(base,'zero').score(current)
        a,b = zero['scores'][:2]
        self.assertEqual({k:a['search_features'][k] for k in original.PARAMETERS},
                         {k:b['search_features'][k] for k in original.PARAMETERS})
        for cid,index in [('CLAW',0),('SWEEPING_BEAM',1)]:
            params=dict(base);params[features.ID_PARAMETERS[cid]]=4.
            scored=self.model(params,cid).score(current)
            for i,(before,after) in enumerate(zip(zero['scores'],scored['scores'])):
                self.assertEqual(after['score']-before['score'],4. if i==index else 0.)

    def test_cost_shop_gold_upgrade_and_unknown_boundaries(self):
        def f(action,**item):
            row={'request':{'action':action}}
            return features.features(row,{'request':row['request'],'evidence':{'id':'CARD.CLAW',**item}})
        self.assertEqual(f('buy_card',cost=150,card_cost=2,current_upgrade_level=2)['card_actual_cost'],.2)
        self.assertEqual(f('buy_card',cost=150)['card_cost_unknown'],1.)
        self.assertEqual(f('select_card_reward',cost=3,current_upgrade_level=2)['card_upgrade_level'],.5)
        for invalid in (-1,None,True,float('nan'),float('inf')):
            with self.subTest(value=invalid):
                self.assertEqual(f('select_card_reward',cost=invalid)['card_cost_unknown'],1.)
        row={'request':{'action':'select_card_reward'}}
        v=features.features(row,{'request':row['request'],'evidence':{'id':'CARD.FUTURE_CARD','cost':1}})
        self.assertEqual(v['card_identity_unknown'],1.)
        self.assertEqual(v['card_upgrade_unknown'],1.)
        with self.assertRaises(DataContractError):
            features.features(row,{'request':{'action':'buy_card'},'evidence':{}})

    def test_no_identity_adjustment_for_ordered_nonacquisition_selection(self):
        current=selection_state(n=7,minimum=3,maximum=3)
        current['context'].update(act=2,ascension=10,combat_in_progress=False)
        params=features.zero_extend(dict.fromkeys(original.PARAMETERS,0.))
        params.update(dict.fromkeys(features.PARAMETERS,4.))
        policy=self.model(params,'selection')
        packet=policy.base.score(current,selection_purpose='remove')
        self.assertEqual(len(packet['scores']),210)
        self.assertTrue(all(row['learned_residual']==0 for row in packet['scores']))

    def test_artifact_source_and_parameter_tampering_rejected(self):
        params=dict.fromkeys(identity.PARAMETERS,0.)
        policy=self.model(params,'sources')
        current=state();current['context']['act']=1
        original_sources=identity.feature_sources()
        for name in identity.LOCAL_SOURCES:
            changed=copy.deepcopy(original_sources);changed[name]['sha256']='0'*64
            with patch.object(identity,'feature_sources',return_value=changed), self.assertRaises(DataContractError):
                policy.score(current)
        for invalid in (True,float('nan'),4.01):
            changed=dict(params);changed[features.ID_PARAMETERS['CLAW']]=invalid
            with self.assertRaises(DataContractError):self.model(changed,'invalid')
        policy.base.artifact['parameters'][features.ID_PARAMETERS['CLAW']]=1
        with self.assertRaises(DataContractError):policy.score(current)
        with self.assertRaises(DataContractError):features.zero_extend({'card_acquire':0.})

    def test_sampler_and_full_raw_reconstruction_reject_tampered_identity(self):
        params=dict.fromkeys(identity.PARAMETERS,0.);params[features.ID_PARAMETERS['CLAW']]=3.
        policy=self.model(params,'sample')
        with self.assertRaises(DataContractError):
            build_policy('test',self.config,ascension=9,model_path=policy.base.path)
        initial=state([card('CLAW',damage=3,cost=0),card('SWEEPING_BEAM',damage=6,cost=1)])
        initial['context'].update(act=1,floor=2,integrity_recovery_used=False)
        terminal=copy.deepcopy(initial);terminal.update(decision='game_over',victory=False)
        terminal['player']['hp']=0
        class FakeBridge:
            def send(self,**request):
                return copy.deepcopy(initial if request['cmd']=='start_run' else terminal)
            def close(self):pass
        with patch.object(sample_runs,'ROOT',self.root), patch.object(sample_runs,'Bridge',return_value=FakeBridge()):
            report=sample_runs.run_one('identity-fixture','identity-fixture',settings=self.config,
                epsilon=0.,model_path=policy.base.path,selection_budget=8)
        audit=_Audit(self.root/'outputs/audit')
        records,_=audit.run(report)
        self.assertEqual(audit.issues,[])
        self.assertTrue(audit.checks['prefix_actual_natural_run_start'])
        self.assertTrue(audit.checks['prefix_entire_macro_trace_coverage'])
        policies={r['decision_id']:r for r in map(json.loads,
            (self.root/'outputs/identity-fixture/policy.jsonl').read_text(encoding='utf-8').splitlines())}
        self.assertTrue(validate_whole_run_choices(records,policies))
        first=policies[records[0]['decision_id']]['scoring']['scores'][0]
        first['search_features'][features.ID_PARAMETERS['CLAW']]+=1.
        with self.assertRaises(DataContractError):validate_whole_run_choices(records,policies)


if __name__=='__main__':unittest.main()
