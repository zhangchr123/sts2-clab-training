"""Artificial original-engine Seeker repeats via the real Duplicator potion."""
import copy
import unittest
import uuid

from combat_executor import CombatExecutor
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers


class SeekerRepeatBoundaryTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def run_boundary(self, draw, upgraded):
        label = f'seeker-repeat-boundary-n{draw}-u{int(upgraded)}-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        executor, passed = None, False
        try:
            send(cmd='start_run', character='Defect', ascension=10, seed=f'seeker-repeat-n{draw}')
            potions = ['BLESSING_OF_THE_FORGE', 'DUPLICATOR'] if upgraded else ['DUPLICATOR']
            send(cmd='set_player', hp=1000, max_hp=1000, deck=['SEEKER_STRIKE'] * (5 + draw), relics=[], potions=potions)
            state = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
            self.assertEqual(state['draw_pile_count'], draw)
            for potion in potions:
                meta = send(cmd='combat_meta')
                selected = next(p for p in meta['potions'] if p['id'] == potion)
                state = send(cmd='action', action='use_potion', args={'potion_index': selected['index']})
            executor = CombatExecutor(send)
            final = executor.advance(state)
            self.assertEqual(final['decision'], 'card_reward')
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            all_proofs = [p for c in executor.solve_calls for p in c.get('replay', [])]
            first = next(p for p in all_proofs if p['kind'] == 'seeker_option_choice')
            root = first['actual_choice_metadata']['completion_audit']['action_id']
            self.assertTrue(first['actual_choice_metadata']['seeker_choice']['source_card_key'].startswith(f'SEEKER_STRIKE+{int(upgraded)}|'))
            manuals = [p for p in all_proofs if p['kind'] == 'seeker_option_choice'
                and p['actual_selection_audit'].get('seeker_continuation', {}).get('origin_action_id') == root]
            automatic = [p for p in all_proofs if p['kind'] == 'seeker_automatic_continuation_completed'
                and p['actual_origin_audit']['action_id'] == root]
            self.assertEqual(len(manuals), 1 if draw == 2 else 2)
            self.assertEqual(len(automatic), 1 if draw == 2 else 0)
            self.assertEqual([len(p['actual_choice_metadata']['seeker_choice']['source_cards']) for p in manuals],
                [2] if draw == 2 else [4, 3])
            self.assertFalse(final['context']['integrity_recovery_used'])
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='artificial_original_engine_potion_repeat',
                original_solver_used=True, actual_duplicator_potion=True,
                actual_blessing_of_the_forge=upgraded, initial_draw=draw,
                hidden_state_or_rng_equality_claimed=False,
                solver_calls=copy.deepcopy(executor.solve_calls) if executor else [])
            bridge.close()
            print({'label': label, 'passed': passed}, flush=True)

    def test_original_manual_singleton_base_and_upgraded(self):
        for upgraded in (False, True):
            with self.subTest(upgraded=upgraded): self.run_boundary(2, upgraded)

    def test_original_manual_manual_base_and_upgraded(self):
        for upgraded in (False, True):
            with self.subTest(upgraded=upgraded): self.run_boundary(4, upgraded)


if __name__ == '__main__': unittest.main(verbosity=2)
