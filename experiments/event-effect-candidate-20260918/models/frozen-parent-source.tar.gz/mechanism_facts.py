"""Small, engine-bound effect facts; quantities come from current exported stats.

GunkUp/Glacier/Hailstorm were checked in inspection/MACRO_SELECTION_REVIEW.md.
Coolheaded/Skim/Overclock/Modded/Turbo were checked with ILSpy against the same
DLL's OnPlay methods. These facts describe effects, not their strategic value.
Crystal Sphere uses only CellClicked/GetAdjacentCells public click geometry.
"""
from functools import lru_cache
import hashlib
import json
from pathlib import Path

from selection_space import DataContractError

VERSION = "macro-mechanism-facts-v1"
ENGINE_SHA256 = "14b57dbaee1b58cb919625a662831054fd714b3b75b13b7449eac0e95b98a3e4"
DEFAULT_ENGINE = Path(__file__).resolve().parent.parent / "sts2-cli" / "lib" / "sts2.dll"
FACTS = {
    "COLD_SNAP": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.ColdSnap", "source_method": "OnPlay",
        "channel": {"orb": "Frost", "count": 1, "timing": "on_play_after_attack"}},
    "GUNK_UP": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.GunkUp", "source_method": "OnPlay",
        "attack": {"damage_stat": "damage", "hit_count_stat": "repeat", "target": "single_enemy",
                   "semantics": "nominal_attack_before_block_modifiers_and_per_hit_hooks"},
        "generated_status": {"id": "CARD.SLIMED", "count": 1, "pile": "Discard", "persistence": "combat"}},
    "GLACIER": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.Glacier", "source_method": "OnPlay",
        "block_stat": "block", "channel": {"orb": "Frost", "count": 2, "timing": "on_play_after_block"}},
    "HAILSTORM": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.Hailstorm", "source_method": "OnPlay",
        "conditional_damage": {"amount_stat": "hailstormpower", "power": "HailstormPower",
            "trigger_method": "BeforeSideTurnEnd", "owner_participates": True,
            "condition": {"orb": "Frost", "min_count": 1}, "target": "HittableEnemies",
            "value_prop": "Unpowered", "stack_type": "Counter", "per_orb_multiplier": False,
            "immediate_damage": False}},
    "COOLHEADED": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.Coolheaded", "source_method": "OnPlay",
        "draw": {"amount_stat": "cards", "timing": "on_play"},
        "channel": {"orb": "Frost", "count": 1, "timing": "on_play_before_draw"}},
    "SKIM": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.Skim", "source_method": "OnPlay",
        "draw": {"amount_stat": "cards", "timing": "on_play"}},
    "OVERCLOCK": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.Overclock", "source_method": "OnPlay",
        "draw": {"amount_stat": "cards", "timing": "on_play"},
        "generated_status": {"id": "CARD.BURN", "count": 1, "pile": "Discard", "persistence": "combat"}},
    "MODDED": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.Modded", "source_method": "OnPlay",
        "draw": {"amount_stat": "cards", "timing": "on_play_after_add_slots"},
        "other_effects": ["AddSlots(Repeat.IntValue)", "EnergyCost.AddThisCombat(1)"]},
    "TURBO": {
        "source_type": "MegaCrit.Sts2.Core.Models.Cards.Turbo", "source_method": "OnPlay",
        "energy": {"amount_stat": "energy", "timing": "on_play"},
        "generated_status": {"id": "CARD.VOID", "count": 1, "pile": "Discard", "persistence": "combat"}},
}
MINIGAME_FACTS = {
    "CRYSTAL_SPHERE": {
        "source_type": "MegaCrit.Sts2.Core.Events.Custom.CrystalSphereEvent.CrystalSphereMinigame",
        "source_method": "CellClicked", "big_geometry_method": "GetAdjacentCells",
        "big_offsets": [[x, y] for x in (-1, 0, 1) for y in (-1, 0, 1)],
        "small_offsets": [[0, 0]], "bounds": "clip_to_current_public_grid",
        "selectable": "hidden_cells_only", "divination_cost": 1,
        "reward_layout": "not_exposed_or_used_by_policy"},
}


def registry_hash():
    return hashlib.sha256(json.dumps({"version": VERSION, "engine_sha256": ENGINE_SHA256,
        "facts": FACTS, "minigames": MINIGAME_FACTS},
        sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()


@lru_cache(maxsize=8)
def _file_hash(path, size, modified_ns):
    # Cache a verified file version, rather than permanently trusting a path.
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verified_source(engine_path=DEFAULT_ENGINE):
    path = Path(engine_path).resolve()
    try:
        stat = path.stat()
        actual = _file_hash(str(path), stat.st_size, stat.st_mtime_ns)
    except OSError as exc:
        raise DataContractError("Mechanism facts require the verified engine DLL") from exc
    if actual != ENGINE_SHA256:
        raise DataContractError("Mechanism facts engine SHA mismatch; verify and version facts before live use")
    return {"version": VERSION, "engine_sha256": actual, "registry_sha256": registry_hash(),
            "coverage": "limited_effect_and_public_geometry_facts_not_full_reward_or_hook_semantics"}
