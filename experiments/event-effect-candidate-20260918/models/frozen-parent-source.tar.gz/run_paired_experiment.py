"""Counterbalanced paired Defect A10 runs from a prewritten experiment protocol."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import time

from decision_data import read_decisions, split_by_seed
from probe import ROOT
from run_metadata import atomic_json, file_evidence
from sample_runs import run_one


def run(protocol_path):
    protocol_path = Path(protocol_path).resolve()
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    if protocol["schema_version"] != "paired-solver-config-v1":
        raise ValueError("Expected a predeclared solver configuration protocol")
    conditions = protocol["conditions"]
    if conditions["character"] != "Defect" or conditions["ascension"] != 10:
        raise ValueError("This experiment runner is restricted to Defect A10")
    created = datetime.fromisoformat(protocol["created_utc"])
    if created.tzinfo is None or created.timestamp() > time.time():
        raise ValueError("Protocol must be timestamped before execution")
    seeds = protocol["seeds"]
    if not seeds or len(seeds) != len(set(seeds)) or len(seeds) > 10000:
        raise ValueError("Expected unique predeclared seeds")
    arms = protocol["arms"]
    if set(arms) != {"left", "right"} or arms["left"]["batch"] == arms["right"]["batch"]:
        raise ValueError("Expected two distinct batch names")
    destinations = {}
    for name, arm in arms.items():
        if not re.fullmatch(r"[A-Za-z0-9_-]+", arm["batch"]):
            raise ValueError("Invalid batch name")
        target = ROOT / "outputs" / arm["batch"]
        if target.exists() or any((ROOT / "outputs" / f"{arm['batch']}-{i:04d}").exists() for i in range(len(seeds))):
            raise FileExistsError("Experiment output already exists: " + str(target))
        destinations[name] = target
    plan = protocol_path.parent / "execution-plan.json"
    if plan.exists():
        raise FileExistsError(plan)
    atomic_json(plan, {"protocol": file_evidence(protocol_path), "created_utc": datetime.now(timezone.utc).isoformat(),
        "search_workers_concurrent": 1, "order": "even seed index left/right; odd seed index right/left",
        "reason": "Wall-clock search budgets should not compete with another experiment worker"})
    reports, records = {key: [] for key in arms}, {key: [] for key in arms}
    for destination in destinations.values():
        destination.mkdir()
    for index, seed in enumerate(seeds):
        order = ("left", "right") if index % 2 == 0 else ("right", "left")
        for key in order:
            arm = arms[key]
            name = f"{arm['batch']}-{index:04d}"
            report = run_one(name, seed, ascension=10, settings=arm["solver_config"],
                epsilon=conditions["epsilon"], max_seconds=conditions["max_seconds"],
                max_decisions=conditions["max_decisions"], selection_budget=conditions["selection_budget"])
            reports[key].append(report)
            records[key].extend(read_decisions(ROOT / "outputs" / name / "decisions.jsonl"))
            atomic_json(destinations[key] / "reports.json", reports[key])
            print(json.dumps({"arm": key, "completed": len(reports[key]), "planned": len(seeds), **report}), flush=True)
    for key in arms:
        split = split_by_seed(records[key])
        atomic_json(destinations[key] / "split-manifest.json",
            {group: sorted({row["run_id"] for row in rows}) for group, rows in split.items()})
        atomic_json(destinations[key] / "summary.json", {"runs": len(reports[key]), "reports": reports[key],
            "training_eligible_decisions": sum(row["training_eligible"] for row in records[key]),
            "purpose": "predeclared paired Defect A10 development experiment; all outcomes retained"})
    print(json.dumps({"completed": True, "protocol": str(protocol_path), "batches": {key: str(value) for key, value in destinations.items()}}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", required=True, type=Path)
    run(parser.parse_args().protocol)
