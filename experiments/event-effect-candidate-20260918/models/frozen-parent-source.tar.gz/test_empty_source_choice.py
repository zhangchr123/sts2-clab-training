"""Real original-engine return fixtures; artificial decks, never training data."""
import copy
import json
import unittest
import uuid

from combat_executor import CombatExecutor, solver_config
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence
from run_metadata import file_evidence


class EmptySourceChoiceTests(unittest.TestCase):
    def setUp(self):
        self.label = "empty-source-" + self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.bridge = Bridge(self.label)
        self.addCleanup(self.bridge.close)
        self.trace, self.solver_calls = [], []
        self.versions = {"engine": file_evidence(ROOT.parent / "sts2-cli/lib/sts2.dll"),
            "solver": file_evidence(ROOT / "lib/CombatSolver.dll"),
            "bridge": file_evidence(ROOT / "runtime/host/bin/Debug/net9.0/SolverBridge.dll"),
            "cli": file_evidence(ROOT.parent / "sts2-cli/src/Sts2Headless/bin/Debug/net9.0/Sts2Headless.dll")}
        self.send(cmd="start_run", character="Defect", ascension=10, seed="empty-source-original-fixture-v1")

    def tearDown(self):
        with (ROOT / "outputs" / (self.label + ".json")).open("x", encoding="utf-8") as handle:
            json.dump({"fixture": True, "training_eligible": False,
                "provenance": "artificial room/deck/HP fixture; original engine and solver, no natural data",
                "versions": self.versions, "trace": self.trace, "solver_calls": self.solver_calls},
                handle, ensure_ascii=False, indent=2)

    def send(self, **request):
        response = self.bridge.send(**request)
        self.trace.append({"request": copy.deepcopy(request), "response": copy.deepcopy(response)})
        self.assertNotEqual(response.get("type"), "error", response)
        return response

    def test_original_plan_empty_neow_returns_then_continues_to_matching_terminal(self):
        # A single playable card forces this original effect's empty-source
        # branch while the starting lightning orb supplies eventual damage.
        self.send(cmd="set_player", hp=1000, max_hp=1000, deck=["NEOWS_FURY"], potions=[])
        state = self.send(cmd="enter_room", type="combat", encounter="SHRINKER_BEETLE_WEAK")
        self.assertEqual(state["discard_pile_count"], 0)
        config = solver_config()
        config.update(solver_backend="coordinator", first_budget_ms=1500, replan_budget_ms=1500,
            retry_budget_ms=1500, max_replans=3)
        executor = CombatExecutor(self.send, config)
        try:
            final = executor.advance(state)
        finally:
            self.solver_calls = executor.solve_calls
        proofs = [p for c in self.solver_calls for p in c.get("replay", [])]
        self.assertEqual(len(proofs), 1, proofs)
        self.assertEqual(proofs[0]["kind"], "planned_empty_choice_completed")
        self.assertEqual(proofs[0]["plan"]["Cards"], [])
        self.assertFalse(proofs[0]["remaining_battle_plan_stopped"])
        audit = proofs[0]["actual_choice_audit"]
        event = audit["events"][0]
        self.assertTrue(event["require_manual_confirmation"])
        self.assertTrue(event["combat_active_at_entry"])
        self.assertTrue(event["combat_active_at_return"])
        self.assertTrue(event["original_task_completed_successfully"])
        self.assertTrue(event["original_returned_empty_array"])
        self.assertEqual(event["source_pile_count_at_entry"], 0)
        self.assertEqual(event["selector_invocations_before"], event["selector_invocations_after"])
        self.assertFalse(any(t["request"].get("action") == "select_cards" for t in self.trace))
        validated = validate_replay_evidence(self.solver_calls, self.trace)
        query = validated["bindings"][0]["query_trace_index"]
        self.assertEqual(self.trace[query - 1]["response"]["decision"], "combat_play")
        self.assertEqual(self.trace[query + 1]["request"], {"cmd": "action", "action": "end_turn"})
        self.assertEqual(final["decision"], "card_reward")
        self.assertFalse(final["context"]["combat_in_progress"])
        self.assertFalse(final["context"]["integrity_recovery_used"])
        self.assertEqual(final["player"]["hp"], self.solver_calls[-1]["response"]["snapshot"]["PlayerHp"])


if __name__ == "__main__":
    unittest.main()
