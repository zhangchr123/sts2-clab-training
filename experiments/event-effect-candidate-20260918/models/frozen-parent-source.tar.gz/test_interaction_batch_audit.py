"""Two-act synthetic evidence checks; no game process or natural data is used."""
import copy
import json
import unittest

from audit_batch import audit_batch
from decision_data import DecisionJournal, enumerate_candidates, read_decisions
from interaction_survival_policy import InteractionSurvivalPolicy
from run_metadata import file_evidence, metadata
from selection_context import direct_action_evidence
from selection_policy import SelectionPolicy
import test_batch_audit as fixtures
import test_interaction_survival_policy as policy_fixtures
from test_survival_policy import CONFIG, current
from train_interaction_survival import FEATURE_SOURCE_FILES


class InteractionBatchAuditTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.BatchAuditTests(methodName="run")
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        pf = policy_fixtures.InteractionPolicyTests(methodName="run")
        pf.setUp()
        self.addCleanup(pf.doCleanups)
        self.model_path, fallback = pf.artifact()
        artifact = fixtures.read(self.model_path)
        source = pf.directory / "synthetic-training-evidence.txt"
        source.write_text("Synthetic artifact evidence only.", encoding="utf-8")
        artifact["sources"] = [file_evidence(source)]
        fixtures.write(self.model_path, artifact)
        self.policy = SelectionPolicy(InteractionSurvivalPolicy(self.model_path,
            fallback=fallback, solver_config=CONFIG, seed="synthetic-two-act", epsilon=.25))
        self.out = self.fixture.root / "two-act-model"
        self.out.mkdir()
        manifest = metadata(self.out.name, "synthetic-two-act", 10, CONFIG, self.policy.provenance)
        manifest["sampling"] = {"epsilon": .25, "model_path": str(self.model_path), "selection_budget": 256}
        fixtures.write(self.out / "manifest.json", manifest)
        state = current(1)
        traces = [{"request": {"cmd": "start_run", "seed": manifest["seed"]}, "response": state}]
        policies = []
        with DecisionJournal(self.out, manifest) as journal:
            for act in (1, 2):
                candidates = enumerate_candidates(state)
                picked = self.policy.choose(state, candidates)
                token = journal.begin(state, picked["request"], policy=picked["policy_provenance"], candidates=candidates)
                policies.append({"decision_id": token, **picked, "selection_context": None})
                after = current(2) if act == 1 else {"type": "decision", "decision": "game_over",
                    "victory": False, "context": state["context"], "player": {"hp": 0}}
                traces.append({"request": picked["request"], "response": after})
                journal.complete(token, after, execution={"exploration": picked["exploration"],
                    "selection_context": None, "selection_purpose": None,
                    "direct_action_result": direct_action_evidence(after)})
                state = after
            finish = journal.finalize(state, termination="engine_terminal")
        fixtures.write(self.out / "policy.jsonl", policies, lines=True)
        fixtures.write(self.out / "trace.jsonl", traces, lines=True)
        fixtures.write(self.out / "state.json", state)
        records = read_decisions(self.out / "decisions.jsonl")
        report = {"run_id": self.out.name, "seed": manifest["seed"], "outcome": finish["outcome"],
            "decisions": 2, "solver_calls": 0, "seconds": 1., "error": None,
            "training_eligible_decisions": sum(r["training_eligible"] for r in records),
            "exclusion_reasons": sorted({s for r in records for s in r["training_exclusion_reasons"]}),
            "final_context": state["context"], "final_hp": 0}
        fixtures.write(self.out / "report.json", report)
        fixtures.write(self.out / "status.json", {"status": "finished", **report})
        self.fixture.reports.append(report)
        self.fixture.finish_batch()

    def audit(self):
        return audit_batch(self.fixture.batch)

    def change_packet(self, index, mutate):
        path = self.out / "policy.jsonl"
        rows = fixtures.read(path, lines=True)
        mutate(rows[index]["scoring"])
        fixtures.write(path, rows, lines=True)

    def test_actual_119_act1_to_101_act2_chain_passes_full_audit(self):
        result = self.audit()
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual(result["counts"]["training_eligible_decisions"], 2)

    def test_later_act_cannot_pretend_model_active_or_use_119_schema(self):
        self.change_packet(1, lambda s: s["model"].update(active=True))
        self.fixture.assert_issue(self.audit(), "survival_model_actual_scope")
        self.change_packet(1, lambda s: s["scores"][0]["features"].update(ix_missing_gold=0.))
        self.fixture.assert_issue(self.audit(), "feature_schema_consistency")

    def test_forged_interaction_definition_and_products_are_rejected(self):
        self.change_packet(0, lambda s: s["interaction_feature_source"].update(definition_sha256="0" * 64))
        self.fixture.assert_issue(self.audit(), "scoring_interaction_transform_identity")
        self.fixture.assert_issue(self.audit(), "selection_context_source_chain")

    def test_missing_manifest_feature_source_is_rejected_even_with_matching_journal(self):
        manifest = fixtures.read(self.out / "manifest.json")
        del manifest["versions"]["sources"][FEATURE_SOURCE_FILES[0]]
        fixtures.write(self.out / "manifest.json", manifest)
        path = self.out / "decisions.jsonl"
        rows = fixtures.read(path, lines=True)
        rows[0]["metadata"]["versions"] = copy.deepcopy(manifest["versions"])
        fixtures.write(path, rows, lines=True)
        self.fixture.assert_issue(self.audit(), "interaction_model_manifest_feature_source")

    def test_actual_score_tamper_is_rejected_in_both_acts(self):
        for index in (0, 1):
            self.change_packet(index, lambda s: s["scores"][0].update(score=9876.))
        self.fixture.assert_issue(self.audit(), "interaction_actual_model_or_fallback_score")

    def test_reported_skip_delta_tamper_is_rejected(self):
        self.change_packet(1, lambda s: s["scores"][0].update(delta_from_skip=9876.))
        self.fixture.assert_issue(self.audit(), "interaction_actual_delta_from_skip")

    def test_interaction_direct_return_hash_must_match_actual_trace(self):
        path = self.out / "decisions.jsonl"
        rows = fixtures.read(path, lines=True)
        completed = next(row for row in rows if row["record_type"] == "decision_completed")
        completed["execution"]["direct_action_result"]["state_hash"] = "0" * 64
        fixtures.write(path, rows, lines=True)
        self.fixture.assert_issue(self.audit(), "direct_action_return_matches_trace")


if __name__ == "__main__":
    unittest.main()
