"""Read-only observation/replay auditing; this module cannot restore a branch.

`python branch_audit.py --live` runs a labeled, isolated interface fixture. It is
not a natural game or training sample. `--expected A.json --actual B.json` compares
branch_audit responses. The default full-state scope fails closed because the
current bridge does not capture all state or implement an audited restore path.
Hidden RNG and pile data must not be used as macro-policy features.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
from typing import Any
import uuid


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def fingerprint(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def differences(expected: Any, actual: Any, path: str = "") -> list[dict]:
    """Compare types, missing/null, list order and values without hiding differences."""
    if type(expected) is not type(actual):
        return [{"path": path or "/", "expected": expected, "actual": actual}]
    if isinstance(expected, dict):
        result = []
        for key in sorted(set(expected) | set(actual)):
            child = path + "/" + str(key).replace("~", "~0").replace("/", "~1")
            if key not in expected or key not in actual:
                result.append({"path": child, "missing_from": "expected" if key not in expected else "actual"})
            else:
                result.extend(differences(expected[key], actual[key], child))
        return result
    if isinstance(expected, list):
        result = []
        if len(expected) != len(actual):
            result.append({"path": path + "/length", "expected": len(expected), "actual": len(actual)})
        for index, (left, right) in enumerate(zip(expected, actual)):
            result.extend(differences(left, right, path + "/" + str(index)))
        return result
    return [] if expected == actual else [{"path": path or "/", "expected": expected, "actual": actual}]


def _validate_rng_set(value: Any, path: str, errors: list[str]) -> None:
    if not isinstance(value, dict) or not isinstance(value.get("seed"), str) or not value["seed"]:
        errors.append(path + ": missing RNG set/seed")
        return
    expected, streams = value.get("expected_streams"), value.get("streams")
    if (not isinstance(expected, list) or not expected or not all(isinstance(x, str) for x in expected)
            or len(set(expected)) != len(expected) or not isinstance(streams, dict) or set(streams) != set(expected)):
        errors.append(path + ": stream inventory is absent/incomplete")
        return
    for name, stream in streams.items():
        if not isinstance(stream, dict) or type(stream.get("initialized")) is not bool:
            errors.append(path + "/" + name + ": missing initialized flag")
            continue
        if not stream["initialized"]:
            if set(stream) != {"initialized"}:
                errors.append(path + "/" + name + ": uninitialized stream has unexpected state")
            continue
        state = stream.get("state")
        if (type(stream.get("counter")) is not int or stream["counter"] < 0
                or not isinstance(state, list) or len(state) != 4
                or not all(isinstance(word, str) and re.fullmatch(r"[0-9a-f]{16}", word) for word in state)):
            errors.append(path + "/" + name + ": incomplete counter/generator words")


def validate_observation(snapshot: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(snapshot, dict) or snapshot.get("type") != "branch_audit":
        return ["not a branch_audit response"]
    if type(snapshot.get("schema_version")) is not int or snapshot["schema_version"] != 1:
        errors.append("unsupported observation schema")
    if snapshot.get("capture_kind") != "read_only_observation":
        errors.append("unsupported capture kind")
    if snapshot.get("capture_stable") is not True:
        errors.append("observed mutation during capture or stability not supplied")
    engine = snapshot.get("engine", {})
    if not isinstance(engine, dict) or any(not isinstance(engine.get(k), str) or not engine[k] for k in ("game_mvid", "cli_mvid")):
        errors.append("missing engine build identities")
    coverage = snapshot.get("coverage", {})
    if not isinstance(coverage, dict):
        errors.append("missing coverage")
        coverage = {}
    for field in ("rng_complete", "relic_counters_complete"):
        if coverage.get(field) is not True:
            errors.append("coverage incomplete: " + field)
    payload = snapshot.get("payload")
    if not isinstance(payload, dict):
        return errors + ["missing payload"]
    for field in ("missing_rng_fields", "missing_relic_fields"):
        if payload.get(field) != []:
            errors.append("capture has missing/unreported fields: " + field)
    run, players, rng, relics = (payload.get(k) for k in ("run", "players", "rng", "relics"))
    if not isinstance(run, dict) or not isinstance(run.get("seed"), str) or not run["seed"]:
        errors.append("missing run seed")
    if not isinstance(players, list) or not players:
        return errors + ["missing player state"]
    for index, player in enumerate(players):
        if (not isinstance(player, dict) or player.get("index") != index
                or not isinstance(player.get("deck"), list) or not isinstance(player.get("character"), str)):
            errors.append("missing player/deck identity")
    if not isinstance(rng, dict):
        errors.append("missing RNG payload")
    else:
        _validate_rng_set(rng.get("run"), "rng/run", errors)
        rng_players = rng.get("players")
        if not isinstance(rng_players, list) or len(rng_players) != len(players):
            errors.append("missing player RNG inventory")
        else:
            for index, value in enumerate(rng_players):
                if not isinstance(value, dict) or value.get("index") != index:
                    errors.append("player RNG index mismatch")
                else:
                    _validate_rng_set(value.get("rng"), "rng/players/" + str(index), errors)
    if not isinstance(relics, list) or len(relics) != len(players):
        errors.append("missing relic inventory")
    else:
        for index, value in enumerate(relics):
            if not isinstance(value, dict) or value.get("player_index") != index or not isinstance(value.get("entries"), list):
                errors.append("invalid relic player inventory")
                continue
            for relic_index, relic in enumerate(value["entries"]):
                if (not isinstance(relic, dict) or relic.get("index") != relic_index
                        or not isinstance(relic.get("id"), str) or not isinstance(relic.get("runtime_fields"), dict)):
                    errors.append("missing relic identity/runtime fields")
    return errors


def compare_snapshots(expected: dict, actual: dict, *, scope: str = "full-state",
                      comparison_kind: str = "independent_observations") -> dict:
    """Observed equality may pass; exact-branch/restore certification never does.

    `observed-state` requires all captured state, complete run/player RNG and relic
    counter coverage to match. It still omits state listed by the engine capture.
    `full-state` intentionally fails until a separate reviewed capture/restore
    implementation exists; trusting a caller-set coverage flag would be unsafe.
    """
    if scope not in {"observed-state", "full-state"}:
        raise ValueError("scope must be observed-state or full-state")
    if comparison_kind not in {"independent_observations", "same_process_read", "same_seed_action_replay", "branch_restore"}:
        raise ValueError("unknown comparison kind")
    errors = ["expected: " + item for item in validate_observation(expected)]
    errors += ["actual: " + item for item in validate_observation(actual)]
    compared = ("schema_version", "capture_kind", "engine", "coverage", "payload")
    left = {key: expected.get(key) for key in compared} if isinstance(expected, dict) else {"invalid_response": expected}
    right = {key: actual.get(key) for key in compared} if isinstance(actual, dict) else {"invalid_response": actual}
    delta = differences(left, right)
    observed_match = not delta
    reasons = list(errors)
    if delta:
        reasons.append("captured state differs")
    if scope == "full-state":
        reasons.append("full engine state and asynchronous quiescence are not completely captured")
    if comparison_kind == "branch_restore":
        reasons.append("no audited branch restore protocol exists")
    return {"type": "branch_comparison", "schema_version": 1, "scope": scope,
            "comparison_kind": comparison_kind, "passed": not reasons,
            "observed_match": observed_match, "coverage_valid": not errors,
            "exact_branch_verified": False, "restore_authorized": False,
            "expected_fingerprint": fingerprint(left), "actual_fingerprint": fingerprint(right),
            "differences": delta, "reasons": reasons}


def _capture_fixture(seed: str, label: str, requests: list[dict] | None = None) -> dict:
    from probe import Bridge
    bridge = Bridge(label)
    records = []
    try:
        if requests is None:
            requests = [
                {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": seed},
                {"cmd": "set_player", "deck": ["STRIKE_DEFECT"] * 5, "relics": ["NUNCHAKU"]},
                {"cmd": "enter_room", "type": "combat", "encounter": "SHRINKER_BEETLE_WEAK"},
                # Protocol fixture: every hand card is the same attack, one enemy.
                # This fixed test action is neither a rollout policy nor LLM combat.
                {"cmd": "action", "action": "play_card", "args": {"card_index": 0, "target_index": 0}},
            ]
        for request in requests:
            state = bridge.send(**request)
            if state.get("type") == "error":
                raise RuntimeError("fixture action failed: " + canonical_json(state))
            audit = bridge.send(cmd="branch_audit")
            repeat = bridge.send(cmd="branch_audit")
            check = compare_snapshots(audit, repeat, scope="observed-state", comparison_kind="same_process_read")
            records.append({"request": request, "state": state, "audit": audit, "repeat_check": check})
        return {"records": records, "requests": requests, "environment_error": None}
    except Exception as exc:
        return {"records": records, "requests": requests,
                "environment_error": {"category": "fixture_or_environment_failure", "exception": type(exc).__name__, "message": str(exc)}}
    finally:
        bridge.close()


def run_live_fixture(seed: str = "branch-audit-fixture-v1") -> dict:
    """Two new processes, exact same requests; no write_continue_save/load_save."""
    suffix = uuid.uuid4().hex[:12]
    first = _capture_fixture(seed, "branch-audit-" + suffix + "-a")
    provenance = {"kind": "artificial_interface_fixture", "training_eligible": False,
                  "seed": seed, "interventions": ["set_player deck/relics", "enter_room encounter", "one fixed protocol attack"],
                  "reconstruction": "fresh process and exact same requests; no save or restore"}
    if first["environment_error"]:
        return {"type": "branch_audit_fixture", "schema_version": 1, "passed": False, "provenance": provenance,
                "environment_error": first["environment_error"], "exact_branch_verified": False, "restore_authorized": False, "runs": [first]}
    second = _capture_fixture(seed, "branch-audit-" + suffix + "-b", first["requests"])
    if second["environment_error"]:
        return {"type": "branch_audit_fixture", "schema_version": 1, "passed": False, "provenance": provenance,
                "environment_error": second["environment_error"], "exact_branch_verified": False, "restore_authorized": False, "runs": [first, second]}
    checks = []
    for index, (left, right) in enumerate(zip(first["records"], second["records"])):
        check = compare_snapshots(left["audit"], right["audit"], scope="observed-state", comparison_kind="same_seed_action_replay")
        check["stage"] = index
        check["decision_differences"] = differences(left["state"], right["state"])
        if check["decision_differences"]:
            check["passed"] = False
            check["reasons"].append("returned decision state differs")
        checks.append(check)
    before = first["records"][2]["audit"]["payload"]["relics"][0]["entries"][0]["runtime_fields"]
    after = first["records"][3]["audit"]["payload"]["relics"][0]["entries"][0]["runtime_fields"]
    counter_key = "Nunchaku._attacksPlayed"
    counter_changed = before.get(counter_key) == 0 and after.get(counter_key) == 1
    rng_changed = first["records"][1]["audit"]["payload"]["rng"] != first["records"][2]["audit"]["payload"]["rng"]
    checks_passed = all(check["passed"] for check in checks)
    reads_passed = all(record["repeat_check"]["passed"] for run in (first, second) for record in run["records"])
    return {"type": "branch_audit_fixture", "schema_version": 1,
            "provenance": provenance, "environment_error": None,
            "passed": checks_passed and reads_passed and counter_changed and rng_changed,
            "exact_branch_verified": False, "restore_authorized": False,
            "counter_transition": {"key": counter_key, "before": before.get(counter_key), "after": after.get(counter_key), "passed": counter_changed},
            "rng_transition_detected": rng_changed, "read_only_checks_passed": reads_passed,
            "replay_checks": checks, "runs": [first, second]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", help="run two isolated, artificial protocol fixtures")
    parser.add_argument("--seed", default="branch-audit-fixture-v1")
    parser.add_argument("--expected", type=Path)
    parser.add_argument("--actual", type=Path)
    parser.add_argument("--scope", choices=("observed-state", "full-state"), default="full-state")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.live:
        if args.expected or args.actual:
            parser.error("--live cannot be combined with file comparison")
        result = run_live_fixture(args.seed)
    else:
        if not args.expected or not args.actual:
            parser.error("provide --live or both --expected and --actual")
        result = compare_snapshots(json.loads(args.expected.read_text(encoding="utf-8-sig")),
                                   json.loads(args.actual.read_text(encoding="utf-8-sig")), scope=args.scope)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        # Never overwrite an earlier audit, including an old fixture result.
        with args.output.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    summary = {key: value for key, value in result.items() if key not in {"runs", "replay_checks", "differences"}}
    if "replay_checks" in result:
        summary["replay_checks"] = [{key: value for key, value in check.items() if key not in {"differences", "decision_differences"}} for check in result["replay_checks"]]
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
