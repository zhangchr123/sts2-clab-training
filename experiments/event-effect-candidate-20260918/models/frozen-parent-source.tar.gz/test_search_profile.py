"""Real DLL checks for the bridge's independent solver profile argument."""
import json
import unittest
import uuid

from probe import Bridge, ROOT, replay_basic


DEFAULT_PROFILE = {
    "beam_width": 30,
    "max_expanded_nodes": 5000,
    "max_card_branches_per_node": 24,
    "max_pile_choice_branches_per_action": 12,
    "max_hand_choice_branches_per_action": 12,
    "soft_time_budget_ms": 1500,
    "recover_deferred_turn_frontier": False,
}


class SearchProfileTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.b = Bridge(self.label)
        self.b.send(cmd="start_run", character="Defect", ascension=10,
                    seed="solver-bridge-1")
        self.state = self.b.send(cmd="enter_room", type="combat",
                                 encounter="SHRINKER_BEETLE_WEAK")
        self.assertEqual(self.state.get("decision"), "combat_play", self.state)

    def tearDown(self):
        (ROOT / "outputs" / f"{self.label}.json").write_text(
            json.dumps(self.b.rows, ensure_ascii=False, indent=2), encoding="utf-8")
        self.b.close()

    def test_default_profile_verified_and_route_matches_engine(self):
        result = self.b.send(cmd="solve", budget_ms=1500)
        self.assertEqual(result["type"], "solver_result", result)
        self.assertEqual(result["settings"]["search_profile"], DEFAULT_PROFILE)
        self.assertIs(result["settings"]["search_profile_verified"], True)
        self.assertEqual(result["settings"]["max_degree_of_parallelism"], 1)
        self.assertLessEqual(result["summary"]["MaxParallelExpansionConcurrency"], 1)
        final = replay_basic(self.b, self.state, result)
        self.assertEqual(final["decision"], "card_reward", final)
        self.assertEqual(final["player"]["hp"], result["snapshot"]["PlayerHp"])

    def test_custom_profile_limits_actual_expansion_and_does_not_persist(self):
        # The old omitted constructor argument silently used 24000 nodes. A real
        # one-node search verifies behavior beyond simply echoing requested values.
        profile = {
            "beam_width": 1,
            "max_expanded_nodes": 1,
            "max_card_branches_per_node": 2,
            "max_pile_choice_branches_per_action": 3,
            "max_hand_choice_branches_per_action": 4,
            "recover_deferred_turn_frontier": True,
        }
        limited = self.b.send(cmd="solve", budget_ms=1500, search_profile=profile,
                              stop_at_acceptable_hp_loss=False)
        self.assertEqual(limited["type"], "solver_result", limited)
        self.assertEqual(limited["settings"]["search_profile"],
                         {**profile, "soft_time_budget_ms": 1500})
        self.assertIs(limited["settings"]["search_profile_verified"], True)
        self.assertEqual(limited["summary"]["ExpandedNodes"], 1)
        self.assertEqual(limited["summary"]["BoundaryReason"], "NodeLimit")

        default = self.b.send(cmd="solve", budget_ms=1500)
        self.assertEqual(default["type"], "solver_result", default)
        self.assertEqual(default["settings"]["search_profile"], DEFAULT_PROFILE)
        self.assertGreater(default["summary"]["ExpandedNodes"], 1)

    def test_invalid_profile_is_rejected(self):
        for profile in (None, [], {"beam_wdth": 30}, {"beam_width": 0},
                        {"max_expanded_nodes": 1000001}, {"beam_width": 1.5},
                        {"max_card_branches_per_node": "24"},
                        {"recover_deferred_turn_frontier": 1},
                        {"soft_time_budget_ms": 1500}):
            with self.subTest(profile=profile):
                result = self.b.send(cmd="solve", search_profile=profile)
                self.assertEqual(result["type"], "error", result)

    def test_policy_and_cumulative_damage_snapshots_report_actual_settings(self):
        result = self.b.send(cmd="solve", budget_ms=500,
                             search_profile={"max_expanded_nodes": 1},
                             potion_policy="RequireAtLeastOne", hp_lost_so_far=9,
                             sold_hp_committed=2, potions_used_so_far=1,
                             acceptable_hp_loss=7, stop_at_acceptable_hp_loss=False,
                             ignore_long_term_rewards=True,
                             act_boss_hp_strategy="MinimizeHpLoss",
                             final_boss_hp_strategy="MinimizeHpLoss",
                             brightest_flame_max_hp_loss_limit=6)
        self.assertEqual(result["type"], "solver_result", result)
        settings = result["settings"]
        self.assertEqual(settings["battle_damage_snapshot"],
                         {"HpLostSoFar": 9, "SoldHpCommitted": 2, "PotionsUsedSoFar": 1})
        policy = settings["policy_snapshot"]
        expected = {
            "PotionPolicy": "RequireAtLeastOne", "BudgetOverrideMilliseconds": 500,
            "MaxDegreeOfParallelism": 1, "IncludeTurnSetup": False,
            "ActTransitionBossHpStrategy": "MinimizeHpLoss", "FinalBossHpStrategy": "MinimizeHpLoss",
            "AcceptableBattleHpLoss": 7, "StopAtAcceptableBattleHpLoss": False,
            "IgnoreLongTermRewards": True, "BrightestFlameMaxHpLossLimit": 6,
            "DetailedDiagnostics": False, "VerifyIncrementalSearch": False,
            "FixedBudget": False, "MeasurePhasePerformance": False, "TheftPolicy": None,
        }
        for name, value in expected.items():
            self.assertEqual(policy[name], value, name)
        self.assertIs(policy["CanStopAtHpTarget"], False)
        self.assertIs(policy["EffectiveHasGrowthTargets"], False)
        self.assertTrue(all(value is None or type(value) in (int, float, bool, str)
                            for value in policy.values()))
        # The original DLL changes RequireAtLeastOne to Smart when an earlier
        # search segment already used a potion. Preserve both pieces of evidence.
        self.assertEqual(settings["effective_potion_policy"], "Smart")
        self.assertIs(settings["search_profile_verified"], True)


if __name__ == "__main__":
    unittest.main()
