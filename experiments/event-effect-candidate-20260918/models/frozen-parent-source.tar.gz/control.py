"""Read a named run or submit one JSON request file to its live controller."""
import argparse
import json
import os
from pathlib import Path
import re
import time


def read_json(path):
    for _ in range(20):
        try:
            return json.loads(path.read_text(encoding='utf-8-sig'))
        except json.JSONDecodeError:
            time.sleep(.05)
    raise RuntimeError(f'Incomplete JSON: {path}')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run-name', required=True)
    ap.add_argument('--request-file', type=Path)
    ap.add_argument('--timeout', type=float, default=45)
    args=ap.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]+',args.run_name):ap.error('Invalid run name')
    p=Path(__file__).resolve().parent/'outputs'/args.run_name
    status=read_json(p/'status.json')
    if args.request_file:
        cmd=read_json(args.request_file)
        if status['status'] != 'waiting' and not (status['status']=='blocked' and cmd.get('cmd')=='stop'):
            ap.error('Run is not waiting for a macro action; read its state/error first')
        if cmd.get('cmd') not in ('action','get_map','stop'):
            ap.error('Controller permits macro action/get_map/stop only; use an isolated Bridge for scenario APIs')
        if (p/'command.json').exists():ap.error('A command is already pending')
        previous=(p/'state.json').stat().st_mtime_ns
        temp=p/f'command-{os.getpid()}.tmp'
        temp.write_text(json.dumps(cmd),encoding='utf-8')
        temp.rename(p/'command.json')
        until=time.monotonic()+args.timeout
        while time.monotonic()<until:
            time.sleep(.15)
            status=read_json(p/'status.json')
            changed=(p/'state.json').stat().st_mtime_ns!=previous
            if not (p/'command.json').exists() and changed and status['status']!='combat':break
        else:
            print(json.dumps({'type':'pending','message':'Request may still be running. Read status; do not resend.'}))
            return
    output={'status':read_json(p/'status.json'),'state':read_json(p/'state.json')}
    if args.request_file and cmd.get('cmd')=='get_map' and (p/'map.json').exists():output['query_result']=read_json(p/'map.json')
    if (p/'error.txt').exists():output['error']=(p/'error.txt').read_text(encoding='utf-8')
    print(json.dumps(output,ensure_ascii=True))


if __name__=='__main__':main()
