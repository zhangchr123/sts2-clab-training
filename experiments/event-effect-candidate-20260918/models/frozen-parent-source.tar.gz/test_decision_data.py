"""Data correctness tests use explicit fixtures, never natural rollout labels."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from decision_data import (DataContractError, DecisionJournal, enumerate_candidates,
                           materialize_candidate, read_decisions, split_by_seed,
                           validate_candidate_set, validate_request)
from selection_space import build_space, request_for_indices, request_for_rank


def policy(kind="rules", origin="natural"):
    return {"origin": origin, "kind": kind, "id": "test-policy", "version": "1",
            "llm_involved": kind == "llm"}


def metadata(seed="seed-1", run_id="run-1", ascension=10):
    return {"run_id": run_id, "seed": seed, "character": "Defect", "ascension": ascension,
            "mode": "standard", "versions": {"engine": "fixture-engine", "solver": "fixture-solver",
                                             "bridge": "fixture-bridge"},
            "solver_requested_config": {"budget_ms": 1000}, "provenance": policy()}


def reward(skip=True):
    return {"type": "decision", "decision": "card_reward", "can_skip": skip,
            "cards": [{"index": 4, "id": "CARD.A"}, {"index": 9, "id": "CARD.B"}],
            "player": {"hp": 30, "deck": []}, "context": {"ascension": 10}}


def solver_call(verified=True):
    return {"request": {"cmd": "solve", "budget_ms": 1000},
            "response": {"type": "solver_result", "settings": {
                "search_profile_verified": verified,
                "search_profile": {"beam_width": 30, "max_expanded_nodes": 5000,
                                   "max_card_branches_per_node": 8, "max_pile_choice_branches_per_action": 8,
                                   "max_hand_choice_branches_per_action": 8, "soft_time_budget_ms": 1000,
                                   "recover_deferred_turn_frontier": False},
                "max_degree_of_parallelism": 1, "potion_policy": "Smart", "potions": [], "growth_budgets": {}}}}


def terminal(victory=False):
    return {"type": "decision", "decision": "game_over", "victory": victory,
            "context": {"ascension": 10}, "player": {"hp": 40 if victory else 0}}


class CandidateTests(unittest.TestCase):
    def test_crystal_sphere_enumerates_only_visible_legal_blind_actions(self):
        state = {"type": "decision", "decision": "crystal_sphere", "grid_size": {"x": 11, "y": 11},
                 "divinations_left": 3, "tools": ["small", "big"],
                 "cells": [{"x": x, "y": y, "hidden": True} for y in range(11) for x in range(11)]}
        result = enumerate_candidates(state)
        self.assertTrue(result["complete"], result)
        self.assertEqual(result["candidate_count"], 242)
        center = next(c for c in result["candidates"] if c["request"]["args"] == {"x": 5, "y": 5, "tool": "big"})
        self.assertEqual(center["evidence"]["hidden_cells_covered"], 9)
        state["cells"][0].update(hidden=False, item_kind=None)
        result = enumerate_candidates(state)
        self.assertEqual(result["candidate_count"], 240)
        self.assertFalse(validate_request(result, {"cmd": "action", "action": "crystal_sphere_reveal",
            "args": {"x": 0, "y": 0, "tool": "big"}}))
        state["cells"][1]["item_kind"] = "Relic"
        self.assertFalse(enumerate_candidates(state)["complete"], "Hidden item leakage is invalid")
        del state["cells"][1]["item_kind"]
        state["cells"].pop()
        self.assertFalse(enumerate_candidates(state)["complete"], "Partial boards cannot truncate actions")

    def requests(self, state):
        result = enumerate_candidates(state)
        self.assertTrue(result["complete"], result)
        return [c["request"] for c in result["candidates"]]

    def test_reward_preserves_current_indices_and_explicit_skip(self):
        actions = self.requests(reward())
        self.assertEqual([r.get("args", {}).get("card_index") for r in actions], [4, 9, None])
        self.assertEqual(actions[-1]["action"], "skip_card_reward")
        self.assertEqual(len(self.requests(reward(False))), 2)
        missing = reward(); del missing["can_skip"]
        self.assertFalse(enumerate_candidates(missing)["complete"])

    def test_locked_event_and_disabled_rest_options(self):
        state = {"type": "decision", "decision": "event_choice",
                 "options": [{"index": 2, "is_locked": True}, {"index": 7, "is_locked": False}]}
        self.assertEqual(self.requests(state)[0]["args"], {"option_index": 7})
        state.update(decision="rest_site", options=[{"index": 3, "is_enabled": False}, {"index": 9, "is_enabled": True}])
        self.assertEqual(self.requests(state)[0]["args"], {"option_index": 9})
        state["options"].append({"index": 10})
        self.assertEqual(enumerate_candidates(state)["candidates"], [])

    def test_all_ordered_card_selections_and_empty_selection(self):
        state = {"type": "decision", "decision": "card_select", "min_select": 0, "max_select": 2,
                 "cards": [{"index": 8}, {"index": 3}, {"index": 5}], "context": {"room_type": "Event"}}
        selections = [r["args"]["indices"] for r in self.requests(state)]
        self.assertEqual(len(selections), 10)
        self.assertIn("", selections)
        self.assertIn("8,3", selections)
        self.assertIn("3,8", selections)
        state["min_select"] = 1
        self.assertNotIn("", [r["args"]["indices"] for r in self.requests(state)])
        limited = enumerate_candidates(state, max_candidates=3)
        self.assertTrue(limited["complete"])
        self.assertEqual(limited["representation"], "ordered_selection_implicit_v1")
        self.assertEqual(limited["candidate_count"], 9)
        self.assertEqual(limited["candidates"], [])

    def test_huge_space_keeps_all_actions_in_exact_descriptor(self):
        state = {"type": "decision", "decision": "card_select", "min_select": 0, "max_select": 15,
                 "cards": [{"index": i * 2, "id": f"CARD.{i}"} for i in range(15)],
                 "context": {"room_type": "Event", "combat_in_progress": False}}
        result = enumerate_candidates(state)
        self.assertTrue(result["complete"])
        self.assertEqual(result["candidate_count"], 3554627472076)
        self.assertEqual(result["candidates"], [])
        self.assertEqual(result["selection_space"]["cards"], state["cards"])
        empty = materialize_candidate(result, request_for_rank(result["selection_space"], 0))
        self.assertTrue(empty["is_skip"])
        self.assertEqual(empty["evidence"]["indices"], [])
        selected = materialize_candidate(result, request_for_indices(result["selection_space"], [28, 0, 14]))
        self.assertEqual(selected["evidence"]["indices"], [28, 0, 14])
        self.assertEqual([c["index"] for c in selected["evidence"]["cards"]], [28, 0, 14])
        self.assertFalse(selected["is_skip"])

    def test_materialized_identity_matches_explicit_candidate(self):
        state = {"type": "decision", "decision": "card_select", "min_select": 0, "max_select": 2,
                 "cards": [{"index": 8}, {"index": 3}], "context": {"room_type": "Event"}}
        explicit = enumerate_candidates(state)
        implicit = enumerate_candidates(state, max_candidates=1)
        for candidate in explicit["candidates"]:
            self.assertEqual(materialize_candidate(implicit, candidate["request"]), candidate)
            self.assertTrue(validate_request(implicit, candidate["request"]))

    def test_proposal_subset_cannot_replace_an_implicit_space(self):
        state = {"type": "decision", "decision": "card_select", "min_select": 0, "max_select": 2,
                 "cards": [{"index": 8}, {"index": 3}], "context": {"room_type": "Event"}}
        space = enumerate_candidates(state, max_candidates=1)
        request = request_for_rank(space["selection_space"], 0)
        space["candidates"] = [materialize_candidate(space, request)]
        with self.assertRaises(DataContractError):
            validate_request(space, request)

    def test_bad_request_returns_false_but_bad_descriptor_raises(self):
        state = {"type": "decision", "decision": "card_select", "min_select": 0, "max_select": 2,
                 "cards": [{"index": 8}, {"index": 3}], "context": {"room_type": "Event"}}
        space = enumerate_candidates(state, max_candidates=1)
        bad_request = {"cmd": "action", "action": "select_cards", "args": {"indices": "8,8"}}
        self.assertFalse(validate_request(space, bad_request))
        with self.assertRaises(DataContractError):
            materialize_candidate(space, bad_request)
        space["candidate_count"] += 1
        with self.assertRaises(DataContractError):
            validate_request(space, bad_request)

    def test_boolean_action_argument_never_matches_integer_candidate(self):
        state = reward()
        state["cards"][0]["index"] = 1
        request = {"cmd": "action", "action": "select_card_reward", "args": {"card_index": True}}
        self.assertFalse(validate_request(enumerate_candidates(state), request))

    def test_combat_choices_and_unknown_surfaces_fail_closed(self):
        state = {"type": "decision", "decision": "card_select", "min_select": 1, "max_select": 1,
                 "cards": [{"index": 0}], "context": {"room_type": "Boss"}}
        for decision in ("card_select", "combat_play", "unknown", "future_event"):
            state["decision"] = decision
            self.assertFalse(enumerate_candidates(state)["complete"])

    def test_map_and_bundle_use_exported_ids(self):
        state = {"type": "decision", "decision": "map_select", "choices": [{"col": 2, "row": 10}, {"col": 5, "row": 10}]}
        self.assertEqual(self.requests(state)[1]["args"], {"col": 5, "row": 10})
        state.update(decision="bundle_select", bundles=[{"index": 6, "cards": [{"id": "CARD.A"}]}])
        self.assertEqual(self.requests(state)[0], {"cmd": "action", "action": "select_bundle", "args": {"bundle_index": 6}})

    def test_shop_requires_purchase_legality_and_enumerates_inventory(self):
        state = {"type": "decision", "decision": "shop", "cards": [{"index": 4, "can_purchase": True}],
                 "relics": [{"index": 8, "can_purchase": False}], "potions": [{"index": 2, "can_purchase": False}],
                 "player": {"gold": 70, "potions": [{"index": 3, "id": "POTION.FIRE"}]},
                 "can_leave": True, "card_removal_available": True, "card_removal_cost": 75}
        self.assertEqual([r["action"] for r in self.requests(state)], ["buy_card", "discard_potion", "leave_room"])
        state["player"]["gold"] = 75
        self.assertIn("remove_card", [r["action"] for r in self.requests(state)])
        del state["potions"][0]["can_purchase"]
        self.assertFalse(enumerate_candidates(state)["complete"])

    def test_invalid_or_duplicate_indices_never_become_actions(self):
        state = reward(); state["cards"][1]["index"] = 4
        self.assertFalse(enumerate_candidates(state)["complete"])
        state["cards"][1]["index"] = True
        self.assertFalse(enumerate_candidates(state)["complete"])


class JournalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)

    def journal(self, **metadata_kwargs):
        journal = DecisionJournal(self.temp.name, metadata(**metadata_kwargs))
        self.addCleanup(journal.close)
        return journal

    def record(self, journal, *, actor=None, calls=None, next_state=None):
        state = reward()
        token = journal.begin(state, {"cmd": "action", "action": "skip_card_reward"}, policy=actor or policy())
        return journal.complete(token, next_state or terminal(), solver_calls=[solver_call()] if calls is None else calls)

    def test_snapshots_complete_candidates_actual_settings_and_true_loss(self):
        journal = self.journal()
        before = reward()
        token = journal.begin(before, {"cmd": "action", "action": "skip_card_reward"}, policy=policy())
        before["cards"].clear()
        result = journal.complete(token, terminal(), solver_calls=[solver_call()])
        self.assertEqual(len(result["state"]["cards"]), 2)
        journal.finalize(terminal(), termination="engine_terminal")
        records = read_decisions(journal.path)
        self.assertTrue(records[0]["training_eligible"], records)
        self.assertIsNone(records[0]["chosen_is_optimal"])
        self.assertEqual(records[0]["run_outcome"]["outcome"], "defeat")

    def test_stale_or_illegal_selection_is_rejected_before_execution(self):
        journal = self.journal()
        state = reward()
        candidates = enumerate_candidates(state)
        state["cards"][0]["index"] = 6
        with self.assertRaises(DataContractError):
            journal.begin(state, {"cmd": "action", "action": "skip_card_reward"}, policy=policy(), candidates=candidates)
        with self.assertRaises(DataContractError):
            journal.begin(state, {"cmd": "action", "action": "select_card_reward", "args": {"card_index": 0}}, policy=policy())

    def test_llm_followup_excludes_entire_run_including_previous_rules(self):
        journal = self.journal()
        self.record(journal)
        self.record(journal, actor=policy("llm", "deployment"))
        journal.finalize(terminal(), termination="engine_terminal")
        records = read_decisions(journal.path)
        self.assertTrue(all(not r["training_eligible"] for r in records))
        self.assertIn("run_contains_non_natural_or_non_training_policy", records[0]["training_exclusion_reasons"])

    def test_smoke_fixture_and_manual_are_audit_only(self):
        for kind, origin in (("scripted_fixture", "control_smoke"), ("human", "natural"), ("rules", "fixture")):
            with tempfile.TemporaryDirectory() as directory:
                meta = metadata(); meta["provenance"] = policy(kind, origin)
                with DecisionJournal(directory, meta) as journal:
                    self.record(journal, actor=policy(kind, origin))
                    journal.finalize(terminal(), termination="engine_terminal")
                    self.assertFalse(read_decisions(journal.path)[0]["training_eligible"])

    def test_missing_actual_profile_is_not_replaced_by_requested_profile(self):
        journal = self.journal()
        self.record(journal, calls=[solver_call(False)])
        journal.finalize(terminal(), termination="engine_terminal")
        self.assertIn("missing_or_unverified_actual_solver_configuration", read_decisions(journal.path)[0]["training_exclusion_reasons"])

    def test_real_event_death_before_any_combat_does_not_require_a_fabricated_solve(self):
        journal = self.journal()
        state = {"type": "decision", "decision": "event_choice",
                 "options": [{"index": 0, "is_locked": False}],
                 "context": {"combat_in_progress": False, "room_type": "Event"}}
        final = terminal()
        final["context"].update(combat_in_progress=False, room_type="Event")
        token = journal.begin(state, {"cmd": "action", "action": "choose_option", "args": {"option_index": 0}}, policy=policy())
        journal.complete(token, final)
        journal.finalize(final, termination="engine_terminal")
        result = read_decisions(journal.path)[0]
        self.assertTrue(result["training_eligible"], result["training_exclusion_reasons"])
        self.assertEqual(result["solver_calls"], [])

    def test_stop_and_environment_error_are_not_losses(self):
        for termination in ("stopped", "environment_error", "timeout"):
            with tempfile.TemporaryDirectory() as directory:
                with DecisionJournal(directory, metadata()) as journal:
                    self.record(journal)
                    result = journal.finalize(reward(), termination=termination)
                    self.assertNotIn(result["outcome"], ("victory", "defeat"))
                    self.assertIsNone(result["engine_victory"])
                    self.assertFalse(read_decisions(journal.path)[0]["training_eligible"])

    def test_a10_victory_requires_second_boss_evidence(self):
        journal = self.journal()
        self.record(journal)
        journal.finalize(terminal(True), termination="engine_terminal")
        self.assertIn("a10_second_boss_victory_unverified", read_decisions(journal.path)[0]["training_exclusion_reasons"])

    def test_environment_failure_contaminates_later_terminal_loss(self):
        journal = self.journal()
        self.record(journal, next_state={"type": "error", "error": "executor stuck"})
        journal.finalize(terminal(), termination="engine_terminal")
        self.assertIn("run_environment_error", read_decisions(journal.path)[0]["training_exclusion_reasons"])

    def test_crash_leaves_an_unresolved_intent_not_a_fabricated_transition(self):
        journal = self.journal()
        journal.begin(reward(), {"cmd": "action", "action": "skip_card_reward"}, policy=policy())
        journal.close()
        self.assertEqual(read_decisions(journal.path), [])
        with self.assertRaises(FileExistsError):
            DecisionJournal(self.temp.name, metadata())

    def test_tampered_candidate_set_is_rejected_at_read(self):
        journal = self.journal()
        self.record(journal)
        journal.finalize(terminal(), termination="engine_terminal")
        rows = [json.loads(line) for line in journal.path.read_text().splitlines()]
        for row in rows:
            if row["record_type"] == "decision_completed":
                row["candidate_set"]["candidates"] = row["candidate_set"]["candidates"][-1:]
        journal.path.write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")
        with self.assertRaises(DataContractError):
            read_decisions(journal.path)

    def test_terminal_outcome_cannot_disagree_with_engine_state(self):
        journal = self.journal()
        self.record(journal)
        journal.finalize(terminal(), termination="engine_terminal")
        rows = [json.loads(line) for line in journal.path.read_text().splitlines()]
        rows[-1]["outcome"] = "victory"
        rows[-1]["engine_victory"] = True
        journal.path.write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")
        with self.assertRaises(DataContractError):
            read_decisions(journal.path)

    def test_duplicate_completion_cannot_hide_an_unresolved_intent(self):
        journal = self.journal()
        self.record(journal)
        journal.finalize(terminal(), termination="engine_terminal")
        rows = [json.loads(line) for line in journal.path.read_text().splitlines()]
        rows.insert(3, copy.deepcopy(rows[2]))
        journal.path.write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")
        with self.assertRaises(DataContractError):
            read_decisions(journal.path)

    def test_implicit_journal_materializes_chosen_and_retains_nondefault_threshold(self):
        journal = self.journal()
        state = {"type": "decision", "decision": "card_select", "min_select": 0, "max_select": 3,
                 "cards": [{"index": 8}, {"index": 3}, {"index": 5}],
                 "context": {"room_type": "Event", "combat_in_progress": False}}
        space = enumerate_candidates(state, max_candidates=2)
        request = request_for_indices(space["selection_space"], [5, 8])
        token = journal.begin(state, request, policy=policy(), candidates=space)
        journal.complete(token, terminal(), solver_calls=[solver_call()])
        journal.finalize(terminal(), termination="engine_terminal")
        result = read_decisions(journal.path)[0]
        self.assertTrue(result["training_eligible"])
        self.assertEqual(result["candidate_set"]["enumeration_limit"], 2)
        self.assertEqual(result["candidate_set"]["candidates"], [])
        self.assertEqual(result["chosen"]["evidence"]["indices"], [5, 8])
        self.assertIsNone(result["chosen_is_optimal"])

    def test_implicit_descriptor_must_match_actual_state_even_if_self_hash_valid(self):
        journal = self.journal()
        state = {"type": "decision", "decision": "card_select", "min_select": 0, "max_select": 3,
                 "cards": [{"index": 8}, {"index": 3}, {"index": 5}], "context": {"room_type": "Event"}}
        space = enumerate_candidates(state, max_candidates=2)
        changed_cards = copy.deepcopy(space["selection_space"]["cards"])
        changed_cards[0]["id"] = "CARD.FORGED"
        space["selection_space"] = build_space(changed_cards, 0, 3, space["state_hash"])
        request = request_for_indices(space["selection_space"], [8])
        with self.assertRaises(DataContractError):
            journal.begin(state, request, policy=policy(), candidates=space)

    def test_legacy_explicit_v1_journal_remains_readable(self):
        journal = self.journal()
        state = reward()
        legacy = enumerate_candidates(state)
        for key in ("representation", "candidate_count", "enumeration_limit"):
            legacy.pop(key)
        legacy["adapter_version"] = "runsimulator-candidates.v1"
        token = journal.begin(state, {"cmd": "action", "action": "skip_card_reward"}, policy=policy(), candidates=legacy)
        journal.complete(token, terminal(), solver_calls=[solver_call()])
        journal.finalize(terminal(), termination="engine_terminal")
        result = read_decisions(journal.path)[0]
        self.assertTrue(result["training_eligible"])
        self.assertEqual(result["candidate_set"], legacy)
        legacy["representation"] = "future-unchecked-schema"
        with self.assertRaises(DataContractError):
            validate_candidate_set(legacy)

    def test_implicit_read_rechecks_chosen_against_complete_space(self):
        journal = self.journal()
        state = {"type": "decision", "decision": "card_select", "min_select": 0, "max_select": 3,
                 "cards": [{"index": 8}, {"index": 3}, {"index": 5}], "context": {"room_type": "Event"}}
        space = enumerate_candidates(state, max_candidates=2)
        token = journal.begin(state, request_for_indices(space["selection_space"], [8]), policy=policy(), candidates=space)
        journal.complete(token, terminal(), solver_calls=[solver_call()])
        journal.finalize(terminal(), termination="engine_terminal")
        rows = [json.loads(line) for line in journal.path.read_text().splitlines()]
        for row in rows:
            if row["record_type"] in {"decision_started", "decision_completed"}:
                row["chosen"]["request"]["args"]["indices"] = "8,8"
        journal.path.write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")
        with self.assertRaises(DataContractError):
            read_decisions(journal.path)


class SplitTests(unittest.TestCase):
    def test_same_seed_runs_and_branches_never_cross_splits(self):
        rows = [{"seed": f"seed-{i}", "run_id": f"run-{i}", "node": node}
                for i in range(100) for node in range(3)]
        rows += [{"seed": "seed-2", "run_id": "comparison", "node": 99},
                 {"seed": "branch-seed", "lineage_root_seed": "seed-2", "run_id": "branch", "node": 100}]
        splits = split_by_seed(rows)
        self.assertEqual(sum(map(len, splits.values())), len(rows))
        seed_splits = {}
        for split, values in splits.items():
            for value in values:
                seed = value.get("lineage_root_seed", value["seed"])
                seed_splits.setdefault(seed, set()).add(split)
        self.assertTrue(all(len(values) == 1 for values in seed_splits.values()))
        reverse = split_by_seed(list(reversed(rows)))
        self.assertEqual({key: sorted(v["node"] for v in values) for key, values in splits.items()},
                         {key: sorted(v["node"] for v in values) for key, values in reverse.items()})

    def test_renaming_runs_cannot_change_seed_split(self):
        row = {"seed": "permanent", "run_id": "zzz"}
        left = next(k for k, v in split_by_seed([row]).items() if v)
        row["run_id"] = "aaa"
        right = next(k for k, v in split_by_seed([row]).items() if v)
        self.assertEqual(left, right)

    def test_adding_a_branch_preserves_original_seed_assignment(self):
        root = {"seed": "zzz-original", "run_id": "original"}
        before = next(k for k, v in split_by_seed([root]).items() if v)
        branch = {"seed": "aaa-branch", "run_id": "branch", "lineage_root_seed": "zzz-original"}
        after = next(k for k, v in split_by_seed([root, branch]).items() if v)
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
