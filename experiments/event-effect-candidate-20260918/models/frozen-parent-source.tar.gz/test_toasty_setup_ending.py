"""Actual historical public prefix; recorded search envelope, never a natural sample."""
import copy
import json
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence
from run_metadata import file_evidence


class ToastySetupEndingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source_root = Path('D:/sts2-training/staging/uproar-neows-ending/sts2-solver-bridge')
        batch = source_root / 'outputs/defect-contextual-d8-20260914a'
        name = batch.name + '-g00-c04-s13'
        source = source_root / 'outputs' / name
        original = read_json(batch / 'generation-00' / (name + '-audit.json'))
        assert original['audit_passed'] and unchanged(original['actual_source_evidence'])
        rows = read_lines(source / 'trace.jsonl')
        assert len(rows) == 1102
        historical = copy.deepcopy(rows[1099])
        manifest = read_json(source / 'manifest.json')
        label = 'toasty-setup-ending-' + uuid.uuid4().hex[:12]
        bridge = Bridge(label)
        traces = []
        cls.addClassCleanup(bridge.close)
        executor = None
        def send(**request):
            if request['cmd'] == 'solve':
                # Explicitly reuse the old plan to test execution of this exact failure.
                assert request == historical['request'], (request, historical['request'])
                response = copy.deepcopy(historical['response'])
            else:
                response = bridge.send(**request)
            traces.append({'request': copy.deepcopy(request), 'response': copy.deepcopy(response)})
            assert response.get('type') != 'error', response
            return response
        matched = 0
        try:
            for row in rows[:1099]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}:
                    continue
                before = send(**row['request'])
                assert checked_public(before) == checked_public(row['response']), matched
                matched += 1
            cls.gate = len(traces)
            cls.before = copy.deepcopy(before)
            executor = CombatExecutor(send, manifest['solver_requested_config'])
            after = executor.advance(before)
            assert checked_public(after) == checked_public(rows[-1]['response'])
            cls.after = after
            cls.calls = copy.deepcopy(executor.solve_calls)
            cls.traces = copy.deepcopy(traces)
            cls.matched = matched
            # An unrelated action, even a rejected one, cannot reuse the ending receipt.
            invalid = bridge.send(cmd='action', action='play_card', args={'card_index': -1})
            assert invalid.get('type') == 'error', invalid
            stale = bridge.send(cmd='choice_meta')
            assert 'setup_completion' not in stale, stale
            cls.stale_invalidated = True
            assert unchanged(original['actual_source_evidence'])
        finally:
            with (ROOT / 'outputs' / (label + '.json')).open('x', encoding='utf-8') as handle:
                json.dump({'training_eligible': False, 'natural_win_rate_sample': False,
                    'recorded_solver_envelope_is_not_new_search': True,
                    'hidden_state_or_rng_equality_claimed': False,
                    'original_training_result_modified': False,
                    'original_sources': original['actual_source_evidence'],
                    'host': file_evidence(ROOT / 'runtime/host/bin/Debug/net9.0/SolverBridge.dll'),
                    'public_prefix_responses_verified': matched, 'traces': traces,
                    'solver_calls': executor.solve_calls if executor else []}, handle, indent=2)

    def test_original_task_ends_combat_without_first_planned_card(self):
        self.assertEqual(self.matched, 622)
        self.assertEqual(self.after['decision'], 'card_reward')
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.calls[0]['response']['actions'][0]['CardId'], 'BOOT_SEQUENCE')
        requests = [t['request'] for t in self.traces[self.gate:]]
        self.assertEqual([r['cmd'] for r in requests], ['solve', 'choice_meta', 'action', 'choice_meta'])
        self.assertEqual(requests[2], {'cmd': 'action', 'action': 'select_cards', 'args': {'indices': '5'}})
        proof = self.calls[0]['replay'][0]
        self.assertEqual(proof['kind'], 'turn_setup_ended_combat')
        self.assertEqual(proof['selected_cards'][0]['CardId'], 'CHILL')
        self.assertTrue(proof['remaining_battle_plan_stopped'])
        self.assertFalse(proof['first_action_submitted'])
        self.assertTrue(self.stale_invalidated)
        self.assertEqual(validate_replay_evidence(self.calls, self.traces)['replay_count'], 1)

    def test_completion_capture_task_object_and_selector_tampering_rejected(self):
        completion = self.traces[-1]['response']['setup_completion']
        variants = []
        for key, value in completion.items():
            changed = copy.deepcopy(completion)
            changed[key] = not value if type(value) is bool else value + 1 if type(value) is int else [] if isinstance(value, list) else 'wrong'
            variants.append((key, changed))
            missing = copy.deepcopy(completion)
            del missing[key]
            variants.append(('missing-' + key, missing))
        for key in completion['selected_cards'][0]:
            changed = copy.deepcopy(completion)
            value = changed['selected_cards'][0][key]
            changed['selected_cards'][0][key] = value + 1 if type(value) is int else 'wrong'
            variants.append(('token-' + key, changed))
        variants += [('extra', dict(completion, unverified=True)), ('missing', None)]
        for label, changed in variants:
            with self.subTest(label=label):
                observed = copy.deepcopy(self.traces[self.gate + 1:])
                observed[-1]['response']['setup_completion'] = changed
                cursor = 0
                def send(**request):
                    nonlocal cursor
                    self.assertEqual(request, observed[cursor]['request'])
                    result = observed[cursor]['response']
                    cursor += 1
                    return result
                executor = CombatExecutor(send)
                executor.solve_calls = [copy.deepcopy(self.calls[0])]
                with self.assertRaises(RuntimeError):
                    executor.resolve_setup_for_continuation(self.before, executor.solve_calls[0]['response'])

    def test_offline_proof_omission_stale_capture_and_post_ending_actions_rejected(self):
        for variant in ('missing', 'duplicate', 'extra', 'selected', 'capture', 'reuse', 'stale', 'no_completion', 'play_after'):
            with self.subTest(variant=variant):
                calls, traces = copy.deepcopy((self.calls, self.traces))
                proof = calls[0]['replay'][0]
                if variant == 'missing': calls[0]['replay'] = []
                elif variant == 'duplicate': calls[0]['replay'].append(copy.deepcopy(proof))
                elif variant == 'extra': proof['claimed'] = True
                elif variant == 'selected': proof['selected_cards'][0]['CardId'] = 'BOOT_SEQUENCE'
                elif variant == 'capture': proof['setup_origin']['capture_id'] += 1
                elif variant == 'reuse': calls[0]['setup_plan_reuse']['reason'] = 'first_action_fingerprint_changed'
                elif variant == 'stale': traces[-1]['response']['setup_origin']['capture_id'] += 1
                elif variant == 'no_completion': del traces[-1]['response']['setup_completion']
                elif variant == 'play_after': traces.append({'request': {'cmd': 'action', 'action': 'play_card', 'args': {'card_index': 0}}, 'response': copy.deepcopy(self.after)})
                with self.assertRaises(ValueError):
                    validate_replay_evidence(calls, traces)


if __name__ == '__main__': unittest.main()
