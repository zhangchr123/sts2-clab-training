"""Independent 119-feature observational Act-1 survival ridge experiment.

Reuses the audited natural-run loader and ridge implementation. Only the actual
Act-1 chosen action gets its observed Act2-entry label. No deployment, choice,
game worker, RNG draw, counterfactual label, or claim of A10 victory is made.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

from decision_data import split_by_seed, state_hash
from initial_policy import InitialPolicy, POLICY_VERSION
from interaction_features import FEATURE_NAMES, VERSION as TRANSFORM_VERSION, extend_scoring_packet
from run_metadata import atomic_json, file_evidence
from train_act_survival import (TARGET, _act, _hash_evidence, _metrics, _read_lines, _require, _same,
                                load_dataset as load_base_dataset)
from train_ranker import fit, predict, validate_mechanism_facts, validate_model


VERSION = "defect-act1-interaction-survival-ridge-v1"
MODE = "act1_interaction_survival"
SCOPE = {"character": "Defect", "ascension": 10, "mode": "standard", "act": 1}
FEATURE_SOURCE_FILES = ("interaction_features.py", "initial_policy.py", "mechanism_facts.py",
                        "decision_data.py", "selection_space.py", "train_interaction_survival.py",
                        "train_ranker.py", "train_act_survival.py")
TRAINING_SOURCE_FILES = ("train_interaction_survival.py", "train_act_survival.py", "train_ranker.py",
                         "selection_context.py", "replay_evidence.py")


def _code_sources(names):
    return {name: file_evidence(Path(__file__).resolve().parent / name) for name in names}


def _content_identity(sources, names):
    _require(isinstance(sources, dict) and set(sources) == set(names), "Incomplete frozen source set")
    return {name: _hash_evidence(sources[name], name) for name in names}


def _unchanged_sources(sources):
    for evidence in sources:
        _require(_same(file_evidence(evidence["path"]), evidence), "Input changed during feature extension")


def load_interaction_dataset(paths):
    """Extend the shared loader's audited chosen examples, never unchosen rows."""
    paths = [Path(path) for path in paths]
    feature_sources = _code_sources(FEATURE_SOURCE_FILES)
    training_sources = _code_sources(TRAINING_SOURCE_FILES)
    dataset = load_base_dataset(paths)
    # The base loader checks every scoring prior, its live hash, and all source
    # files. Read its already audited path once; do not assume the default CSV.
    _unchanged_sources(dataset["sources"])
    prior = _read_lines(paths[0] / "policy.jsonl")[0]["scoring"]["prior_source"]
    fallback = InitialPolicy(prior_path=prior.get("path"))
    _require(_same(fallback.prior.source, prior)
             and fallback.prior.source["sha256"] == dataset["feature_prior_sha256"]
             and _same(fallback.mechanism_source, dataset["feature_mechanism_facts"]),
             "Recomputed base features differ from the audited prior or facts")
    records = {row["decision_id"]: row for row in dataset["records"]}
    examples, transform = [], None
    for example in dataset["examples"]:
        record = records[example["decision_id"]]
        packet = fallback.score_requests(record["state"], [record["chosen"]["request"]],
            selection_purpose=record["execution"].get("selection_purpose"))
        current = packet["scores"][0]
        _require(_same(current["features"], example["features"])
                 and current["candidate_id"] == example["candidate_id"],
                 "Audited chosen base features drifted before interaction extension")
        extended = extend_scoring_packet(record["state"], packet)
        source = extended["interaction_feature_source"]
        if transform is None:
            transform = copy.deepcopy(source)
        _require(_same(transform, source), "Feature transform changed within input data")
        row = extended["scores"][0]
        examples.append({**copy.deepcopy(example), "features": row["features"],
            "base_features_sha256": state_hash(current["features"]),
            "interaction_missing": row["interaction_missing"]})
    _unchanged_sources(dataset["sources"])
    _require(_same(feature_sources, _code_sources(FEATURE_SOURCE_FILES))
             and _same(training_sources, _code_sources(TRAINING_SOURCE_FILES)),
             "Source code changed during dataset loading")
    return {**dataset, "examples": examples, "feature_prior_source": copy.deepcopy(prior),
            "feature_transform": transform, "feature_transform_sources": feature_sources,
            "training_sources": training_sources}


def train(paths, output, *, regularization=1.0):
    _require(not Path(output).exists(), "Choose a new model output path")
    _require(type(regularization) in (int, float) and regularization == 1.,
             "This predeclared experiment fixes regularization at 1.0")
    dataset = load_interaction_dataset(paths)
    grouped = split_by_seed(dataset["records"])
    groups = {key: {r["run_id"] for r in rows} for key, rows in grouped.items()}
    examples = {key: [e for e in dataset["examples"] if e["run_id"] in runs] for key, runs in groups.items()}
    train_seeds = {e["seed"] for e in examples["train"]}
    _require(len(train_seeds) >= 10, "Interaction survival requires at least 10 clean training seeds")
    _require({e["target"] for e in examples["train"]} == {0., 1.},
             "Training seeds must contain both actual Act2 entry and Act1 defeat")
    model = fit(examples["train"], FEATURE_NAMES, 1.)
    model.update(format=VERSION, mode=MODE, target_semantics=TARGET,
        feature_policy_version=TRANSFORM_VERSION, base_feature_policy_version=POLICY_VERSION,
        feature_prior_sha256=dataset["feature_prior_sha256"], feature_prior_source=dataset["feature_prior_source"],
        feature_mechanism_facts=dataset["feature_mechanism_facts"],
        feature_transform=dataset["feature_transform"], feature_transform_sources=dataset["feature_transform_sources"],
        training_sources=dataset["training_sources"], frozen_followup=dataset["frozen_followup"],
        calibrated_probability=False, counterfactual_labels=False, chosen_action_is_optimal_label=False,
        deployment_scope=copy.deepcopy(SCOPE), automatic_deployment=False, regularization=1.,
        weighting="equal_seed_then_equal_run_then_equal_Act1_chosen_decision",
        normalization="train_decisions_only_shared_ridge_fit",
        training_seed_count=len(train_seeds), sources=dataset["sources"],
        split_runs={k: sorted(v) for k, v in groups.items()},
        split_seeds={k: sorted({r["seed"] for r in rows}) for k, rows in grouped.items()},
        observed_labels={run: label for run, label in dataset["labels"].items() if run not in groups["test"]},
        test_label_evidence_retained_in_sources_only=True,
        validation={k: _metrics(model, examples[k]) for k in ("train", "validation")},
        test_used_for_fit_or_tuning=False,
        limitations=["Act1_survival_is_not_A10_victory", "uncalibrated_relative_score",
            "observational_return_is_not_causal_action_value", "changing_policy_changes_the_label_distribution",
            "short_horizon_may_avoid_growth_needed_in_later_acts", "whole_run_errors_excluded_even_after_Act2",
            "future_actions_require_prospective_full_A10_evaluation", "evaluated_unchosen_actions_have_no_labels",
            "interactions_do_not_remove_action_support_or_confounding_limits",
            "orb_source_coverage_is_only_three_verified_direct_Frost_card_ids"])
    _unchanged_sources(dataset["sources"])
    _require(_same(dataset["feature_transform_sources"], _code_sources(FEATURE_SOURCE_FILES))
             and _same(dataset["training_sources"], _code_sources(TRAINING_SOURCE_FILES)),
             "Source code changed during training")
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    atomic_json(output, model)
    return model


class InteractionSurvivalScorer:
    """Read-only request scoring; no choice, deployment, worker or RNG draw."""
    def __init__(self, path, *, fallback=None):
        self.source = file_evidence(path)
        self.model = json.loads(Path(path).read_text(encoding="utf-8"))
        _require(_same(file_evidence(path), self.source), "Model file changed during loading")
        self.fallback = fallback or InitialPolicy()
        model = self.model
        validate_model(model)
        _require(model.get("format") == VERSION and model.get("mode") == MODE
                 and model.get("target_semantics") == TARGET, "Wrong interaction survival model format or target")
        _require(model.get("feature_policy_version") == TRANSFORM_VERSION
                 and model.get("base_feature_policy_version") == POLICY_VERSION
                 and model["feature_names"] == list(FEATURE_NAMES), "Model feature version or schema differs")
        _require(model.get("deployment_scope") == SCOPE and model.get("automatic_deployment") is False
                 and all(model.get(k) is False for k in ("calibrated_probability", "counterfactual_labels",
                                                       "chosen_action_is_optimal_label", "test_used_for_fit_or_tuning")),
                 "Invalid interaction model scope or label/deployment semantics")
        _require(type(model.get("regularization")) in (int, float) and model["regularization"] == 1.,
                 "Interaction model regularization differs from the fixed experiment")
        _require(isinstance(model.get("frozen_followup"), dict) and bool(model["frozen_followup"]),
                 "Missing frozen follow-up policy")
        self.facts = validate_mechanism_facts(model.get("feature_mechanism_facts"))
        transform = model.get("feature_transform")
        _require(isinstance(transform, dict) and transform.get("version") == TRANSFORM_VERSION
                 and transform.get("base_feature_version") == POLICY_VERSION
                 and transform.get("feature_names") == list(FEATURE_NAMES)
                 and _same(transform.get("mechanism_facts"), self.facts), "Invalid frozen feature transform")
        definition = {k: v for k, v in transform.items() if k not in {"definition_sha256", "mechanism_facts"}}
        _require(transform.get("definition_sha256") == state_hash(definition), "Feature definition hash mismatch")
        self._model_hash = state_hash(model)
        self._check_features()

    def _check_features(self):
        _require(state_hash(self.model) == self._model_hash, "Loaded interaction model changed in memory")
        _require(_same(self.facts, self.fallback.mechanism_source)
                 and self.model.get("feature_prior_sha256") == self.fallback.prior.source["sha256"]
                 and _same(self.model.get("feature_prior_source"), self.fallback.prior.source),
                 "Live base facts or prior differ from the frozen interaction model")
        _require(_same(_content_identity(self.model.get("feature_transform_sources"), FEATURE_SOURCE_FILES),
                       _content_identity(_code_sources(FEATURE_SOURCE_FILES), FEATURE_SOURCE_FILES)),
                 "Live feature source code differs from the frozen interaction model")

    def score_requests(self, state, requests, *, character, mode, selection_purpose=None):
        self._check_features()
        _require(character == "Defect" and mode == "standard" and _act(state) == 1
                 and state.get("type") == "decision" and state.get("decision") != "game_over"
                 and state.get("context", {}).get("combat_in_progress") is False,
                 "Interaction survival only scores actual noncombat Act1 Defect A10 choices")
        base = self.fallback.score_requests(state, requests, selection_purpose=selection_purpose)
        packet = extend_scoring_packet(state, base)
        _require(_same(packet["interaction_feature_source"], self.model["feature_transform"]),
                 "Recomputed interaction definition differs from the frozen model")
        packet.update(advisor_format=VERSION, target_semantics=TARGET, calibrated=False,
            automatic_deployment=False, act1_proxy_only=True, policy_id=VERSION, policy_version=VERSION,
            score_semantics="uncalibrated_Act1_interaction_survival_proxy_not_A10_win_probability",
            model={**copy.deepcopy(self.source), "mode": MODE, "calibrated_probability": False},
            required_followup=copy.deepcopy(self.model["frozen_followup"]), interaction_scores_applied=True)
        for row, original in zip(packet["scores"], base["scores"]):
            row["rule_score"] = row["score"]
            row["base_features_sha256"] = state_hash(original["features"])
            row["score"] = predict(self.model, row["features"])
            _require(math.isfinite(row["score"]), "Nonfinite interaction model prediction")
            row["model_coverage"] = {"out_of_training_range": [name for name, lo, hi in
                zip(self.model["feature_names"], self.model["feature_min"], self.model["feature_max"])
                if not lo <= row["features"][name] <= hi], "uncertainty_calibrated": False}
            row["mechanism_evidence_source"] = "public feature rules; not the model's reasoning"
        skip = next((row["score"] for row in packet["scores"] if row["is_skip"]), None)
        for row in packet["scores"]:
            row["delta_from_skip"] = None if skip is None else row["score"] - skip
        return packet


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", nargs="+")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    model = train(args.runs, args.output)
    print(json.dumps({"format": model["format"], "training_seed_count": model["training_seed_count"],
        "validation": model["validation"], "automatic_deployment": False}))


if __name__ == "__main__":
    main()
