"""Exercise the real natural-run policy factory and retained hard cap."""
import json
from pathlib import Path
import tempfile
import unittest
from decision_data import DataContractError
from sample_runs import build_policy
from test_initial_policy import card,state
import event_risk_policy as p

class EventRiskBindingTests(unittest.TestCase):
    def test_natural_factory_loads_bound_289_model_and_preserves_cap(self):
        config=json.loads((p.ROOT/'configs/defect-v3-base.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory(dir=p.ROOT/'outputs') as folder:
            path=Path(folder)/'model.json';path.write_text(json.dumps(p.make_artifact(dict.fromkeys(p.PARAMETERS,4.),config,training={'synthetic':True})),encoding='utf-8')
            policy=build_policy('binding-test',config,ascension=10,epsilon=0.,model_path=path)
            self.assertIsInstance(policy,p.EventRiskSelectionPolicy)
            self.assertEqual(policy.provenance['id'],p.VERSION)
            s=state([card('BALL_LIGHTNING',damage=7)]);s['context']['act']=2
            s['player'].update(deck=[card('DEFEND_DEFECT',block=5)]*36,deck_size=36)
            self.assertEqual(policy.choose(s)['request']['action'],'skip_card_reward')
            with self.assertRaises(DataContractError):build_policy('binding-test',config,ascension=9,epsilon=0.,model_path=path)
            with self.assertRaises(DataContractError):build_policy('binding-test',config,ascension=10,epsilon=.1,model_path=path)

    def test_real_factory_avoids_original_fatal_bridge_choice_with_all_289_weights_preserved(self):
        import test_event_risk_guard as examples
        examples.EventRiskGuardTests.setUpClass()
        record,scoring,weights=next(c for c in examples.EventRiskGuardTests.cases if c[0]['next_state']['player']['hp']==0)
        config=json.loads((p.ROOT/'configs/defect-v3-base.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory(dir=p.ROOT/'outputs') as folder:
            path=Path(folder)/'model.json'
            artifact=p.make_artifact(weights,config,training={'recorded_training_policy_binding':True})
            path.write_text(json.dumps(artifact),encoding='utf-8')
            policy=build_policy('real-bridge-binding',config,ascension=10,epsilon=0.,model_path=path)
            actual=policy.choose(record['state'])
            self.assertEqual(actual['request']['args']['option_index'],0)
            self.assertEqual(artifact['parameters'],weights)
            self.assertTrue(any(r.get('event_risk_guard',{}).get('hard_blocked') for r in actual['scoring']['scores']))
            artifact['event_risk_contract']={}
            path.write_text(json.dumps(artifact),encoding='utf-8')
            with self.assertRaises(DataContractError):build_policy('invalid-risk-contract',config,ascension=10,epsilon=0.,model_path=path)

if __name__=='__main__':unittest.main()
