"""Audit explicit removals and the original LordsParasol automatic shop entry."""
from decision_data import DataContractError

CONTRACT='original-removal-ui-lifecycle-v1'
PARASOL_CONTRACT='parasol-entry-observed-removal-v1'


def require(ok,message):
    if not ok:raise DataContractError('Merchant removal lifecycle: '+message)


def shop_fields(state):
    require(state.get('card_removal_contract')==CONTRACT,'missing lifecycle contract')
    count=state.get('card_shop_removals_used')
    require(type(count) is int and count>=0,'missing original removal counter')
    used=state.get('card_removal_used');available=state.get('card_removal_available')
    require(type(available) is bool,'missing availability')
    if state.get('card_removal_cost') is None:
        require(used is None and not available,'missing entry marked available')
    else:
        require(type(used) is bool and available is (not used),'used flag contradicts availability')
    return count,used,available


def has_parasol(state):
    return any(r.get('id')=='RELIC.LORDS_PARASOL' for r in state.get('player',{}).get('relics',[]))


def room_key(state):
    context=state.get('context',{})
    return context.get('act'),context.get('floor'),context.get('room_type')


def parasol_completion(before,after,request,entry):
    require(entry is not None and before is not None,'counter change has no observed automatic entry')
    require(room_key(before)==room_key(after)==entry['room'] and entry['room'][2]=='Shop',
            'automatic removal changed rooms')
    require(before.get('decision')=='card_select' and before.get('min_select')==1 and before.get('max_select')==1,
            'automatic removal lacks mandatory single selection')
    require(has_parasol(before) and has_parasol(after),'automatic removal relic missing')
    require(request.get('cmd')=='action' and request.get('action')=='select_cards','automatic removal not selected')
    indices=request.get('args',{}).get('indices')
    require(isinstance(indices,str) and indices.isascii() and indices.isdecimal(),'invalid automatic removal index')
    selected=int(indices)
    cards=before.get('cards',[]);deck=before['player'].get('deck',[])
    require(before['player'].get('deck_size')==len(deck) and after['player'].get('deck_size')==len(deck)-1,
            'automatic removal did not remove one permanent card')
    require(all(type(c.get('is_removable')) is bool for c in deck),'missing original removal eligibility')
    removable=sorted(((i,c) for i,c in enumerate(deck) if c['is_removable']),
                     key=lambda item:-999999999 if item[1].get('type')=='Curse' else item[0])
    require(len(cards)==len(removable) and 0<=selected<len(cards),'automatic selection is not the removable deck')
    keys=('id','cost','type','upgraded','stats','keywords','current_upgrade_level')
    for index,(card,(_,original)) in enumerate(zip(cards,removable)):
        require(card.get('index')==index and all(card.get(k)==original.get(k) for k in keys),
                'automatic selection identity or order differs from removable deck')
    deck_index=removable[selected][0]
    require(after['player'].get('deck')==deck[:deck_index]+deck[deck_index+1:],
            'automatic removal changed a different card or additional deck state')
    require(type(before['player'].get('gold')) is int and before['player']['gold']==after['player'].get('gold'),
            'automatic free removal charged gold')
    count,used,available=shop_fields(after)
    require(type(entry['count']) is int and count==entry['count']+1,'automatic removal counter is not exactly plus one')
    require(used is True and available is False,'automatic removal did not consume the shop service')
    return dict(entry_trace_index=entry['index'],room=list(entry['room']),count_before=entry['count'],count_after=count,
                selected_index=selected,removed_card_id=cards[selected]['id'],contract=PARASOL_CONTRACT)


def validate_merchant_lifecycle(traces):
    current=None;pending=None;last_count=None;visit_used=None;automatic=None;saw_start=False
    successes=cancellations=rejections=shops=0;automatic_proofs=[]
    for i,row in enumerate(traces):
        request=row.get('request') or {};response=row.get('response') or {}
        if request.get('cmd')=='start_run':
            current=None;pending=None;last_count=None;visit_used=None;automatic=None;saw_start=True
        if request.get('cmd')=='enter_room':
            require(pending is None,'fixture entered a room with removal pending')
            visit_used=None;automatic=None
        action=request.get('action') if request.get('cmd')=='action' else None
        if action=='select_map_node' and current and current.get('decision')=='map_select' and has_parasol(current):
            if response.get('type')=='decision' and response.get('context',{}).get('room_type')=='Shop':
                require(pending is None and automatic is None,'overlapping automatic shop entry')
                require(response.get('context',{}).get('combat_in_progress') is False,'automatic shop entry is in combat')
                require(room_key(current)!=room_key(response),'automatic shop entry did not change rooms')
                automatic=dict(index=i,room=room_key(response),count=last_count if last_count is not None else (0 if saw_start else None))
        if action=='remove_card' and current and current.get('decision')=='shop':
            count,used,available=shop_fields(current)
            if not available:
                require(response.get('type')=='error','unavailable service was executed')
                rejections+=1
            elif response.get('type')!='error':
                require(pending is None,'overlapping removal tasks')
                pending=(count,used)
        if response.get('type')!='decision':continue
        if response.get('decision')=='shop':
            count,used,available=shop_fields(response);shops+=1
            require(last_count is None or count>=last_count,'original count decreased')
            if pending is None and automatic is not None and count!=automatic['count']:
                proof=parasol_completion(current,response,request,automatic)
                proof['completion_trace_index']=i;automatic_proofs.append(proof)
                pending=(automatic['count'],False)
            if pending is None and last_count is not None:
                require(count==last_count,'original count changed without a removal request')
            if pending is not None:
                before,old_used=pending
                require(count in (before,before+1),'one removal changed the counter more than once')
                if count==before+1:
                    require(used is True and available is False,'successful removal did not consume this shop service')
                    successes+=1
                else:
                    require(used==old_used and available is True,'canceled removal consumed the service')
                    cancellations+=1
                pending=None
            require(visit_used is not True or used is True,'used service became available in the same visit')
            visit_used=used;last_count=count;automatic=None
        elif response.get('context',{}).get('room_type')!='Shop':
            visit_used=None;automatic=None
            if pending is not None:
                require(response.get('decision')=='game_over','removal left the shop without an observed completion')
                pending=None
        current=response
    require(pending is None,'trace ended with an unobserved removal completion')
    require(automatic is None,'trace ended with an unobserved automatic shop entry')
    return dict(passed=True,contract=CONTRACT,shop_states=shops,successful_removals=successes,
                canceled_removals=cancellations,rejected_used_requests=rejections,
                automatic_parasol_removals=len(automatic_proofs),automatic_parasol_proofs=automatic_proofs)
