"""Synthetic, temporary-data checks for model provenance and split correctness."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from decision_data import DataContractError, DecisionJournal, split_by_seed
from initial_policy import FEATURE_NAMES, POLICY_VERSION, InitialPolicy
from selection_context import direct_action_evidence
from test_decision_data import solver_call
from test_initial_policy import card, state as reward_state
from train_ranker import (VERSION, SmallValuePolicy, examples_for, fit, load_runs,
                          predict, train, vector)


def seed_in(split, index=0):
    matches = []
    for number in range(10000):
        seed = f"ranker-test-{number}"
        record = {"seed": seed, "run_id": seed}
        if split_by_seed([record])[split]:
            matches.append(seed)
        if len(matches) > index:
            return matches[index]
    raise AssertionError("Could not find deterministic split seed")


class RankerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def run_fixture(self, name, seed=None, *, victory=False, steps=1,
                    damage=6, epsilon=.2, termination="engine_terminal"):
        """Fabricate auditable wire records only inside the test temp directory."""
        seed = seed or seed_in("train")
        path = self.root / name
        policy = InitialPolicy(prior_path=None, epsilon=epsilon, random_seed=seed)
        states = [reward_state([card("TEST", damage=damage + index)]) for index in range(steps)]
        picks = [policy.choose(current) for current in states]
        metadata = {"run_id": name, "seed": seed, "character": "Defect", "ascension": 0,
                    "mode": "standard", "versions": {"engine": "synthetic-engine",
                        "solver": "synthetic-solver", "bridge": "synthetic-bridge"},
                    "solver_requested_config": {"budget_ms": 1000},
                    "provenance": picks[0]["policy_provenance"]}
        final = {"type": "decision", "decision": "game_over", "victory": victory,
                 "context": {"ascension": 0}, "player": {"hp": 40 if victory else 0}}
        policy_rows = []
        with DecisionJournal(path, metadata) as journal:
            for index, (current, picked) in enumerate(zip(states, picks)):
                token = journal.begin(current, picked["request"], policy=picked["policy_provenance"])
                policy_rows.append({"decision_id": token, **picked, "selection_context": None})
                journal.complete(token, final if index + 1 == steps else states[index + 1],
                                 solver_calls=[solver_call()], execution={"selection_context": None, "selection_purpose": None,
                                     "direct_action_result": direct_action_evidence(final if index + 1 == steps else states[index + 1])})
            journal.finalize(final, termination=termination)
        (path / "policy.jsonl").write_text("".join(json.dumps(row) + "\n" for row in policy_rows), encoding="utf-8")
        return path

    def model_fixture(self, name="model.json", **updates):
        count = len(FEATURE_NAMES)
        model = {"format": VERSION, "feature_policy_version": POLICY_VERSION,
                 "feature_prior_sha256": None,
                 "feature_mechanism_facts": InitialPolicy(prior_path=None).mechanism_source,
                 "feature_names": list(FEATURE_NAMES), "means": [0.] * count,
                 "scales": [1.] * count, "weights": [0.] * (count + 1),
                 "feature_min": [-100.] * count, "feature_max": [100.] * count,
                 "mode": "prior", "calibrated_probability": False}
        model.update(updates)
        path = self.root / name
        path.write_text(json.dumps(model), encoding="utf-8")
        return path

    def test_prior_uses_all_candidates_outcome_only_observed_action(self):
        records, scores, _ = load_runs([self.run_fixture("clean")])
        self.assertTrue(records[0]["training_eligible"])
        prior = examples_for(records, scores, "prior")
        self.assertEqual(len(prior), 2)  # exported card plus explicit skip
        self.assertAlmostEqual(sum(row["weight"] for row in prior), 1.)
        self.assertCountEqual([row["target"] for row in prior],
                              [row["score"] for row in scores[records[0]["decision_id"]]["scoring"]["scores"]])
        outcome = examples_for(records, scores, "outcome")
        self.assertEqual(len(outcome), 1)
        self.assertEqual(outcome[0]["target"], 0.)
        self.assertIsNone(records[0]["chosen_is_optimal"])

    def implicit_fixture(self):
        from selection_policy import SelectionPolicy
        policy = SelectionPolicy(InitialPolicy(prior_path=None, epsilon=.1, random_seed="implicit-fixture"), max_evaluations=16)
        current = reward_state([card(f"TEST{i}", damage=i) for i in range(15)])
        current.update(decision="card_select", min_select=0, max_select=15)
        picked = policy.choose(current)
        metadata = {"run_id":"implicit", "seed":seed_in("train"), "character":"Defect", "ascension":0,
                    "mode":"standard", "versions":{"engine":"synthetic", "solver":"synthetic", "bridge":"synthetic"},
                    "solver_requested_config":{"budget_ms":1000}, "provenance":policy.provenance}
        final = {"type":"decision", "decision":"game_over", "victory":False,
                 "context":{"combat_in_progress":False}, "player":{"hp":0}}
        path = self.root / "implicit"
        with DecisionJournal(path, metadata) as journal:
            token = journal.begin(current, picked["request"], policy=picked["policy_provenance"])
            journal.complete(token, final, solver_calls=[solver_call()], execution={"selection_context": None, "selection_purpose": None, "direct_action_result": direct_action_evidence(final)})
            journal.finalize(final, termination="engine_terminal")
        (path / "policy.jsonl").write_text(json.dumps({"decision_id":token, **picked, "selection_context": None}) + "\n", encoding="utf-8")
        return load_runs([path])

    def test_implicit_prior_uses_only_evaluated_actions_and_outcome_only_chosen(self):
        records, scores, _ = self.implicit_fixture()
        prior = examples_for(records, scores, "prior")
        self.assertLessEqual(len(prior), 16)
        self.assertGreater(len(prior), 0)
        self.assertAlmostEqual(sum(row["weight"] for row in prior), 1.)
        self.assertEqual(len(examples_for(records, scores, "outcome")), 1)

    def test_implicit_scoring_cannot_claim_full_coverage_or_forge_candidates(self):
        records, scores, _ = self.implicit_fixture()
        token = records[0]["decision_id"]
        for field, value in (("evaluated_candidates_complete", True), ("candidate_count", 12)):
            changed = copy.deepcopy(scores)
            changed[token]["scoring"][field] = value
            with self.assertRaises(DataContractError):
                examples_for(records, changed, "prior")
        changed = copy.deepcopy(scores)
        changed[token]["scoring"]["scores"][0]["request"] = {"cmd":"action", "action":"select_cards", "args":{"indices":"0,0"}}
        with self.assertRaises(DataContractError):
            examples_for(records, changed, "prior")

    def test_model_subset_scoring_preserves_frozen_features_and_identity(self):
        current = reward_state([card("TEST", damage=9)])
        policy = SmallValuePolicy(self.model_fixture(), fallback=InitialPolicy(prior_path=None), epsilon=0)
        full = policy.score(current)
        subset = policy.score_requests(current, [full["scores"][0]["request"]])
        self.assertFalse(subset["evaluated_candidates_complete"])
        self.assertEqual(subset["model"]["sha256"], policy.sha256)
        self.assertEqual(subset["scores"][0]["score"], full["scores"][0]["score"])
        self.assertEqual(subset["feature_policy_version"], POLICY_VERSION)

    def test_environment_failure_is_not_a_defeat_target(self):
        records, scores, _ = load_runs([self.run_fixture("failed", termination="environment_error")])
        self.assertFalse(records[0]["training_eligible"])
        self.assertEqual(records[0]["run_outcome"]["outcome"], "environment_error")
        self.assertEqual(examples_for(records, scores, "outcome"), [])

    def test_prior_rejects_llm_or_deployment_journal_disguised_as_rule_scores(self):
        records, scores, _ = load_runs([self.run_fixture("clean")])
        for changes in ({"kind": "llm", "llm_involved": True}, {"origin": "deployment"}):
            with self.subTest(changes=changes):
                contaminated = copy.deepcopy(records)
                contaminated[0]["policy_provenance"].update(changes)
                contaminated[0]["training_eligible"] = False
                contaminated[0]["training_exclusion_reasons"] = ["run_contains_non_natural_or_non_training_policy"]
                with self.assertRaises(DataContractError):
                    examples_for(contaminated, scores, "prior")

    def test_scoring_rows_must_match_recorded_state_choice_and_feature_version(self):
        records, scores, _ = load_runs([self.run_fixture("clean")])
        token = records[0]["decision_id"]
        mutations = {
            "stale_state": lambda row: row["scoring"].update(state_hash="0" * 64),
            "wrong_feature_version": lambda row: row["scoring"].update(policy_version="obsolete"),
            "wrong_choice": lambda row: row.update(candidate_id="invented"),
            "wrong_request": lambda row: row.update(request={"cmd": "action", "action": "leave_room"}),
            "wrong_candidate_request": lambda row: row["scoring"]["scores"][0].update(
                request={"cmd": "action", "action": "leave_room"}),
            "different_policy": lambda row: row["policy_provenance"].update(epsilon=.9),
        }
        for label, mutate in mutations.items():
            with self.subTest(case=label):
                changed = copy.deepcopy(scores)
                mutate(changed[token])
                with self.assertRaises(DataContractError):
                    examples_for(records, changed, "prior")

    def test_training_features_and_targets_are_finite_and_exact_schema(self):
        records, scores, _ = load_runs([self.run_fixture("clean")])
        token = records[0]["decision_id"]
        mutations = {
            "missing_feature": lambda row: row["features"].pop(FEATURE_NAMES[0]),
            "unknown_feature": lambda row: row["features"].update(hidden_rng_word=123.),
            "nonfinite_feature": lambda row: row["features"].update({FEATURE_NAMES[0]: float("inf")}),
            "nonfinite_target": lambda row: row.update(score=float("nan")),
        }
        for label, mutate in mutations.items():
            with self.subTest(case=label):
                changed = copy.deepcopy(scores)
                mutate(changed[token]["scoring"]["scores"][0])
                with self.assertRaises(DataContractError):
                    examples_for(records, changed, "prior")

    def test_vector_does_not_silently_fill_missing_features(self):
        with self.assertRaises(DataContractError):
            vector({"x": 3.}, ["x", "y"])

    def test_validation_and_test_do_not_change_fit_or_normalization(self):
        training = [self.run_fixture("training-a", seed_in("train", 0), damage=3),
                    self.run_fixture("training-b", seed_in("train", 1), damage=9)]
        ordinary = [self.run_fixture("validation-a", seed_in("validation"), damage=5),
                    self.run_fixture("test-a", seed_in("test"), damage=7)]
        extreme = [self.run_fixture("validation-b", seed_in("validation"), damage=5000),
                   self.run_fixture("test-b", seed_in("test"), damage=9000)]
        left = train(training + ordinary, self.root / "ordinary.json")
        right = train(training + extreme, self.root / "extreme.json")
        for key in ("weights", "means", "scales", "feature_min", "feature_max"):
            self.assertEqual(left[key], right[key], key)
        self.assertFalse(left["test_used_for_fit_or_tuning"])
        self.assertNotIn("test", left["validation"])
        sets = [set(left["split_runs"][key]) for key in ("train", "validation", "test")]
        self.assertFalse(sets[0] & sets[1] or sets[0] & sets[2] or sets[1] & sets[2])

    def test_outcome_freeze_allows_rng_progress_across_clean_seeds(self):
        paths = [self.run_fixture(f"outcome-{i}", seed_in("train", i), steps=2,
                                  victory=i % 2 == 0) for i in range(10)]
        model = train(paths, self.root / "outcome.json", mode="outcome")
        self.assertEqual(model["mode"], "outcome")
        self.assertEqual(model["validation"]["train"]["examples"], 20)
        self.assertFalse(model["counterfactual_labels"])
        self.assertFalse(model["calibrated_probability"])

    def test_outcome_freeze_rejects_different_epsilon(self):
        paths = [self.run_fixture(f"mixed-{i}", seed_in("train", i),
                                  victory=i % 2 == 0, epsilon=.9 if i == 9 else .2)
                 for i in range(10)]
        with self.assertRaises(DataContractError):
            train(paths, self.root / "mixed.json", mode="outcome")

    def test_outcome_validation_must_use_the_same_frozen_policy(self):
        paths = [self.run_fixture(f"frozen-train-{i}", seed_in("train", i),
                                  victory=i % 2 == 0, epsilon=.2) for i in range(10)]
        paths.append(self.run_fixture("different-validation-policy", seed_in("validation"),
                                      victory=True, epsilon=.9))
        with self.assertRaises(DataContractError):
            train(paths, self.root / "different-validation.json", mode="outcome")

    def test_outcome_cannot_mix_difficulty_character_or_mode(self):
        paths = [self.run_fixture(f"conditions-{i}", seed_in("train", i), victory=i % 2 == 0) for i in range(10)]
        journal_path = paths[-1] / "decisions.jsonl"
        original = journal_path.read_text(encoding="utf-8")
        for key, value in (("ascension", 1), ("character", "Ironclad"), ("mode", "daily")):
            with self.subTest(key=key):
                rows = [json.loads(line) for line in original.splitlines()]
                rows[0]["metadata"][key] = value
                journal_path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
                with self.assertRaisesRegex(DataContractError, "cannot mix"):
                    train(paths, self.root / f"invalid-{key}.json", mode="outcome")
        journal_path.write_text(original, encoding="utf-8")

    def test_model_rejects_changed_feature_prior_csv(self):
        prior_path = self.root / "card-prior.csv"
        original = "InternalName,胜率,选取率,略过率\nTEST,50,20,80\n"
        prior_path.write_text(original, encoding="utf-8")
        frozen = InitialPolicy(prior_path=prior_path)
        model_path = self.model_fixture(feature_prior_sha256=frozen.prior.source["sha256"])
        SmallValuePolicy(model_path, fallback=frozen)
        prior_path.write_text(original.replace("TEST,50", "TEST,75"), encoding="utf-8")
        with self.assertRaises(DataContractError):
            SmallValuePolicy(model_path, fallback=InitialPolicy(prior_path=prior_path))

    def test_loaded_model_rejects_silent_zip_truncation_and_invalid_scales(self):
        count = len(FEATURE_NAMES)
        variants = ({"weights": [0.] * count}, {"means": []}, {"scales": [0.] * count},
                    {"scales": [-1.] * count}, {"weights": [float("nan")] * (count + 1)},
                    {"feature_names": [FEATURE_NAMES[0]] * count}, {"feature_min": []})
        for index, updates in enumerate(variants):
            with self.subTest(updates=list(updates)):
                path = self.model_fixture(f"bad-{index}.json", **updates)
                with self.assertRaises(DataContractError):
                    SmallValuePolicy(path, fallback=InitialPolicy(prior_path=None))

    def test_small_policy_preserves_uniform_ties_and_exploration_contract(self):
        path = self.model_fixture()
        current = reward_state()  # two cards and skip, tied under zero weights
        left = SmallValuePolicy(path, fallback=InitialPolicy(prior_path=None), epsilon=.2, seed="ties")
        right = SmallValuePolicy(path, fallback=InitialPolicy(prior_path=None), epsilon=.2, seed="ties")
        chosen = [left.choose(current) for _ in range(60)]
        self.assertEqual(chosen, [right.choose(current) for _ in range(60)])
        self.assertEqual(len({row["candidate_id"] for row in chosen}), 3)
        for index, row in enumerate(chosen):
            self.assertAlmostEqual(row["exploration"]["chosen_probability"], 1 / 3)
            self.assertEqual(row["exploration"]["greedy_tie_count"], 3)
            self.assertEqual(row["exploration"]["choice_count"], index)
            self.assertIs(row["policy_provenance"]["llm_involved"], False)

    def test_small_policy_scores_predictions_and_relative_skip(self):
        weights = [0.] * (len(FEATURE_NAMES) + 1)
        weights[0] = 4.
        weights[1 + FEATURE_NAMES.index("base_damage_per_cost")] = 2.
        path = self.model_fixture(weights=weights)
        policy = SmallValuePolicy(path, fallback=InitialPolicy(prior_path=None), epsilon=0)
        scoring = policy.score(reward_state())
        baseline = next(row["score"] for row in scoring["scores"] if row["is_skip"])
        for row in scoring["scores"]:
            self.assertEqual(row["score"], predict(policy.model, row["features"]))
            self.assertEqual(row["delta_from_skip"], row["score"] - baseline)
            self.assertIn("prior_score", row)
            self.assertFalse(row["model_coverage"]["uncertainty_calibrated"])
        self.assertFalse(scoring["model"]["calibrated_probability"])

    def test_training_freezes_facts_and_model_exports_the_same_feature_source(self):
        model = train([self.run_fixture("facts")], self.root / "facts-model.json")
        fallback = InitialPolicy(prior_path=None)
        self.assertEqual(model["feature_mechanism_facts"], fallback.mechanism_source)
        policy = SmallValuePolicy(self.root / "facts-model.json", fallback=fallback)
        self.assertEqual(policy.provenance["mechanism_facts"], fallback.mechanism_source)
        full = policy.score(reward_state())
        subset = policy.score_requests(reward_state(), [full["scores"][0]["request"]])
        for packet in (full, subset):
            self.assertEqual(packet["mechanism_facts"], model["feature_mechanism_facts"])
            self.assertEqual(packet["model"]["feature_mechanism_facts"], model["feature_mechanism_facts"])

    def test_training_rejects_missing_or_mismatched_facts_even_outside_training_split(self):
        paths = [self.run_fixture("facts-" + split, seed_in(split)) for split in ("train", "validation", "test")]
        records, scores, sources = load_runs(paths)
        for split in ("train", "validation", "test"):
            for missing in (False, True):
                with self.subTest(split=split, missing=missing):
                    changed, policy_rows = copy.deepcopy(records), copy.deepcopy(scores)
                    row = next(r for r in changed if r["run_id"] == "facts-" + split)
                    picked = policy_rows[row["decision_id"]]
                    facts = None if missing else {**picked["scoring"]["mechanism_facts"], "registry_sha256": "0" * 64}
                    # Keep both provenance copies consistent: the cross-split
                    # registry check must reject this independently.
                    row["policy_provenance"]["mechanism_facts"] = copy.deepcopy(facts)
                    picked["policy_provenance"]["mechanism_facts"] = copy.deepcopy(facts)
                    picked["scoring"]["mechanism_facts"] = copy.deepcopy(facts)
                    with patch("train_ranker.load_runs", return_value=(changed, policy_rows, sources)):
                        with self.assertRaises(DataContractError):
                            train(paths, self.root / (split + str(missing) + ".json"))

    def test_scoring_cannot_disagree_with_its_facts_provenance(self):
        records, scores, _ = load_runs([self.run_fixture("fact-source")])
        changed = copy.deepcopy(scores)
        changed[records[0]["decision_id"]]["scoring"]["mechanism_facts"]["registry_sha256"] = "0" * 64
        with self.assertRaisesRegex(DataContractError, "differ from policy provenance"):
            examples_for(records, changed, "prior")

    def test_outcome_freeze_includes_the_registry_source_file(self):
        paths = [self.run_fixture("registry-" + str(i), seed_in("train", i), victory=i % 2 == 0) for i in range(10)]
        records, scores, sources = load_runs(paths)
        records[-1]["metadata"]["versions"]["sources"] = {
            "mechanism_facts.py": {"path": "synthetic registry", "sha256": "0" * 64, "bytes": 1}}
        with patch("train_ranker.load_runs", return_value=(records, scores, sources)):
            with self.assertRaisesRegex(DataContractError, "cannot mix"):
                train(paths, self.root / "registry-mix.json", mode="outcome")

    def test_live_model_requires_complete_and_exact_engine_registry_coverage(self):
        good = InitialPolicy(prior_path=None).mechanism_source
        variants = [None, {}, {**good, "extra": "unverified"},
                    *[{**good, key: value} for key, value in
                      (("version", "different"), ("engine_sha256", "0" * 64),
                       ("registry_sha256", "0" * 64), ("coverage", "full"))]]
        for index, facts in enumerate(variants):
            with self.subTest(index=index):
                path = self.model_fixture("facts-bad-" + str(index) + ".json", feature_mechanism_facts=facts)
                with self.assertRaisesRegex(DataContractError, "mechanism facts"):
                    SmallValuePolicy(path, fallback=InitialPolicy(prior_path=None))

    def test_loaded_policy_refuses_feature_source_drift(self):
        fallback = InitialPolicy(prior_path=None)
        policy = SmallValuePolicy(self.model_fixture(), fallback=fallback)
        fallback.mechanism_source["registry_sha256"] = "0" * 64
        with self.assertRaisesRegex(DataContractError, "changed after model loading"):
            policy.score(reward_state())

    def test_old_model_remains_numerically_readable_but_cannot_run_live(self):
        model = fit([{"features": {"old_feature": 1.}, "target": 2.}], ["old_feature"])
        model.update(format=VERSION, feature_policy_version="initial-stat-mechanism-v2", mode="prior")
        path = self.root / "historical.json"
        path.write_text(json.dumps(model), encoding="utf-8")
        historical = json.loads(path.read_text(encoding="utf-8"))
        self.assertAlmostEqual(predict(historical, {"old_feature": 1.}), 2., places=6)
        with self.assertRaisesRegex(DataContractError, "historical artifacts are read-only"):
            SmallValuePolicy(path)


if __name__ == "__main__":
    unittest.main()
