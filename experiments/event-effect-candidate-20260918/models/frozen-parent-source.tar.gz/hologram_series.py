"""Authenticate actual Hologram play series, manual tasks and automatic returns."""
import copy
import re


def require(value, message):
    if not value: raise RuntimeError(message)


def equal_fields(data, expected, message):
    require(isinstance(data, dict) and all(type(data.get(k)) is type(v) and data[k] == v
        for k,v in expected.items()), message)


def integer(data, key, low=0, high=None):
    value = data.get(key)
    require(type(value) is int and value >= low and (high is None or value <= high), 'Invalid Hologram ' + key)
    return value


def terminal_boundary(state):
    """Only an explicit, clean engine boundary can finish a manual series."""
    if state.get('context',{}).get('combat_in_progress') is not False:
        return False
    require(state.get('type') == 'decision'
        and state.get('decision') in {'card_reward','map','game_over'}
        and state.get('context',{}).get('integrity_recovery_used') is False,
        'Invalid Hologram terminal boundary')
    return True


def checked_envelope(state, audit):
    """Validate the declared observer before public-state projection; no replay claim."""
    c = audit.get('hologram_continuation')
    true_fields = {'original_task_pending_at_resume','selector_task_identity_matches','source_is_original_card_object',
        'original_play_task_pending_at_resume','original_task_completed_successfully','selector_task_completed_successfully',
        'original_and_selector_return_same_card_objects'}
    ints = {'origin_action_id','previous_action_id','original_source_count_at_entry','selector_invocation_at_resume',
        'original_play_action_id','pending_play_index','original_play_count','selector_invocation_at_end',
        'original_task_returned_count','selected_original_option_index'}
    keys = true_fields | ints | {'schema_version','origin_parent','original_play_card_id','original_play_target_combat_id',
        'original_play_task_completed_successfully','original_play_state_at_end','original_play_cancelled','selector_pending_at_end'}
    require(isinstance(c,dict) and set(c) == keys, 'Unknown Hologram series continuation envelope')
    equal_fields(c, {**dict.fromkeys(true_fields,True), 'schema_version':'hologram-pending-task-continuation-v2',
        'original_play_card_id':'HOLOGRAM','original_play_target_combat_id':None,'original_play_cancelled':False,
        'original_task_returned_count':1}, 'Incomplete original Hologram continuation task')
    for key in ints: integer(c,key)
    require(c['origin_action_id'] >= 1 and c['previous_action_id'] >= c['origin_action_id']
        and integer(audit,'action_id',1) == c['previous_action_id'] + 1
        and c['original_source_count_at_entry'] >= 2 and c['selector_invocation_at_resume'] >= 1
        and c['original_play_action_id'] >= 0 and 1 <= c['original_play_count'] <= 65
        and c['pending_play_index'] < c['original_play_count']
        and c['selected_original_option_index'] < c['original_source_count_at_entry'], 'Hologram continuation bounds differ')
    pending = c['selector_pending_at_end']
    require(type(pending) is bool, 'Missing Hologram pending state')
    equal_fields(c, {'original_play_task_completed_successfully':not pending,
        'original_play_state_at_end':'Executing' if pending else 'Finished',
        'selector_invocation_at_end':c['selector_invocation_at_resume'] + int(pending)},
        'Hologram original play/selector completion differs')
    parent_keys = {'action','card_index','card_id','card_key','player_id','combat_id','player_turn',
        'combat_active_before','potion_index','potion_slot','potion_id'}
    origin,parent = c['origin_parent'],audit.get('parent')
    require(isinstance(origin,dict) and isinstance(parent,dict) and set(origin)==set(parent)==parent_keys,
        'Unknown Hologram original parent')
    equal_fields(origin, {'action':'play_card','card_id':'HOLOGRAM'}, 'Wrong original Hologram parent')
    require(isinstance(origin['card_key'],str) and origin['card_key'].startswith('HOLOGRAM+'), 'Missing Hologram fingerprint')
    integer(origin,'card_index')
    equal_fields(parent, {'action':'select_cards','card_id':None,'card_key':None,'card_index':-1}, 'Wrong Hologram selection parent')
    for p in (origin,parent):
        equal_fields(p, {'combat_active_before':True,'potion_index':-1,'potion_slot':-1,'potion_id':None}, 'Hologram owner differs')
        require(isinstance(p['player_id'],str) and p['player_id'], 'Missing Hologram player')
        integer(p,'combat_id',1); integer(p,'player_turn',1)
    ended = terminal_boundary(state)
    require(all(origin[k] == parent[k] for k in ('player_id','combat_id','player_turn'))
        and parent['combat_id'] == state.get('player',{}).get('combat_metrics',{}).get('combat_id')
        and ('player_turn' not in state and (pending or ended) or parent['player_turn'] == state.get('player_turn')),
        'Hologram continuation crossed its original turn/combat')
    if ended:
        require(not pending and c['original_play_task_completed_successfully'],
            'Hologram ended before its original play completed')
    else:
        require(state.get('decision') == ('card_select' if pending else 'combat_play')
            and state.get('context',{}).get('combat_in_progress') is True, 'Hologram continuation has wrong live state')
    return c


def token(card):
    require(isinstance(card,dict) and all(isinstance(card.get(k),str) and card[k] for k in ('CardId','StateKey')),
        'Missing Hologram returned fingerprint')
    for k in ('UpgradeLevel','SourceOccurrence','OptionOccurrence'): integer(card,k)
    return {k:card[k] for k in ('CardId','UpgradeLevel','StateKey','SourceOccurrence','OptionOccurrence')}


def checked_card_replay(action):
    # ChoiceCardKey stores BaseReplayCount. PlanAction stores the original
    # GetEnchantedReplayCount: GLAM adds one until its first play this combat.
    # Hook-added executions (e.g. Echo Form) remain bound to actual CardPlay.
    key=action.get('CardStateKey')
    require(isinstance(key,str), 'Missing Hologram card fingerprint')
    base=re.findall(r'\|replay=(\d+)\|',key)
    require(len(base)==1 and int(base[0])<=64, 'Invalid Hologram base replay fingerprint')
    expected=int(base[0])
    glam=re.findall(r'\|GLAM:(\d+):(\d+):(True|False)\|',key)
    if action.get('CardEnchantmentId')=='GLAM' or '|GLAM:' in key:
        require(action.get('CardEnchantmentId')=='GLAM' and len(glam)==1,
            'Hologram GLAM fingerprint differs')
        expected+=int(glam[0][2]=='False')
    require(type(action.get('ReplayCount')) is int and action['ReplayCount']==expected,
        'Hologram enchanted replay fingerprint differs')


def resolve(executor, before, state, action, manual):
    from combat_executor import choice_plans
    root_state = copy.deepcopy(state)
    root = state.get('choice_audit',{}); parent=root.get('parent',{})
    root_id=integer(root,'action_id',1)
    play=root_state.get('play_action',{})
    play_id=integer(play,'action_id')
    equal_fields(action, {'Kind':'PlayCard','CardId':'HOLOGRAM','NestedChoicesBeforePrimary':0,
        'EndsPlayerTurn':False}, 'Unsupported Hologram action shape')
    integer(action,'ReplayCount',0,64)
    plans=choice_plans(action)
    require(plans and action.get('Choice') == plans[0] and (action.get('NestedChoices') or []) == plans[1:]
        and not action.get('TurnStartChoices'), 'Hologram plans changed their original order')
    for p in plans:
        equal_fields(p, {'Effect':'MoveToHand','SourcePile':'Discard','SourceId':'','ContextId':'','Timing':'Action'},
            'Unsupported Hologram choice')
        require(isinstance(p.get('Cards'),list) and len(p['Cards']) <= 1, 'Hologram must return at most one card per play')
        for card in p['Cards']: token(card)
    equal_fields(root, {'schema_version':'combat-choice-return-v2','closed':True,'events':[]}, 'Open Hologram root audit')
    equal_fields(parent, {'action':'play_card','card_id':'HOLOGRAM','card_key':action.get('CardStateKey'),
        'combat_active_before':True,'player_turn':action.get('Turn')}, 'Wrong original Hologram action')
    checked_card_replay(action)
    require(executor.last_action_request == {'cmd':'action','action':'play_card','args':{'card_index':integer(parent,'card_index')}}
        and parent['player_turn'] == before.get('player_turn')
        and parent['combat_id'] == before.get('player',{}).get('combat_metrics',{}).get('combat_id')
        and before.get('context',{}).get('combat_in_progress') is True, 'Hologram original public state/request differs')
    equal_fields(play, {'schema_version':'original-play-action-v1','card_id':'HOLOGRAM','target_combat_id':None,
        'cancellation_observed':False,'on_play_entered':True,
        'outcome':'awaiting_selection' if manual else 'completed','state':'Executing' if manual else 'Finished',
        'completion_task_status':'WaitingForActivation' if manual else 'RanToCompletion'}, 'Wrong original Hologram PlayCardAction')
    initial=root.get('original_returns')
    require(isinstance(initial,list) and initial, 'Missing original Hologram series call')
    count=integer(initial[0],'hologram_play_count',1,65)
    require(initial[0].get('hologram_play_index') == 0 and count >= 1 + action['ReplayCount'], 'Incomplete original Hologram series')
    require(initial[0].get('raw_source_count_at_entry') == before.get('discard_pile_count'), 'Hologram initial discard changed')
    index=0; used=0; choices=[]; automatic=[]; previous_counter=None

    def event_check(event,audit,pending):
        nonlocal previous_counter
        counter=integer(event,'selector_invocations_before')
        if previous_counter is not None: require(counter==previous_counter, 'Hologram selector chain skipped an invocation')
        expected={'schema_version':'original-choice-return-v1','action_id':audit['action_id'],
            'source_method':'CardSelectCmd.FromCombatPile','effect_callsite':'Hologram.OnPlay','effect':'MoveToHand',
            'source_id':'HOLOGRAM','source_pile':'Discard','source_is_actual_parent_object':True,
            'player_id':parent['player_id'],'player_turn':action['Turn'],'is_over_or_ending_at_entry':False,
            'combat_active_at_entry':True,'min_select':1,'max_select':1,'require_manual_confirmation':False,
            'filter_is_null':False,'filter_reexecuted_by_observer':False,'selector_pending_before':False,
            'selector_invocations_after':counter+int(pending),'selector_pending_after':pending,
            'verified':not pending,'original_task_completed_successfully':not pending,
            'combat_active_at_return':True,'is_over_or_ending_at_return':False,
            'hologram_original_series_verified':True,'hologram_play_index':index,'hologram_play_count':count,
            'hologram_original_play_action_id':play_id}
        equal_fields(event,expected,'Incomplete original Hologram indexed return')
        raw=integer(event,'raw_source_count_at_entry')
        require(raw>=2 if pending else raw<=1, 'Hologram returned without required manual choice')
        previous_counter=counter+int(pending)
        return raw

    while state.get('decision') == 'card_select':
        require(manual and index<count and used<len(plans) and len(plans[used]['Cards'])==1,
            'Missing Hologram manual invocation plan')
        audit=state.get('choice_audit',{}); events=audit.get('original_returns')
        require(isinstance(events,list) and len(events)==1, 'Hologram manual call count differs')
        equal_fields(events[0],{'invocation_index':0},'Wrong Hologram local invocation index')
        raw=event_check(events[0],audit,True)
        capture=[]
        next_state=executor.resolve(state,[plans[used]],setup_choices=capture,allow_pending=True)
        require(len(capture)==1 and len(capture[0]['actual_choice_metadata']['cards'])==raw, 'Hologram actual choice surface changed')
        c=checked_envelope(next_state,next_state['choice_audit'])
        equal_fields(c, {'origin_action_id':root_id,'origin_parent':parent,'previous_action_id':audit['action_id'],
            'original_source_count_at_entry':raw,'pending_play_index':index,'original_play_count':count,
            'original_play_action_id':play_id,'selector_invocation_at_resume':previous_counter},
            'Hologram resumed a different original task or series')
        require(capture[0]['actual_request'] == {'cmd':'action','action':'select_cards',
            'args':{'indices':str(c['selected_original_option_index'])}}, 'Hologram original task returned a different manual selection')
        choices.append({**capture[0],'actual_continuation':copy.deepcopy(c)})
        state=next_state; index+=1; used+=1

    audit=state.get('choice_audit',{}); events=audit.get('original_returns')
    equal_fields(audit,{'schema_version':'combat-choice-return-v2','closed':True,'events':[],'coverage':root.get('coverage')},
        'Hologram series changed its audit owner')
    ended = terminal_boundary(state)
    require((manual and ended or state.get('decision')=='combat_play'
        and state.get('context',{}).get('combat_in_progress') is True and state.get('player_turn')==action['Turn'])
        and executor.setup_state_identity(before)==executor.setup_state_identity(state)
        and isinstance(events,list) and len(events)==count-index, 'Hologram series ended before all original effects')
    for local,event in enumerate(events):
        equal_fields(event,{'invocation_index':local},'Hologram skipped an original automatic call')
        raw=event_check(event,audit,False)
        equal_fields(event,{'raw_source_count_at_return':raw,'returned_count':raw,'returned_objects_match_original_source':True,
            'candidate_basis':'original_implementation_and_completed_return_without_selector',
            'original_returned_collection':'List<CardModel>' if raw else 'CardModel[]'}, 'Incomplete automatic Hologram task return')
        returned=event.get('returned_cards')
        require(isinstance(returned,list) and len(returned)==raw, 'Hologram original collection differs')
        if raw:
            require(used<len(plans) and [token(c) for c in returned]==[token(c) for c in plans[used]['Cards']]
                and returned[0]['SourceOccurrence']==0 and returned[0]['OptionOccurrence']==0,
                'Automatic Hologram card does not match its original plan')
            used+=1
        elif used<len(plans) and plans[used]['Cards']==[]:
            used+=1
        automatic.append(copy.deepcopy(event)); index+=1
    require(index==count and used==len(plans), 'Original Hologram series omitted a solver choice or effect')
    if manual:
        checked_envelope(state,audit)
        require(choices and audit['hologram_continuation']['original_play_task_completed_successfully'], 'Hologram play did not finish')
    meta=executor.checked(cmd='choice_meta')
    equal_fields(meta,{'type':'choice_meta','selection':'none','cards':[],'completion_audit':audit}, 'Stale Hologram series evidence')
    require(executor.solve_calls, 'No original solver owns Hologram series')
    executor.solve_calls[-1].setdefault('replay',[]).append({'kind':
        'original_choice_continuation_ended_combat' if ended else
        'original_choice_continuation_completed' if manual else 'original_choice_return_completed',
        'series_schema':'hologram-original-indexed-series-v1','plan':copy.deepcopy(plans[0]),'all_plans':copy.deepcopy(plans),
        'actual_root_audit':copy.deepcopy(root),'actual_original_play':copy.deepcopy(play),'actual_choice_audit':copy.deepcopy(audit),
        'manual_choices':choices,'original_automatic_returns':automatic,'original_play_count':count,
        'manual_selection_requests_sent':len(choices),'automatic_selection_request_sent':False,
        'remaining_battle_plan_stopped':ended})
    return state
