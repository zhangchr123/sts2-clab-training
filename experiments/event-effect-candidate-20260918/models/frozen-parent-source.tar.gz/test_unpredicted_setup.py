"""Actual original terminal forecast plus a freshly solved, owned next setup."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from inspection.trial_cosmetic_projection import project_trial_number
from prefix_interventions import read_json,read_lines,unchanged
from replay_evidence import validate_replay_evidence
from unpredicted_setup import proof
import test_liquid_memories as helpers

ORIGINAL=Path('D:/sts2-training/staging/hologram-original-repeat-glam/sts2-solver-bridge')
NAME='defect-identity-step-search-20260915a-training-base-023'
BASELINE=ORIGINAL/'outputs/step-unexpected-toasty-baseline-e972bf192e.json'

class UnpredictedSetup(unittest.TestCase):
    worker=helpers.LiquidMemoriesTests.worker
    save=helpers.LiquidMemoriesTests.save

    def baseline(self):
        base=read_json(BASELINE);self.assertTrue(base['passed'] and unchanged(base['original_sources']))
        rows=read_lines(ORIGINAL/'outputs'/NAME/'trace.jsonl')
        action=rows[722]['response']['actions'][-1]
        return rows[-2]['response'],rows[-1]['response'],action,base['actual_pending_choice'],55

    def test_actual_task_chain_and_scope_mutation_rejection(self):
        args=self.baseline();self.assertEqual(proof(*args)['schema_version'],'actual-unpredicted-turn-setup-replan-v1')
        for path,value in [
            (('setup_choice','source_is_current_live_relic'),False),(('setup_choice','original_task_pending'),False),
            (('setup_choice','filter_is_null'),False),(('setup_choice','source_id'),'OTHER'),
            (('setup_origin','capture_id'),97),(('setup_origin','captured_turn'),12),
            (('setup_origin','live_same_combat'),False),(('setup_origin','live_phase'),'Play'),
            (('turn_end_origin','setup_capture_before'),96),(('turn_end_origin','action_id'),489),
            (('turn_end_origin','after_action','selector_invocations'),52),
            (('turn_end_origin','after_action','selector_pending'),False),
            (('turn_end_origin','calls',0,'original_task_completed_successfully'),True),
            (('turn_end_origin','calls',1,'source_is_original_player_object'),False),
            (('turn_end_origin','calls',2,'raw_hand_count'),4),
            (('turn_end_origin','calls',2,'original_task_status'),'RanToCompletion'),
            (('turn_end_origin','calls',2,'entry','selector_pending'),True)]:
            with self.subTest(path=path):
                changed=copy.deepcopy(args);target=changed[3]
                for k in path[:-1]:target=target[k]
                target[path[-1]]=value
                with self.assertRaises(RuntimeError):proof(*changed)

    def test_existing_plans_and_other_combat_are_not_discarded(self):
        args=self.baseline()
        for change in ('planned','card','combat'):
            with self.subTest(change=change):
                changed=copy.deepcopy(args)
                if change=='planned':changed[2]['TurnStartChoices']=[{'Cards':[]}]
                elif change=='card':changed[2]['Kind']='PlayCard'
                else:changed[1]['player']['combat_metrics']['combat_id']+=1
                with self.assertRaises(RuntimeError):proof(*changed)

    def replay(self,limit=False):
        rows=read_lines(ORIGINAL/'outputs'/NAME/'trace.jsonl');base=read_json(BASELINE)
        self.assertTrue(base['passed'] and unchanged(base['original_sources']))
        original=copy.deepcopy(rows[722]);label='unpredicted-setup-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);matched=0;passed=False;cosmetic=[];executor=None
        try:
            for row in rows[:722]:
                if row['request']['cmd'] in ('solve','combat_meta','choice_meta'):continue
                before=send(row['request']);a,ad=project_trial_number(checked_public(before));b,bd=project_trial_number(checked_public(row['response']))
                self.assertEqual(a,b)
                if ad or bd:cosmetic.append({'prefix':matched,'actual':ad,'original':bd})
                matched+=1
            config=read_json(ORIGINAL/'outputs'/NAME/'manifest.json')['solver_requested_config']
            if limit:config['max_replans']=1
            executor=CombatExecutor(send,config);actual_solve=executor.solve;supplied=False
            def first(state,budget,used=0,setup=False):
                nonlocal supplied
                if supplied:return actual_solve(state,budget,used,setup)
                self.assertEqual(state,before);self.assertTrue(setup);supplied=True
                call=copy.deepcopy(original);traces.append(copy.deepcopy(call));executor.solve_calls.append(call)
                return call['response']
            executor.solve=first
            if limit:
                with self.assertRaisesRegex(RuntimeError,'Too many combat replans'):executor.advance(before)
                self.assertEqual(len(executor.solve_calls),1)
                self.assertEqual(traces[-1]['request'],{'cmd':'choice_meta'})
            else:
                final=executor.advance(before)
                self.assertFalse(final['context']['combat_in_progress'])
                self.assertFalse(final['context']['integrity_recovery_used'])
                self.assertGreaterEqual(len(executor.solve_calls),2)
                self.assertTrue(executor.solve_calls[1]['request']['include_turn_setup'])
                self.assertEqual(executor.solve_calls[1]['response']['setup_origin']['captured_turn'],13)
            self.assertEqual(executor.solve_calls[0]['response'],original['response'])
            invalidation=executor.solve_calls[0]['plan_invalidation']
            self.assertEqual(invalidation['schema_version'],'actual-unpredicted-turn-setup-replan-v1')
            self.assertFalse(invalidation['selection_submitted'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
            corrupted=copy.deepcopy(executor.solve_calls);corrupted[0].pop('plan_invalidation')
            with self.assertRaises(ValueError):validate_replay_evidence(corrupted,traces)
            corrupted=copy.deepcopy(executor.solve_calls);changed=copy.deepcopy(traces)
            # Joint metadata/proof corruption must not forge an original pending task.
            invalidation=corrupted[0]['plan_invalidation'];invalidation['actual_choice_metadata']['setup_choice']['original_task_pending']=False
            q=next(r for r in changed if r['request']=={'cmd':'choice_meta'} and
                r.get('response',{}).get('setup_origin',{}).get('capture_id')==invalidation['actual_choice_metadata']['setup_origin']['capture_id'])
            q['response']['setup_choice']['original_task_pending']=False
            with self.assertRaises(ValueError):validate_replay_evidence(corrupted,changed)
            self.assertTrue(unchanged(base['original_sources']));passed=True
        finally:
            self.save(label,traces,passed=passed,original_failed_run=NAME,original_sources=base['original_sources'],
                public_prefix_responses_verified=matched,first_solve_is_complete_original_envelope=True,
                original_plan_response_unchanged=True,bounded_replan_limit_test=limit,
                fresh_setup_solver_used=not limit,Trial_display_projection=cosmetic,
                hidden_state_or_rng_equality_claimed=False,solver_calls=executor.solve_calls if executor else [])
            bridge.close();print({'label':label,'passed':passed,'prefix':matched},flush=True)

    def test_original_full_56_action_plan_replans_and_finishes(self):self.replay()
    def test_replan_limit_keeps_pending_choice_unselected(self):self.replay(limit=True)

if __name__=='__main__':unittest.main(verbosity=2)
