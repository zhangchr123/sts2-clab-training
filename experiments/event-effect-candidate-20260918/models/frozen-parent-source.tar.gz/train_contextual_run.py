"""Cross-entropy parameter search using complete, actual Defect A10 games.

All population/seed allocations precede execution. No LLM decisions, fabricated
counterfactuals, save-state injection, mid-generation fitting, or repeated runs.
The objective remains Act3 FIRST boss completion; dense progress only guides
search until successes exist. A later untouched evaluation is separate.
"""
import argparse
import copy
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import random

from audit_batch import _Audit
from boss_progress import observed_progress
from prefix_interventions import read_json, read_lines, require, unchanged
from run_metadata import atomic_json, file_evidence, metadata
from sample_runs import run_one
from contextual_policy import PARAMETERS, FEATURE_SOURCES, make_artifact, ContextualPolicy
from whole_run_policy import ROOT, VERSION as LEGACY_POLICY_VERSION, WholeRunPolicy as LegacyPolicy
from contextual_policy import VERSION as CONTEXTUAL_POLICY_VERSION

LOCAL_ROOT = Path(__file__).resolve().parent
VERSION = "original-engine-contextual-cem-v2"
WARM_VERSION = "original-engine-contextual-cem-warmstart-v2"
SOURCES = tuple(dict.fromkeys((*FEATURE_SOURCES, "train_contextual_run.py", "boss_progress.py", "whole_run_audit.py",
    "sample_runs.py", "audit_batch.py", "selection_context.py", "combat_executor.py", "solver_evidence.py",
    "replay_evidence.py", "probe.py", "run_metadata.py", "compare_batches.py",
    "reconcile_contextual_generation.py", "archive_contextual_training.py",
    "evaluate_contextual_run.py", "reconcile_contextual_evaluation.py")))
METHOD = {"population": 17, "elites": 5, "initial_std": 1.5, "minimum_std": .15,
          "smoothing": .5, "parameter_bound": 4., "sampling": "eight_antithetic_pairs_plus_center",
          "selection": "goal_success_count_then_mean_shaped_actual_progress_then_candidate_index",
          "score_if_environment_error_or_timeout": -1., "test_used_for_fit_or_tuning": False}


STAGED_SOURCES = {"contextual_policy.py", "contextual_features.py", "contextual_effects.py",
                  "train_contextual_run.py", "sample_runs.py", "whole_run_audit.py", "audit_batch.py",
                  "reconcile_contextual_generation.py", "archive_contextual_training.py",
                  "evaluate_contextual_run.py", "reconcile_contextual_evaluation.py"}


def source_path(name):
    return (LOCAL_ROOT if name in STAGED_SOURCES else ROOT) / name


def authenticated_initial_model(path, config):
    """Read a source-bound model and zero-extend only a genuine legacy vector."""
    artifact = read_json(path)
    if artifact.get("format") == LEGACY_POLICY_VERSION:
        policy = LegacyPolicy(path, solver_config=config, seed="initialization", epsilon=0.)
        center = {name: policy.artifact["parameters"].get(name, 0.) for name in PARAMETERS}
        initialization = "authenticated_19_parameter_model_zero_extended_to_51_then_fresh_games"
    else:
        require(artifact.get("format") == CONTEXTUAL_POLICY_VERSION, "Unknown initialization model format")
        policy = ContextualPolicy(path, solver_config=config, seed="initialization", epsilon=0.)
        center = dict(policy.artifact["parameters"])
        initialization = "inherit_frozen_51_parameters_then_fresh_natural_games"
    return policy, center, initialization


def initial_distribution(protocol):
    """Authenticate inherited parameters; this never resumes an old game."""
    if protocol["schema_version"] == VERSION:
        require("initial_model" not in protocol, "Legacy training cannot silently inherit a model")
        center = dict.fromkeys(PARAMETERS, 0.)
    else:
        require(protocol["schema_version"] == WARM_VERSION, "Unknown initialization protocol")
        source = protocol["initial_model"]
        require(unchanged([source]), "Initial model changed")
        policy, center, initialization = authenticated_initial_model(source["path"], protocol["solver_config"])
        require(protocol["initialization"] == initialization, "Initialization provenance changed")
        require(center == protocol["initial_center"], "Initial center differs from authenticated source model")
        ancestors = []
        parent_source = policy.artifact.get("training", {}).get("protocol")
        if parent_source:
            require(unchanged([parent_source]), "Parent training protocol changed")
            parent = read_json(parent_source["path"])
            ancestors = sorted(set(parent.get("ancestor_seeds", [])
                + sum(parent["training_seeds"], []) + parent["reserved_evaluation_seeds"]))
        require(protocol["ancestor_seeds"] == ancestors, "Ancestor seed declaration differs from source lineage")
        require(not set(sum(protocol["training_seeds"], []) + protocol["reserved_evaluation_seeds"])
                .intersection(protocol["ancestor_seeds"]), "Ancestor training/evaluation seeds reused")
    deviation = protocol.get("initial_std", METHOD["initial_std"])
    require(type(deviation) in (float, int) and math.isfinite(deviation) and .15 <= deviation <= 2.,
            "Initial exploration standard deviation must be finite and between 0.15 and 2")
    require(protocol["schema_version"] == WARM_VERSION or deviation == METHOD["initial_std"],
            "Legacy training distribution cannot silently change")
    return center, dict.fromkeys(PARAMETERS, deviation)


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)


def population(center, deviations, rng):
    result = [dict(center)]
    for _ in range(8):
        noise = {k: rng.gauss(0., deviations[k]) for k in PARAMETERS}
        for sign in (1, -1):
            result.append({k: max(-4., min(4., center[k] + sign * noise[k])) for k in PARAMETERS})
    return result


def update_distribution(vectors, evaluations, center, deviations):
    require(len(vectors) == 17 and len(evaluations) == 17, "Incomplete population cannot update")
    order = sorted(range(17), key=lambda i: (-evaluations[i]["goal_successes"], -evaluations[i]["mean_fitness"], i))
    elites = order[:5]
    means = {k: sum(vectors[i][k] for i in elites) / 5 for k in PARAMETERS}
    variance = {k: sum((vectors[i][k] - means[k]) ** 2 for i in elites) / 5 for k in PARAMETERS}
    return ({k: .5 * center[k] + .5 * means[k] for k in PARAMETERS},
            {k: max(.15, .5 * deviations[k] + .5 * math.sqrt(variance[k])) for k in PARAMETERS}, elites)


def prepare(path, *, name, generations=4, seeds_per_generation=24, initial_model=None, initial_std=1.5):
    path = Path(path).resolve()
    require(not path.parent.exists(), "New training directory required")
    require(generations >= 1 and seeds_per_generation >= 2, "Invalid training allocation")
    import re
    require(re.fullmatch(r"[A-Za-z0-9_-]+", name), "Invalid name")
    config = read_json(ROOT / "configs/defect-v3-base.json")
    versions = metadata(name, name, 10, config, {})["versions"]
    frozen = [versions[k] for k in ("engine", "solver", "ritsu", "bridge", "cli", "godot")]
    frozen += [file_evidence(source_path(n)) for n in SOURCES]
    prior = make_artifact(dict.fromkeys(PARAMETERS, 0.), config, training={})["prior_source"]
    frozen += [file_evidence(prior["path"])]
    require(unchanged(frozen), "Missing original sources")
    seeds = [[f"{name}-train-g{g:02d}-s{s:02d}" for s in range(seeds_per_generation)] for g in range(generations)]
    doc = {"schema_version": VERSION, "created_utc": datetime.now(timezone.utc).isoformat(),
        "name": name, "objective": "Defect A10 actually defeats Act3 first boss on every evaluation run",
        "conditions": {"character": "Defect", "ascension": 10, "mode": "standard"},
        "method": METHOD, "solver_config": config, "training_seeds": seeds,
        "reserved_evaluation_seeds": [f"{name}-eval-{i:03d}" for i in range(30)],
        "sampling": {"epsilon": 0., "max_seconds": 1200, "max_decisions": 500, "selection_budget": 256},
        "frozen_sources": frozen, "parameter_names": list(PARAMETERS), "optimizer_seed": name + ":contextual-optimizer-v2",
        "planned_training_games": generations * 17 * seeds_per_generation,
        "training_games_are_not_evaluation": True, "training_failures_remain_in_denominator": True,
        "llm_gameplay_choices": False, "goal_complete_from_finite_training_games": False,
        "progress_fitness": {"goal_success": 4., "otherwise": "max_observed_act_minus_one_plus_floor_in_that_act_divided_by_100",
            "environment_error_or_timeout": -1., "meaning": "shaped_search_return_not_goal_success_or_probability"}}
    if initial_model is not None:
        policy, center, initialization = authenticated_initial_model(initial_model, config)
        model_source = file_evidence(Path(initial_model).resolve())
        ancestor_seeds = []
        parent_source = policy.artifact.get("training", {}).get("protocol")
        if parent_source:
            require(unchanged([parent_source]), "Initial model training protocol changed")
            parent = read_json(parent_source["path"])
            ancestor_seeds = sorted(set(parent.get("ancestor_seeds", [])
                + sum(parent["training_seeds"], []) + parent["reserved_evaluation_seeds"]))
            frozen.append(parent_source)
        frozen.append(model_source)
        doc.update(schema_version=WARM_VERSION, initial_model=model_source,
            initial_center=center, ancestor_seeds=ancestor_seeds,
            initialization=initialization,
            initial_std=initial_std, optimizer_distribution="declared_std_around_inherited_center",
            old_games_reused_for_new_generation=False)
    else:
        require(initial_std == METHOD["initial_std"], "Custom exploration requires explicit warmstart protocol")
    initial_distribution(doc)
    path.parent.mkdir()
    write_new(path, doc)
    return doc


def audit_training_run(report, destination, *, seed):
    # The raw runs are siblings directly under outputs, not generation folders.
    audit = _Audit(ROOT / "outputs" / report["run_id"])
    try:
        records, audited = audit.run(report)
    except (ValueError, KeyError, TypeError, IndexError, OSError) as exc:
        audit.check(False, "training_run_readable", report["run_id"], str(exc))
        audited = None
    goal = observed_progress(read_lines(ROOT / "outputs" / report["run_id"] / "trace.jsonl"),
                             natural=True, expected_seed=seed)
    result = {"report": report, "audit_passed": not audit.issues, "issues": audit.issues,
        "checks": dict(audit.checks), "goal": goal, "training_only": True,
        "actual_source_evidence": list(audit.evidence.values())}
    good = report["outcome"] in {"defeat", "victory"} and not audit.issues and not goal["errors"]
    result["fitness"] = goal["shaped_progress_not_win_probability"] if good else -1.
    result["goal_success_for_search"] = good and goal["natural_goal_success"]
    write_new(destination / (report["run_id"] + "-audit.json"), result)
    require(not audit.issues, "Raw audit failed; no parameter update: " + str(audit.issues[:3]))
    require(not goal["errors"] or report["outcome"] not in {"defeat", "victory"}, "Goal evidence malformed")
    return result


def run(protocol_path):
    path = Path(protocol_path).resolve()
    protocol = read_json(path)
    require(protocol["schema_version"] in {VERSION, WARM_VERSION} and protocol["method"] == METHOD, "Unsupported training protocol")
    require(protocol["parameter_names"] == list(PARAMETERS), "Parameter schema changed")
    frozen = protocol["frozen_sources"] + [file_evidence(path)]
    require(unchanged(frozen), "Frozen inputs changed before training")
    center, deviations = initial_distribution(protocol)
    write_new(path.parent / "execution-started.json", {"protocol": file_evidence(path), "workers": 1,
        "resume_or_rerun_existing_games": False, "started_utc": datetime.now(timezone.utc).isoformat()})
    rng = random.Random(protocol["optimizer_seed"])
    completed_generations = []
    for generation, seeds in enumerate(protocol["training_seeds"]):
        require(unchanged(frozen), "Frozen input drift")
        folder = path.parent / f"generation-{generation:02d}"
        folder.mkdir()
        vectors = population(center, deviations, rng)
        artifacts = []
        for candidate, params in enumerate(vectors):
            model_path = folder / f"candidate-{candidate:02d}.json"
            write_new(model_path, make_artifact(params, protocol["solver_config"], training={
                "method": protocol["schema_version"], "protocol": file_evidence(path), "generation": generation,
                "candidate": candidate, "trained_on_generations": completed_generations,
                "phase": "parameter_search_candidate_not_validated_champion"}))
            artifacts.append(file_evidence(model_path))
        order = []
        for seed in seeds:
            indices = list(range(17)); rng.shuffle(indices)
            order.extend({"seed": seed, "candidate": i} for i in indices)
        write_new(folder / "allocation.json", {"seeds": seeds, "vectors": vectors, "order": order,
            "artifacts": artifacts, "center_before": center, "std_before": deviations})
        generation_frozen = frozen + artifacts + [file_evidence(folder / "allocation.json")]
        results = [[] for _ in range(17)]
        for index, allocation in enumerate(order):
            require(unchanged(generation_frozen), "Frozen training input drift")
            candidate, seed = allocation["candidate"], allocation["seed"]
            label = f"{protocol['name']}-g{generation:02d}-c{candidate:02d}-s{seeds.index(seed):02d}"
            sampling = protocol["sampling"]
            report = run_one(label, seed, ascension=10, settings=protocol["solver_config"],
                epsilon=sampling["epsilon"], max_seconds=sampling["max_seconds"],
                max_decisions=sampling["max_decisions"], selection_budget=sampling["selection_budget"],
                model_path=Path(artifacts[candidate]["path"]))
            result = audit_training_run(report, folder, seed=seed)
            results[candidate].append(result)
            require(unchanged(generation_frozen), "Frozen training input drift after game")
            print(json.dumps({"generation": generation, "completed": index + 1, "planned": len(order),
                "candidate": candidate, "seed": seed, "outcome": report["outcome"], "fitness": result["fitness"],
                "goal_success": result["goal_success_for_search"], "audit_passed": result["audit_passed"]}), flush=True)
        evaluations = [{"candidate": i, "planned_games": len(seeds), "actual_games": len(rows),
            "goal_successes": sum(r["goal_success_for_search"] for r in rows),
            "mean_fitness": sum(r["fitness"] for r in rows) / len(seeds),
            "environment_errors_or_timeouts": sum(r["report"]["outcome"] not in {"victory", "defeat"} for r in rows)}
            for i, rows in enumerate(results)]
        center, deviations, elites = update_distribution(vectors, evaluations, center, deviations)
        summary = {"generation": generation, "evaluations": evaluations, "elite_indices": elites,
            "center_after": center, "std_after": deviations, "best_candidate_artifact": artifacts[elites[0]],
            "training_only_no_evaluation_claim": True, "source_allocation": file_evidence(folder / "allocation.json")}
        write_new(folder / "summary.json", summary)
        completed_generations.append(file_evidence(folder / "summary.json"))
        atomic_json(path.parent / "progress.json", {"completed_generations": completed_generations,
            "latest_training_best": artifacts[elites[0]], "goal_achieved": False})
        print(json.dumps({"generation_complete": generation, "summary": summary}), flush=True)
    write_new(path.parent / "training-completed.json", {"generations": completed_generations,
        "reserved_evaluation_not_run": True, "goal_achieved": False, "model_deployed": False})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare"); p.add_argument("--output", required=True, type=Path)
    p.add_argument("--name", required=True); p.add_argument("--generations", type=int, default=4)
    p.add_argument("--seeds-per-generation", type=int, default=24)
    p.add_argument("--initial-model", type=Path)
    p.add_argument("--initial-std", type=float, default=1.5)
    p = sub.add_parser("run"); p.add_argument("--protocol", required=True, type=Path)
    args = parser.parse_args()
    if args.command == "prepare":
        doc = prepare(args.output, name=args.name, generations=args.generations, seeds_per_generation=args.seeds_per_generation,
            initial_model=args.initial_model, initial_std=args.initial_std)
        print(json.dumps({"prepared": str(args.output), "planned_games": doc["planned_training_games"]}))
    else:
        run(args.protocol)
