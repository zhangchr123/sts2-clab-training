"""Unactivated 289-term prototype: preserve 265 terms, learn removal/transform targets.

Descriptors refer only to the selected public cards. They do not simulate
removal hooks, transformed replacements, or claim every starter should go.
"""
import math
from event_cost_features import PARAMETERS as ORIGINAL_PARAMETERS, features as original_features
from decision_data import DataContractError
from initial_policy import card_id,card_mechanisms

ROLES=('remove','transform')
DESCRIPTORS=('starter_attack','starter_block','starter_orb_channel','starter_orb_evoke',
    'curse','nonstarter_noncurse','upgraded','known_draw','known_energy','known_frost','known_focus','known_retrieval')
EXTRA_PARAMETERS=tuple(f'{role}_target_{name}' for role in ROLES for name in DESCRIPTORS)
PARAMETERS=(*ORIGINAL_PARAMETERS,*EXTRA_PARAMETERS)
STARTERS={'STRIKE_DEFECT','DEFEND_DEFECT','ZAP','DUALCAST','ASCENDERS_BANE'}

def extra_features(state,row,candidate):
    if row['request']!=candidate['request']:raise DataContractError('Selection row/request mismatch')
    result=dict.fromkeys(EXTRA_PARAMETERS,0.)
    if row['request'].get('action')!='select_cards':return result
    selected=[r for r in ROLES if row['features'].get('selection_'+r)==1.]
    if not selected:return result
    if len(selected)!=1:raise DataContractError('Conflicting remove/transform roles')
    role=selected[0];cards=candidate['evidence'].get('cards')
    if not isinstance(cards,list):raise DataContractError('Selection target list missing')
    for card in cards:
        if not isinstance(card,dict) or not isinstance(card.get('id'),str) or not card['id']:
            raise DataContractError('Selection needs identified public cards')
        cid=card_id(card);tags=card_mechanisms(card)
        level=card.get('current_upgrade_level')
        if level is not None and (type(level) is not int or level<0):raise DataContractError('Invalid public upgrade level')
        values=dict(starter_attack=cid=='STRIKE_DEFECT',starter_block=cid=='DEFEND_DEFECT',
            starter_orb_channel=cid=='ZAP',starter_orb_evoke=cid=='DUALCAST',
            curse=card.get('type')=='Curse',nonstarter_noncurse=cid not in STARTERS and card.get('type') in ('Attack','Skill','Power'),
            upgraded=level is not None and level>0,known_draw='draw' in tags,known_energy='energy' in tags,
            known_frost='frost_source' in tags,known_focus=bool(tags & {'sustained_focus','temporary_focus','decaying_focus'}),
            known_retrieval='discard_retrieval' in tags)
        for name,value in values.items():result[f'{role}_target_{name}']+=float(value)
    return result

def features(state,row,candidate):
    values=original_features(state,row,candidate)
    if tuple(values)!=ORIGINAL_PARAMETERS:raise DataContractError('Original 265 schema drift')
    return {**values,**extra_features(state,row,candidate)}

def zero_extend(parameters):
    if set(parameters)!=set(ORIGINAL_PARAMETERS) or any(type(v) not in (int,float)
        or not math.isfinite(v) or abs(v)>4 for v in parameters.values()):
        raise DataContractError('Invalid original 265 vector')
    return {**{k:parameters[k] for k in ORIGINAL_PARAMETERS},**dict.fromkeys(EXTRA_PARAMETERS,0.)}
