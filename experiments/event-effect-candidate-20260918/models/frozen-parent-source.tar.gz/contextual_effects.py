"""Four supplemental original-engine-bound binary effect descriptors.

Unactivated experiment only. These describe code paths, not proc probabilities,
effect magnitudes, card values or natural gameplay outcomes. Keep separate from
the previously validated 47-feature prototype and its immutable validation.
"""
from initial_policy import card_id
from mechanism_facts import verified_source

PARAMETERS = (
    'card_energy_reset_glass_channel',
    'card_owner_status_generation_random_channel',
    'card_status_draw_history_gated_draw',
    'card_hp_loss_replacement_charge',
)
FACTS = {
    'SPINNER': {
        'parameter': PARAMETERS[0],
        'card_method': 'Spinner.OnPlay',
        'power_method': 'SpinnerPower.AfterEnergyReset',
        'condition': 'reset player equals power owner player',
        'effect': 'channel GlassOrb in loop i < power Amount',
        'upgrade_note': 'upgraded OnPlay additionally channels one GlassOrb before applying power',
    },
    'TRASH_TO_TREASURE': {
        'parameter': PARAMETERS[1],
        'card_method': 'TrashToTreasure.OnPlay',
        'power_method': 'TrashToTreasurePower.AfterCardGeneratedForCombat',
        'condition': 'generated card Type Status; creator nonnull; creator Creature equals power owner',
        'effect': 'GetRandomOrb using CombatOrbGeneration then Channel; loop i < Amount',
        'unknown': 'does not imply existing status cards generate any new statuses',
    },
    'ITERATION': {
        'parameter': PARAMETERS[2],
        'card_method': 'Iteration.OnPlay',
        'power_method': 'IterationPower.AfterCardDrawn',
        'condition': 'drawn card owner Creature equals power owner and Type Status; '
                     'count of this-turn owner Status CardDrawnEntry records <= 1',
        'effect': 'CardPileCmd.Draw Amount cards with received choice context',
        'unknown': 'no assumed trigger count, hand limit outcome or draw-history hook ordering',
    },
    'BUFFER': {
        'parameter': PARAMETERS[3],
        'card_method': 'Buffer.OnPlay',
        'power_method': 'BufferPower.ModifyHpLostAfterOstyLate',
        'condition': 'target equals power owner',
        'effect': 'return zero from this modifier; otherwise pass amount through',
        'decrement_method': 'BufferPower.AfterModifyingHpLostAfterOsty calls PowerCmd.Decrement',
        'unknown': 'no assumed HP saved, charge consumption timing beyond this hook, or survival',
    },
}


def effect_features(row, candidate):
    # Existing engine verifier checks the DLL SHA and caches only a file version.
    verified_source()
    values = dict.fromkeys(PARAMETERS, 0.)
    if row['request'] != candidate['request']:
        from decision_data import DataContractError
        raise DataContractError('Effect descriptor row/candidate mismatch')
    if row['request']['action'] in {'select_card_reward', 'buy_card'}:
        fact = FACTS.get(card_id(candidate['evidence']))
        if fact is not None:
            values[fact['parameter']] = 1.
    return values
