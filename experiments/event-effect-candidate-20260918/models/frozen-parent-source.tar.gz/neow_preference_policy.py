"""Whole-run Defect policy with a bounded opening Neow preference residual."""
import copy
import json
import math
from pathlib import Path

from decision_data import DataContractError, enumerate_candidates, state_hash
from initial_policy import InitialPolicy, POLICY_VERSION
from public_route_policy import PublicRoutePolicy, FEATURE_SOURCES as ROUTE_SOURCES
from public_route_learning import validate_input
from reference_archetype_features import CONTRACT, PRIOR, PRIOR_PATH, PRIOR_EVIDENCE
from neow_preference_features import PARAMETERS, NEOW_PARAMETERS, CONTRACT as NEOW_CONTRACT, features as residual_features
from run_metadata import file_evidence
import deck_discipline
import event_risk_guard
import noncombat_potions

VERSION = "whole-run-public-neow-preference-v1"
ROOT = Path(__file__).resolve().parent
FEATURE_SOURCES = (*ROUTE_SOURCES, "reference_archetype_features.py", "reference_archetype_policy.py", "noncombat_potions.py", "neow_preference_features.py", "neow_preference_policy.py")


def feature_sources():
    return {name: file_evidence(ROOT / name) for name in FEATURE_SOURCES}


def make_artifact(parameters, solver_config, *, training, noncombat_fruit_juice_enabled=False):
    base = InitialPolicy()
    return {"format": VERSION, "parameters": dict(parameters), "parameter_names": list(PARAMETERS),
        "solver_requested_config": copy.deepcopy(solver_config), "training": copy.deepcopy(training),
        "source_files": feature_sources(), "prior_source": base.prior.source,
        "mechanism_facts": base.mechanism_source,
        "score_semantics": "current_rule_score_plus_learned_public_residual_not_outcome_probability",
        "rule_policy_version": POLICY_VERSION, "calibrated_probability": False,
        "first_boss_success_verified": False, "automatic_deployment": False,
        "deck_contract": copy.deepcopy(deck_discipline.CONTRACT),
        "event_risk_contract": copy.deepcopy(event_risk_guard.CONTRACT),
        "public_route_contract": copy.deepcopy(__import__("public_route_learning").CONTRACT),
        "noncombat_potion_policy": noncombat_potions.configuration(noncombat_fruit_juice_enabled),
        "neow_preference_contract": copy.deepcopy(NEOW_CONTRACT),
        "reference_contract": copy.deepcopy(CONTRACT), "reference_prior": copy.deepcopy(PRIOR_EVIDENCE),
        "reference_source_analysis": copy.deepcopy(PRIOR["source_analysis"]),
        "reference_limitations": copy.deepcopy(PRIOR["limitations"])}


class NeowPreferencePolicy(PublicRoutePolicy):
    def __init__(self, path, *, solver_config, seed, epsilon=0.):
        if epsilon != 0.:
            raise DataContractError("Compact deck hard cap requires zero random exploration")
        InitialPolicy.__init__(self, random_seed=seed, epsilon=epsilon)
        self._special_builds = set()
        self._pending_mirror_size = None
        self._route_input = None
        self.path = Path(path).resolve()
        self.artifact = json.loads(self.path.read_text(encoding="utf-8"))
        a = self.artifact
        if (a.get("format") != VERSION or a.get("parameter_names") != list(PARAMETERS)
                or set(a.get("parameters", {})) != set(PARAMETERS)
                or any(type(v) not in (float, int) or not math.isfinite(v) or abs(v) > 4
                       for v in a["parameters"].values())
                or a.get("solver_requested_config") != solver_config
                or a.get("prior_source") != self.prior.source or a.get("mechanism_facts") != self.mechanism_source
                or a.get("source_files") != feature_sources()
                or a.get("calibrated_probability") is not False
                or a.get("deck_contract") != deck_discipline.CONTRACT
                or a.get("event_risk_contract") != event_risk_guard.CONTRACT
                or a.get("public_route_contract") != __import__("public_route_learning").CONTRACT
                or not isinstance(a.get("noncombat_potion_policy"), dict)
                or type(a["noncombat_potion_policy"].get("enabled")) is not bool
                or a["noncombat_potion_policy"] != noncombat_potions.configuration(a["noncombat_potion_policy"]["enabled"])
                or a.get("neow_preference_contract") != NEOW_CONTRACT
                or any(abs(a["parameters"][k]) > 1 for k in NEOW_PARAMETERS)
                or a.get("reference_contract") != CONTRACT or a.get("reference_prior") != PRIOR_EVIDENCE
                or file_evidence(PRIOR_PATH) != PRIOR_EVIDENCE
                or a.get("reference_source_analysis") != PRIOR["source_analysis"]
                or a.get("reference_limitations") != PRIOR["limitations"]):
            raise DataContractError("Invalid public-reference policy parameters, scope or frozen source")
        self.source = file_evidence(self.path)
        self._artifact_hash = state_hash(a)

    @property
    def provenance(self):
        original = InitialPolicy.provenance.fget(self)
        return {**original, "kind": "search", "id": VERSION, "version": self.source["sha256"],
                "policy_source": copy.deepcopy(self.source), "score_semantics": self.artifact["score_semantics"],
                "solver_requested_config": self.artifact["solver_requested_config"],
                "training_method": "fixed_compact_plus_bounded_public_neow_choice_fit",
                "reference_prior": copy.deepcopy(PRIOR_EVIDENCE), "automatic_deployment": False}

    def _adjust(self, state, packet):
        if (file_evidence(self.path) != self.source or state_hash(self.artifact) != self._artifact_hash
                or file_evidence(PRIOR_PATH) != PRIOR_EVIDENCE
                or self.artifact["source_files"] != feature_sources()):
            raise DataContractError("Public-reference policy changed after loading")
        ctx = state.get("context", {})
        if ctx.get("ascension") != 10 or ctx.get("act") not in (1, 2, 3) or ctx.get("combat_in_progress") is not False:
            raise DataContractError("Public-reference policy requires actual noncombat Defect A10 state")
        from decision_data import materialize_candidate
        space = enumerate_candidates(state)
        by_id = None if space.get("representation") == "ordered_selection_implicit_v1" else {
            candidate["candidate_id"]: candidate for candidate in space["candidates"]}
        for row in packet["scores"]:
            candidate = materialize_candidate(space, row["request"]) if by_id is None else by_id[row["candidate_id"]]
            if candidate["request"] != row["request"]:
                raise DataContractError("Reference residual row does not match current legal action")
            values = (dict.fromkeys(PARAMETERS, 0.) if row["request"]["action"] == "use_potion"
                      else residual_features(state, row, candidate, self._route_input))
            residual = sum(self.artifact["parameters"][name] * values[name] for name in PARAMETERS)
            row.update(rule_score=row["score"], search_features=values, learned_residual=residual)
            row["score"] += residual
            row["reasons"] = [{"source": POLICY_VERSION, "score": row["rule_score"]},
                              {"source": VERSION, "score": residual,
                               "explanation": "linear residual with frozen winner-only descriptive reference features"}]
        skip = next((row["score"] for row in packet["scores"] if row["is_skip"]), None)
        for row in packet["scores"]:
            row["delta_from_skip"] = None if skip is None else row["score"] - skip
        packet.update(policy_id=VERSION, policy_version=self.source["sha256"],
            feature_policy_version=POLICY_VERSION, search_policy_source=self.source,
            score_semantics=self.artifact["score_semantics"], reference_prior=copy.deepcopy(PRIOR_EVIDENCE))
        if state.get("decision") == "map_select":
            validate_input(state, self._route_input)
            packet["public_route_input"] = copy.deepcopy(self._route_input)
            packet["public_route_features_used"] = True
        candidates = {row["candidate_id"]: (materialize_candidate(space, row["request"])
                       if by_id is None else by_id[row["candidate_id"]]) for row in packet["scores"]}
        packet = deck_discipline.adjust(state, packet, candidates, self._special_builds)
        packet = event_risk_guard.adjust(state, packet, candidates, self.artifact["parameters"])
        return noncombat_potions.adjust(packet, self.artifact["noncombat_potion_policy"])
