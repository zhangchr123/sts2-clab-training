import copy
import itertools
import unittest

from selection_space import (DataContractError, build_space, indices_from_request,
                             rank_selection, request_for_indices, request_for_rank,
                             space_size, unrank_selection, validate_space)


class OrderedSelectionSpaceTests(unittest.TestCase):
    def space(self, indices=(8, 3, 5), minimum=0, maximum=3):
        return build_space([{"index": index, "id": f"CARD.FIXTURE_{index}"} for index in indices],
                           minimum, maximum, "a" * 64)

    def test_rank_unrank_equals_full_small_permutation_enumeration(self):
        for minimum, maximum in ((0, 0), (0, 3), (1, 2), (2, 3), (3, 7)):
            space = self.space(minimum=minimum, maximum=maximum)
            expected = [list(values) for size in range(minimum, min(maximum, 3) + 1)
                        for values in itertools.permutations([8, 3, 5], size)]
            self.assertEqual(space_size(space), len(expected))
            for rank, values in enumerate(expected):
                self.assertEqual(unrank_selection(space, rank), values)
                self.assertEqual(rank_selection(space, values), rank)
                self.assertEqual(indices_from_request(space, request_for_rank(space, rank)), values)

    def test_fifteen_card_full_space_is_exact_without_enumeration(self):
        space = self.space(tuple(range(15)), maximum=15)
        self.assertEqual(space_size(space), 3554627472076)
        self.assertEqual(unrank_selection(space, 0), [])
        self.assertEqual(unrank_selection(space, space_size(space) - 1), list(reversed(range(15))))
        for rank in (1, 15, 2387, 900_000_001, 3_554_627_472_075):
            self.assertEqual(rank_selection(space, unrank_selection(space, rank)), rank)
        self.assertEqual(len(space["cards"]), 15)

    def test_zero_card_optional_selection_has_one_empty_action(self):
        space = self.space((), maximum=5)
        self.assertEqual(space_size(space), 1)
        self.assertEqual(unrank_selection(space, 0), [])
        self.assertEqual(request_for_rank(space, 0)["args"], {"indices": ""})
        self.assertEqual(space["max_select"], 5)
        self.assertEqual(space["effective_max_select"], 0)

    def test_descriptor_tampering_and_unknown_fields_are_rejected(self):
        for key, value in (("candidate_count", 123), ("indices", [3, 8, 5]),
                           ("max_select", 2), ("without_replacement", 1),
                           ("state_hash", "b" * 64), ("schema_version", "future-v2"),
                           ("extra", "ignored fields would be unsafe")):
            space = self.space()
            space[key] = value
            with self.subTest(key=key), self.assertRaises(DataContractError):
                validate_space(space)
        space = self.space()
        space["cards"][0]["id"] = "CARD.CHANGED"
        with self.assertRaises(DataContractError):
            space_size(space)

    def test_illegal_indices_and_malformed_wire_requests_are_rejected(self):
        space = self.space(minimum=1, maximum=2)
        for values in ([], [8, 8], [8, 3, 5], [1], [True], [-1]):
            with self.subTest(values=values), self.assertRaises(DataContractError):
                request_for_indices(space, values)
        valid = request_for_indices(space, [8, 3])
        for text in ([8, 3], "8, 3", "08,3", "8,3,", "+8", "8,,3", "8,8"):
            request = copy.deepcopy(valid)
            request["args"]["indices"] = text
            with self.subTest(text=text), self.assertRaises(DataContractError):
                indices_from_request(space, request)
        valid["args"]["ignored"] = True
        with self.assertRaises(DataContractError):
            indices_from_request(space, valid)

    def test_out_of_range_and_boolean_ranks_are_rejected(self):
        space = self.space()
        for rank in (-1, True, 1.0, "1", space_size(space)):
            with self.subTest(rank=rank), self.assertRaises(DataContractError):
                unrank_selection(space, rank)

    def test_invalid_pool_or_bounds_never_form_a_space(self):
        for indices, minimum, maximum in (((8, 8), 0, 2), ((8, 3), 3, 4), ((8, 3), 2, 1),
                                           ((True,), 0, 1), ((-1,), 0, 1), ((8,), False, 1)):
            with self.subTest(indices=indices, minimum=minimum), self.assertRaises(DataContractError):
                self.space(indices, minimum, maximum)


if __name__ == "__main__":
    unittest.main()
