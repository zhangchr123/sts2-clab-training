"""Public pre-choice role descriptors and explicit expert priors; not a deployed model.

Rarity is a categorical scarcity proxy, never a predicted chance of seeing a card.
Role overlap is only a partial substitute proxy. Energy support is observed card
capability, not available combat energy or proof that a high-cost card is playable.
"""
import math
from decision_data import DataContractError

def require(ok, message):
    if not ok: raise DataContractError(message)
from initial_policy import card_id,card_mechanisms
from circulation_capability_features import capabilities

ROLES=('attack','defense','draw','control','exhaust_control','immediate_energy','next_energy','plasma','energy_multiplier','scaling')
EXTRA_FACTS={
    'METEOR_STRIKE':{'plasma','attack'},
    'VOLTAIC':{'scaling'},
    'DOUBLE_ENERGY':{'energy_multiplier'},
    'FUSION':{'plasma'},
    'SCAVENGE':{'exhaust_control','control','next_energy'},
}
PARAMETERS=tuple('role_'+r+'_gap' for r in ROLES)+(
    'common_attack_repeat','common_defense_repeat','functional_repeat',
    'turbo_repeat','overclock_repeat_with_energy','skim_repeat_with_energy',
    'draw_with_immediate_energy','draw_with_delayed_energy','draw_with_multiplier',
    'control_with_draw','exhaust_with_status_sources','energy_with_draw',
    'high_cost_low_energy_support','meteor_energy_gap','meteor_startup_support',
    'voltaic_lightning_support','voltaic_repeatable_lightning_support',
    'rare_first_copy_low_substitution','uncommon_first_copy_low_substitution',
    'rare_redundant_role','role_substitute_density','rarity_unknown','cost_unknown')
# Proposed domain priors, not fitted coefficients or causal action values.
PRIOR=dict.fromkeys(PARAMETERS,0.)
PRIOR.update(common_attack_repeat=-1.,common_defense_repeat=-.8,turbo_repeat=.35,
    overclock_repeat_with_energy=.65,skim_repeat_with_energy=.65,
    draw_with_immediate_energy=1.5,draw_with_delayed_energy=.8,draw_with_multiplier=.5,
    control_with_draw=.9,exhaust_with_status_sources=.8,energy_with_draw=1.2,
    high_cost_low_energy_support=-1.2,meteor_energy_gap=.8,meteor_startup_support=1.2,
    voltaic_lightning_support=1.6,voltaic_repeatable_lightning_support=.6,
    rare_first_copy_low_substitution=.7,uncommon_first_copy_low_substitution=.3,
    rare_redundant_role=-.25,role_substitute_density=-.3)


def roles(card):
    tags=card_mechanisms(card);caps=capabilities(card);cid=card_id(card)
    stats=card.get('stats') or {}
    out=set(EXTRA_FACTS.get(cid,()))
    if card.get('type')=='Attack' and any(type(stats.get(k)) in (int,float) and stats[k]>0 for k in ('damage','repeat')):
        out.add('attack')
    if tags & {'lightning_source','dark_source'}:out.add('attack')
    if (type(stats.get('block')) in (int,float) and stats['block']>0) or 'frost_source' in tags:out.add('defense')
    if 'draw' in caps:out.add('draw')
    if caps & {'discard_retrieval','zero_cost_retrieval'}:out.add('control')
    if 'energy' in caps:out.add('immediate_energy')
    if 'next_turn_energy' in caps:out.add('next_energy')
    if 'plasma_source' in tags:out.add('plasma')
    if tags & {'sustained_focus','temporary_focus','decaying_focus','power_trigger','orb_passive_trigger'}:out.add('scaling')
    return out


def extra_features(state,row,candidate):
    require(row['request']==candidate['request'],'Functional candidate binding differs')
    result=dict.fromkeys(PARAMETERS,0.)
    action=row['request']['action']
    if action in ('select_card_reward','buy_card'):cards=[candidate['evidence']]
    elif action=='select_bundle' or (action=='select_cards' and row['features'].get('selection_acquire')==1.):cards=candidate['evidence']['cards']
    else:return result
    deck=state.get('player',{}).get('deck')
    require(isinstance(deck,list) and deck and state['player']['deck_size']==len(deck),'Full actual deck required')
    droles=[roles(c) for c in deck]
    counts={r:sum(r in cs for cs in droles) for r in ROLES}
    density={r:counts[r]/len(deck) for r in ROLES}
    # Saturating support indicators are explicit heuristics, not energy quantities.
    immediate=counts['immediate_energy']/(1+counts['immediate_energy'])
    delayed_count=counts['next_energy']+counts['plasma']
    delayed=delayed_count/(1+delayed_count)
    multiplier=counts['energy_multiplier']/(1+counts['energy_multiplier'])
    support=1-(1-immediate)*(1-delayed)*(1-multiplier)
    lightning=sum('lightning_source' in card_mechanisms(c) for c in deck)/len(deck)
    status=sum('status_source' in card_mechanisms(c) or c.get('type') in ('Status','Curse') for c in deck)/len(deck)
    seen={}
    for card in cards:
        cid=card_id(card);cr=roles(card)
        copies=sum(card_id(c)==cid for c in deck)+seen.get(cid,0);seen[cid]=seen.get(cid,0)+1
        repeat=min(4,copies)
        functional=bool(cr & {'draw','control','exhaust_control','immediate_energy','next_energy','plasma','energy_multiplier','scaling'})
        rarity=card.get('rarity')
        cost=card.get('card_cost') if action=='buy_card' else card.get('cost')
        cost_known=type(cost) in (int,float) and math.isfinite(cost) and cost>=0
        substitutes=sum(bool(cr & dr) and card_id(dc)!=cid for dc,dr in zip(deck,droles))/len(deck) if cr else 0.
        values={'role_'+r+'_gap':float(r in cr)/(1+counts[r]) for r in ROLES}
        values.update(common_attack_repeat=repeat*float(rarity=='Common' and 'attack' in cr and not functional),
            common_defense_repeat=repeat*float(rarity=='Common' and 'defense' in cr and not functional),
            functional_repeat=repeat*float(functional),turbo_repeat=repeat*float(cid=='TURBO'),
            overclock_repeat_with_energy=repeat*float(cid=='OVERCLOCK')*support,
            skim_repeat_with_energy=repeat*float(cid=='SKIM')*support,
            draw_with_immediate_energy=float('draw' in cr)*immediate,
            draw_with_delayed_energy=float('draw' in cr)*delayed,
            draw_with_multiplier=float('draw' in cr)*multiplier,
            control_with_draw=float('control' in cr or 'exhaust_control' in cr)*density['draw'],
            exhaust_with_status_sources=float('exhaust_control' in cr)*status,
            energy_with_draw=float(bool(cr & {'immediate_energy','next_energy','plasma','energy_multiplier'}))*density['draw'],
            high_cost_low_energy_support=(min(4.,max(0.,cost-1))/4. if cost_known else 0.)*(1-support)*float(card.get('type') in ('Attack','Skill')),
            meteor_energy_gap=float(cid=='METEOR_STRIKE')*(1-support),
            meteor_startup_support=float(cid=='METEOR_STRIKE')*(1-(1-immediate)*(1-multiplier)),
            voltaic_lightning_support=float(cid=='VOLTAIC')*lightning,
            voltaic_repeatable_lightning_support=float(cid=='VOLTAIC' and card.get('current_upgrade_level',0)>0)*lightning,
            rare_first_copy_low_substitution=float(rarity=='Rare' and copies==0 and bool(cr))*(1-substitutes),
            uncommon_first_copy_low_substitution=float(rarity=='Uncommon' and copies==0 and bool(cr))*(1-substitutes),
            rare_redundant_role=float(rarity=='Rare')*substitutes,
            role_substitute_density=substitutes,rarity_unknown=float(rarity not in ('Basic','Common','Uncommon','Rare','Special','Ancient','Event','Curse','Status')),
            cost_unknown=float(not cost_known))
        for k,v in values.items():result[k]+=v
    require(set(result)==set(PARAMETERS) and all(math.isfinite(v) and v>=0 for v in result.values()),'Invalid role feature')
    return result


def proposed_delta(state,row,candidate,baseline_parameters,parameters=None):
    """Review-only overlay. The original hard block and deck penalties stay in force."""
    f=extra_features(state,row,candidate);weights=PRIOR if parameters is None else parameters
    require(set(weights)==set(PARAMETERS) and all(type(v) in (int,float) and math.isfinite(v) for v in weights.values()),'Invalid proposed weights')
    # The frozen InitialPolicy opportunity penalty is .12 per copy for single/ordered acquisition,
    # but bundles have no generic .12 term. Each card retains its model duplicate term.
    # plus the baseline card_duplicate coefficient. Replace only that generic
    # component for functional cards; do not touch the independent deck-size cap.
    opportunity_duplicate_rate=0. if row['request']['action']=='select_bundle' else .12
    correction=(opportunity_duplicate_rate-baseline_parameters['card_duplicate'])*f['functional_repeat']
    delta=sum(weights[k]*f[k] for k in PARAMETERS)+correction
    blocked=bool(row.get('deck_discipline',{}).get('hard_blocked'))
    return dict(features=f,delta=0. if blocked else delta,generic_functional_repeat_correction=0. if blocked else correction,
        hard_block_preserved=blocked,expert_prior_not_fitted=True,calibrated_probability=False,
        missing_context=['actual_future_reward_probability','full_role_coverage','energy_from_relics','actual_combat_draw_order','guaranteed_high_cost_bootstrap'])
