"""Real Knowledge Demon effects and solver replay; artificial fixtures, never training."""
import copy
import json
import unittest
import uuid

from combat_executor import CombatExecutor, solver_config
from probe import Bridge, ROOT
from run_metadata import file_evidence


class KnowledgeDemonTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.bridge = Bridge(self.label)
        self.requests, self.replay = [], []
        self.versions = {"engine": file_evidence(ROOT.parent / "sts2-cli/lib/sts2.dll"),
            "solver": file_evidence(ROOT / "lib/CombatSolver.dll"),
            "bridge": file_evidence(ROOT / "runtime/host/bin/Debug/net9.0/SolverBridge.dll"),
            "cli": file_evidence(ROOT.parent / "sts2-cli/src/Sts2Headless/bin/Debug/net9.0/Sts2Headless.dll")}
        self.send(cmd="start_run", character="Defect", ascension=10, seed="knowledge-effect-fixture-1")

    def tearDown(self):
        try:
            with (ROOT / "outputs" / (self.label + ".json")).open("x", encoding="utf-8") as handle:
                json.dump({"fixture": True, "training_eligible": False,
                    "provenance": "artificial room/HP setup; original DLL effects, no natural data",
                    "versions": self.versions, "requests": self.requests,
                    "responses": self.bridge.rows, "solver_replay": self.replay}, handle,
                    ensure_ascii=False, indent=2)
        finally:
            self.bridge.close()

    def send(self, **request):
        self.requests.append(copy.deepcopy(request))
        response = self.bridge.send(**request)
        self.assertNotEqual(response.get("type"), "error", response)
        return response

    def test_original_solver_plan_crosses_knowledge_choice_and_matches_terminal(self):
        self.send(cmd="set_player", hp=40)
        state = self.send(cmd="enter_room", type="combat", encounter="KNOWLEDGE_DEMON_BOSS")
        config = solver_config()
        config.update(solver_backend="coordinator", first_budget_ms=1500, replan_budget_ms=1500,
                      retry_budget_ms=1500, max_replans=3)
        executor = CombatExecutor(self.send, config)
        try:
            final = executor.advance(state)
        finally:
            self.replay = executor.solve_calls
        self.assertEqual(final["decision"], "game_over", final)
        self.assertIs(final["victory"], False)
        self.assertIs(final["context"]["integrity_recovery_used"], False)
        self.assertEqual(final["player"]["hp"], executor.solve_calls[-1]["response"]["snapshot"]["PlayerHp"])
        observed = [entry for call in executor.solve_calls for entry in call.get("replay", [])
                    if entry["kind"] == "knowledge_demon_effect_choice"]
        self.assertTrue(observed, "Must execute an actual solver-generated Knowledge Demon choice")
        for entry in observed:
            self.assertEqual(entry["plan"]["Cards"][0]["StateKey"], "")
            self.assertEqual(entry["plan"]["SourceId"], entry["actual_choice_metadata"]["knowledge_choice"]["source_id"])

    def test_original_three_counters_apply_dynamic_effect_and_reject_stale_source(self):
        self.send(cmd="set_player", hp=1000, max_hp=1000, deck=["DEFEND_DEFECT"] * 5, relics=[])
        state = self.send(cmd="enter_room", type="combat", encounter="KNOWLEDGE_DEMON_BOSS")
        executor = CombatExecutor(self.send)
        alternatives = ["MIND_ROT", "SLOTH", "WASTE_AWAY"]
        for counter in range(3):
            # Only advance the real engine; no counter, powers, or hidden state edits.
            for _ in range(5):
                state = self.send(cmd="action", action="end_turn")
                if state["decision"] == "card_select":
                    break
                self.assertEqual(state["decision"], "combat_play", state)
            self.assertEqual(state["decision"], "card_select")
            meta = self.send(cmd="choice_meta")
            audit = meta["knowledge_choice"]
            self.assertEqual(audit["curse_counter"], counter)
            self.assertEqual(audit["engine_option_ids"], ["DISINTEGRATION", alternatives[counter]])
            self.assertIn(f"DisintegrationPower={6 + counter}", meta["cards"][0]["key"])
            # Explicitly constructed regression token, matching the decompiled
            # original BuildChoices contract; this is not a solver quality sample.
            plan = {"Effect": "ApplyKnowledgeCurse", "SourcePile": "None", "Timing": "EnemyTurn",
                "SourceId": audit["source_id"], "ContextId": "", "Cards": [{"CardId": "DISINTEGRATION",
                    "UpgradeLevel": 0, "StateKey": "", "SourceOccurrence": 0, "OptionOccurrence": 0}]}
            stale = {**plan, "SourceId": f"KNOWLEDGE_DEMON:{audit['source_combat_id']}:{counter + 1}"}
            before_requests = len(self.requests)
            with self.assertRaisesRegex(RuntimeError, "original effect identity"):
                executor.resolve(state, [stale])
            self.assertFalse(any(r.get("cmd") == "action" for r in self.requests[before_requests:]))
            state = executor.resolve(state, [plan])
            self.assertEqual(state["decision"], "combat_play")
            powers = [p for p in state["player_powers"] if "Disintegration" in p["name"]]
            self.assertEqual([p["amount"] for p in powers], [sum(6 + n for n in range(counter + 1))])
            self.assertIs(self.send(cmd="choice_meta")["knowledge_choice"], None)
            self.assertIs(state["context"]["integrity_recovery_used"], False)

    def test_repeated_real_searches_and_counter_plans_never_pollute_live_observer(self):
        self.send(cmd="set_player", hp=1000, max_hp=1000, deck=["DEFEND_DEFECT"] * 5, relics=[])
        state = self.send(cmd="enter_room", type="combat", encounter="KNOWLEDGE_DEMON_BOSS")
        config = solver_config()
        config.update(solver_backend="coordinator", retry_budget_ms=1000)
        executor = CombatExecutor(self.send, config)
        for counter in range(3):
            # Two actual searches of the same live root; the first uses a very
            # short budget. Never fabricate a cancellation or remove a failed call.
            executor.solve(state, 100)
            result = executor.solve(state, 1000)
            self.replay = executor.solve_calls
            self.assertIs(self.send(cmd="choice_meta")["knowledge_choice"], None)
            action = next(a for a in result["actions"] if a["Kind"] == "EndTurn"
                          and a["Turn"] == state["player_turn"])
            plans = [p for p in action.get("TurnStartChoices") or [] if p["Effect"] == "ApplyKnowledgeCurse"]
            self.assertEqual(len(plans), 1, action)
            self.assertTrue(plans[0]["SourceId"].endswith(f":{counter}"))
            pending = self.send(cmd="action", action="end_turn")
            self.assertEqual(pending["decision"], "card_select")
            state = executor.resolve(pending, plans)
            self.assertEqual(state["decision"], "combat_play")
            self.assertIs(self.send(cmd="choice_meta")["knowledge_choice"], None)
            if counter < 2:
                for _ in range(3):
                    state = self.send(cmd="action", action="end_turn")
                    self.assertEqual(state["decision"], "combat_play")
        evidence = [r for call in executor.solve_calls for r in call.get("replay", [])]
        self.assertEqual([r["actual_choice_metadata"]["knowledge_choice"]["curse_counter"] for r in evidence], [0, 1, 2])

    def test_engine_requires_a_new_worker_for_a_new_run(self):
        self.send(cmd="enter_room", type="combat", encounter="KNOWLEDGE_DEMON_BOSS")
        pending = self.send(cmd="action", action="end_turn")
        self.assertEqual(pending["decision"], "card_select")
        old = self.send(cmd="choice_meta")["knowledge_choice"]
        self.assertTrue(old["original_task_pending"])
        request = {"cmd": "start_run", "character": "Defect", "ascension": 10,
                   "seed": "knowledge-effect-fixture-new-run"}
        self.requests.append(request)
        rejected = self.bridge.send(**request)
        self.assertEqual(rejected["type"], "error")
        self.assertIn("State is already set", rejected["message"])
        # Same-worker restart is outside the original engine contract. Natural
        # runs and all fixtures start fresh workers, so pending statics cannot
        # cross runs. Do not pretend this failed restart produced a new state.


if __name__ == "__main__":
    unittest.main()
