"""Synthetic warmstart provenance, seed separation and parameter continuity."""
import copy
import importlib.util
import json
from pathlib import Path
import random
import sys
import tempfile
import unittest
from unittest.mock import patch
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from run_metadata import file_evidence
from whole_run_policy import make_artifact, PARAMETERS

import train_whole_run as trainer


class WarmstartTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = json.loads((ROOT / 'configs/defect-v3-base.json').read_text())
        self.center = {k: (i - 9) / 10 for i, k in enumerate(PARAMETERS)}
        parent = {'training_seeds': [['ancestor-train']], 'reserved_evaluation_seeds': ['ancestor-test'],
            'ancestor_seeds': ['grandparent-test']}
        self.parent = self.root / 'parent.json'; self.parent.write_text(json.dumps(parent))
        self.model = self.root / 'parent-model.json'
        self.model.write_text(json.dumps(make_artifact(self.center, self.config,
            training={'protocol': file_evidence(self.parent), 'synthetic_test_only': True})))

    def prepare(self):
        path = self.root / 'next' / 'protocol.json'
        doc = trainer.prepare(path, name='synthetic-warm', generations=2, seeds_per_generation=2,
            initial_model=self.model)
        return path, doc

    def test_inherits_all_parameters_and_initial_population_center(self):
        _, doc = self.prepare()
        self.assertEqual(doc['schema_version'], trainer.WARM_VERSION)
        center, std = trainer.initial_distribution(doc)
        self.assertEqual(center, self.center)
        self.assertEqual(trainer.population(center, std, random.Random('fixture'))[0], self.center)
        self.assertEqual(set(doc['ancestor_seeds']), {'ancestor-train', 'ancestor-test', 'grandparent-test'})
        self.assertTrue(any(s == file_evidence(self.model) for s in doc['frozen_sources']))

    def test_ancestor_overlap_and_center_tampering_rejected(self):
        _, doc = self.prepare()
        for modify in ('center', 'train', 'test', 'lineage'):
            bad = copy.deepcopy(doc)
            if modify == 'center': bad['initial_center'][PARAMETERS[0]] += .01
            if modify == 'train': bad['training_seeds'][0][0] = 'grandparent-test'
            if modify == 'test': bad['reserved_evaluation_seeds'][0] = 'ancestor-train'
            if modify == 'lineage': bad['ancestor_seeds'] = []
            with self.assertRaises(ValueError): trainer.initial_distribution(bad)

    def test_source_tampering_rejected_before_new_execution(self):
        path, _ = self.prepare()
        self.model.write_text('{}')
        with patch.object(trainer, 'run_one') as run_one, self.assertRaises(ValueError):
            trainer.run(path)
        run_one.assert_not_called()
        self.assertFalse((path.parent / 'execution-started.json').exists())

    def test_fresh_generations_export_inherited_then_updated_candidates(self):
        path, doc = self.prepare()
        params_seen = []
        def synthetic_run(label, seed, **kwargs):
            params_seen.append(json.loads(kwargs['model_path'].read_text())['parameters'])
            return {'run_id': label, 'seed': seed, 'outcome': 'defeat'}
        def synthetic_audit(report, destination, *, seed):
            return {'fitness': .17, 'goal_success_for_search': False, 'audit_passed': True,
                'report': report}
        with patch.object(trainer, 'run_one', side_effect=synthetic_run) as run_one, \
             patch.object(trainer, 'audit_training_run', side_effect=synthetic_audit), \
             patch('builtins.print'):
            trainer.run(path)
        self.assertEqual(run_one.call_count, 36)
        a = json.loads((path.parent / 'generation-00/allocation.json').read_text())
        b = json.loads((path.parent / 'generation-01/allocation.json').read_text())
        summary = json.loads((path.parent / 'generation-00/summary.json').read_text())
        self.assertEqual(a['vectors'][0], self.center)
        self.assertEqual(b['vectors'][0], summary['center_after'])
        self.assertTrue((path.parent / 'training-completed.json').exists())
        with self.assertRaises(FileExistsError): trainer.run(path)

    def test_legacy_protocol_still_starts_at_zero(self):
        p = self.root / 'legacy' / 'protocol.json'
        doc = trainer.prepare(p, name='legacy-synthetic')
        self.assertEqual(doc['schema_version'], trainer.VERSION)
        self.assertEqual(trainer.initial_distribution(doc)[0], dict.fromkeys(PARAMETERS, 0.))

    def test_wider_exploration_is_declared_and_nonfinite_values_rejected(self):
        path = self.root / 'wide' / 'protocol.json'
        doc = trainer.prepare(path, name='wide-synthetic', initial_model=self.model, initial_std=1.5)
        center, std = trainer.initial_distribution(doc)
        self.assertEqual(center, self.center)
        self.assertEqual(std, dict.fromkeys(PARAMETERS, 1.5))
        for bad in (float('nan'), float('inf'), True, 0., 2.1):
            with self.assertRaises(ValueError): trainer.initial_distribution({**doc, 'initial_std': bad})


if __name__ == '__main__': unittest.main(verbosity=2)
