"""Conservative public nominal-cost policy rule; not a damage-hook simulator."""
import math
from decision_data import DataContractError
from event_cost_features import CONTRACTS, nonnegative

COST_PARAMETERS=('event_nominal_hp_cost_per_max_hp','event_nominal_hp_cost_per_current_hp',
                 'event_nominal_cost_reaches_current_hp')
CONTRACT={'version':'known-event-nominal-cost-guard-v1','remove_positive_learned_cost_contribution':True,
    'minimum_cost_penalty':'0.25*clipped_cost_per_max_hp + clipped_cost_per_current_hp',
    'block_nominal_cost_reaching_hp_only_with_known_zero_cost_permitted_alternative':True,
    'damage_hooks_and_revival_not_simulated':True,'unknown_option_effects_not_inferred':True}


def adjust(state,packet,candidates,weights):
    if state.get('decision')!='event_choice':return packet
    hp=nonnegative(state.get('player',{}).get('hp'),'current HP',True)
    annotated=[]
    for row in packet['scores']:
        candidate=candidates[row['candidate_id']]
        if row['request']!=candidate['request']:raise DataContractError('Risk row/candidate mismatch')
        key=candidate['evidence'].get('text_key')
        contract=CONTRACTS.get(key) if row['request'].get('action')=='choose_option' else None
        if contract is None:continue
        cost_key=contract[0]
        variables=candidate['evidence'].get('vars',{})
        if not isinstance(variables,dict):raise DataContractError('Invalid known event variables')
        cost=0. if cost_key is None else nonnegative(variables.get(cost_key),cost_key)
        annotated.append((row,cost,key))
    allowed_zero=any(cost==0. and not row.get('deck_discipline',{}).get('hard_blocked',False)
        and row['score']>-1e90 for row,cost,key in annotated)
    for row,cost,key in annotated:
        values=row['search_features']
        learned=sum(weights[k]*values[k] for k in COST_PARAMETERS)
        correction=max(0.,learned)
        nominal_penalty=.25*values[COST_PARAMETERS[0]]+values[COST_PARAMETERS[1]]
        blocked=bool(cost>=hp and allowed_zero)
        before=row['score']
        if not math.isfinite(before):raise DataContractError('Nonfinite event risk score')
        row['score']=-1e100 if blocked else before-correction-nominal_penalty
        row['event_risk_guard']=dict(text_key=key,nominal_hp_cost=cost,current_hp=hp,
            known_zero_cost_permitted_alternative=allowed_zero,hard_blocked=blocked,
            positive_learned_cost_removed=correction,nominal_cost_penalty=nominal_penalty,
            score_before=before,actual_damage_or_guaranteed_death_claimed=False)
        row.setdefault('reasons',[]).append(dict(source=CONTRACT['version'],score=row['score']-before,
            explanation='Known nominal HP costs cannot earn positive learned value; nominally lethal costs yield to a permitted known zero-cost option.'))
    skip=next((r['score'] for r in packet['scores'] if r['is_skip']),None)
    for row in packet['scores']:row['delta_from_skip']=None if skip is None else row['score']-skip
    packet['event_risk_contract']=dict(CONTRACT)
    return packet
