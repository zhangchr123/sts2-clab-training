"""Synthetic temporary wire fixtures only; never publish these as game evidence."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from decision_data import DataContractError, DecisionJournal, split_by_seed
from initial_policy import InitialPolicy
from selection_context import direct_action_evidence
from test_initial_policy import card, state as reward_state
from test_train_ranker import seed_in
from train_act_survival import (Act1SurvivalScorer, RUNTIME_KEYS, SOURCE_KEYS, VERSION,
                                load_dataset, train)


class ActSurvivalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def fixture(self, name, *, seed=None, reached=False, steps=1, termination="engine_terminal",
                epsilon=.2):
        """Natural-shaped synthetic records exercise validation, not play strength."""
        seed = seed or seed_in("train")
        path = self.root / name
        policy = InitialPolicy(prior_path=None, epsilon=epsilon, random_seed=seed)
        states = [reward_state([card("TEST", damage=6 + i)]) for i in range(steps + int(reached))]
        for index, state in enumerate(states):
            state["context"].update(act=2 if reached and index == steps else 1,
                                    integrity_recovery_used=False, room_type="Event")
        picks = [policy.choose(state) for state in states]
        def evidence(key):
            return {"path": "synthetic/" + key, "sha256": hashlib.sha256(key.encode()).hexdigest(), "bytes": 100}
        versions = {key: evidence(key) for key in RUNTIME_KEYS}
        versions["engine"]["sha256"] = policy.mechanism_source["engine_sha256"]
        versions["sources"] = {key: evidence(key) for key in SOURCE_KEYS}
        metadata = {"run_id": name, "seed": seed, "character": "Defect", "ascension": 10,
            "mode": "standard", "versions": versions, "solver_requested_config": {"budget_ms": 1000},
            "provenance": policy.provenance, "branch_restore_enabled": False, "llm_used_for_combat": False,
            "sampling": {"hidden_audit_features_used": False, "max_seconds": 1200, "max_decisions": 500}}
        final = {"type": "decision", "decision": "game_over", "victory": False,
            "context": {"ascension": 10, "act": 2 if reached else 1, "integrity_recovery_used": False,
                        "combat_in_progress": False, "room_type": "Event"}, "player": {"hp": 0}}
        traces = [{"request": {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": seed},
                   "response": states[0]}]
        policies = []
        with DecisionJournal(path, metadata) as journal:
            for index, (state, picked) in enumerate(zip(states, picks)):
                result = states[index + 1] if index + 1 < len(states) else final
                token = journal.begin(state, picked["request"], policy=picked["policy_provenance"])
                policies.append({"decision_id": token, **picked, "selection_context": None})
                journal.complete(token, result, solver_calls=[], execution={"selection_context": None,
                    "selection_purpose": None, "direct_action_result": direct_action_evidence(result)})
                traces.append({"request": picked["request"], "response": result})
            journal.finalize(final, termination=termination)
        self.write_lines(path / "policy.jsonl", policies)
        self.write_lines(path / "trace.jsonl", traces)
        return path

    @staticmethod
    def read_lines(path):
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]

    @staticmethod
    def write_lines(path, rows):
        path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")

    def inputs(self):
        return [self.fixture("train" + str(i), seed=seed_in("train", i), reached=bool(i % 2)) for i in range(10)]

    def test_only_act1_executed_choices_have_observed_labels(self):
        path = self.fixture("reached", reached=True, steps=3)
        data = load_dataset([path])
        self.assertEqual(len(data["records"]), 4)
        self.assertEqual(len(data["examples"]), 3)
        self.assertTrue(all(e["target"] == 1. for e in data["examples"]))
        self.assertEqual(data["labels"]["reached"]["terminal_outcome"], "defeat")
        self.assertEqual(data["labels"]["reached"]["act2_entry"]["trace_index"], 3)
        for example in data["examples"]:
            record = next(r for r in data["records"] if r["decision_id"] == example["decision_id"])
            self.assertEqual(example["candidate_id"], record["chosen"]["candidate_id"])
        lost = load_dataset([self.fixture("lost")])
        self.assertEqual(lost["examples"][0]["target"], 0.)
        self.assertIsNone(lost["labels"]["lost"]["act2_entry"])

    def test_weights_equal_seed_then_run_then_decision(self):
        seed = seed_in("train")
        data = load_dataset([self.fixture("short", seed=seed, steps=1),
                             self.fixture("long", seed=seed, steps=3),
                             self.fixture("other", seed=seed_in("train", 1), steps=2)])
        weights = {name: sum(e["weight"] for e in data["examples"] if e["run_id"] == name)
                   for name in ("short", "long", "other")}
        self.assertEqual(weights, {"short": .5, "long": .5, "other": 1.})

    def test_error_after_act2_is_rejected_instead_of_positive_label(self):
        with self.assertRaisesRegex(DataContractError, "Entire input run"):
            load_dataset([self.fixture("error", reached=True, termination="environment_error")])

    def test_trace_injection_restore_restart_error_and_missing_response_rejected(self):
        changes = [lambda rows: rows.insert(1, {"request": {"cmd": "set_player"}, "response": {"type": "ok"}}),
                   lambda rows: rows.insert(1, {"request": {"cmd": "load_save"}, "response": {"type": "ok"}}),
                   lambda rows: rows.insert(1, copy.deepcopy(rows[0])),
                   lambda rows: rows[1].update(response={"type": "error", "message": "original engine error"}),
                   lambda rows: rows[1].update(response=None, transport_error="TimeoutError"),
                   lambda rows: rows[1]["request"].update(action="set_hp")]
        for index, mutate in enumerate(changes):
            with self.subTest(index=index):
                path = self.fixture("bad" + str(index))
                rows = self.read_lines(path / "trace.jsonl")
                mutate(rows)
                self.write_lines(path / "trace.jsonl", rows)
                with self.assertRaises(DataContractError):
                    load_dataset([path])

    def test_trace_label_is_not_inferred_from_unverified_journal_context(self):
        path = self.fixture("forged", reached=True)
        rows = self.read_lines(path / "trace.jsonl")
        rows[1]["response"]["context"]["act"] = 1
        rows[-1]["response"]["context"]["act"] = 1
        self.write_lines(path / "trace.jsonl", rows)
        with self.assertRaises(DataContractError):
            load_dataset([path])

    def test_future_injected_feature_does_not_pass_recomputation(self):
        path = self.fixture("features")
        rows = self.read_lines(path / "policy.jsonl")
        chosen = rows[0]["candidate_id"]
        for row in rows[0]["scoring"]["scores"]:
            if row["candidate_id"] == chosen:
                row["features"]["health_deficit"] = 999.
        self.write_lines(path / "policy.jsonl", rows)
        with self.assertRaisesRegex(DataContractError, "pre-action state"):
            load_dataset([path])

    def test_reject_mixed_followup_and_missing_runtime_evidence(self):
        a, b = self.fixture("a"), self.fixture("b", epsilon=.9)
        with self.assertRaisesRegex(DataContractError, "Cannot mix"):
            load_dataset([a, b])
        rows = self.read_lines(a / "decisions.jsonl")
        rows[0]["metadata"]["versions"]["sources"].pop("selection_context.py")
        self.write_lines(a / "decisions.jsonl", rows)
        with self.assertRaisesRegex(DataContractError, "source evidence"):
            load_dataset([a])

    def test_minimum_training_seeds_and_both_classes_required(self):
        with self.assertRaisesRegex(DataContractError, "at least 10"):
            train([self.fixture("one", reached=True)], self.root / "none.json")
        paths = [self.fixture("negative" + str(i), seed=seed_in("train", i)) for i in range(10)]
        with self.assertRaisesRegex(DataContractError, "both actual"):
            train(paths, self.root / "none.json")
        self.assertFalse((self.root / "none.json").exists())

    def test_whole_seed_split_and_no_test_features_in_fit(self):
        paths = self.inputs()
        repeated = self.fixture("same-seed", seed=seed_in("train"), reached=True)
        held_out = self.fixture("test", seed=seed_in("test"), reached=True)
        validation = self.fixture("validation", seed=seed_in("validation"), reached=True)
        first = train(paths + [repeated], self.root / "train-only.json")
        model = train(paths + [repeated, held_out, validation], self.root / "model.json")
        self.assertEqual(model["weights"], first["weights"])
        self.assertEqual(model["means"], first["means"])
        self.assertEqual(model["training_seed_count"], 10)
        self.assertIn("same-seed", model["split_runs"]["train"])
        self.assertEqual(model["split_runs"]["test"], ["test"])
        self.assertNotIn("test", model["validation"])
        self.assertNotIn("test", model["observed_labels"])
        self.assertFalse(model["test_used_for_fit_or_tuning"])
        self.assertFalse(model["automatic_deployment"])
        self.assertEqual(model["format"], VERSION)
        self.assertFalse(model["calibrated_probability"])

    def test_prediction_scope_legal_requests_facts_and_rng_purity(self):
        path = self.root / "model.json"
        train(self.inputs(), path)
        fallback = InitialPolicy(prior_path=None, random_seed="untouched")
        scorer = Act1SurvivalScorer(path, fallback=fallback)
        current = reward_state()
        current["context"].update(act=1, integrity_recovery_used=False)
        request = {"cmd": "action", "action": "skip_card_reward"}
        before = fallback.rng.getstate()
        packet = scorer.score_requests(current, [request], character="Defect", mode="standard")
        self.assertEqual(fallback.choice_count, 0)
        self.assertEqual(fallback.rng.getstate(), before)
        self.assertFalse(packet["calibrated"])
        self.assertTrue(packet["act1_proxy_only"])
        self.assertEqual(packet["scores"][0]["delta_from_skip"], 0.)
        for changes, character, mode in (({"act": 2}, "Defect", "standard"),
                                          ({"act": 1}, "Ironclad", "standard"),
                                          ({"act": 1}, "Defect", "daily"),
                                          ({"act": 1, "combat_in_progress": True}, "Defect", "standard")):
            invalid = copy.deepcopy(current)
            invalid["context"].update(changes)
            with self.assertRaises(DataContractError):
                scorer.score_requests(invalid, [request], character=character, mode=mode)
        with self.assertRaises(DataContractError):
            scorer.score_requests(current, [{"cmd": "action", "action": "set_hp"}], character="Defect", mode="standard")
        fallback.mechanism_source["registry_sha256"] = "0" * 64
        with self.assertRaisesRegex(DataContractError, "frozen model"):
            scorer.score_requests(current, [request], character="Defect", mode="standard")

    def test_fixture_and_llm_metadata_rejected(self):
        for name, change in (("fixture", {"origin": "fixture"}), ("llm", {"llm_involved": True, "kind": "llm"})):
            path = self.fixture(name)
            rows = self.read_lines(path / "decisions.jsonl")
            rows[0]["metadata"]["provenance"].update(change)
            self.write_lines(path / "decisions.jsonl", rows)
            with self.assertRaises(DataContractError):
                load_dataset([path])

    def test_duplicate_json_keys_rejected(self):
        path = self.fixture("duplicate")
        trace = path / "trace.jsonl"
        trace.write_text(trace.read_text(encoding="utf-8").replace('"cmd": "start_run"',
                         '"cmd": "set_player", "cmd": "start_run"', 1), encoding="utf-8")
        with self.assertRaisesRegex(DataContractError, "Duplicate JSON"):
            load_dataset([path])


if __name__ == "__main__":
    unittest.main()
