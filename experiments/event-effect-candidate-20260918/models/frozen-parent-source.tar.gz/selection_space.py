"""Exact compact space for ordered, non-repeating card selections.

Sequences are ordered first by their length, then by the input card-pool order
(the same order as itertools.permutations). Rank/unrank permits exact uniform
sampling with rng.randrange(space_size(space)), without enumerating the space.
The descriptor describes all legal actions; it is never a scored proposal set.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from typing import Any, Mapping, Sequence


SPACE_VERSION = "sts2.ordered_selection.v1"


class DataContractError(ValueError):
    """Evidence is incomplete, malformed, stale or internally inconsistent."""


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise DataContractError(f"{name} must be an integer >= {minimum}")
    return value


def build_space(cards: Sequence[Mapping[str, Any]], min_select: int, max_select: int,
                state_hash: str) -> dict[str, Any]:
    """Build a descriptor with original cards/bounds and a checked exact count."""
    if not isinstance(cards, list) or any(not isinstance(card, dict) for card in cards):
        raise DataContractError("Selection cards must be an exported list of objects")
    indices = [_integer(card.get("index"), "cards.index") for card in cards]
    if len(set(indices)) != len(indices):
        raise DataContractError("Selection pool contains duplicate indices")
    minimum, maximum = _integer(min_select, "min_select"), _integer(max_select, "max_select")
    if minimum > maximum or minimum > len(cards):
        raise DataContractError("Inconsistent card selection bounds")
    if not isinstance(state_hash, str) or re.fullmatch(r"[0-9a-f]{64}", state_hash) is None:
        raise DataContractError("Selection space requires the full state SHA-256")
    effective_maximum = min(maximum, len(cards))
    space = {"schema_version": SPACE_VERSION, "state_hash": state_hash,
             "cards": json.loads(_json(cards)), "indices": indices,
             "min_select": minimum, "max_select": maximum, "effective_max_select": effective_maximum,
             "candidate_count": sum(math.perm(len(cards), k) for k in range(minimum, effective_maximum + 1)),
             "ordering": "significant", "without_replacement": True}
    space["space_hash"] = hashlib.sha256(_json(space).encode("utf-8")).hexdigest()
    return space


def validate_space(space: Mapping[str, Any]) -> dict[str, Any]:
    """Strict structural/count/hash validation; no unknown fields are ignored."""
    if not isinstance(space, Mapping):
        raise DataContractError("Selection-space descriptor must be an object")
    required = {"schema_version", "state_hash", "cards", "indices", "min_select", "max_select",
                "effective_max_select", "candidate_count", "ordering", "without_replacement", "space_hash"}
    if set(space) != required or space.get("schema_version") != SPACE_VERSION:
        raise DataContractError("Unsupported or incomplete selection-space schema")
    actual = build_space(space["cards"], space["min_select"], space["max_select"], space["state_hash"])
    # JSON comparison preserves the distinction between booleans and integers.
    if _json(actual) != _json(space):
        raise DataContractError("Selection-space descriptor has inconsistent indices, bounds, count or hash")
    return actual


def space_size(space: Mapping[str, Any]) -> int:
    return validate_space(space)["candidate_count"]


def _validate_indices(space, indices):
    if not isinstance(indices, (list, tuple)):
        raise DataContractError("Selection indices must be an ordered list or tuple")
    values = [_integer(index, "selection index") for index in indices]
    if not space["min_select"] <= len(values) <= space["effective_max_select"]:
        raise DataContractError("Selection cardinality violates current bounds")
    if len(set(values)) != len(values):
        raise DataContractError("A card instance cannot occur twice in one selection")
    if not set(values) <= set(space["indices"]):
        raise DataContractError("Selection contains an index absent from the current pool")
    return values


def rank_selection(space: Mapping[str, Any], indices: Sequence[int]) -> int:
    """Map a legal complete sequence to its unique integer rank."""
    space = validate_space(space)
    indices = _validate_indices(space, indices)
    pool = list(space["indices"])
    n, k = len(pool), len(indices)
    rank = sum(math.perm(n, length) for length in range(space["min_select"], k))
    for position, index in enumerate(indices):
        offset = pool.index(index)
        rank += offset * math.perm(n - position - 1, k - position - 1)
        pool.pop(offset)
    return rank


def unrank_selection(space: Mapping[str, Any], rank: int) -> list[int]:
    """Return one exact sequence in O(pool size + selection size squared)."""
    space = validate_space(space)
    rank = _integer(rank, "rank")
    if rank >= space["candidate_count"]:
        raise DataContractError("Rank is outside the complete selection space")
    pool = list(space["indices"])
    n = len(pool)
    for length in range(space["min_select"], space["effective_max_select"] + 1):
        block = math.perm(n, length)
        if rank < block:
            break
        rank -= block
    selected = []
    for position in range(length):
        block = math.perm(n - position - 1, length - position - 1)
        offset, rank = divmod(rank, block)
        selected.append(pool.pop(offset))
    return selected


def request_for_indices(space: Mapping[str, Any], indices: Sequence[int]) -> dict[str, Any]:
    space = validate_space(space)
    indices = _validate_indices(space, indices)
    return {"cmd": "action", "action": "select_cards", "args": {"indices": ",".join(map(str, indices))}}


def request_for_rank(space: Mapping[str, Any], rank: int) -> dict[str, Any]:
    return request_for_indices(space, unrank_selection(space, rank))


def indices_from_request(space: Mapping[str, Any], request: Mapping[str, Any]) -> list[int]:
    """Accept only the canonical wire form, with no silent parsing/defaulting."""
    space = validate_space(space)
    if (not isinstance(request, Mapping) or set(request) != {"cmd", "action", "args"}
            or request.get("cmd") != "action" or request.get("action") != "select_cards"
            or not isinstance(request.get("args"), Mapping) or set(request["args"]) != {"indices"}):
        raise DataContractError("Expected an exact select_cards wire request")
    text = request["args"]["indices"]
    if not isinstance(text, str) or (text and re.fullmatch(r"(?:0|[1-9][0-9]*)(?:,(?:0|[1-9][0-9]*))*", text) is None):
        raise DataContractError("indices must be a canonical comma-separated integer string")
    indices = [] if text == "" else [int(value) for value in text.split(",")]
    return _validate_indices(space, indices)
