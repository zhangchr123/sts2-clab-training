"""Offline binding of retained solver replay annotations to original plan and trace.

No engine, model, search or real action is invoked. Request/response projections
are compared without removing any fields from the caller's recorded data.
"""
import copy
import json

from combat_executor import CombatExecutor, choice_plans


KINDS = {"knowledge_demon_effect_choice", "seeker_option_choice", "planned_choice_not_executed", "planned_empty_choice_completed", "turn_setup_plan_continued", "turn_setup_ended_combat", "original_choice_return_completed", "original_choice_continuation_completed", "original_choice_continuation_ended_combat"}
KINDS.add("end_turn_setup_choice_not_executed")
KINDS.add("seeker_automatic_continuation_completed")
KINDS.add("seeker_manual_continuation_ended_combat")
KINDS.add("neows_empty_series_completed")
SELECTION_ACTIONS = {"select_cards", "select_card_reward", "skip_card_reward"}


def same(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def require(ok, message):
    if not ok:
        raise ValueError("Replay evidence: " + message)


def solver_projection(calls):
    return [{"request": call["request"], "response": call["response"]} for call in calls]


def parent_matches(action, index, traces, before):
    state, request = before[index], traces[index]["request"]
    if (not isinstance(state, dict) or state.get("decision") != "combat_play"
            or state.get("context", {}).get("combat_in_progress") is not True
            or type(state.get("player_turn")) is not int or state["player_turn"] < 1
            or type(action.get("Turn")) is not int or action["Turn"] != state["player_turn"]):
        return False
    if action.get("Kind") == "EndTurn":
        return same(request, {"cmd": "action", "action": "end_turn"})
    if action.get("Kind") not in {"PlayCard", "UsePotion"} or index == 0:
        return False
    meta_row = traces[index - 1]
    if not same(meta_row["request"], {"cmd": "combat_meta"}):
        return False
    meta = meta_row.get("response", {})
    if meta.get("type") != "combat_meta":
        return False
    args = {}
    if action["Kind"] == "PlayCard":
        key, occurrence = action.get("CardStateKey"), action.get("CardStateOccurrence", 0)
        if not key or type(occurrence) is not int or occurrence < 0:
            return False
        matches = [c for c in meta.get("hand", []) if c.get("key") == key]
        if occurrence >= len(matches):
            return False
        args["card_index"] = matches[occurrence]["index"]
        method = "play_card"
    else:
        matches = [p for p in meta.get("potions", [])
                   if p.get("slot") == action.get("PotionSlot") and p.get("id") == action.get("PotionId")]
        if len(matches) != 1:
            return False
        args["potion_index"] = matches[0]["index"]
        method = "use_potion"
    if action.get("TargetIndex", -1) >= 0:
        matches = [e for e in meta.get("enemies", []) if e.get("combat_id") == action.get("TargetCombatId")]
        if len(matches) != 1:
            return False
        args["target_index"] = matches[0]["index"]
    return same(request, {"cmd": "action", "action": method, "args": args})


def original_parent(proof, solve_index, query_index, call, traces, before):
    plan = proof.get("plan")
    parent = next((i for i in range(query_index - 1, solve_index, -1)
                   if traces[i]["request"].get("cmd") == "action"
                   and traces[i]["request"].get("action") not in SELECTION_ACTIONS), None)
    if parent is None:
        require(proof["kind"] == "knowledge_demon_effect_choice"
                and call["request"].get("include_turn_setup") is True
                and any(same(plan, p) for p in call["response"].get("turn_setup_choices") or [])
                and same(before[solve_index], before[query_index]),
                "choice has neither its executed parent nor matching captured setup plan")
        return None, None
    # Execution consumes the returned actions in order and starts a new solve
    # whenever that prefix cannot continue. A repeated identical card/choice
    # later in the same plan is not another possible owner of an earlier action.
    # Bind every actual non-selection action since this solve to its ordinal,
    # retaining all turn, card-state, potion and target checks for the prefix.
    executed = [i for i in range(solve_index + 1, parent + 1)
                if traces[i]["request"].get("cmd") == "action"
                and traces[i]["request"].get("action") not in SELECTION_ACTIONS]
    actions = call["response"].get("actions", [])
    require(executed and executed[-1] == parent and len(executed) <= len(actions),
            "replay parent has no corresponding original action ordinal")
    require(all(parent_matches(actions[n], index, traces, before)
                for n, index in enumerate(executed)),
            "executed action prefix differs from original solver order or identity")
    action = actions[len(executed) - 1]
    require(any(same(plan, p) for p in choice_plans(action)),
            "replay choice plan differs from its executed original parent ordinal")
    return parent, action



def knowledge_proof(proof, query, traces, before):
    meta, state = traces[query]["response"], before[query]
    cards = meta.get("cards")
    require(meta.get("type") == "choice_meta" and meta.get("selection") == state.get("decision") == "card_select"
            and state.get("context", {}).get("combat_in_progress") is True,
            "knowledge metadata is not the actual pending combat selection")
    require(isinstance(cards, list) and all(isinstance(c, dict)
            and type(c.get("index")) is int and c["index"] >= 0
            and isinstance(c.get("id"), str) and bool(c["id"])
            and isinstance(c.get("key"), str) and bool(c["key"])
            and type(c.get("upgrade_level")) is int and c["upgrade_level"] >= 0 for c in cards)
            and len({c["index"] for c in cards}) == len(cards), "invalid actual option fingerprints")
    visible = state.get("cards", [])
    require(len(visible) == len(cards) and
            {c["index"]: c["id"].split(".")[-1] for c in visible} == {c["index"]: c["id"] for c in cards},
            "choice metadata differs from the actual visible surface")
    indices = CombatExecutor.knowledge_choice_indices(state, proof["plan"], meta)
    lo, hi = state.get("min_select"), state.get("max_select")
    require(type(lo) is int and type(hi) is int and lo <= len(indices) <= hi,
            "selection violates actual bounds")
    require(same(traces[query + 1]["request"], {"cmd": "action", "action": "select_cards",
            "args": {"indices": ",".join(map(str, indices))}}), "actual selection indices differ from the solver effect")
    return {"kind": "knowledge_demon_effect_choice", "plan": copy.deepcopy(proof["plan"]),
        "actual_choice_metadata": copy.deepcopy(meta), "selected_indices": indices,
        "identity_basis": "original_pending_ChooseCurse_source_counter_and_unique_effect_id"}


def seeker_sequence_proofs(parent, action, call, traces, before):
    require(parent is not None, "Seeker continuation has no original action")
    cursor, queries = parent + 1, []
    def observed_only(**request):
        nonlocal cursor
        require(cursor < len(traces) and cursor <= parent + 2 * len(choice_plans(action)) + 1
                and same(request, traces[cursor]['request']), "Seeker continuation issued an unobserved request")
        if request == {'cmd': 'choice_meta'}:
            queries.append(cursor)
        response = copy.deepcopy(traces[cursor]['response'])
        cursor += 1
        return response
    executor = CombatExecutor(observed_only)
    executor.last_action_request = copy.deepcopy(traces[parent]['request'])
    executor.solve_calls = [copy.deepcopy(solver_projection([call])[0])]
    state = executor.resolve_seeker_continuation(before[parent], traces[parent]['response'], action)
    require(same(state, before[cursor] if cursor < len(before) else traces[cursor - 1]['response']
            if traces[cursor - 1]['response'].get('type') == 'decision' else before[cursor - 1]),
            'Seeker sequence final state differs')
    proofs = executor.solve_calls[0].get('replay', [])
    require(len(queries) == len(proofs), 'Seeker sequence annotation count differs')
    return dict(zip(queries, proofs))


def seeker_proof(proof, query, parent, call, traces, before):
    require(parent == query - 1, "Seeker option metadata is not bound to the immediate original play")
    cursor = query
    def observed_only(**request):
        nonlocal cursor
        require(cursor <= query + 1 and same(request, traces[cursor]["request"]),
                "Seeker mapping issued an unobserved request")
        result = copy.deepcopy(traces[cursor]["response"])
        cursor += 1
        return result
    executor = CombatExecutor(observed_only)
    executor.solve_calls = [copy.deepcopy(solver_projection([call])[0])]
    state = executor.resolve(before[query], [proof["plan"]])
    require(cursor == query + 2 and same(state, traces[query + 1]["response"])
            and len(executor.solve_calls[0].get("replay", [])) == 1,
            "Seeker replay did not verify exactly one mapped original selection")
    return executor.solve_calls[0]["replay"][0]


def ending_proof(query, parent, action, call, traces, before, *, empty_source=False, original_return=False):
    require(parent == query - 1, "ending audit is not the immediate original action return")
    def observed_only(**request):
        require(same(request, traces[query]["request"]), "ending audit issued an unobserved request")
        return copy.deepcopy(traces[query]["response"])
    executor = CombatExecutor(observed_only)
    executor.last_action_request = copy.deepcopy(traces[parent]["request"])
    executor.solve_calls = [copy.deepcopy(solver_projection([call])[0])]
    resolve = executor.resolve_original_automatic_choice if original_return else \
        executor.resolve_empty_source_choice if empty_source else executor.resolve_ending_choice
    require(resolve(before[parent], traces[parent]["response"], action),
            "original return does not prove the recorded empty or ending choice")
    return executor.solve_calls[0]["replay"][0]


def hologram_continuation_proof(query, parent, action, call, traces, before):
    series = traces[query]["response"].get("completion_audit", {}).get("hologram_continuation", {}).get("schema_version") == "hologram-pending-task-continuation-v2"
    require(parent is not None and (3 <= query - parent <= 131 and (query-parent) % 2 == 1 if series else query == parent + 3),
            "Hologram continuation must follow its original play and every observed manual selection")
    cursor = parent + 1
    def observed_only(**request):
        nonlocal cursor
        require(cursor <= query and same(request, traces[cursor]["request"]),
                "Hologram continuation issued an unobserved request")
        response = copy.deepcopy(traces[cursor]["response"])
        cursor += 1
        return response
    executor = CombatExecutor(observed_only)
    executor.last_action_request = copy.deepcopy(traces[parent]["request"])
    executor.solve_calls = [copy.deepcopy(solver_projection([call])[0])]
    resolve = (executor.resolve_neows_continuation if action.get("CardId") == "NEOWS_FURY" else
               executor.resolve_scavenge_continuation if action.get("CardId") == "SCAVENGE" else
               executor.resolve_hand_trick_continuation if action.get("CardId") == "HAND_TRICK" else
               executor.resolve_secret_technique_continuation if action.get("CardId") == "SECRET_TECHNIQUE" else executor.resolve_hologram_continuation)
    state = resolve(before[parent], traces[parent]["response"], action)
    require(cursor == query + 1 and same(state, traces[query - 1]["response"])
            and len(executor.solve_calls[0].get("replay", [])) == 1,
            "Hologram continuation did not verify exactly the original observed return")
    return executor.solve_calls[0]["replay"][0]


def setup_ending_proof(start, query, end, call, traces, before):
    cursor = start + 1
    def observed_only(**request):
        nonlocal cursor
        require(cursor <= query and same(request, traces[cursor]["request"]),
                "ending setup issued an unobserved selection or query")
        response = copy.deepcopy(traces[cursor]["response"])
        cursor += 1
        return response
    executor = CombatExecutor(observed_only)
    executor.solve_calls = [copy.deepcopy(solver_projection([call])[0])]
    state, proof = executor.resolve_setup_for_continuation(before[start], call["response"])
    require(cursor == query + 1 and same(state, traces[query - 1]["response"])
            and isinstance(proof, dict) and proof.get("kind") == "turn_setup_ended_combat",
            "ending setup lacks its observed original task completion")
    require(not any(t["request"].get("cmd") == "action" and t["request"].get("action") in
                    {"play_card", "use_potion", "end_turn"} for t in traces[query + 1:end]),
            "original battle plan executed after setup ended combat")
    return proof


def setup_continuation_proof(start, first, call, traces, before):
    cursor = start + 1
    def observed_only(**request):
        nonlocal cursor
        require(cursor < first and same(request, traces[cursor]["request"]),
                "setup continuation issued an unobserved selection or query")
        response = copy.deepcopy(traces[cursor]["response"])
        cursor += 1
        return response
    executor = CombatExecutor(observed_only)
    executor.solve_calls = [copy.deepcopy(solver_projection([call])[0])]
    state, proof = executor.resolve_setup_for_continuation(before[start], call["response"])
    require(proof is not None, "setup continuation lacks an original authenticated source")
    action = call["response"]["actions"][0]
    expected_cursor = first - 1 if action.get("Kind") in {"PlayCard", "UsePotion"} else first
    require(cursor == expected_cursor and same(state, before[first])
            and parent_matches(action, first, traces, before),
            "setup plan's first original action differs from its actual execution")
    proof.update(first_action=copy.deepcopy(action), actual_first_request=copy.deepcopy(traces[first]["request"]))
    return proof



def checked_choice_free_relic_summary(action, original):
    # RazorTooth/PaelsLegion annotate the played card, and Vambrace modifies its
    # first block synchronously. Their reviewed hooks never request a selection.
    # JossPaper uses original thresholded Draw; the enclosing completed-play
    # and unchanged-selector evidence must still prove this actual action.
    # These reviewed RelicEffects entries are display summaries, not selector requests.
    # The enclosing validator still requires exact solver/trace equality, actual parent
    # identity, completed play, zero discard candidates and unchanged selector counters.
    effects = action.get('RelicEffects')
    if effects is None or effects == []:
        return
    reviewed={'RAZOR_TOOTH':'RELIC.RAZOR_TOOTH','PAELS_LEGION':'RELIC.PAELS_LEGION','VAMBRACE':'RELIC.VAMBRACE','JOSS_PAPER':'RELIC.JOSS_PAPER','FORGOTTEN_SOUL':'RELIC.FORGOTTEN_SOUL','LETTER_OPENER':'RELIC.LETTER_OPENER'}
    require(isinstance(effects, list) and 1 <= len(effects) <= len(reviewed),
            'Unsupported choice-free relic effects')
    seen=set()
    for effect in effects:
        require(isinstance(effect, dict) and set(effect) == {'RelicId','RelicTitle','Summary'}
                and effect.get('RelicId') in reviewed
                and all(isinstance(effect[k], str) for k in effect),
                'Unsupported choice-free relic summary')
        require(effect['RelicId'] not in seen,'Repeated choice-free relic summary')
        seen.add(effect['RelicId'])
        require(any(r.get('id') == reviewed[effect['RelicId']] for r in original.get('player',{}).get('relics',[])),
                'Choice-free relic summary is not owned by the actual player')


def checked_choice_free_hologram(action, index, traces, before):
    """A completed indexed empty series needs no selection continuation query.

    No solver choice may be omitted. This bounded exception authenticates the
    original completed action and actual empty discard, not an invented plan.
    Every indexed return must share its actual original play; planned choices keep the query guard.
    """
    from hologram_series import equal_fields, integer, checked_card_replay
    state=traces[index]['response']; audit=state.get('choice_audit',{})
    original=before[index]; parent=audit.get('parent',{}); play=state.get('play_action',{})
    require(parent_matches(action,index,traces,before), 'Choice-free Hologram original action mismatch')
    require(not choice_plans(action) and action.get('Choice') is None
        and not action.get('NestedChoices') and not action.get('TurnStartChoices'),
        'Choice-free Hologram has planned choices')
    checked_choice_free_relic_summary(action, original)
    equal_fields(action,{'Kind':'PlayCard','CardId':'HOLOGRAM',
        'NestedChoicesBeforePrimary':0,'EndsPlayerTurn':False,'TargetIndex':-1,'TargetCombatId':None},
        'Unsupported choice-free Hologram action')
    checked_card_replay(action)
    equal_fields(original,{'discard_pile_count':0,'decision':'combat_play'}, 'Discard was not actually empty')
    equal_fields(state,{'decision':'combat_play','player_turn':action['Turn']}, 'Choice-free Hologram changed turn')
    require(state.get('context',{}).get('combat_in_progress') is True
        and CombatExecutor.setup_state_identity(original)==CombatExecutor.setup_state_identity(state),
        'Choice-free Hologram changed combat identity')
    equal_fields(audit,{'schema_version':'combat-choice-return-v2','closed':True,'events':[]}, 'Open original empty return audit')
    require(not audit.get('hologram_continuation'), 'Manual continuation cannot be choice-free')
    equal_fields(parent,{'action':'play_card','card_id':'HOLOGRAM','card_key':action['CardStateKey'],
        'combat_active_before':True,'player_turn':action['Turn'],
        'card_index':traces[index]['request']['args']['card_index'],
        'combat_id':original['player']['combat_metrics']['combat_id']}, 'Wrong empty-return parent')
    equal_fields(play,{'schema_version':'original-play-action-v1','card_id':'HOLOGRAM',
        'target_combat_id':None,'cancellation_observed':False,'on_play_entered':True,
        'outcome':'completed','state':'Finished','completion_task_status':'RanToCompletion'},
        'Uncompleted original choice-free play')
    returns=audit.get('original_returns')
    require(isinstance(returns,list) and returns,'Missing original empty series')
    count=integer(returns[0],'hologram_play_count',1,65)
    require(len(returns)==count and count>=1+integer(action,'ReplayCount',0,64),
        'Incomplete original empty Hologram series')
    counter=integer(returns[0],'selector_invocations_before')
    for ordinal,event in enumerate(returns):
        equal_fields(event,{'schema_version':'original-choice-return-v1','invocation_index':ordinal,
            'action_id':integer(audit,'action_id',1),'source_method':'CardSelectCmd.FromCombatPile',
            'effect_callsite':'Hologram.OnPlay','effect':'MoveToHand','source_id':'HOLOGRAM','source_pile':'Discard',
            'source_is_actual_parent_object':True,'player_id':parent['player_id'],'player_turn':action['Turn'],
            'is_over_or_ending_at_entry':False,'combat_active_at_entry':True,'min_select':1,'max_select':1,
            'require_manual_confirmation':False,'filter_is_null':False,'filter_reexecuted_by_observer':False,
            'raw_source_count_at_entry':0,'raw_source_count_at_return':0,'returned_count':0,'returned_cards':[],
            'selector_invocations_before':counter,'selector_invocations_after':counter,
            'selector_pending_before':False,'selector_pending_after':False,'verified':True,
            'hologram_original_series_verified':True,'hologram_play_index':ordinal,'hologram_play_count':count,
            'hologram_original_play_action_id':integer(play,'action_id'),'original_task_completed_successfully':True,
            'combat_active_at_return':True,'is_over_or_ending_at_return':False,
            'original_returned_collection':'CardModel[]','returned_objects_match_original_source':True,
            'candidate_basis':'original_implementation_and_completed_return_without_selector'},
            'Unverified choice-free original Hologram return')
    return True

def validate_replay_evidence(calls, traces):
    """Validate all calls and known annotations, including omitted proofs.

    Each proof must occur after its solve and before the next solve attempt.
    Failed selections do not claim successful replay. Unknown kinds or extra
    proof fields fail because the complete regenerated evidence must agree.
    """
    try:
        require(isinstance(calls, list) and isinstance(traces, list), "calls/trace must be lists")
        solve_indices = [i for i, t in enumerate(traces) if t["request"].get("cmd") == "solve"]
        returned = [i for i in solve_indices if traces[i].get("response") is not None]
        require(same(solver_projection(calls), solver_projection([traces[i] for i in returned])),
                "solver request/response projection differs from trace")
        before, current = [], {"type": "initializing"}
        for trace in traces:
            before.append(current)
            response = trace.get("response")
            if isinstance(response, dict) and (response.get("type") == "decision" or
                    trace["request"].get("cmd") in {"action", "start_run"} and response.get("type") == "error"):
                current = response
        validated = []
        for call_index, (call, start) in enumerate(zip(calls, returned)):
            end = next((i for i in solve_indices if i > start), len(traces))
            proofs = call.get("replay", [])
            invalidation = call.get("plan_invalidation")
            # A missing-target stop is the final metadata query before another solve
            # (or a bounded-replan error). Never allow a stale action to be submitted.
            tail = traces[end - 1] if end > start + 1 else {}
            missing = None
            if tail.get("request") == {"cmd": "combat_meta"}:
                executed = sum(t["request"].get("cmd") == "action"
                    and t["request"].get("action") in {"play_card", "use_potion", "end_turn"}
                    for t in traces[start + 1:end - 1])
                actions = call.get("response", {}).get("actions", [])
                if executed < len(actions):
                    candidate = actions[executed]
                    meta = tail["response"]
                    occurrence = candidate.get("CardStateOccurrence", 0)
                    identity_present = (candidate.get("Kind") == "PlayCard" and type(occurrence) is int
                        and 0 <= occurrence < sum(c.get("key") == candidate.get("CardStateKey") for c in meta.get("hand", [])))
                    identity_present |= (candidate.get("Kind") == "UsePotion" and sum(
                        p.get("slot") == candidate.get("PotionSlot") and p.get("id") == candidate.get("PotionId")
                        for p in meta.get("potions", [])) == 1)
                    if identity_present:
                        try:
                            missing = CombatExecutor.unplayable_card_proof(before[end - 1], candidate,
                                tail["response"], executed)
                            if missing is None:
                                missing = CombatExecutor.missing_hologram_choice_proof(before[end - 1], candidate,
                                    tail["response"], executed)
                            if missing is None and candidate.get("TargetIndex", -1) >= 0:
                                missing = CombatExecutor.missing_target_proof(before[end - 1], candidate,
                                    tail["response"], executed)
                        except RuntimeError:
                            require(invalidation is None, 'Malformed preflight metadata cannot justify a replan')
                            require(call_index == len(calls) - 1,
                                    'Malformed preflight cannot continue into another solve')
                        if call_index + 1 < len(calls):
                            require(missing is not None,
                                    'Present original action cannot silently disappear before a new solve')
            if (tail.get("request") == {"cmd":"choice_meta"} and end > start + 2
                    and traces[end-2]["request"] == {"cmd":"action","action":"end_turn"}
                    and tail.get("response",{}).get("selection") == "card_select"):
                executed = sum(t["request"].get("cmd") == "action"
                    and t["request"].get("action") in {"play_card","use_potion","end_turn"}
                    for t in traces[start+1:end-1])
                actions = call.get("response",{}).get("actions",[])
                if 0 < executed <= len(actions) and not choice_plans(actions[executed-1]):
                    from unpredicted_setup import proof as unpredicted_setup_proof
                    missing = unpredicted_setup_proof(before[end-2],before[end-1],actions[executed-1],
                        tail["response"],executed-1)
                    if call_index+1 < len(calls):
                        following = calls[call_index+1]
                        require(following["request"].get("include_turn_setup") is True,
                            "Unpredicted setup continued without a fresh setup solve")
                        if following.get("response",{}).get("type") == "solver_result":
                            require(following["response"].get("setup_origin") == tail["response"]["setup_origin"],
                                "Fresh setup solve belongs to another original capture")
            if (tail.get("request") == {"cmd":"choice_meta"} and end > start+2
                    and traces[end-2]["request"].get("action") == "use_potion"
                    and before[end-1].get("decision") == "combat_play"
                    and before[end-1].get("choice_audit",{}).get("parent",{}).get("potion_id") == "DISTILLED_CHAOS"):
                executed = [i for i in range(start+1,end-1) if traces[i]["request"].get("cmd")=="action"
                    and traces[i]["request"].get("action") in {"play_card","use_potion","end_turn"}]
                actions = call.get("response",{}).get("actions",[])
                require(executed and executed[-1]==end-2 and len(executed)<=len(actions)
                    and all(parent_matches(actions[n],i,traces,before) for n,i in enumerate(executed)),
                    "Autoplay replan original action prefix differs")
                action = actions[len(executed)-1]
                from distilled_chaos_replan import proof as distilled_replan_proof
                missing = distilled_replan_proof(before[end-2],before[end-1],action,tail["response"],
                    len(executed)-1,traces[end-2]["request"])
                if call_index+1 < len(calls):
                    following=calls[call_index+1]["request"]
                    require(following.get("include_turn_setup") is False
                        and following.get("hp_lost_so_far")==CombatExecutor.metrics(before[end-1])["hp_lost"]
                        and following.get("potions_used_so_far")==call["request"]["potions_used_so_far"]
                            +sum(actions[n]["Kind"]=="UsePotion" for n in range(len(executed))),
                        "Fresh autoplay solve lost actual battle accounting")
            require(same(invalidation, missing), "plan invalidation differs from original plan/actual trace")
            require(isinstance(proofs, list) and all(isinstance(p, dict) and p.get("kind") in KINDS for p in proofs),
                    "unknown or malformed replay kind")
            observed = []
            first_setup_action = None
            for i in range(start + 1, end):
                row, meta = traces[i], traces[i].get("response")
                # A completed indexed series may not silently continue if both
                # its proof and final metadata query were removed. An actual
                # error tail can remain incomplete, but no later command may
                # treat that unverified effect as a successful continuation.
                if row["request"].get("cmd") == "action" and isinstance(meta, dict):
                    audit = meta.get("choice_audit", {})
                    if (row["request"].get("action")=="use_potion" and meta.get("decision")=="combat_play"
                            and audit.get("parent",{}).get("potion_id")=="DISTILLED_CHAOS"):
                        ordinal=sum(t["request"].get("cmd")=="action" and t["request"].get("action")
                            in {"play_card","use_potion","end_turn"} for t in traces[start+1:i])
                        actions=call.get("response",{}).get("actions",[])
                        require(ordinal<len(actions),"No original potion action")
                        if choice_plans(actions[ordinal]) and i+1<len(traces):
                            require(i+2==end and traces[i+1]["request"]=={"cmd":"choice_meta"}
                                and invalidation is not None,
                                "Completed autoplay continued without its completion query and fresh solve")
                    if (audit.get('parent',{}).get('card_id')=='NEOWS_FURY'
                            and len(audit.get('events',[]))>=2 and i+1<len(traces)):
                        require(traces[i+1]['request']=={'cmd':'choice_meta'}
                            and traces[i+1].get('response',{}).get('completion_audit')==audit,
                            'Repeated empty Neows action continued without completion query')
                    if (audit.get("parent", {}).get("card_id") == "UPROAR"
                            and meta.get("context", {}).get("combat_in_progress") is False and i + 1 < len(traces)):
                        query_present = (traces[i+1]["request"] == {"cmd":"choice_meta"}
                            and traces[i+1].get("response", {}).get("completion_audit") == audit)
                        if not query_present:
                            executed = sum(t["request"].get("cmd") == "action"
                                and t["request"].get("action") in {"play_card","use_potion","end_turn"}
                                for t in traces[start+1:i])
                            actions = call.get("response",{}).get("actions",[])
                            require(executed < len(actions) and not choice_plans(actions[executed]),
                                "Terminal Uproar continued without its original child completion query")
                    continuation = audit.get("hologram_continuation", {})
                    indexed_complete = (continuation.get("schema_version") == "hologram-pending-task-continuation-v2"
                        and continuation.get("original_play_task_completed_successfully") is True)
                    indexed_complete |= (row["request"].get("action") == "play_card"
                        and meta.get("play_action", {}).get("outcome") == "completed"
                        and any(e.get("hologram_original_series_verified") is True for e in audit.get("original_returns", [])))
                    if indexed_complete and i + 1 < len(traces):
                        query_present = (traces[i+1]["request"] == {"cmd":"choice_meta"}
                            and traces[i+1].get("response", {}).get("completion_audit") == audit)
                        if not query_present:
                            executed = sum(t["request"].get("cmd") == "action"
                                and t["request"].get("action") in {"play_card","use_potion","end_turn"}
                                for t in traces[start+1:i])
                            actions = call.get("response",{}).get("actions",[])
                            require(executed < len(actions) and not choice_plans(actions[executed]),
                                "Indexed Hologram continued without its original completion query")
                            checked_choice_free_hologram(actions[executed],i,traces,before)
                if (first_setup_action is None and call["request"].get("include_turn_setup") is True
                        and call["response"].get("turn_setup_choices")
                        and row["request"].get("cmd") == "action"
                        and row["request"].get("action") in {"play_card", "use_potion", "end_turn"}
                        and isinstance(meta, dict) and meta.get("type") == "decision"):
                    # Noncombat choices between this solve and the next do not
                    # continue its plan. A real combat action still requires
                    # the complete original setup proof, even if omitted.
                    require(before[i].get("decision") == "combat_play"
                            and before[i].get("context", {}).get("combat_in_progress") is True
                            and not any(t.get("response", {}).get("type") == "decision"
                                and t["response"].get("context", {}).get("combat_in_progress") is False
                                for t in traces[start + 1:i]),
                            "setup battle plan continued outside its original combat")
                    first_setup_action = i
                    observed.append((i, "turn_setup_plan_continued"))
                if not same(row["request"], {"cmd": "choice_meta"}) or not isinstance(meta, dict):
                    continue
                if (call["request"].get("include_turn_setup") is True
                        and call["response"].get("turn_setup_choices")
                        and meta.get("selection") == "none" and i > start + 1
                        and traces[i - 1]["request"].get("action") == "select_cards"
                        and (meta.get("setup_completion") is not None or
                            traces[i - 1].get("response", {}).get("context", {}).get("combat_in_progress") is False)):
                    observed.append((i, "turn_setup_ended_combat"))
                elif (i + 1 < end and traces[i + 1]["request"].get("action") == "select_cards"
                        and isinstance(traces[i + 1].get("response"), dict)
                        and traces[i + 1]["response"].get("type") == "decision"
                        and (meta.get("seeker_choice") is not None or (
                            before[i].get("choice_audit", {}).get("parent", {}).get("card_id") == "SEEKER_STRIKE"
                            and any(str(p.get("ContextId", "")).startswith("seeker:")
                                for a in call["response"].get("actions", []) for p in choice_plans(a))))):
                    observed.append((i, "seeker_option_choice"))
                elif (isinstance(meta.get("knowledge_choice"), dict) and i + 1 < end
                        and traces[i + 1]["request"].get("action") == "select_cards"
                        and isinstance(traces[i + 1].get("response"), dict)
                        and traces[i + 1]["response"].get("type") == "decision"):
                    observed.append((i, "knowledge_demon_effect_choice"))
                elif (meta.get("selection") == "none" and i > start + 1
                      and traces[i - 1]["request"].get("action") == "end_turn"
                      and before[i].get("context", {}).get("combat_in_progress") is False
                      and (meta.get("turn_end_origin") is not None or any(
                          p.get("SourceId") == "TOASTY_MITTENS"
                          for a in call["response"].get("actions", [])
                          if parent_matches(a, i - 1, traces, before) for p in choice_plans(a)))):
                    observed.append((i, "end_turn_setup_choice_not_executed"))
                elif (meta.get("selection") == "none"
                      and meta.get("completion_audit", {}).get("neows_full_hand_diagnostic")
                      and i > start + 1 and traces[i - 1]["request"].get("action") == "select_cards"):
                    observed.append((i, "original_choice_continuation_completed"))
                elif (meta.get("selection") == "none" and meta.get("completion_audit", {}).get("neows_continuation")
                      and meta.get("completion_audit", {}).get("original_returns")
                      and i > start + 1 and traces[i - 1]["request"].get("action") == "select_cards"):
                    observed.append((i, "original_choice_continuation_ended_combat"))
                elif (meta.get('selection') == 'none' and meta.get('completion_audit', {}).get('seeker_continuation')
                      and meta.get('completion_audit', {}).get('original_returns') == []
                      and i > start + 1 and traces[i - 1]['request'].get('action') == 'select_cards'
                      and traces[i - 1]['response'].get('context', {}).get('combat_in_progress') is False):
                    observed.append((i, 'seeker_manual_continuation_ended_combat'))
                elif (meta.get("selection") == "none" and meta.get("completion_audit", {}).get("seeker_continuation")
                      and meta.get("completion_audit", {}).get("original_returns")
                      and i > start + 1 and traces[i - 1]["request"].get("action") == "select_cards"):
                    observed.append((i, "seeker_automatic_continuation_completed"))
                elif (meta.get("selection") == "none" and (meta.get("completion_audit", {}).get("hologram_continuation") or meta.get("completion_audit", {}).get("scavenge_continuation") or meta.get("completion_audit", {}).get("hand_trick_continuation") or meta.get("completion_audit", {}).get("secret_technique_continuation"))
                      and (meta.get("completion_audit", {}).get("original_returns")
                           or meta.get("completion_audit", {}).get("hologram_continuation", {}).get("schema_version") == "hologram-pending-task-continuation-v2")
                      and i > start + 1 and traces[i - 1]["request"].get("action") == "select_cards"):
                    ended_hologram = (meta.get("completion_audit", {}).get("hologram_continuation", {}).get("schema_version")
                        == "hologram-pending-task-continuation-v2"
                        and traces[i - 1]["response"].get("context", {}).get("combat_in_progress") is False)
                    observed.append((i, "original_choice_continuation_ended_combat" if ended_hologram
                        else "original_choice_continuation_completed"))
                elif (meta.get("selection") == "none" and meta.get("completion_audit", {}).get("original_returns")
                      and i > start + 1 and traces[i - 1]["request"].get("action") in {"play_card", "use_potion", "end_turn"}):
                    audit = meta["completion_audit"]
                    nested_ending = (audit.get("parent", {}).get("card_id") == "UPROAR"
                        and isinstance(audit["original_returns"], list) and len(audit["original_returns"]) == 1
                        and isinstance(audit["original_returns"][0], dict)
                        and audit["original_returns"][0].get("nested_relation") in {
                            "UPROAR_action_SEEKER_STRIKE_original_OnPlay_combat_ending",
                            "UPROAR_action_NEOWS_FURY_original_OnPlay_combat_ending",
                            "UPROAR_original_AutoPlay_HEADBUTT_original_OnPlay_combat_ending"})
                    observed.append((i, "planned_choice_not_executed" if nested_ending else "original_choice_return_completed"))
                elif (meta.get("selection") == "none" and meta.get("completion_audit", {}).get("events")
                      and i > start + 1 and traces[i - 1]["request"].get("action") == "play_card"):
                    events = meta["completion_audit"]["events"]
                    empty_source = (isinstance(events, list) and len(events) == 1
                                    and isinstance(events[0], dict) and events[0].get("reason") == "empty_source_pile")
                    neows_series=(len(events)>=2 and meta['completion_audit'].get('parent',{}).get('card_id')=='NEOWS_FURY')
                    observed.append((i, 'neows_empty_series_completed' if neows_series else
                        "planned_empty_choice_completed" if empty_source else "planned_choice_not_executed"))
            require(len(proofs) == len(observed), "successful trace replay has missing/extra annotations")
            if "setup_plan_reuse" in call:
                reuse = call["setup_plan_reuse"]
                require(isinstance(reuse, dict) and set(reuse) == {"schema_version", "reused", "reason"}
                        and reuse.get("schema_version") == "setup-plan-reuse-v1" and type(reuse.get("reused")) is bool
                        and call["request"].get("include_turn_setup") is True,
                        "invalid setup-plan reuse diagnostic schema or owner")
                reasons = {True: {"original_setup_and_first_action_verified"},
                    False: {"unsupported_setup_source_or_shape", "first_action_fingerprint_changed", "original_setup_ended_combat"}}
                require(reuse.get("reason") in reasons[reuse["reused"]]
                        and reuse["reused"] == any(kind == "turn_setup_plan_continued" for _, kind in observed)
                        and (reuse["reason"] == "original_setup_ended_combat") ==
                            any(kind == "turn_setup_ended_combat" for _, kind in observed),
                        "setup-plan reuse diagnostic differs from actual observed continuation")
            seeker_sequences = {}
            for proof, (query, kind) in zip(proofs, observed):
                require(proof["kind"] == kind, "replay order or kind differs from actual trace")
                require(call["response"].get("type") == "solver_result", "failed solve cannot own successful replay")
                if kind == "turn_setup_ended_combat":
                    parent = query - 1
                    actual = setup_ending_proof(start, query, end, call, traces, before)
                elif kind == "turn_setup_plan_continued":
                    parent = query
                    actual = setup_continuation_proof(start, query, call, traces, before)
                else:
                    parent, action = original_parent(proof, start, query, call, traces, before)
                    if kind=='neows_empty_series_completed':
                        from neows_empty_series import proof as neows_empty_proof
                        require(query==parent+1,'Neows completion query was not immediate')
                        actual=neows_empty_proof(before[parent],traces[parent]['response'],action,
                            traces[parent]['request'],traces[query]['response'])
                    elif kind in {'seeker_automatic_continuation_completed', 'seeker_manual_continuation_ended_combat'} or (kind == 'seeker_option_choice'
                            and action is not None and len(choice_plans(action)) > 1):
                        if parent not in seeker_sequences:
                            seeker_sequences[parent] = seeker_sequence_proofs(parent, action, call, traces, before)
                        require(query in seeker_sequences[parent], 'Seeker proof is outside its original sequence')
                        actual = seeker_sequences[parent][query]
                    else:
                        actual = seeker_proof(proof, query, parent, call, traces, before) if kind == "seeker_option_choice" else \
                        hologram_continuation_proof(query, parent, action, call, traces, before) if kind in {"original_choice_continuation_completed", "original_choice_continuation_ended_combat"} else \
                        knowledge_proof(proof, query, traces, before) if kind == "knowledge_demon_effect_choice" else \
                        ending_proof(query, parent, action, call, traces, before,
                            empty_source=kind == "planned_empty_choice_completed", original_return=kind in {"original_choice_return_completed", "end_turn_setup_choice_not_executed"})
                require(same(proof, actual), "retained replay proof differs from its actual trace/plan binding")
                if (kind in {"original_choice_continuation_ended_combat", "end_turn_setup_choice_not_executed"}
                        or kind=='neows_empty_series_completed' and proof['remaining_battle_plan_stopped']
                        or proof.get("nested_effect_binding") == "actual_Uproar_AutoPlay_task_with_original_Headbutt_ending_return"):
                    require(not any(row["request"].get("cmd") == "action" and row["request"].get("action")
                            in {"play_card", "use_potion", "end_turn"} for row in traces[query + 1:end]),
                            "Ended original solver plan continued issuing combat actions")
                validated.append({"call_index": call_index, "solve_trace_index": start,
                    "query_trace_index": query, "parent_trace_index": parent, "kind": kind})
        return {"schema_version": "solver-replay-evidence-v1", "verified": True,
                "solver_calls": len(calls), "replay_count": len(validated), "bindings": validated}
    except (KeyError, TypeError, AttributeError, IndexError, RuntimeError) as exc:
        raise ValueError("Replay evidence: malformed or invalid binding: " + str(exc)) from exc
