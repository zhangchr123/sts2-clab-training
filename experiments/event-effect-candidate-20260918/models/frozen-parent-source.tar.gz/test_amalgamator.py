"""Artificial Amalgamator integrity fixtures; never natural training evidence."""
from collections import Counter
import json
import unittest
import uuid

from probe import Bridge, ROOT


class AmalgamatorTests(unittest.TestCase):
    def setUp(self):
        self.label = "amalgamator-" + self._testMethodName + "-" + uuid.uuid4().hex[:10]
        self.requests = []
        self.bridge = Bridge(self.label)
        self.addCleanup(self.bridge.close)
        self.addCleanup(self.write_evidence)

    def write_evidence(self):
        (ROOT / "outputs" / (self.label + ".json")).write_text(json.dumps({
            "provenance": "artificial Amalgamator fixture; not natural or training data",
            "requests": self.requests, "responses": self.bridge.rows,
        }, ensure_ascii=False, indent=2), encoding="utf-8")

    def send(self, **request):
        self.requests.append(request)
        result = self.bridge.send(**request)
        self.assertNotEqual(result.get("type"), "error", result)
        return result

    def combine(self, kind, egg=None):
        self.send(cmd="start_run", character="Defect", ascension=10, seed="integrity-amalgamator")
        deck = ["STRIKE_DEFECT"] * 3 + ["DEFEND_DEFECT"] * 3 + ["GLACIER", "COLD_SNAP"]
        self.send(cmd="set_player", hp=43, max_hp=75, gold=211, deck=deck, relics=[egg] if egg else [])
        before = self.send(cmd="enter_room", type="event", event="AMALGAMATOR")
        option = next(o for o in before["options"]
                      if o["text_key"] == "AMALGAMATOR.pages.INITIAL.options.COMBINE_" + kind)
        selected = self.send(cmd="action", action="choose_option", args={"option_index": option["index"]})
        self.assertEqual(selected.get("decision"), "card_select", selected)
        self.assertEqual((selected["min_select"], selected["max_select"]), (2, 2))
        self.assertEqual(len(selected["cards"]), 3)
        source = "CARD." + ("DEFEND_DEFECT" if kind == "DEFENDS" else "STRIKE_DEFECT")
        self.assertTrue(all(c["id"] == source for c in selected["cards"]))
        # One action only. The original two removals and one addition must finish.
        after = self.send(cmd="action", action="select_cards", args={"indices": "0,2"})
        self.assertEqual(after.get("decision"), "map_select", after)
        self.assertIs(after["context"]["integrity_recovery_used"], False)
        expected = Counter(c["id"] for c in before["player"]["deck"])
        expected[source] -= 2
        result_id = "CARD.ULTIMATE_DEFEND" if kind == "DEFENDS" else "CARD.ULTIMATE_STRIKE"
        expected[result_id] += 1
        self.assertEqual(Counter(c["id"] for c in after["player"]["deck"]), expected)
        self.assertEqual(after["player"]["deck_size"], before["player"]["deck_size"] - 1)
        for key in ("hp", "max_hp", "gold", "relics", "potions"):
            self.assertEqual(after["player"][key], before["player"][key], key)
        result = next(c for c in after["player"]["deck"] if c["id"] == result_id)
        self.assertEqual(result["current_upgrade_level"], int(egg is not None))
        self.assertEqual(result["cost"], 1)
        stat = "block" if kind == "DEFENDS" else "damage"
        nominal = (15 if egg else 11) if kind == "DEFENDS" else (20 if egg else 14)
        self.assertEqual(result["stats"][stat], nominal)

    def test_defends_remove_two_and_generate_one_original_card(self):
        self.combine("DEFENDS")

    def test_strikes_remove_two_and_generate_one_original_card(self):
        self.combine("STRIKES")

    def test_toxic_egg_original_add_to_deck_upgrade_hook(self):
        self.combine("DEFENDS", "TOXIC_EGG")

    def test_molten_egg_original_add_to_deck_upgrade_hook(self):
        self.combine("STRIKES", "MOLTEN_EGG")


if __name__ == "__main__":
    unittest.main()
