"""Real-engine integrity fixtures. Artificial room/HP setup is NOT training data."""
from collections import Counter
import json
import unittest
import uuid

from probe import Bridge, ROOT


class IntegrityTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.b = Bridge(self.label)

    def tearDown(self):
        (ROOT / "outputs" / f"{self.label}.json").write_text(
            json.dumps({"provenance": "artificial integrity fixture; not training data",
                        "responses": self.b.rows}, ensure_ascii=False, indent=2),
            encoding="utf-8")
        self.b.close()

    def send(self, **request):
        state = self.b.send(**request)
        self.assertNotEqual(state.get("type"), "error", state)
        return state

    def trial(self, seed, text_key):
        self.send(cmd="start_run", character="Defect", ascension=10, seed=seed)
        state = self.send(cmd="enter_room", type="event", event="TRIAL")
        accept = next(o for o in state["options"]
                      if o["text_key"] == "TRIAL.pages.INITIAL.options.ACCEPT")
        state = self.send(cmd="action", action="choose_option",
                          args={"option_index": accept["index"]})
        choice = next(o for o in state["options"] if o["text_key"] == text_key)
        self.assertFalse(choice["is_locked"])
        before = state["player"]["deck"]
        return before, self.send(cmd="action", action="choose_option",
                                 args={"option_index": choice["index"]})

    def test_trial_upgrade_completes_before_response(self):
        before, state = self.trial("integrity-trial-0",
                                  "TRIAL.pages.MERCHANT.options.INNOCENT")
        self.assertEqual(state["decision"], "card_select")
        self.assertEqual((state["min_select"], state["max_select"]), (2, 2))
        cards = [c for c in state["cards"] if c["id"] in ("CARD.ZAP", "CARD.DUALCAST")]
        self.assertEqual(len(cards), 2)
        meta = self.send(cmd="choice_meta")
        self.assertEqual(meta["selection"], "card_select")
        self.assertEqual([c["index"] for c in meta["cards"]], [c["index"] for c in state["cards"]])
        for visible, actual in zip(state["cards"], meta["cards"]):
            self.assertEqual(actual["id"], visible["id"].split(".")[-1])
            self.assertEqual(actual["upgrade_level"], 0)
            self.assertTrue(actual["key"].startswith(actual["id"] + "+0|"))

        # A rejected undersized selection must leave the pending choice usable.
        rejected = self.b.send(cmd="action", action="select_cards",
                               args={"indices": str(cards[0]["index"])})
        self.assertEqual(rejected["type"], "error", rejected)
        state = self.send(cmd="action", action="select_cards",
                          args={"indices": ",".join(str(c["index"]) for c in cards)})
        self.assertEqual(state["decision"], "map_select", state)
        deck = state["player"]["deck"]
        upgraded = [c for c in deck if c["upgraded"]]
        self.assertCountEqual([c["id"] for c in upgraded], [c["id"] for c in cards])
        self.assertTrue(all(c["cost"] == 0 for c in upgraded))
        self.assertEqual(len(deck), len(before) + 1)
        self.assertEqual(sum(c["id"] == "CARD.SHAME" for c in deck), 1)
        meta = self.send(cmd="choice_meta")
        self.assertEqual((meta["selection"], meta["cards"]), ("none", []))

    def test_trial_sequential_rewards_are_not_lost(self):
        before, state = self.trial("integrity-trial-3",
                                  "TRIAL.pages.NONDESCRIPT.options.GUILTY")
        expected = Counter(c["id"] for c in before)
        expected["CARD.DOUBT"] += 1
        for index in range(2):
            self.assertEqual(state["decision"], "card_reward", state)
            self.assertTrue(state["from_event"])
            meta = self.send(cmd="choice_meta")
            self.assertEqual(meta["selection"], "card_reward")
            self.assertEqual([c["id"] for c in meta["cards"]],
                             [c["id"].split(".")[-1] for c in state["cards"]])
            self.assertTrue(all(c["key"] and c["upgrade_level"] == 0 for c in meta["cards"]))
            chosen = state["cards"][0]
            expected[chosen["id"]] += 1
            state = self.send(cmd="action", action="select_card_reward",
                              args={"card_index": chosen["index"]})
            self.assertEqual(Counter(c["id"] for c in state["player"]["deck"]), expected)
            self.assertEqual(state["decision"], "card_reward" if index == 0 else "map_select")

    def test_damage_and_healing_in_one_action_and_solver_isolation(self):
        self.send(cmd="start_run", character="Defect", ascension=10,
                  seed="integrity-health")
        self.send(cmd="set_player", hp=35, potions=["REGEN_POTION"])
        state = self.send(cmd="enter_room", type="combat", encounter="SHRINKER_BEETLE_WEAK")
        self.assertEqual(state["player"]["combat_metrics"]["hp_lost"], 0)
        state = self.send(cmd="action", action="use_potion",
                          args={"potion_index": state["player"]["potions"][0]["index"]})
        state = self.send(cmd="action", action="end_turn")
        before = state["player"]
        state = self.send(cmd="action", action="end_turn")
        after = state["player"]
        old_metrics, metrics = before["combat_metrics"], after["combat_metrics"]
        lost = metrics["hp_lost"] - old_metrics["hp_lost"]
        recovered = metrics["hp_recovered"] - old_metrics["hp_recovered"]
        self.assertEqual((lost, recovered), (8, 4))
        self.assertEqual(after["hp"], before["hp"] - lost + recovered)
        self.assertGreater(lost, before["hp"] - after["hp"])
        self.assertEqual(metrics["hp_change_events"] - old_metrics["hp_change_events"], 2)
        self.assertEqual(metrics["source"], "Creature.CurrentHpChanged")

        result = self.send(cmd="solve", budget_ms=500,
                           hp_lost_so_far=metrics["hp_lost"])
        self.assertEqual(result["type"], "solver_result")
        # Empty fixture update invokes only PlayerSummary, with no HP/deck/relic
        # field supplied or modified; the CLI does not expose a get_state command.
        observed = self.send(cmd="set_player")["player"]
        self.assertEqual(observed["combat_metrics"], metrics)
        self.assertEqual(observed["hp"], after["hp"])
        self.assertEqual(observed["deck"], after["deck"])


if __name__ == "__main__":
    unittest.main()
