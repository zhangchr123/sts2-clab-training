"""Immutable file/version evidence collected before each isolated run."""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def file_evidence(path):
    path = Path(path)
    if not path.is_file():
        return None
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}


def metadata(run_id, seed, ascension, config, provenance):
    return {"run_id": run_id, "seed": seed, "character": "Defect", "ascension": ascension,
        "mode": "standard", "solver_requested_config": config, "provenance": provenance,
        "versions": {
            "engine": file_evidence(ROOT.parent / "sts2-cli/lib/sts2.dll"),
            "solver": file_evidence(ROOT / "lib/CombatSolver.dll"),
            "ritsu": file_evidence(ROOT / "lib/STS2-RitsuLib.dll"),
            "bridge": file_evidence(ROOT / "runtime/host/bin/Debug/net9.0/SolverBridge.dll"),
            "cli": file_evidence(ROOT.parent / "sts2-cli/src/Sts2Headless/bin/Debug/net9.0/Sts2Headless.dll"),
            "godot": file_evidence(ROOT.parent / "sts2-cli/src/Sts2Headless/bin/Debug/net9.0/GodotSharp.dll"),
            "sources": {p.name: file_evidence(p) for p in (*ROOT.glob("*.py"), ROOT / "ancient_reward_catalog.json")}},
        "branch_restore_enabled": False, "llm_used_for_combat": False}


def atomic_json(path, value):
    import json
    import os
    import time
    import uuid
    path = Path(path)
    temp = path.with_name(path.name + f".{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    # Windows readers/AV can briefly hold the destination without delete sharing.
    # Retry only publication, never an engine action, and preserve atomic replace.
    try:
        for attempt in range(40):
            try:
                temp.replace(path)
                return
            except PermissionError:
                if attempt == 39:
                    raise
                time.sleep(.05)
    finally:
        temp.unlink(missing_ok=True)
