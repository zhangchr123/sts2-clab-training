import json,datetime,collections
from pathlib import Path
P=Path(__file__).parent/'outputs/cli-defect-run-20260913'
rows=[json.loads(l) for l in (P/'trace.jsonl').read_text(encoding='utf-8').splitlines()]
original=[];sessions=[];session=None;offset=0;solves=[]
for number,r in enumerate(rows):
    q=r.get('request',{});s=r.get('response',{})
    if q.get('cmd')=='start_run':
        session={'first_row':number,'reconstructed_actions':0,'differences':[]};sessions.append(session);offset=0
    if q.get('cmd')=='solve':solves.append(r)
    if r.get('reconstruction'):
        expected=original[offset]['response'];offset+=1;session['reconstructed_actions']+=1
        if expected!=s:
            keys=[k for k in set(expected)|set(s) if expected.get(k)!=s.get(k)]
            detail={'row':number,'request':q,'keys':keys,'expected_decision':expected.get('decision'),'actual_decision':s.get('decision')}
            if expected.get('player')!=s.get('player'):
                ep=expected.get('player',{});ap=s.get('player',{})
                detail['player_keys']=[k for k in set(ep)|set(ap) if ep.get(k)!=ap.get(k)]
                for key in ('hp','max_hp','gold'):
                    if ep.get(key)!=ap.get(key):detail[key]=[ep.get(key),ap.get(key)]
                if ep.get('deck')!=ap.get('deck'):
                    def names(p):return [c['name']+('+' if c.get('upgraded') else '') for c in p.get('deck',[])]
                    detail['deck_expected']=names(ep);detail['deck_actual']=names(ap)
            session['differences'].append(detail)
    elif q.get('cmd')=='action' and s.get('type')!='error':original.append(r)
final=json.loads((P/'state.json').read_text(encoding='utf-8'))
start=(P/'trace.jsonl').stat().st_ctime;end=(P/'status.json').stat().st_mtime
summary={'seed':'codex-cli-defect-20260913-1','character':'Defect','ascension':10,'victory':final.get('victory'),
         'final':final,'started_local':datetime.datetime.fromtimestamp(start).isoformat(),'finished_local':datetime.datetime.fromtimestamp(end).isoformat(),
         'wall_seconds':end-start,'solver_calls':len(solves),'solver_seconds':sum(r.get('seconds',0) for r in solves),
         'solver_errors':[{'request':r['request'],'error':r['response']} for r in solves if r['response'].get('type')=='error'],
         'api_seconds':sum(r.get('seconds',0) for r in rows),'original_actions':len(original),'reconstruction_sessions':sessions}
(P/'audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('final','reconstruction_sessions','solver_errors')},indent=2))
print('sessions',[(s['reconstructed_actions'],len(s['differences'])) for s in sessions])
print('last_session_noncosmetic_differences',json.dumps([d for d in sessions[-1]['differences'] if 'player' in d['keys'] or d['expected_decision']!=d['actual_decision']],ensure_ascii=True))
