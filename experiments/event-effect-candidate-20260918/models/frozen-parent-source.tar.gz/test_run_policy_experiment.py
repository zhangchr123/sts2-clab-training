"""Pre-run rejection tests use temporary evidence only; no game process starts."""
from datetime import datetime, timedelta, timezone
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from run_metadata import file_evidence
from run_policy_experiment import EXECUTION_AND_AUDIT_SOURCES, finalize_trial, preflight, run, verify_frozen_files
from test_compare_policy_batches import ComparePolicyBatchTests, write


class PolicyExperimentPreflightTests(unittest.TestCase):
    def setUp(self):
        self.fixture = ComparePolicyBatchTests(methodName="run")
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.path = self.fixture.declare()
        self.root = self.fixture.root
        evidence = file_evidence(self.path)
        from compare_policy_batches import POLICY_SOURCES
        source_names = (*POLICY_SOURCES, *EXECUTION_AND_AUDIT_SOURCES)
        versions = {k: evidence for k in ("engine", "solver", "ritsu", "bridge", "cli", "godot")}
        versions["sources"] = {k: evidence for k in source_names}
        self.addCleanup(patch.stopall)
        patch("run_policy_experiment.metadata", return_value={"versions": versions}).start()
        self.policy = patch("run_policy_experiment.build_policy", side_effect=self.build_policy).start()
        self.run_one = patch("run_policy_experiment.run_one").start()

    def build_policy(self, seed, settings, **kwargs):
        arm = self.fixture.document["arms"]["right" if kwargs["model_path"] else "left"]
        return SimpleNamespace(provenance={**arm["policy_identity"], "random_seed": seed, "choice_count": 0})

    def save(self):
        write(self.path, self.fixture.document)

    def test_exact_preflight_constructs_both_policies_without_running(self):
        loaded, sources = preflight(self.path)
        self.assertEqual(loaded["document"]["seeds"], ["seed-0", "seed-1"])
        self.assertEqual(self.policy.call_count, 2)
        verify_frozen_files(sources)
        self.run_one.assert_not_called()

    def test_wrong_actual_policy_rejected_before_any_output_or_worker(self):
        self.policy.side_effect = None
        self.policy.return_value = SimpleNamespace(provenance={
            **self.fixture.document["arms"]["left"]["policy_identity"], "version": "changed"})
        with self.assertRaisesRegex(ValueError, "Constructed policy"):
            run(self.path)
        self.assertFalse((self.root / "execution-plan.json").exists())
        self.run_one.assert_not_called()

    def test_changed_model_bytes_rejected_before_loading_policy(self):
        model = self.root / "model.json"
        model.write_text("{}", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "artifact changed"):
            preflight(self.path)
        self.run_one.assert_not_called()

    def test_training_or_validation_or_test_seed_overlap_rejected(self):
        for split in ("train", "validation", "test"):
            with self.subTest(split=split):
                model = self.root / "model.json"
                write(model, {"split_seeds": {split: ["seed-1"]}})
                arm = self.fixture.document["arms"]["right"]
                arm["model_artifacts"][0].update(file_evidence(model))
                arm["policy_identity"]["version"] = file_evidence(model)["sha256"]
                self.save()
                with self.assertRaisesRegex(ValueError, "overlap"):
                    preflight(self.path)
        self.run_one.assert_not_called()

    def test_future_protocol_rejected(self):
        self.fixture.document["created_utc"] = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        self.save()
        with self.assertRaisesRegex(ValueError, "future"):
            preflight(self.path)
        self.policy.assert_not_called()

    def test_other_character_rejected(self):
        self.fixture.document["conditions"]["character"] = "Silent"
        self.save()
        with self.assertRaisesRegex(ValueError, "Defect A10"):
            preflight(self.path)
        self.policy.assert_not_called()

    def test_file_drift_between_paired_games_rejected(self):
        _, sources = preflight(self.path)
        self.path.write_text(json.dumps({"changed": True}), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "source changed"):
            verify_frozen_files(sources)

    def test_registered_prefix_sidecars_are_frozen_between_games(self):
        from compare_policy_batches import load_policy_protocol
        loaded = load_policy_protocol(self.path)
        sidecars = {}
        for name in ("protocol", "fit_receipt", "training_audit"):
            path = self.root / (name + "-registered.json")
            write(path, {"registered": name})
            sidecars[name] = file_evidence(path)
        feature = self.root / "registered-feature.py"
        feature.write_text("frozen = True\n", encoding="utf-8")
        loaded["prefix_registrations"] = {"right": {
            "registered_sources": sidecars, "feature_sources": {feature.name: file_evidence(feature)},
            "source_runtime": {"solver": file_evidence(self.path)}}}
        with patch("run_policy_experiment.load_policy_protocol", return_value=loaded):
            _, sources = preflight(self.path)
        for evidence in (*sidecars.values(), file_evidence(feature)):
            self.assertEqual(sources[evidence["path"]], evidence)
        verify_frozen_files(sources)
        for evidence in (*sidecars.values(), file_evidence(feature)):
            from pathlib import Path
            path = Path(evidence["path"])
            original = path.read_bytes()
            path.write_bytes(original + b" ")
            with self.assertRaisesRegex(ValueError, "source changed"):
                verify_frozen_files(sources)
            path.write_bytes(original)
        self.run_one.assert_not_called()

    def test_prefix_original_solver_change_rejected_before_worker(self):
        from compare_policy_batches import load_policy_protocol
        loaded = load_policy_protocol(self.path)
        loaded["prefix_registrations"] = {"right": {
            "registered_sources": {}, "feature_sources": {},
            "source_runtime": {"solver": {**file_evidence(self.path), "sha256": "a" * 64}}}}
        with patch("run_policy_experiment.load_policy_protocol", return_value=loaded):
            with self.assertRaisesRegex(ValueError, "original runtime differs"):
                preflight(self.path)
        self.run_one.assert_not_called()

    def test_finalization_requires_both_data_audits_even_when_comparison_is_valid(self):
        audits = []
        for index, passed in enumerate((True, False)):
            path = self.root / f"audit-{index}.json"
            write(path, {"passed": passed})
            audits.append({"passed": passed, "output_path": str(path)})
        compared = {"comparable": True, "errors": [], "paired": {"pairs": 2},
                    "left": {"summary": {"runs_in_denominator": 2}},
                    "right": {"summary": {"runs_in_denominator": 2}}}
        with patch("run_policy_experiment.audit_batch", side_effect=audits) as auditor, patch(
                "run_policy_experiment.compare_policy_batches", return_value=compared):
            result = finalize_trial(self.path, {"left": self.root / "a", "right": self.root / "b"}, 2)
        self.assertEqual(auditor.call_count, 2)
        self.assertFalse(result["data_ready_for_conclusion"])
        self.assertEqual(result["summaries"]["left"]["runs_in_denominator"], 2)
        saved = json.loads((self.root / "comparison.json").read_text(encoding="utf-8"))
        self.assertFalse(saved["required_full_data_audits"][1]["passed"])
        self.assertFalse(saved["data_ready_for_conclusion"])
        with self.assertRaises(FileExistsError):
            finalize_trial(self.path, {}, 2)


if __name__ == "__main__":
    unittest.main()
