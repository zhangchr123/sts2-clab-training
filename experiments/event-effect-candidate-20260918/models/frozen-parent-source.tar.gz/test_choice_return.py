"""Original-DLL fixtures; artificial decks/rooms, never training observations."""
import json
import unittest
import uuid

from combat_executor import CombatExecutor
from probe import Bridge, ROOT


class ChoiceReturnTests(unittest.TestCase):
    def setUp(self):
        self.label = "choice-return-" + self._testMethodName + "-" + uuid.uuid4().hex[:10]
        self.bridge = Bridge(self.label)
        self.addCleanup(self.bridge.close)
        self.trace = []
        self.replays = []
        self.send(cmd="start_run", character="Defect", ascension=10, seed="choice-return-fixture-v1")
        self.send(cmd="set_player", deck=["NEOWS_FURY", "ROCKET_PUNCH"] + ["DEFEND_DEFECT"] * 3,
                  potions=["FIRE_POTION"])
        self.state = self.send(cmd="enter_room", type="combat", encounter="SHRINKER_BEETLE_WEAK")
        self.initial_hp = self.state["enemies"][0]["hp"]
        self.assertTrue(34 <= self.initial_hp <= 43)
        self.play("ROCKET_PUNCH")
        self.assertEqual(self.state["enemies"][0]["hp"], self.initial_hp - 13)

    def tearDown(self):
        (ROOT / "outputs" / (self.label + ".json")).write_text(json.dumps({
            "provenance": "artificial original-engine fixture, excluded from training",
            "trace": self.trace, "solver_calls": self.replays}, ensure_ascii=False, indent=2), encoding="utf-8")

    def send(self, **request):
        response = self.bridge.send(**request)
        self.trace.append({"request": request, "response": response})
        self.assertNotEqual(response.get("type"), "error", response)
        return response

    def play(self, card_id):
        card = next(c for c in self.state["hand"] if c["id"] == "CARD." + card_id)
        self.state = self.send(cmd="action", action="play_card", args={"card_index": card["index"], "target_index": 0})

    def test_nonlethal_neow_keeps_optional_single_choice_pending(self):
        self.play("NEOWS_FURY")
        self.assertEqual(self.state["decision"], "card_select")
        self.assertEqual(self.state["min_select"], 0)
        self.assertEqual([c["id"] for c in self.state["cards"]], ["CARD.ROCKET_PUNCH"])
        self.assertEqual(self.state["choice_audit"]["events"], [])
        meta = self.send(cmd="choice_meta")
        self.assertEqual(meta["selection"], "card_select")
        self.assertEqual(meta["completion_audit"], self.state["choice_audit"])
        self.state = self.send(cmd="action", action="select_cards", args={"indices": "0"})
        self.assertEqual(self.state["decision"], "combat_play")
        self.assertIn("CARD.ROCKET_PUNCH", [c["id"] for c in self.state["hand"]])
        self.assertEqual(self.state["choice_audit"]["events"], [])

    def test_lethal_neow_original_solver_plan_is_audited_as_unexecuted(self):
        self.state = self.send(cmd="action", action="use_potion", args={"potion_index": 0, "target_index": 0})
        self.assertEqual(self.state["enemies"][0]["hp"], self.initial_hp - 33)
        executor = CombatExecutor(self.send)
        self.state = executor.advance(self.state)
        self.replays = executor.solve_calls
        self.assertEqual(self.state["decision"], "card_reward")
        self.assertFalse(self.state["context"]["combat_in_progress"])
        evidence = [r for call in self.replays for r in call.get("replay", [])]
        self.assertEqual(len(evidence), 1)
        proof = evidence[0]
        self.assertEqual(proof["kind"], "planned_choice_not_executed")
        self.assertEqual([c["CardId"] for c in proof["plan"]["Cards"]], ["ROCKET_PUNCH"])
        self.assertEqual(proof["selected_cards"], [])
        events = self.state["choice_audit"]["events"]
        self.assertEqual(len(events), 1)
        self.assertTrue(events[0]["original_returned_empty_array"])
        self.assertFalse(events[0]["selection_executed"])
        self.assertEqual(events[0]["selector_invocations_before"], events[0]["selector_invocations_after"])
        self.assertFalse(any(t["request"].get("action") == "select_cards" for t in self.trace))


if __name__ == "__main__":
    unittest.main()
