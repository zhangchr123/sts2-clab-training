"""Original natural prefix, both isolated orders, and actual game continuation."""
import unittest
import uuid
from pathlib import Path

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from inspection.trial_cosmetic_projection import project_trial_number
from prefix_interventions import read_json,read_lines,unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

SOURCE=Path('D:/sts2-training/staging/hologram-original-repeat-glam/sts2-solver-bridge')
BATCH='defect-identity-step-search-20260915a'
LABEL=BATCH+'-training-half-008'

class PaelsEyeOrder(unittest.TestCase):
    worker=helpers.LiquidMemoriesTests.worker
    save=helpers.LiquidMemoriesTests.save

    def exercise(self,stop,check,fresh=False):
        rows=read_lines(SOURCE/'outputs'/LABEL/'trace.jsonl')
        audit=read_json(SOURCE/'outputs'/BATCH/(LABEL+'-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        label='paels-eye-order-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);matched=0;passed=False;executor=None;probe=None;cosmetic=[]
        try:
            for row in rows[:stop]:
                if row['request']['cmd'] in ('solve','combat_meta','choice_meta'):continue
                before=send(row['request']);a,ad=project_trial_number(checked_public(before));b,bd=project_trial_number(checked_public(row['response']))
                self.assertEqual(a,b)
                if ad or bd:cosmetic.append({'prefix':matched,'actual':ad,'original':bd})
                matched+=1
            if fresh:
                executor=CombatExecutor(send,read_json(SOURCE/'outputs'/LABEL/'manifest.json')['solver_requested_config'])
                state=executor.advance(before)
                self.assertFalse(state['context']['combat_in_progress'])
                self.assertFalse(state['context']['integrity_recovery_used'])
                self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
                self.assertTrue(executor.solve_calls)
            else:
                probe=send(cmd='probe_paels_eye_order')
                self.assertTrue(probe['diagnostic_only'] and probe['observed_live_branch_audit_unchanged'])
                self.assertFalse(probe['training_sample'] or probe['complete_hidden_state_equality_claimed'])
                self.assertEqual(probe['observation_scope'],'after_original_root_capture')
                self.assertEqual(probe['original_order'],probe['original_live_order'])
                self.assertEqual(probe['corrected_order'],probe['corrected_live_order'])
                check(probe)
                # This is the original actual next end-turn, not a simulated state.
                after=send(rows[stop]['request'])
                self.assertEqual(project_trial_number(checked_public(after))[0],
                    project_trial_number(checked_public(rows[stop]['response']))[0])
            self.assertTrue(unchanged(audit['actual_source_evidence']));passed=True
        finally:
            self.save(label,traces,passed=passed,original_failure=LABEL,original_sources=audit['actual_source_evidence'],
                public_prefix_responses_verified=matched,Trial_display_projection=cosmetic,
                probe=probe,solver_calls=executor.solve_calls if executor else [],
                original_solver_plan_reused=False,fresh_solver_used=fresh,hidden_state_or_rng_equality_claimed=False)
            bridge.close();print({'label':label,'passed':passed,'prefix':matched},flush=True)

    def test_newly_exhausted_howl_stays_exhausted_until_next_auto_phase(self):
        def check(probe):
            old,new=probe['original_order'],probe['corrected_order']
            self.assertTrue(old['extra_turn'] and new['extra_turn'] and old['before_orb_hooks_completed'] and new['before_orb_hooks_completed'])
            a,b,c=old['snapshots'];x,y,z=new['snapshots']
            self.assertEqual(a,x);self.assertIn('HOWL_FROM_BEYOND',x['hand'])
            self.assertEqual(b['hand'],[]);self.assertEqual(y['hand'],x['hand'])
            self.assertIn('HOWL_FROM_BEYOND',c['discard']);self.assertNotIn('HOWL_FROM_BEYOND',c['exhaust'])
            self.assertIn('HOWL_FROM_BEYOND',z['exhaust']);self.assertNotIn('HOWL_FROM_BEYOND',z['discard'])
            self.assertEqual(z['hand'],[])
        self.exercise(624,check)

    def test_manual_card_turn_does_not_trigger_paels_eye(self):
        def check(probe):
            a,b=probe['original_order'],probe['corrected_order']
            self.assertFalse(a['extra_turn'] or b['extra_turn']);self.assertEqual(a['snapshots'],b['snapshots'])
        self.exercise(623,check)

    def test_consumed_eye_keeps_existing_exhaust_howl_autoplay(self):
        rows=read_lines(SOURCE/'outputs'/LABEL/'trace.jsonl')
        # After the actual extra-turn boundary the next natural action is a card,
        # and is replayed only to prove that the probe leaves actual state intact.
        def check(probe):
            a,b=probe['original_order'],probe['corrected_order']
            self.assertFalse(a['extra_turn'] or b['extra_turn']);self.assertEqual(a['snapshots'],b['snapshots'])
            self.assertIn('HOWL_FROM_BEYOND',b['snapshots'][0]['exhaust'])
            self.assertIn('HOWL_FROM_BEYOND',b['snapshots'][2]['discard'])
        self.exercise(626,check)

    def test_fresh_solver_finishes_original_failed_combat(self):
        self.exercise(603,None,fresh=True)

if __name__=='__main__':unittest.main(verbosity=2)
