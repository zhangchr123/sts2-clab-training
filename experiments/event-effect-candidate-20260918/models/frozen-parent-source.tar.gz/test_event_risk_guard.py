"""Actual completed natural bridge deaths plus conservative policy boundaries."""
import copy
import json
from pathlib import Path
import sys
import unittest

HERE=Path('D:/sts2-training/inspection')
PARENT=HERE.parent/'staging/compact-selection-target-289/sts2-solver-bridge'
if Path(__file__).resolve().parent==HERE:sys.path.insert(0,str(PARENT))
import event_risk_guard as guard
from decision_data import DataContractError,materialize_candidate


class EventRiskGuardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases=[]
        for suffix in ('zero-base-030','guided_half-base-002'):
            folder=PARENT/'outputs'/('defect-selection-target-search-20260915a-training-'+suffix)
            records=[json.loads(line) for line in (folder/'decisions.jsonl').read_text(encoding='utf-8').splitlines()]
            completed=[r for r in records if r.get('record_type')=='decision_completed']
            packet={r['decision_id']:r for r in map(json.loads,(folder/'policy.jsonl').read_text(encoding='utf-8').splitlines())}
            for record in completed:
                if record['state']['decision']!='event_choice':continue
                selected=record['chosen'].get('evidence',{})
                if not str(selected.get('text_key','')).startswith('SLIPPERY_BRIDGE.'):continue
                scoring=packet[record['decision_id']]['scoring']
                weights=json.loads(Path(scoring['search_policy_source']['path']).read_text(encoding='utf-8'))['parameters']
                cls.cases.append((record,scoring,weights))
        assert len(cls.cases)>=5

    def apply(self,case):
        record,scoring,weights=case
        candidates={r['candidate_id']:materialize_candidate(record['candidate_set'],r['request']) for r in scoring['scores']}
        return guard.adjust(record['state'],copy.deepcopy(scoring),candidates,weights)

    def test_both_actual_fatal_nominal_costs_yield_to_public_zero_cost_option(self):
        fatal=[c for c in self.cases if c[0]['next_state']['player']['hp']==0]
        self.assertEqual(len(fatal),2)
        for case in fatal:
            changed=self.apply(case);best=max(changed['scores'],key=lambda r:r['score'])
            self.assertEqual(best['request']['args']['option_index'],0)
            blocked=[r for r in changed['scores'] if r.get('event_risk_guard',{}).get('hard_blocked')]
            self.assertEqual(len(blocked),1)
            self.assertFalse(blocked[0]['event_risk_guard']['actual_damage_or_guaranteed_death_claimed'])

    def test_positive_cost_weights_cannot_reward_bridge_rerolls_at_healthy_hp(self):
        healthy=[c for c in self.cases if c[0]['next_state']['player']['hp']>0]
        self.assertTrue(healthy)
        for case in healthy:
            packet=self.apply(case)
            best=max(packet['scores'],key=lambda r:r['score'])
            self.assertEqual(best['request']['args']['option_index'],0)
            risk=next(r['event_risk_guard'] for r in packet['scores'] if r['request']['args']['option_index']==1)
            self.assertGreater(risk['nominal_cost_penalty'],0)

    def test_all_289_feature_values_and_original_packet_stay_unchanged(self):
        for case in self.cases:
            original=copy.deepcopy(case[1]);updated=self.apply(case)
            self.assertEqual(case[1],original)
            for before,after in zip(original['scores'],updated['scores']):
                self.assertEqual(before['search_features'],after['search_features'])
                self.assertEqual(len(after['search_features']),289)
                self.assertEqual(before['rule_score'],after['rule_score'])

    def test_unknown_shared_variables_do_not_invent_cost_and_no_zero_alternative_does_not_block_every_option(self):
        record,scoring,weights=copy.deepcopy(self.cases[-1])
        candidates={r['candidate_id']:materialize_candidate(record['candidate_set'],r['request']) for r in scoring['scores']}
        for candidate in candidates.values():candidate['evidence']['text_key']='UNKNOWN.pages.INITIAL.options.CHOICE'
        changed=guard.adjust(record['state'],copy.deepcopy(scoring),candidates,weights)
        self.assertEqual([r['score'] for r in changed['scores']],[r['score'] for r in scoring['scores']])
        selected=next(r for r in scoring['scores'] if r['request']['args']['option_index']==1)
        candidate=materialize_candidate(record['candidate_set'],selected['request'])
        single={**scoring,'scores':[copy.deepcopy(selected)]}
        result=guard.adjust(record['state'],single,{selected['candidate_id']:candidate},weights)
        self.assertFalse(result['scores'][0]['event_risk_guard']['hard_blocked'])

    def test_invalid_public_nominal_cost_is_rejected(self):
        record,scoring,weights=copy.deepcopy(self.cases[-1])
        for invalid in (True,-1,float('nan')):
            candidates={r['candidate_id']:materialize_candidate(record['candidate_set'],r['request']) for r in scoring['scores']}
            for c in candidates.values():c['evidence']['vars']['HpLoss']=invalid
            with self.assertRaises(DataContractError):guard.adjust(record['state'],copy.deepcopy(scoring),candidates,weights)


if __name__=='__main__':unittest.main(verbosity=2)
