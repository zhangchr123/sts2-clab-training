"""Public feature extension: public nominal event costs, never guaranteed damage/death.

Exact engine option keys select variables; options export shared variables.
Damage hooks, revival, random rewards and removal value remain unknown.
"""
import math
from circulation_capability_features import PARAMETERS as ORIGINAL_PARAMETERS, features as original_features
from decision_data import DataContractError

ENGINE_SHA256='14b57dbaee1b58cb919625a662831054fd714b3b75b13b7449eac0e95b98a3e4'
CONTRACTS={
    'WHISPERING_HOLLOW.pages.INITIAL.options.HUG':('HpLoss',None,'WhisperingHollow.Hug'),
    'WHISPERING_HOLLOW.pages.INITIAL.options.GOLD':(None,None,'WhisperingHollow.Gold'),
    'THIS_OR_THAT.pages.INITIAL.options.PLAIN':('HpLoss','Gold','ThisOrThat.Plain'),
    'THIS_OR_THAT.pages.INITIAL.options.ORNATE':(None,None,'ThisOrThat.Ornate'),
    'JUNGLE_MAZE_ADVENTURE.pages.INITIAL.options.SOLO_QUEST':('SoloHp','SoloGold','JungleMazeAdventure.DontNeedHelp'),
    'JUNGLE_MAZE_ADVENTURE.pages.INITIAL.options.JOIN_FORCES':(None,'JoinForcesGold','JungleMazeAdventure.SafetyInNumbers'),
    'SLIPPERY_BRIDGE.pages.INITIAL.options.OVERCOME':(None,None,'SlipperyBridge.Overcome'),
    'SLIPPERY_BRIDGE.pages.INITIAL.options.HOLD_ON_0':('HpLoss',None,'SlipperyBridge.HoldOn'),
    'BRAIN_LEECH.pages.INITIAL.options.RIP':('RipHpLoss',None,'BrainLeech.Rip'),
    'BRAIN_LEECH.pages.INITIAL.options.SHARE_KNOWLEDGE':(None,None,'BrainLeech.ShareKnowledge'),
}
# The engine increments the step and clamps the localization suffix to LOOP at 7.
for i in range(7):
    after=str(i+1) if i+1<7 else 'LOOP'
    CONTRACTS[f'SLIPPERY_BRIDGE.pages.HOLD_ON_{i}.options.HOLD_ON_{after}']=('HpLoss',None,'SlipperyBridge.HoldOn')
CONTRACTS['SLIPPERY_BRIDGE.pages.HOLD_ON_LOOP.options.HOLD_ON_LOOP']=('HpLoss',None,'SlipperyBridge.HoldOn')
CONTRACTS.update({
    'ROOM_FULL_OF_CHEESE.pages.INITIAL.options.GORGE':(None,None,'RoomFullOfCheese.Gorge'),
    'ROOM_FULL_OF_CHEESE.pages.INITIAL.options.SEARCH':('Damage',None,'RoomFullOfCheese.Search'),
})
EXTRA_PARAMETERS=('event_nominal_hp_cost_per_max_hp','event_nominal_hp_cost_per_current_hp',
                  'event_nominal_cost_reaches_current_hp','event_explicit_gold_gain_hundreds')
PARAMETERS=(*ORIGINAL_PARAMETERS,*EXTRA_PARAMETERS)


def nonnegative(value,name,positive=False):
    if type(value) not in (int,float) or not math.isfinite(value) or value<0 or (positive and value==0):
        raise DataContractError('Missing or invalid public event '+name)
    return float(value)


def extra_features(state,row,candidate):
    if row['request']!=candidate['request']:raise DataContractError('Event row/candidate mismatch')
    values=dict.fromkeys(EXTRA_PARAMETERS,0.)
    if state.get('decision')!='event_choice' or row['request'].get('action')!='choose_option':return values
    item=candidate['evidence'];contract=CONTRACTS.get(item.get('text_key'))
    if contract is None:return values
    cost_key,gold_key,_=contract
    public=item.get('vars',{})
    if not isinstance(public,dict):raise DataContractError('Invalid event public variables')
    cost=0. if cost_key is None else nonnegative(public.get(cost_key),cost_key)
    gold=0. if gold_key is None else nonnegative(public.get(gold_key),gold_key)
    hp=nonnegative(state.get('player',{}).get('hp'),'current HP',True)
    maximum=nonnegative(state.get('player',{}).get('max_hp'),'maximum HP',True)
    values.update(event_nominal_hp_cost_per_max_hp=min(2.,cost/maximum),
                  event_nominal_hp_cost_per_current_hp=min(2.,cost/hp),
                  event_nominal_cost_reaches_current_hp=float(cost>=hp),
                  event_explicit_gold_gain_hundreds=min(4.,gold/100.))
    return values


def features(state,row,candidate):
    old=original_features(state,row,candidate)
    if tuple(old)!=ORIGINAL_PARAMETERS:raise DataContractError('Original 261 schema differs')
    return {**old,**extra_features(state,row,candidate)}


def zero_extend(parameters):
    if set(parameters)!=set(ORIGINAL_PARAMETERS) or any(type(v) not in (int,float)
        or not math.isfinite(v) or abs(v)>4 for v in parameters.values()):
        raise DataContractError('Invalid original 261 parameters')
    return {**{k:parameters[k] for k in ORIGINAL_PARAMETERS},**dict.fromkeys(EXTRA_PARAMETERS,0.)}
