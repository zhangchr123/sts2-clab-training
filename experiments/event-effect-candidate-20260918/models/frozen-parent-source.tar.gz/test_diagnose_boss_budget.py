"""Pure prefix/diagnostic tests; never starts an engine or creates training data."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from inspection.diagnose_boss_search_budget import locate_gate, replay, prepare, run
from test_boss_progress import trace


class BudgetDiagnosticTests(unittest.TestCase):
    def rows(self):
        rows = trace()
        rows[1]['response']['player_turn'] = 1
        return rows

    def test_replay_uses_original_actions_and_stops_at_first_boss(self):
        rows = self.rows(); gate = locate_gate(rows, 'fixture')
        requests = []
        def send(q, phase, index):
            requests.append(q)
            return copy.deepcopy(rows[index]['response'])
        state, count = replay(rows, gate, send)
        self.assertEqual(count, 2)
        self.assertEqual(state, rows[1]['response'])
        self.assertEqual(requests, [r['request'] for r in rows[:2]])
        bad = copy.deepcopy(rows); bad[1]['request'] = {'cmd': 'set_player'}
        with self.assertRaises(ValueError):
            locate_gate(bad, 'fixture')

    def test_prefix_mismatch_stops_before_new_solve(self):
        rows = self.rows(); gate = locate_gate(rows, 'fixture')
        def wrong(q, phase, index):
            s = copy.deepcopy(rows[index]['response']); s['player']['hp'] -= 1
            return s
        with self.assertRaisesRegex(ValueError, 'Public prefix mismatch'):
            replay(rows, gate, wrong)

    def test_unfinished_training_blocks_execution_before_engine(self):
        from inspection import diagnose_boss_search_budget as diagnostic
        from combat_executor import DEFAULT_CONFIG
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'protocol.json'
            protocol = {'schema_version': diagnostic.VERSION, **diagnostic.FLAGS,
                'source_run': diagnostic.SOURCE_RUN, 'required_training_completion': str(Path(directory) / 'absent.json'),
                'arms': [{'name': name, 'config': {**DEFAULT_CONFIG, 'first_budget_ms': budget}}
                         for name, budget in [('base', 2500), ('extended', 30000)]]}
            path.write_text(json.dumps(protocol), encoding='utf-8')
            with patch('inspection.diagnose_boss_search_budget.Bridge') as bridge:
                read = diagnostic.read_json
                def synthetic_manifest(p):
                    if Path(p).name == 'manifest.json':
                        return {'solver_requested_config': DEFAULT_CONFIG}
                    return read(p)
                with patch.object(diagnostic, 'read_json', side_effect=synthetic_manifest), self.assertRaises(FileNotFoundError):
                    run(path)
                bridge.assert_not_called()
                self.assertFalse((path.parent / 'execution-started.json').exists())


if __name__ == '__main__':
    unittest.main()
