"""Untouched-seed paired evaluation after complete original-engine CEM training.

Select only the final generation's predeclared top candidate, before evaluation.
All reserved seeds count, including environment failures. No tuning or deployment.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import random

from audit_batch import _Audit
from boss_progress import observed_progress
from prefix_interventions import read_json, read_lines, require, unchanged
from run_metadata import atomic_json, file_evidence
from sample_runs import run_one
from train_contextual_run import ROOT, VERSION as TRAIN_VERSION, WARM_VERSION, SOURCES, METHOD, write_new
from contextual_policy import PARAMETERS, make_artifact, ContextualPolicy

VERSION = 'contextual-first-boss-reserved-paired-evaluation-v2'


def evaluation_order(seeds, name):
    require(len(seeds) == 30 and len(set(seeds)) == 30, 'Need all 30 distinct reserved seeds')
    rng = random.Random(name + ':evaluation-order-v1')
    order = []
    for index, seed in enumerate(seeds):
        arms = ['zero', 'trained']; rng.shuffle(arms)
        order.extend({'seed': seed, 'seed_index': index, 'arm': arm} for arm in arms)
    return order


def summarize(rows, seeds):
    lookup = {(r['seed'], r['arm']): r for r in rows}
    require(len(lookup) == len(rows) == 2 * len(seeds), 'Incomplete or duplicate evaluation')
    require(set(lookup) == {(seed, arm) for seed in seeds for arm in ('zero', 'trained')}, 'Wrong evaluation allocation')
    arms = {}
    for arm in ('zero', 'trained'):
        records = [lookup[seed, arm] for seed in seeds]
        arms[arm] = {'planned_games': len(seeds), 'actual_games': len(records),
            'first_boss_successes': sum(r['goal_success'] for r in records),
            'act3_reached': sum(r['goal']['max_act_observed'] >= 3 for r in records),
            'act2_reached': sum(r['goal']['max_act_observed'] >= 2 for r in records),
            'outcomes': dict(Counter(r['outcome'] for r in records)),
            'all_audits_passed': all(r['audit_passed'] for r in records)}
    pairs = Counter()
    for seed in seeds:
        a, b = lookup[seed, 'zero']['goal_success'], lookup[seed, 'trained']['goal_success']
        pairs['both' if a and b else 'zero_only' if a else 'trained_only' if b else 'neither'] += 1
    return {'schema_version': VERSION, 'arms': arms, 'paired_first_boss_results': dict(pairs),
        'all_reserved_trained_games_succeeded': arms['trained']['first_boss_successes'] == len(seeds),
        'universal_success_proven': False, 'model_deployed': False,
        'evaluation_used_for_fit_or_parameter_selection': False}


def prepare(training_path, output):
    training_path, output = Path(training_path).resolve(), Path(output).resolve()
    require(not output.parent.exists(), 'Use a new evaluation directory')
    training = read_json(training_path)
    require(training['schema_version'] in {TRAIN_VERSION, WARM_VERSION} and training['method'] == METHOD,
            'Unsupported training protocol')
    completion_path = training_path.parent / 'training-completed.json'
    completion = read_json(completion_path)
    summaries = completion['generations']
    require(len(summaries) == len(training['training_seeds']) and len(summaries) > 0,
            'Training must finish all generations before evaluation')
    frozen = training['frozen_sources'] + [file_evidence(training_path), file_evidence(completion_path)] + summaries
    require(unchanged(frozen), 'Training source or completion evidence drift')
    for generation, evidence in enumerate(summaries):
        summary = read_json(evidence['path'])
        require(summary['generation'] == generation, 'Wrong generation order')
        expected = len(training['training_seeds'][generation])
        evaluations = summary['evaluations']
        require(len(evaluations) == 17 and all(r['actual_games'] == r['planned_games'] == expected for r in evaluations),
                'Incomplete population')
        receipt_path = training_path.parent / f'generation-{generation:02d}' / 'RECONCILIATION.json'
        receipt = read_json(receipt_path)
        require(receipt['passed'] is True and receipt['generation'] == generation
                and receipt['actual_games'] == 17 * expected
                and receipt['source_protocol'] == file_evidence(training_path)
                and receipt['source_summary'] == evidence
                and receipt['evaluations_recomputed_from_original_traces'] == evaluations,
                'Complete matching generation reconciliation required')
        frozen += [summary['source_allocation'], file_evidence(receipt_path)]
    final = read_json(summaries[-1]['path'])
    model = final['best_candidate_artifact']
    frozen.append(model)
    seeds = training['reserved_evaluation_seeds']
    require(not set(seeds).intersection(sum(training['training_seeds'], [])), 'Train/evaluation overlap')
    ContextualPolicy(model['path'], solver_config=training['solver_config'], seed=seeds[0], epsilon=0.)
    order = evaluation_order(seeds, training['name'])
    require(unchanged(frozen), 'Training allocation or chosen artifact drift')
    output.parent.mkdir()
    zero_path = output.parent / 'zero-parameters.json'
    write_new(zero_path, make_artifact(dict.fromkeys(PARAMETERS, 0.), training['solver_config'],
        training={'phase': 'zero_parameter_current_rule_control', 'source_training_protocol': file_evidence(training_path)}))
    frozen += [file_evidence(zero_path), file_evidence(Path(__file__).resolve())]
    doc = {'schema_version': VERSION, 'created_utc': datetime.now(timezone.utc).isoformat(),
        'name': training['name'] + '-reserved', 'source_training_protocol': file_evidence(training_path),
        'candidate_selection': 'final_generation_predeclared_top_candidate_no_evaluation_outcomes',
        'seeds': seeds, 'order': order, 'models': {'trained': model, 'zero': file_evidence(zero_path)},
        'solver_config': training['solver_config'], 'sampling': training['sampling'],
        'frozen_sources': frozen, 'planned_games': 60, 'environment_failures_remain_in_denominator': True,
        'llm_gameplay_choices': False, 'automatic_deployment': False}
    write_new(output, doc)
    return doc


def run(path):
    path = Path(path).resolve()
    protocol = read_json(path)
    require(protocol['schema_version'] == VERSION and protocol['planned_games'] == 60, 'Wrong evaluation protocol')
    require('runtime_transfer' not in protocol, 'Contextual evaluation requires the frozen training runtime')
    require(protocol['order'] == evaluation_order(protocol['seeds'],
        read_json(protocol['source_training_protocol']['path'])['name']), 'Changed evaluation order')
    frozen = protocol['frozen_sources'] + [file_evidence(path)]
    require(unchanged(frozen), 'Frozen evaluation input drift')
    write_new(path.parent / 'execution-started.json', {'protocol': file_evidence(path), 'workers': 1,
        'resume_or_rerun': False, 'started_utc': datetime.now(timezone.utc).isoformat()})
    rows = []
    for allocation in protocol['order']:
        require(unchanged(frozen), 'Frozen evaluation input drift')
        arm, seed = allocation['arm'], allocation['seed']
        label = f"{protocol['name']}-{arm}-{allocation['seed_index']:03d}"
        sampling = protocol['sampling']
        report = run_one(label, seed, settings=protocol['solver_config'], epsilon=sampling['epsilon'],
            max_seconds=sampling['max_seconds'], max_decisions=sampling['max_decisions'],
            selection_budget=sampling['selection_budget'], model_path=Path(protocol['models'][arm]['path']))
        audit = _Audit(ROOT / 'outputs' / label)
        audit.run(report)
        goal = observed_progress(read_lines(ROOT / 'outputs' / label / 'trace.jsonl'), natural=True, expected_seed=seed)
        good = report['outcome'] in {'victory', 'defeat'} and not audit.issues and not goal['errors']
        row = {'run_id': label, 'seed': seed, 'arm': arm, 'outcome': report['outcome'], 'report': report,
            'audit_passed': not audit.issues, 'issues': audit.issues, 'checks': dict(audit.checks),
            'actual_source_evidence': list(audit.evidence.values()), 'goal': goal,
            'goal_success': good and goal['natural_goal_success'], 'evaluation_only': True}
        write_new(path.parent / (label + '-audit.json'), row)
        require(not audit.issues and (not goal['errors'] or report['outcome'] not in {'victory', 'defeat'}),
                'Evaluation raw evidence audit failed')
        require(unchanged(frozen), 'Frozen evaluation input drift after game')
        rows.append(row)
        atomic_json(path.parent / 'progress.json', {'completed': len(rows), 'planned': 60,
            'first_boss_successes': dict(Counter(r['arm'] for r in rows if r['goal_success']))})
        print(json.dumps({k: row[k] for k in ('run_id', 'arm', 'outcome', 'goal_success', 'audit_passed')}), flush=True)
    summary = summarize(rows, protocol['seeds'])
    summary['schema_version'] = protocol['schema_version']
    summary['source_protocol'] = file_evidence(path)
    summary['run_audits'] = [file_evidence(path.parent / (r['run_id'] + '-audit.json')) for r in rows]
    write_new(path.parent / 'comparison.json', summary)
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('prepare'); p.add_argument('--training', type=Path, required=True); p.add_argument('--output', type=Path, required=True)
    p = sub.add_parser('run'); p.add_argument('--protocol', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'prepare':
        print(json.dumps({'prepared': str(args.output), 'planned_games': prepare(args.training, args.output)['planned_games']}))
    else:
        run(args.protocol)
