"""Observed original-engine progress toward the Act3 FIRST boss, never predictions.

Pure trace analysis. Caller separately proves provenance, source hashes and replay
integrity. A diagnostic can prove its own boss transition but never a natural win.
"""
from decision_data import state_hash

VERSION = "actual-act3-first-boss-progress-v1"
ALLOWED_COMMANDS = {"start_run", "action", "solve", "choice_meta", "combat_meta", "get_map"}
ALLOWED_ACTIONS = {"choose_option", "select_cards", "select_card_reward", "skip_card_reward",
    "select_bundle", "select_map_node", "buy_card", "buy_relic", "buy_potion", "remove_card",
    "leave_room", "leave_shop", "discard_potion", "use_potion", "play_card", "end_turn", "proceed",
    "crystal_sphere_reveal"}


def observed_progress(trace, *, natural=False, expected_seed=None):
    errors, proof = [], None
    first_boss = None
    last_decision = None
    maximum = (0, 0)
    for index, row in enumerate(trace):
        request, response = row.get("request", {}), row.get("response")
        command = request.get("cmd")
        if command not in ALLOWED_COMMANDS or (command == "action" and request.get("action") not in ALLOWED_ACTIONS):
            errors.append({"index": index, "reason": "unsupported_or_injected_request"})
        if command == "start_run":
            if index != 0 or request.get("character") != "Defect" or request.get("ascension") != 10:
                errors.append({"index": index, "reason": "not_original_Defect_A10_start"})
            if expected_seed is not None and request.get("seed") != expected_seed:
                errors.append({"index": index, "reason": "seed_mismatch"})
        if not isinstance(response, dict):
            errors.append({"index": index, "reason": "missing_actual_response"})
            continue
        if response.get("type") == "error":
            # Recoverable solver timeouts are validated by the execution auditor.
            if command != "solve":
                errors.append({"index": index, "reason": "actual_engine_error"})
            continue
        if response.get("type") != "decision" or command not in {"start_run", "action"}:
            continue
        ctx = response.get("context", {})
        act, floor = ctx.get("act"), ctx.get("floor")
        if (type(act) is not int or act not in (1, 2, 3) or type(floor) is not int
                or not 0 <= floor <= 99 or ctx.get("ascension") != 10
                or ctx.get("integrity_recovery_used") is not False):
            errors.append({"index": index, "reason": "invalid_actual_context"})
            continue
        maximum = max(maximum, (act, floor))
        hp = response.get("player", {}).get("hp")
        metrics = response.get("player", {}).get("combat_metrics", {})
        combat_id = metrics.get("combat_id")
        if (act == 3 and ctx.get("room_type") == "Boss" and ctx.get("is_second_boss") is False
                and ctx.get("combat_in_progress") is True
                and ctx.get("encounter_id") == (ctx.get("boss") or {}).get("id")
                and isinstance(ctx.get("encounter_id"), str) and type(combat_id) is int):
            first_boss = {"entry_index": (first_boss or {}).get("entry_index", index), "encounter_id": ctx["encounter_id"],
                          "combat_id": combat_id, "floor": floor}
        if first_boss and proof is None and act == 3 and command == "action":
            # The original CLI clears the defeated boss room and returns a map.
            # Preserve the last actual boss combat id; merely entering Act3 or
            # seeing a predicted Victory is never sufficient.
            ended = (ctx.get("combat_in_progress") is False
                     and response.get("decision") in {"map_select", "card_reward"}
                     and combat_id == first_boss["combat_id"]
                     and floor == first_boss["floor"] and type(hp) is int and hp > 0)
            previous = last_decision or {}
            prior_ctx = previous.get("context", {})
            if (ended and prior_ctx.get("combat_in_progress") is True
                    and prior_ctx.get("encounter_id") == first_boss["encounter_id"]
                    and prior_ctx.get("is_second_boss") is False):
                proof = {**first_boss, "end_index": index, "actual_hp_after": hp,
                         "end_state_hash": state_hash(response), "boundary": response["decision"]}
        last_decision = response
    if not trace or trace[0].get("request", {}).get("cmd") != "start_run":
        errors.append({"index": 0, "reason": "missing_original_run_start"})
    success = proof is not None and not errors
    # This is explicitly shaped progress for searching policies, not a win rate.
    # Any observed Act2 outranks any Act1 floor; goal success outranks all floors.
    shaped = 4.0 if success else (maximum[0] - 1 + maximum[1] / 100 if maximum[0] else 0.)
    return {"schema_version": VERSION, "verified_first_boss_defeated": success,
            "natural_goal_success": success and natural, "provenance_supplied_by_caller": True,
            "proof": proof if success else None, "errors": errors,
            "max_act_observed": maximum[0], "max_floor_in_max_act": maximum[1],
            "shaped_progress_not_win_probability": shaped,
            "complete_A10_victory_claimed": False}
