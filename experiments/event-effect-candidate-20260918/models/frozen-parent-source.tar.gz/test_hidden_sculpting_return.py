"""Original failure prefixes and synthetic boundaries; never natural training data."""
import copy
import os
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor, choice_plans
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
from inspection.replay_cheese_event import checked_public
import test_liquid_memories as helpers

ORIGINAL = Path('C:/Users/zhangchr/Documents/code/sts2-solver-bridge')
BASELINE = os.environ.get('RETURN_DIAGNOSTIC_BASELINE') == '1'


class HiddenSculptingTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def observe(self, send, before, after, action, request):
        observer = CombatExecutor(send)
        observer.last_action_request = request
        observer.solve_calls = [{'request': {'cmd': 'solve'},
            'response': {'type': 'solver_result', 'actions': [copy.deepcopy(action)]}}]
        self.assertTrue(observer.resolve_original_automatic_choice(before, after, action))
        return observer

    def test_five_original_failures_bind_returns_and_continue(self):
        for batch, generation, candidate, seed, card in [
            ('parallel', 2, 11, 22, 'HIDDEN_DAGGERS'), ('parallel', 2, 15, 22, 'HIDDEN_DAGGERS'),
            ('parallel', 2, 1, 22, 'HIDDEN_DAGGERS'), ('cem', 1, 13, 2, 'SCULPTING_STRIKE'),
            ('cem', 1, 2, 2, 'SCULPTING_STRIKE')]:
            with self.subTest(card=card, candidate=candidate):
                folder = ORIGINAL / 'outputs' / f'defect-contextual-{batch}-20260914a'
                name = f'{folder.name}-g{generation:02d}-c{candidate:02d}-s{seed:02d}'
                source = folder.parent / name
                receipt = read_json(folder / f'generation-{generation:02d}' / (name + '-audit.json'))
                self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
                rows = read_lines(source / 'trace.jsonl')
                parent = rows[-1]['response']['choice_audit']['parent']
                solve = max(i for i, r in enumerate(rows) if r['request']['cmd'] == 'solve')
                actions = [a for a in rows[solve]['response']['actions'] if a.get('CardId') == card
                    and a.get('CardStateKey') == parent['card_key'] and a.get('Turn') == parent['player_turn']]
                self.assertEqual(len(actions), 1)
                action = copy.deepcopy(actions[0])
                label = f'{"baseline" if BASELINE else "fixed"}-{card.lower()}-c{candidate:02d}-' + uuid.uuid4().hex[:10]
                bridge, traces, send = self.worker(label)
                matched = 0
                try:
                    for row in rows[:-1]:
                        if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                        before = send(row['request'])
                        self.assertEqual(checked_public(before), checked_public(row['response']))
                        matched += 1
                    meta = send(cmd='combat_meta')
                    after = send(rows[-1]['request'])
                    self.assertEqual(checked_public(after), checked_public(rows[-1]['response']))
                    if BASELINE:
                        self.assertEqual(after['choice_audit']['original_returns'], [])
                        with self.assertRaisesRegex(RuntimeError, 'Expected solver choice surface'):
                            CombatExecutor(send).resolve(after, choice_plans(action))
                        self.save(label, traces, passed=True, origin='original_runtime_baseline_prefix',
                            prefix_responses_verified=matched, original_source=receipt['actual_source_evidence'],
                            original_failure_reproduced=True)
                        continue
                    observer = self.observe(send, before, after, action, rows[-1]['request'])
                    proof = copy.deepcopy(observer.solve_calls[0]['replay'][0])
                    ending = card == 'SCULPTING_STRIKE'
                    self.assertEqual(proof['remaining_battle_plan_stopped'], ending)
                    self.assertEqual(proof['selected_cards'], [] if ending else [
                        {k: token[k] for k in ('CardId', 'UpgradeLevel', 'StateKey', 'SourceOccurrence', 'OptionOccurrence')}
                        for token in action['Choice']['Cards']])
                    self.assertFalse(proof['selection_request_sent'])
                    self.assertEqual(after['decision'], 'card_reward' if ending else 'combat_play')
                    synthetic = [{'request': {'cmd': 'start_run'}, 'response': before},
                        {'request': observer.solve_calls[0]['request'], 'response': observer.solve_calls[0]['response']},
                        {'request': {'cmd': 'combat_meta'}, 'response': meta},
                        {'request': rows[-1]['request'], 'response': after}, traces[-1]]
                    self.assertTrue(validate_replay_evidence(observer.solve_calls, synthetic)['verified'])
                    for field in ('source_id', 'effect_callsite', 'source_is_actual_parent_object',
                                  'original_task_completed_successfully', 'filter_reexecuted_by_observer',
                                  'filter_is_null', 'min_select', 'max_select', 'selector_invocations_after',
                                  'selector_pending_after', 'is_over_or_ending_at_entry', 'returned_count'):
                        bad = copy.deepcopy(after); event = bad['choice_audit']['original_returns'][0]
                        value = event[field]
                        event[field] = not value if type(value) is bool else value + 1 if type(value) is int else 'unrelated'
                        with self.subTest(corruption=field), self.assertRaises(RuntimeError):
                            observer.resolve_original_automatic_choice(before, bad, action)
                    for mutation in ('missing', 'selected', 'plan', 'submitted'):
                        bad = copy.deepcopy(observer.solve_calls)
                        if mutation == 'missing': bad[0]['replay'] = []
                        elif mutation == 'selected': bad[0]['replay'][0]['selected_cards'] = [{'CardId': 'UNRELATED'}]
                        elif mutation == 'plan': bad[0]['replay'][0]['plan']['Effect'] = 'Upgrade'
                        else: bad[0]['replay'][0]['selection_request_sent'] = True
                        with self.assertRaises(ValueError): validate_replay_evidence(bad, synthetic)
                    executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
                    final = executor.advance(after)
                    self.assertIn(final['decision'], {'card_reward', 'map_select', 'game_over'})
                    self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
                    self.save(label, traces, passed=True, origin='recorded_public_prefix_diagnostic',
                        prefix_responses_verified=matched, original_source=receipt['actual_source_evidence'],
                        historical_recorded_action=action, actual_recorded_action_proof=proof,
                        synthetic_offline_contract_checked=True, solver_calls=executor.solve_calls,
                        full_state_or_rng_equality_claimed=False)
                finally:
                    bridge.close()

    @unittest.skipIf(BASELINE, 'Boundaries belong to the repaired observer')
    def test_hidden_empty_singleton_two_mandatory_and_three_manual_cards(self):
        for count in (0, 1, 2, 3):
            with self.subTest(count=count):
                label = f'hidden-boundary-{count}-' + uuid.uuid4().hex[:10]
                bridge, traces, send = self.worker(label)
                try:
                    send(cmd='start_run', character='Defect', ascension=10, seed='hidden-synthetic-boundary')
                    send(cmd='set_player', hp=1000, max_hp=1000, relics=[], potions=[],
                         deck=['HIDDEN_DAGGERS'] + ['DEFEND_DEFECT'] * count)
                    before = send(cmd='enter_room', type='combat', encounter='FOGMOG_NORMAL')
                    index = next(c['index'] for c in before['hand'] if c['id'] == 'CARD.HIDDEN_DAGGERS')
                    meta = send(cmd='combat_meta')
                    key = next(c['key'] for c in meta['hand'] if c['index'] == index)
                    keys = [c['key'] for c in meta['hand'] if c['index'] != index]
                    request = {'cmd': 'action', 'action': 'play_card', 'args': {'card_index': index}}
                    after = send(request)
                    if count == 3:
                        self.assertEqual(after['decision'], 'card_select')
                        self.assertEqual((after['min_select'], after['max_select'], len(after['cards'])), (2, 2, 3))
                        self.assertFalse(CombatExecutor(send).resolve_original_automatic_choice(before, after, {}))
                        final = send(cmd='action', action='select_cards', args={'indices': '0,1'})
                        self.assertEqual(final['decision'], 'combat_play')
                    else:
                        cards = [{'CardId': 'DEFEND_DEFECT', 'UpgradeLevel': 0, 'StateKey': k,
                                  'SourceOccurrence': i, 'OptionOccurrence': i} for i, k in enumerate(keys)]
                        action = {'Kind': 'PlayCard', 'CardId': 'HIDDEN_DAGGERS', 'CardStateKey': key,
                            'Turn': before['player_turn'], 'Choice': {'Effect': 'Discard', 'SourcePile': 'Hand',
                            'SourceId': '', 'ContextId': '', 'Timing': 'Action', 'Cards': cards},
                            'NestedChoices': [], 'NestedChoicesBeforePrimary': 0, 'EndsPlayerTurn': False, 'ReplayCount': 0}
                        proof = self.observe(send, before, after, action, request).solve_calls[0]['replay'][0]
                        self.assertEqual(len(proof['selected_cards']), count)
                        final = after
                    self.assertEqual(sum(c['id'] == 'CARD.SHIV' for c in final['hand']), 2)
                    self.assertEqual(sum(c['id'] == 'CARD.DEFEND_DEFECT' for c in final['hand']), max(count - 2, 0))
                    self.save(label, traces, passed=True, origin='synthetic_boundary_not_training')
                finally:
                    bridge.close()

    @unittest.skipIf(BASELINE, 'Boundaries belong to the repaired observer')
    def test_sculpting_filtered_empty_singleton_and_manual_selection(self):
        for count in (0, 1, 2):
            with self.subTest(eligible=count):
                label = f'sculpting-boundary-{count}-' + uuid.uuid4().hex[:10]
                bridge, traces, send = self.worker(label)
                try:
                    send(cmd='start_run', character='Defect', ascension=10, seed='sculpting-synthetic-boundary')
                    send(cmd='set_player', hp=1000, max_hp=1000, relics=[], potions=[],
                         deck=['SCULPTING_STRIKE', 'ASCENDERS_BANE'] + ['DEFEND_DEFECT'] * count)
                    before = send(cmd='enter_room', type='combat', encounter='FOGMOG_NORMAL')
                    index = next(c['index'] for c in before['hand'] if c['id'] == 'CARD.SCULPTING_STRIKE')
                    meta = send(cmd='combat_meta'); key = next(c['key'] for c in meta['hand'] if c['index'] == index)
                    request = {'cmd': 'action', 'action': 'play_card', 'args': {'card_index': index, 'target_index': 0}}
                    after = send(request)
                    if count == 2:
                        self.assertEqual(after['decision'], 'card_select')
                        self.assertEqual(len(after['cards']), 2)
                        self.assertFalse(CombatExecutor(send).resolve_original_automatic_choice(before, after, {}))
                        final = send(cmd='action', action='select_cards', args={'indices': '0'})
                        self.assertEqual(final['decision'], 'combat_play')
                    else:
                        keys = [c['key'] for c in meta['hand'] if c['key'].startswith('DEFEND_DEFECT+')]
                        cards = [{'CardId': 'DEFEND_DEFECT', 'UpgradeLevel': 0, 'StateKey': k,
                                  'SourceOccurrence': i, 'OptionOccurrence': i} for i, k in enumerate(keys)]
                        action = {'Kind': 'PlayCard', 'CardId': 'SCULPTING_STRIKE', 'CardStateKey': key,
                            'Turn': before['player_turn'], 'Choice': {'Effect': 'ApplyEthereal', 'SourcePile': 'Hand',
                            'SourceId': '', 'ContextId': '', 'Timing': 'Action', 'Cards': cards},
                            'NestedChoices': [], 'NestedChoicesBeforePrimary': 0, 'EndsPlayerTurn': False, 'ReplayCount': 0}
                        proof = self.observe(send, before, after, action, request).solve_calls[0]['replay'][0]
                        self.assertEqual(len(proof['selected_cards']), count)
                        self.assertEqual(proof['actual_choice_audit']['original_returns'][0]['raw_source_count_at_entry'], count + 1)
                    hands = send(cmd='combat_meta')['hand']
                    changed = [c for c in hands if c['key'].startswith('DEFEND_DEFECT+') and 'keywords=Ethereal' in c['key']]
                    self.assertEqual(len(changed), min(count, 1))
                    self.save(label, traces, passed=True, origin='synthetic_boundary_not_training')
                finally:
                    bridge.close()


if __name__ == '__main__': unittest.main()
