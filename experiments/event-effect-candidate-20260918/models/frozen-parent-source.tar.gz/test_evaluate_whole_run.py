"""Synthetic evaluation accounting; never starts a game."""
import copy
import unittest
import json
from pathlib import Path
import tempfile
from unittest.mock import patch
import zipfile

from evaluate_whole_run import corrected_runtime_sources, evaluation_order, summarize
from run_metadata import file_evidence


class EvaluationTests(unittest.TestCase):
    def test_liquid_transfer_keeps_replay_and_solver_frozen_and_requires_own_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'bridge'; root.mkdir()
            cli = root.parent / 'sts2-cli/src/Sts2Headless'
            paths = [root / 'combat_executor.py', cli / 'bin/Debug/net9.0/Sts2Headless.dll',
                     root / 'replay_evidence.py', root / 'CombatSolver.dll']
            old = []
            for path in paths:
                path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b'old')
                old.append(file_evidence(path))
            records = [{**r, 'archive_member': str(i)} for i, r in enumerate(old)]
            archive = root / 'old.zip'
            with zipfile.ZipFile(archive, 'x') as z:
                for r in records: z.writestr(r['archive_member'], b'old')
                z.writestr('sources.json', json.dumps(records))
            receipt = root / 'receipt.json'
            receipt.write_text(json.dumps({'archive': str(archive), 'sha256': file_evidence(archive)['sha256'],
                                           'sources': records}))
            for path in paths[:2]: path.write_bytes(b'liquid fix')
            for name in ('RunSimulator.cs', 'RunSimulator.OriginalReturnAudit.cs'):
                (cli / name).write_bytes(b'observer source')
            with patch('evaluate_whole_run.ROOT', root):
                def transfer():
                    return corrected_runtime_sources({'frozen_sources': old}, receipt,
                                                     runtime_fix='liquid-memories-singleton')
                current, declaration = transfer()
                self.assertEqual(len(declaration['changed_sources']), 2)
                self.assertIn('LiquidMemories', declaration['corrections'][0])
                self.assertFalse(declaration['solver_budget_or_profile_changed'])
                self.assertFalse(declaration['parameters_refit'])
                self.assertIn(file_evidence(cli / 'RunSimulator.OriginalReturnAudit.cs'), current)
                with self.assertRaisesRegex(ValueError, 'Expected exactly'):
                    corrected_runtime_sources({'frozen_sources': old}, receipt)
                for path in paths[2:]:
                    path.write_bytes(b'unreviewed')
                    with self.assertRaisesRegex(ValueError, 'Unreviewed'):
                        transfer()
                    path.write_bytes(b'old')
                paths[0].write_bytes(b'old')
                with self.assertRaisesRegex(ValueError, 'Expected exactly'):
                    transfer()

    def test_runtime_transfer_authenticates_archive_and_rejects_other_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'bridge'; root.mkdir()
            cli = root.parent / 'sts2-cli/src/Sts2Headless'
            paths = [root / 'combat_executor.py', root / 'replay_evidence.py',
                     cli / 'bin/Debug/net9.0/Sts2Headless.dll', root / 'engine.dll']
            old = []
            for p in paths:
                p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b'old')
                old.append(file_evidence(p))
            records = [{**row, 'archive_member': str(i)} for i, row in enumerate(old)]
            archive = root / 'old.zip'
            with zipfile.ZipFile(archive, 'x') as z:
                for r in records: z.writestr(r['archive_member'], b'old')
                z.writestr('sources.json', json.dumps(records))
            receipt = root / 'archive.json'
            receipt.write_text(json.dumps({'archive': str(archive), 'sha256': file_evidence(archive)['sha256'], 'sources': records}))
            for p in paths[:3]: p.write_bytes(b'corrected')
            for n in ('RunSimulator.cs', 'RunSimulator.SoulNexus.cs'): (cli / n).write_bytes(b'source')
            with patch('evaluate_whole_run.ROOT', root):
                current, transfer = corrected_runtime_sources({'frozen_sources': old}, receipt)
                self.assertEqual(len(transfer['changed_sources']), 3)
                self.assertFalse(transfer['parameters_refit'])
                paths[-1].write_bytes(b'unreviewed engine change')
                with self.assertRaisesRegex(ValueError, 'Unreviewed'):
                    corrected_runtime_sources({'frozen_sources': old}, receipt)
                paths[-1].write_bytes(b'old')
                archive.write_bytes(b'corrupted')
                with self.assertRaisesRegex(ValueError, 'archive drift'):
                    corrected_runtime_sources({'frozen_sources': old}, receipt)

    def test_all_thirty_seed_pairs_preallocated_once(self):
        seeds = ['fixture-' + str(i) for i in range(30)]
        order = evaluation_order(seeds, 'fixture')
        self.assertEqual(len(order), 60)
        self.assertEqual(order, evaluation_order(seeds, 'fixture'))
        self.assertEqual({(r['seed'], r['arm']) for r in order},
                         {(s, a) for s in seeds for a in ('zero', 'trained')})
        self.assertEqual({order[i]['arm'] for i in range(0, 60, 2)}, {'zero', 'trained'})
        with self.assertRaises(ValueError):
            evaluation_order(['duplicate'] * 30, 'fixture')

    def test_failure_retained_and_first_boss_win_independent_of_full_a10(self):
        rows = [{'seed': s, 'arm': a, 'goal_success': a == 'trained' and s == 'one',
                 'goal': {'max_act_observed': 3}, 'outcome': 'defeat', 'audit_passed': True}
                for s in ('one', 'two') for a in ('zero', 'trained')]
        rows[-1]['outcome'] = 'environment_error'
        result = summarize(rows, ['one', 'two'])
        trained = result['arms']['trained']
        self.assertEqual(trained['planned_games'], 2)
        self.assertEqual(trained['first_boss_successes'], 1)
        self.assertEqual(trained['outcomes']['environment_error'], 1)
        self.assertFalse(result['all_reserved_trained_games_succeeded'])
        self.assertFalse(result['universal_success_proven'])
        self.assertEqual(result['paired_first_boss_results'], {'trained_only': 1, 'neither': 1})
        with self.assertRaises(ValueError):
            summarize(rows[:-1], ['one', 'two'])
        with self.assertRaises(ValueError):
            summarize(rows + [copy.deepcopy(rows[0])], ['one', 'two'])


if __name__ == '__main__':
    unittest.main()
