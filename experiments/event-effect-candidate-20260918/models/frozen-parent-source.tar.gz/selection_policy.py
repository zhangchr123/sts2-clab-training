"""Bounded non-LLM search over a complete, implicit ordered-selection space.

Every scored proposal is a complete legal wire request. Search scores are not
outcomes and the evaluated list is never advertised as the complete action set.
An exploration draw is uniform over *all* legal ordered selections, not over
the search proposals. Its score cannot change the already frozen exploit ties.
"""
from __future__ import annotations

import copy
from fractions import Fraction
import heapq
import math

from decision_data import (DEFAULT_ENUMERATION_LIMIT, LEGACY_ENUMERATION_LIMIT,
                           DataContractError, enumerate_candidates, materialize_candidate,
                           state_hash, validate_candidate_set)
from selection_space import (indices_from_request, rank_selection, request_for_indices,
                             request_for_rank, space_size)


LEGACY_VERSION = "bounded-ordered-selection-v1"
VERSION = "bounded-ordered-selection-v2"
TIE_TOLERANCE = 1e-12
HARD_MAX_EVALUATIONS = 4096
PROPOSALS_PER_EVALUATION = 32
REPRESENTATION = "ordered_selection_implicit_v1"


class SelectionPolicy:
    """Wrap InitialPolicy/SmallValuePolicy while preserving its global RNG position.

    max_evaluations includes the possible extra exploration score. At least two
    slots are required: one for the deterministic exploit set and one for an
    independently drawn exploration action. score() uses all slots and neither
    consumes RNG nor chooses or executes an action.
    """

    def __init__(self, base, max_evaluations=256):
        if type(max_evaluations) is not int or not 2 <= max_evaluations <= HARD_MAX_EVALUATIONS:
            raise DataContractError(f"max_evaluations must be 2..{HARD_MAX_EVALUATIONS}")
        epsilon = base.epsilon
        if type(epsilon) not in (int, float) or not math.isfinite(epsilon) or not 0 <= epsilon <= 1:
            raise DataContractError("Base epsilon must be finite and in [0, 1]")
        if not callable(getattr(base, "score_requests", None)):
            raise DataContractError("Base policy must expose strict score_requests")
        self.base = base
        self.max_evaluations = max_evaluations
        self.max_proposals = max_evaluations * PROPOSALS_PER_EVALUATION
        binder = getattr(base, "bind_merchant_selection_wrapper", None)
        if binder is not None:
            binder(self)

    @property
    def provenance(self):
        return {**self.base.provenance, "selection_search": self.parameters}

    @property
    def parameters(self):
        return {"version": VERSION, "max_evaluations": self.max_evaluations,
                "max_proposals": self.max_proposals, "tie_tolerance": TIE_TOLERANCE,
                "seed_strategy": "lexicographic_each_length_then_reversed_extremes",
                "frontier": "score_descending_rank_ascending",
                "neighbor_order": ["append", "delete", "replace", "swap"],
                "exploration": "uniform_full_ordered_space",
                "epsilon_draw": "exact_decimal_rational_randrange",
                "exploit_ties": "uniform_frozen_evaluated_best",
                "exploration_score_reserve": 1, "llm_involved": False}

    def _candidates(self, state, supplied):
        if supplied is not None:
            supplied = validate_candidate_set(supplied)
        actual = enumerate_candidates(state, max_candidates=(
            supplied.get("enumeration_limit", LEGACY_ENUMERATION_LIMIT)
            if supplied is not None else DEFAULT_ENUMERATION_LIMIT))
        if not actual.get("complete"):
            raise DataContractError(actual.get("reason") or "Incomplete legal action space")
        if supplied is not None and supplied != actual:
            raise DataContractError("Stale or modified candidate set")
        return actual

    def score_requests(self, state, requests, *, selection_purpose=None):
        """Evaluate only; legality and feature-version checks stay in the base API."""
        return self.base.score_requests(state, requests, selection_purpose=selection_purpose)

    @staticmethod
    def _neighbors(indices, pool, minimum, maximum):
        used = set(indices)
        unused = [value for value in pool if value not in used]
        if len(indices) < maximum:
            for value in unused:
                yield (*indices, value), "append"
        if len(indices) > minimum:
            for position in range(len(indices)):
                yield indices[:position] + indices[position + 1:], "delete"
        for position in range(len(indices)):
            for value in unused:
                yield indices[:position] + (value,) + indices[position + 1:], "replace"
        for left in range(len(indices)):
            for right in range(left + 1, len(indices)):
                changed = list(indices)
                changed[left], changed[right] = changed[right], changed[left]
                yield tuple(changed), "swap"

    def _search(self, state, candidate_set, limit, selection_purpose):
        descriptor = candidate_set["selection_space"]
        count = space_size(descriptor)
        pool = tuple(descriptor["indices"])
        minimum, maximum = descriptor["min_select"], descriptor["effective_max_select"]
        evaluated, frontier, proposals = {}, [], []
        first_metadata = None
        duplicates = 0

        def propose(indices, operation, parent_rank=None):
            nonlocal first_metadata, duplicates
            if len(evaluated) >= limit or len(proposals) >= self.max_proposals:
                return False
            rank = rank_selection(descriptor, indices)
            if rank in evaluated:
                duplicates += 1
                proposals.append({"rank": rank, "operation": operation,
                                  "parent_rank": parent_rank, "status": "already_evaluated"})
                return True
            request = request_for_indices(descriptor, indices)
            result, row = self._evaluate(state, request, selection_purpose)
            if first_metadata is None:
                first_metadata = {key: copy.deepcopy(value) for key, value in result.items() if key != "scores"}
            row["selection_rank"] = rank
            row["selection_proposal"] = {"operation": operation, "parent_rank": parent_rank}
            evaluated[rank] = row
            heapq.heappush(frontier, (-row["score"], rank, tuple(indices)))
            proposals.append({"rank": rank, "operation": operation,
                              "parent_rank": parent_rank, "status": "scored"})
            return True

        # Seed every legal cardinality without ever scoring an incomplete prefix.
        # In particular, min_select > 1 never causes singleton proposals.
        for length in range(minimum, maximum + 1):
            if not propose(pool[:length], "seed_length"):
                break
        for length in dict.fromkeys((minimum, maximum)):
            if not propose(tuple(reversed(pool[:length])), "seed_reverse"):
                break
        while frontier and len(evaluated) < limit and len(proposals) < self.max_proposals:
            _, parent_rank, indices = heapq.heappop(frontier)
            for neighbor, operation in self._neighbors(indices, pool, minimum, maximum):
                if not propose(neighbor, operation, parent_rank):
                    break
        if not evaluated:
            raise DataContractError("Search did not evaluate a legal complete request")
        best = max(row["score"] for row in evaluated.values())
        ties = sorted(rank for rank, row in evaluated.items() if abs(row["score"] - best) <= TIE_TOLERANCE)
        stop_reason = ("evaluation_budget" if len(evaluated) >= limit else
                       "proposal_budget" if len(proposals) >= self.max_proposals else "frontier_exhausted")
        scoring = {**first_metadata, "scores": list(evaluated.values()),
                   "selection_space": copy.deepcopy(descriptor), "candidate_count": count,
                   "candidate_space_representation": REPRESENTATION,
                   "evaluated_candidate_count": len(evaluated), "evaluated_candidates_complete": False,
                   "selection_search": {**self.parameters, "evaluation_budget": self.max_evaluations,
                       "search_evaluation_budget": limit, "search_evaluations": len(evaluated),
                       "evaluations": len(evaluated), "proposal_budget": self.max_proposals,
                       "proposals": proposals, "duplicate_proposals": duplicates,
                       "stop_reason": stop_reason, "frozen_greedy_ranks": ties,
                       "frozen_greedy_candidate_ids": [evaluated[rank]["candidate_id"] for rank in ties],
                       "best_score_semantics": "best_among_evaluated_search_candidates_only"}}
        self._refresh_skip_baseline(scoring)
        return scoring, evaluated, ties

    @staticmethod
    def _refresh_skip_baseline(scoring):
        skips = [row["score"] for row in scoring["scores"] if row.get("is_skip") is True]
        baseline = max(skips) if skips else None
        for row in scoring["scores"]:
            row["delta_from_skip"] = row["score"] - baseline if baseline is not None else None

    def _evaluate(self, state, request, selection_purpose):
        result = self.score_requests(state, [request], selection_purpose=selection_purpose)
        rows = result.get("scores", [])
        if result.get("state_hash") != state_hash(state) or len(rows) != 1:
            raise DataContractError("Base scorer returned stale or incomplete evaluation evidence")
        row = copy.deepcopy(rows[0])
        if (row.get("request") != request or row.get("candidate_id") != "action:" + state_hash(request)[:24]
                or type(row.get("score")) not in (int, float)
                or not math.isfinite(row["score"])):
            raise DataContractError("Base scorer returned an invalid selection score")
        return result, row

    def score(self, state, candidates=None, *, selection_purpose=None):
        candidate_set = self._candidates(state, candidates)
        if candidate_set.get("representation") != REPRESENTATION:
            return self.base.score(state, candidate_set, selection_purpose=selection_purpose)
        scoring, _, _ = self._search(state, candidate_set, self.max_evaluations, selection_purpose)
        return scoring

    def choose(self, state, candidates=None, *, selection_purpose=None):
        candidate_set = self._candidates(state, candidates)
        before = self.base.choice_count
        if candidate_set.get("representation") != REPRESENTATION:
            result = self.base.choose(state, candidate_set, selection_purpose=selection_purpose)
            result["policy_provenance"] = {**self.provenance, "choice_count": before}
            return result
        epsilon = self.base.epsilon
        count = space_size(candidate_set["selection_space"])
        reserve = int(epsilon > 0 and count > 1)
        scoring, evaluated, ties = self._search(
            state, candidate_set, self.max_evaluations - reserve, selection_purpose)
        # Freeze the exploit distribution BEFORE sampling or scoring exploration.
        eps = Fraction(str(epsilon))
        explored = self.base.rng.randrange(eps.denominator) < eps.numerator
        rank = self.base.rng.randrange(count) if explored else self.base.rng.choice(ties)
        if rank not in evaluated:
            request = request_for_rank(candidate_set["selection_space"], rank)
            _, row = self._evaluate(state, request, selection_purpose)
            row["selection_rank"] = rank
            row["selection_proposal"] = {"operation": "uniform_exploration", "parent_rank": None}
            evaluated[rank] = row
            scoring["scores"].append(row)
        chosen = evaluated[rank]
        scoring["evaluated_candidate_count"] = len(evaluated)
        scoring["selection_search"]["evaluations"] = len(evaluated)
        scoring["selection_search"]["exploration_rank"] = rank if explored else None
        scoring["selection_search"]["exploration_score_evaluations"] = len(evaluated) - scoring["selection_search"]["search_evaluations"]
        self._refresh_skip_baseline(scoring)
        probability = eps / count + ((1 - eps) / len(ties) if rank in ties else 0)
        result = {"request": copy.deepcopy(chosen["request"]), "candidate_id": chosen["candidate_id"],
                  "scoring": scoring, "policy_provenance": {**self.provenance, "choice_count": before},
                  "exploration": {"epsilon": epsilon, "explored": explored,
                      "chosen_probability": float(probability),
                      "chosen_probability_rational": {"numerator": probability.numerator,
                                                       "denominator": probability.denominator},
                      "probability_semantics": "epsilon_uniform_full_space_plus_uniform_frozen_search_best_ties",
                      "probability_precision": "exact_decimal_rational",
                      "greedy_tie_count": len(ties), "candidate_count": count,
                      "evaluated_candidate_count": len(evaluated), "choice_count": before,
                      "random_seed": self.base.provenance.get("random_seed"),
                      "chosen_rank": rank, "exploration_component_probability": float(eps / count)}}
        self.base.choice_count += 1
        return result


def validate_selection_evidence(state, candidate_set, picked):
    """Audit implicit-choice evidence without rerunning the scorer or the search.

    Raises DataContractError on any mismatch and returns validation metadata.
    Historical v1 uses a float-threshold Bernoulli, so its rational mixture is
    nominal. v2 uses an exact decimal-rational Bernoulli. This checks legality and
    the logged conditional sampling distribution; it does not establish that
    the scorer is accurate or that any unexecuted action has a known outcome.
    """
    try:
        return _validate_selection_evidence(state, candidate_set, picked)
    except DataContractError:
        raise
    except (TypeError, ValueError, AttributeError, KeyError, OverflowError) as exc:
        raise DataContractError("Malformed selection search evidence") from exc


def _validate_selection_evidence(state, candidate_set, picked):
    def require(condition, message):
        if not condition:
            raise DataContractError(message)

    def integer(value, minimum=0):
        require(type(value) is int and value >= minimum, "Invalid selection evidence integer")
        return value

    candidate_set = validate_candidate_set(candidate_set)
    require(candidate_set.get("representation") == REPRESENTATION, "Expected an implicit selection space")
    require(candidate_set == enumerate_candidates(state, max_candidates=candidate_set["enumeration_limit"]),
            "Selection evidence is bound to a different state")
    descriptor = candidate_set["selection_space"]
    count = space_size(descriptor)
    require(isinstance(picked, dict), "Missing selection policy evidence")
    scoring = picked.get("scoring", {})
    require(isinstance(scoring, dict), "Malformed selection scoring")
    search = scoring.get("selection_search", {})
    exploration = picked.get("exploration", {})
    provenance = picked.get("policy_provenance", {})
    require(all(isinstance(value, dict) for value in (scoring, search, exploration, provenance)),
            "Malformed selection evidence objects")
    require(scoring.get("state_hash") == state_hash(state)
            and scoring.get("selection_space") == descriptor
            and scoring.get("candidate_count") == count
            and scoring.get("candidate_space_representation") == REPRESENTATION
            and scoring.get("evaluated_candidates_complete") is False,
            "Selection scoring completeness or state identity is inconsistent")
    require(search.get("best_score_semantics") == "best_among_evaluated_search_candidates_only",
            "Selection search claims unsupported global score coverage")
    budget = integer(search.get("max_evaluations"), 2)
    require(budget <= HARD_MAX_EVALUATIONS, "Selection evaluation budget exceeds hard cap")
    version = search.get("version")
    require(version in {LEGACY_VERSION, VERSION}, "Unsupported selection search version")
    expected_parameters = {"version": version, "max_evaluations": budget,
        "max_proposals": budget * PROPOSALS_PER_EVALUATION, "tie_tolerance": TIE_TOLERANCE,
        "seed_strategy": "lexicographic_each_length_then_reversed_extremes",
        "frontier": "score_descending_rank_ascending", "neighbor_order": ["append", "delete", "replace", "swap"],
        "exploration": "uniform_full_ordered_space", "exploit_ties": "uniform_frozen_evaluated_best",
        "exploration_score_reserve": 1, "llm_involved": False}
    if version == VERSION:
        expected_parameters["epsilon_draw"] = "exact_decimal_rational_randrange"
    require(state_hash(provenance.get("selection_search")) == state_hash(expected_parameters)
            and state_hash({key: search.get(key) for key in expected_parameters}) == state_hash(expected_parameters),
            "Search parameters differ from run policy provenance")
    require(provenance.get("llm_involved") is False, "Selection search requires a non-LLM scorer")
    epsilon = exploration.get("epsilon")
    require(type(epsilon) in (int, float) and math.isfinite(epsilon) and 0 <= epsilon <= 1
            and provenance.get("epsilon") == epsilon, "Inconsistent exploration epsilon")
    require(type(exploration.get("explored")) is bool, "Exploration branch is not explicit")
    explored = exploration["explored"]
    require(not (epsilon == 0 and explored) and not (epsilon == 1 and not explored),
            "Impossible exploration branch")
    reserve = int(epsilon > 0 and count > 1)
    core_budget = budget - reserve
    require(search.get("evaluation_budget") == budget and search.get("search_evaluation_budget") == core_budget,
            "Search does not reserve the required exploration score budget")
    rows = scoring.get("scores")
    require(isinstance(rows, list) and 0 < len(rows) <= budget, "Invalid evaluated candidate count")
    for container, fields in ((scoring, ("candidate_count", "evaluated_candidate_count")),
            (search, ("evaluation_budget", "search_evaluation_budget", "search_evaluations", "evaluations",
                      "proposal_budget", "duplicate_proposals", "exploration_score_evaluations")),
            (exploration, ("candidate_count", "evaluated_candidate_count", "greedy_tie_count", "choice_count", "chosen_rank"))):
        for field in fields:
            integer(container.get(field))
    require(scoring.get("evaluated_candidate_count") == len(rows) and search.get("evaluations") == len(rows)
            and exploration.get("evaluated_candidate_count") == len(rows), "Evaluation counts disagree")
    by_rank, ids, search_rows, extra_rows = {}, set(), [], []
    for row in rows:
        require(isinstance(row, dict), "Malformed score row")
        candidate = materialize_candidate(candidate_set, row.get("request", {}))
        rank = rank_selection(descriptor, indices_from_request(descriptor, row["request"]))
        require(row.get("candidate_id") == candidate["candidate_id"] and type(row.get("is_skip")) is bool
                and row["is_skip"] == candidate["is_skip"]
                and type(row.get("selection_rank")) is int and row["selection_rank"] == rank,
                "Score identity/rank does not match its complete legal request")
        require(rank not in by_rank and row["candidate_id"] not in ids, "Duplicate evaluated selection")
        require(type(row.get("score")) in (int, float) and math.isfinite(row["score"]), "Nonfinite selection score")
        proposal = row.get("selection_proposal")
        require(isinstance(proposal, dict) and set(proposal) == {"operation", "parent_rank"}, "Missing proposal source")
        (extra_rows if proposal["operation"] == "uniform_exploration" else search_rows).append(row)
        by_rank[rank] = row
        ids.add(row["candidate_id"])
    require(0 < len(search_rows) <= core_budget and len(extra_rows) <= reserve
            and search.get("search_evaluations") == len(search_rows)
            and search.get("exploration_score_evaluations") == len(extra_rows), "Core/exploration score counts disagree")
    best = max(row["score"] for row in search_rows)
    ties = sorted(row["selection_rank"] for row in search_rows if abs(row["score"] - best) <= TIE_TOLERANCE)
    require(isinstance(search.get("frozen_greedy_ranks"), list)
            and all(type(rank) is int for rank in search["frozen_greedy_ranks"]), "Invalid frozen tie ranks")
    require(search.get("frozen_greedy_ranks") == ties and search.get("frozen_greedy_candidate_ids")
            == [by_rank[rank]["candidate_id"] for rank in ties], "Frozen exploit ties do not match pre-exploration scores")
    proposals = search.get("proposals")
    require(isinstance(proposals, list) and 0 < len(proposals) <= budget * PROPOSALS_PER_EVALUATION
            and search.get("proposal_budget") == budget * PROPOSALS_PER_EVALUATION, "Invalid proposal budget")
    seen, duplicates = set(), 0
    for proposal in proposals:
        require(isinstance(proposal, dict) and set(proposal) == {"rank", "operation", "parent_rank", "status"},
                "Malformed search proposal")
        rank = integer(proposal["rank"])
        require(rank < count, "Proposal rank is not a legal complete selection")
        duplicate = proposal["status"] == "already_evaluated"
        require((duplicate and rank in seen) or (proposal["status"] == "scored" and rank not in seen and rank in by_rank),
                "Search proposal does not match a unique score")
        row = by_rank[rank]
        require(row in search_rows and (duplicate or row["selection_proposal"]
                == {"operation": proposal["operation"], "parent_rank": proposal["parent_rank"]}),
                "Score has inconsistent proposal lineage")
        indices = tuple(indices_from_request(descriptor, row["request"]))
        operation, parent = proposal["operation"], proposal["parent_rank"]
        if operation == "seed_length":
            require(parent is None and indices == tuple(descriptor["indices"][:len(indices)]), "Invalid seed proposal")
        elif operation == "seed_reverse":
            require(parent is None and len(indices) in {descriptor["min_select"], descriptor["effective_max_select"]}
                    and indices == tuple(reversed(descriptor["indices"][:len(indices)])), "Invalid reverse seed")
        else:
            require(type(parent) is int and parent in seen, "Local proposal has no previously evaluated parent")
            parent_indices = tuple(indices_from_request(descriptor, by_rank[parent]["request"]))
            # At most O(n*k + k*k), never materializes the complete action space.
            require(any(indices == neighbor and operation == op for neighbor, op in SelectionPolicy._neighbors(
                parent_indices, descriptor["indices"], descriptor["min_select"], descriptor["effective_max_select"])),
                "Claimed local proposal does not follow from its parent")
        if duplicate:
            duplicates += 1
        else:
            seen.add(rank)
    require(seen == {row["selection_rank"] for row in search_rows}
            and duplicates == search.get("duplicate_proposals"), "Proposal audit omits scored selections")
    reason = search.get("stop_reason")
    require(reason in {"evaluation_budget", "proposal_budget", "frontier_exhausted"}, "Unknown search stop reason")
    require(reason != "evaluation_budget" or len(search_rows) == core_budget, "False evaluation-budget termination")
    require(reason != "proposal_budget" or len(proposals) == budget * PROPOSALS_PER_EVALUATION,
            "False proposal-budget termination")
    # This search never prunes frontier nodes. Every fixed-length permutation
    # graph is connected by replace/swap, and every length has a seed. Therefore
    # a genuinely exhausted frontier has visited the entire finite space.
    require(reason != "frontier_exhausted" or len(search_rows) == count,
            "Frontier exhaustion claimed without evaluating the entire space")
    chosen = materialize_candidate(candidate_set, picked.get("request", {}))
    rank = rank_selection(descriptor, indices_from_request(descriptor, chosen["request"]))
    require(rank in by_rank and picked.get("candidate_id") == chosen["candidate_id"], "Chosen request was not evaluated")
    require(exploration.get("chosen_rank") == rank and exploration.get("candidate_count") == count
            and exploration.get("greedy_tie_count") == len(ties), "Chosen distribution metadata is inconsistent")
    require(explored or rank in ties, "Exploitation chose outside frozen best ties")
    require(search.get("exploration_rank") == (rank if explored else None), "Exploration rank is inconsistent")
    require(search.get("exploration_rank") is None or type(search["exploration_rank"]) is int,
            "Invalid exploration rank type")
    require(not extra_rows or (explored and extra_rows[0]["selection_rank"] == rank
            and extra_rows[0]["selection_proposal"]["parent_rank"] is None), "Extra score is not the actual exploration draw")
    eps = Fraction(str(epsilon))
    probability = eps / count + ((1 - eps) / len(ties) if rank in ties else 0)
    rational = exploration.get("chosen_probability_rational")
    require(isinstance(rational, dict) and set(rational) == {"numerator", "denominator"}, "Missing exact rational probability")
    integer(rational["numerator"])
    integer(rational["denominator"], 1)
    require(type(exploration.get("chosen_probability")) in (int, float)
            and rational == {"numerator": probability.numerator,
            "denominator": probability.denominator} and exploration.get("chosen_probability") == float(probability),
            "Logged selection probability does not match its exact mixture")
    require(exploration.get("probability_semantics") == "epsilon_uniform_full_space_plus_uniform_frozen_search_best_ties"
            and exploration.get("exploration_component_probability") == float(eps / count), "Wrong probability semantics")
    precision = "exact_decimal_rational" if version == VERSION else "nominal_float_threshold"
    require(exploration.get("probability_precision") == precision if version == VERSION else
            exploration.get("probability_precision") in {None, precision}, "Wrong probability precision claim")
    require(integer(provenance.get("choice_count")) == exploration.get("choice_count")
            and provenance.get("random_seed") == exploration.get("random_seed"), "Global RNG position is inconsistent")
    return {"valid": True, "selection_search_version": version, "probability_precision": precision}
