"""Windows publication races must not corrupt state or repeat game actions."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from run_metadata import atomic_json


class AtomicPublicationTests(unittest.TestCase):
    def test_transient_sharing_violation_keeps_old_file_until_atomic_success(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "state.json"
            target.write_text('{"old": true}', encoding="utf-8")
            original = Path.replace
            attempts = []

            def replace(source, destination):
                attempts.append(json.loads(target.read_text(encoding="utf-8")))
                if len(attempts) <= 2:
                    raise PermissionError("simulated Windows sharing violation")
                return original(source, destination)

            with patch.object(Path, "replace", autospec=True, side_effect=replace), patch("time.sleep"):
                atomic_json(target, {"new": True})
            self.assertEqual(attempts, [{"old": True}] * 3)
            self.assertEqual(json.loads(target.read_text(encoding="utf-8")), {"new": True})
            self.assertEqual(list(Path(folder).glob("*.tmp")), [])

    def test_persistent_publication_failure_is_bounded_and_preserves_previous_state(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "state.json"
            target.write_text('{"old": true}', encoding="utf-8")
            with patch.object(Path, "replace", side_effect=PermissionError("denied")) as replace, patch("time.sleep"):
                with self.assertRaises(PermissionError):
                    atomic_json(target, {"new": True})
                self.assertEqual(replace.call_count, 40)
            self.assertEqual(json.loads(target.read_text(encoding="utf-8")), {"old": True})
            self.assertEqual(list(Path(folder).glob("*.tmp")), [])


if __name__ == "__main__":
    unittest.main()
