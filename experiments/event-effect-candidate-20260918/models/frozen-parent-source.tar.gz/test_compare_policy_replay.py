"""Production comparison; temporary synthetic files, no game process."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from decision_data import state_hash
import test_compare_policy_batches as batch_fixtures
from test_replay_evidence import knowledge_fixture

import compare_policy_batches as staged


def read_lines(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def write_lines(path, rows):
    path.write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")


class StagedPolicyReplayTests(unittest.TestCase):
    def setUp(self):
        self.production = ROOT / "compare_policy_batches.py"
        self.frozen_hash = hashlib.sha256(self.production.read_bytes()).hexdigest()
        self.fixture = batch_fixtures.ComparePolicyBatchTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.fixture.declare()
        self.left, self.right = self.fixture.batches()
        self.install_knowledge("b-0")

    def tearDown(self):
        self.assertEqual(hashlib.sha256(self.production.read_bytes()).hexdigest(), self.frozen_hash)

    def install_knowledge(self, run_id, *, stop_at_query=False):
        directory = self.fixture.root / run_id
        trace = read_lines(directory / "trace.jsonl")
        journal = read_lines(directory / "decisions.jsonl")
        completed = next(r for r in journal if r["record_type"] == "decision_completed")
        calls, segment = knowledge_fixture()
        context = trace[1]["response"]["context"]
        for row in segment:
            if row["response"].get("type") == "decision":
                row["response"]["context"].update(context)
        trace[1]["response"] = segment[0]["response"]
        call = copy.deepcopy(completed["solver_calls"][0])
        call["response"]["actions"] = calls[0]["response"]["actions"]
        replay = calls[0]["replay"]
        trace = [*trace[:2], copy.deepcopy(call), *segment[2:]] + ([] if stop_at_query else [trace[-1]])
        if stop_at_query:
            trace.pop()  # pending metadata returned, then Python stopped before select_cards.
            pending = trace[-2]["response"]
            completed["next_state"] = pending
            completed["next_state_hash"] = state_hash(pending)
            finished = next(r for r in journal if r["record_type"] == "run_finished")
            finished["final_state"] = pending
            if "final_state_hash" in finished:
                finished["final_state_hash"] = state_hash(pending)
            (directory / "state.json").write_text(json.dumps(pending), encoding="utf-8")
        else:
            call["replay"] = replay
        completed["solver_calls"] = [call]
        write_lines(directory / "trace.jsonl", trace)
        write_lines(directory / "decisions.jsonl", journal)

    def compare(self):
        return staged.compare_policy_batches(self.left, self.right, protocol=self.fixture.protocol)

    def mutate_proof(self, mutation):
        path = self.fixture.root / "b-0" / "decisions.jsonl"
        rows = read_lines(path)
        call = next(r for r in rows if r["record_type"] == "decision_completed")["solver_calls"][0]
        mutation(call)
        write_lines(path, rows)

    def assert_rejected_with_full_denominator(self, result):
        self.assertFalse(result["comparable"])
        self.assertIsNone(result["paired"])
        self.assertTrue(any("Solver replay evidence" in e for e in result["errors"]), result["errors"])
        self.assertEqual(result["left"]["summary"]["runs_in_denominator"], 2)
        self.assertEqual(result["right"]["summary"]["runs_in_denominator"], 2)
        self.assertEqual(len(result["per_seed"]), 2)
        bad = next(r for r in result["right"]["runs"] if r["run_id"] == "b-0")
        self.assertFalse(bad["replay_verification"]["verified"])
        self.assertEqual(bad["replay_original_category"], "defeat")

    def test_bound_replay_accepted_without_external_audit_file(self):
        result = self.compare()
        self.assertTrue(result["comparable"], result["errors"])
        run = next(r for r in result["right"]["runs"] if r["run_id"] == "b-0")
        self.assertEqual(run["replay_verification"]["replay_count"], 1)
        self.assertFalse(list(self.fixture.root.rglob("DATA_AUDIT*.json")))

    def test_unknown_and_missing_replay_rejected(self):
        self.mutate_proof(lambda c: c["replay"][0].update(kind="unknown_kind"))
        self.assert_rejected_with_full_denominator(self.compare())
        self.mutate_proof(lambda c: c.pop("replay"))
        self.assert_rejected_with_full_denominator(self.compare())

    def test_tampered_source_indices_and_plan_rejected(self):
        path = self.fixture.root / "b-0" / "decisions.jsonl"
        original = path.read_bytes()
        mutations = [lambda c: c["replay"][0]["actual_choice_metadata"]["knowledge_choice"].update(source_id="wrong"),
            lambda c: c["replay"][0].update(selected_indices=[0]),
            lambda c: c["replay"][0]["plan"].update(SourceId="KNOWLEDGE_DEMON:7:2")]
        for mutation in mutations:
            path.write_bytes(original)
            self.mutate_proof(mutation)
            self.assert_rejected_with_full_denominator(self.compare())

    def test_timeout_at_pending_query_has_no_fabricated_successful_replay(self):
        self.install_knowledge("a-1", stop_at_query=True)
        result = self.compare()
        self.assertTrue(result["comparable"], result["errors"])
        run = next(r for r in result["left"]["runs"] if r["run_id"] == "a-1")
        self.assertEqual(run["category"], "timeout")
        self.assertEqual(run["replay_verification"]["replay_count"], 0)
        self.assertEqual(result["left"]["summary"]["runs_in_denominator"], 2)
        self.assertEqual(result["left"]["summary"]["timeouts"], 1)


if __name__ == "__main__":
    unittest.main()
