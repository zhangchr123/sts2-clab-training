"""Exact legality, coverage, probability, and tampering checks; no game actions."""
import copy
from fractions import Fraction
import math
import random
import unittest

from decision_data import DataContractError, enumerate_candidates, materialize_candidate, state_hash
from initial_policy import InitialPolicy
from selection_policy import SelectionPolicy, validate_selection_evidence
from selection_space import indices_from_request, space_size, unrank_selection


def selection_state(n=15, minimum=0, maximum=15):
    return {"type": "decision", "decision": "card_select", "min_select": minimum, "max_select": maximum,
            "context": {"combat_in_progress": False, "room_type": "Event"},
            "cards": [{"index": index, "id": "CARD.STRIKE_DEFECT", "cost": 1,
                       "stats": {"damage": index + 1}, "upgraded": False} for index in range(n)],
            "player": {"hp": 40, "max_hp": 75, "gold": 99, "deck": []}}


class CountingPolicy:
    def __init__(self, score=lambda values: 0.0, epsilon=.2, seed=123):
        self.epsilon, self.seed = epsilon, seed
        self.rng, self.choice_count = random.Random(seed), 0
        self.value, self.requests = score, []

    @property
    def provenance(self):
        return {"origin": "natural", "kind": "rules", "id": "test", "version": "1",
                "llm_involved": False, "random_seed": self.seed, "epsilon": self.epsilon}

    def score_requests(self, state, requests, *, selection_purpose=None):
        candidate_set = enumerate_candidates(state)
        rows = []
        for request in requests:
            candidate = materialize_candidate(candidate_set, request)
            values = candidate["evidence"]["indices"]
            self.requests.append(copy.deepcopy(request))
            rows.append({**candidate, "score": self.value(values), "features": {"selected_count": len(values)}})
        return {"state_hash": state_hash(state), "scores": rows, "policy_id": "test", "policy_version": "1",
                "selection_purpose": selection_purpose, "candidate_space_representation": candidate_set["representation"]}


class FixedDraw:
    def __init__(self, rank, coin=0.0, tie_position=-1):
        self.rank, self.coin, self.tie_position = rank, coin, tie_position
        self.range_arguments = []

    def random(self):
        raise AssertionError("v2 must draw its Bernoulli from an exact rational range")

    def randrange(self, stop):
        self.range_arguments.append(stop)
        if len(self.range_arguments) == 1:
            return min(stop - 1, int(self.coin * stop))  # Exact rational Bernoulli draw.
        if not 0 <= self.rank < stop:
            raise AssertionError("Test rank is outside the sampling space")
        return self.rank

    def choice(self, values):
        return values[self.tie_position]


class SelectionPolicyTests(unittest.TestCase):
    def test_large_space_is_bounded_complete_actions_only(self):
        state = selection_state()
        base = CountingPolicy(lambda values: float(len(values)), epsilon=0)
        policy = SelectionPolicy(base, max_evaluations=40)
        picked = policy.choose(state)
        scoring = picked["scoring"]
        self.assertEqual(scoring["candidate_count"], 3554627472076)
        self.assertIs(scoring["evaluated_candidates_complete"], False)
        self.assertEqual(len(base.requests), 40)
        self.assertEqual(len({state_hash(r) for r in base.requests}), 40)
        self.assertEqual(scoring["evaluated_candidate_count"], 40)
        self.assertTrue(any(r["args"]["indices"] == "" for r in base.requests))
        self.assertTrue(validate_selection_evidence(state, enumerate_candidates(state), picked))

    def test_minimum_above_one_never_scores_partial_prefixes(self):
        state = selection_state(minimum=3, maximum=8)
        base = CountingPolicy(lambda values: sum(values), epsilon=0)
        picked = SelectionPolicy(base, 45).choose(state)
        self.assertTrue(all(3 <= len(r["args"]["indices"].split(",")) <= 8 for r in base.requests))
        self.assertTrue(validate_selection_evidence(state, enumerate_candidates(state), picked))

    def test_order_changes_are_real_distinct_candidates(self):
        state = selection_state(n=5, minimum=2, maximum=2)
        implicit = enumerate_candidates(state, max_candidates=1)
        base = CountingPolicy(lambda values: 10 * values[0] + values[-1], epsilon=0)
        picked = SelectionPolicy(base, 20).choose(state, implicit)
        requests = [r["args"]["indices"] for r in base.requests]
        self.assertIn("0,1", requests)
        self.assertIn("1,0", requests)
        self.assertEqual(picked["request"]["args"]["indices"], "4,3")
        self.assertTrue(validate_selection_evidence(state, implicit, picked))

    def test_exploration_uniform_rank_reaches_unvisited_entire_space(self):
        state = selection_state()
        candidates = enumerate_candidates(state)
        count = space_size(candidates["selection_space"])
        base = CountingPolicy(lambda values: 10000.0 if values and values[0] == 14 else 0.0, epsilon=.25)
        base.rng = FixedDraw(count - 1)
        picked = SelectionPolicy(base, 3).choose(state)
        self.assertEqual(base.rng.range_arguments, [4, count])
        self.assertEqual(picked["request"]["args"]["indices"], ",".join(map(str, reversed(range(15)))))
        self.assertEqual(len(base.requests), 3)
        self.assertNotIn(count - 1, picked["scoring"]["selection_search"]["frozen_greedy_ranks"])
        probability = Fraction(1, 4 * count)
        self.assertEqual(picked["exploration"]["chosen_probability_rational"],
                         {"numerator": probability.numerator, "denominator": probability.denominator})
        self.assertTrue(validate_selection_evidence(state, candidates, picked))

    def test_uniform_exploration_every_small_space_rank_with_exact_mass(self):
        state = selection_state(n=3, maximum=3)
        candidates = enumerate_candidates(state, max_candidates=1)
        count = candidates["candidate_count"]
        observed = set()
        for rank in range(count):
            base = CountingPolicy(epsilon=1)
            base.rng = FixedDraw(rank)
            picked = SelectionPolicy(base, 2).choose(state, candidates)
            values = indices_from_request(candidates["selection_space"], picked["request"])
            self.assertEqual(values, unrank_selection(candidates["selection_space"], rank))
            observed.add(tuple(values))
            self.assertEqual(picked["exploration"]["chosen_probability_rational"], {"numerator": 1, "denominator": count})
            self.assertLessEqual(len(base.requests), 2)
            self.assertTrue(validate_selection_evidence(state, candidates, picked))
        self.assertEqual(len(observed), count)

    def test_exploit_ties_uniform_and_probability_includes_exploration(self):
        state = selection_state()
        base = CountingPolicy(epsilon=.25)
        base.rng = FixedDraw(0, coin=.9)
        picked = SelectionPolicy(base, 4).choose(state)
        self.assertFalse(picked["exploration"]["explored"])
        self.assertEqual(picked["exploration"]["greedy_tie_count"], 3)
        self.assertEqual(picked["exploration"]["chosen_rank"], 16)  # Final frozen tie, rather than always rank zero.
        probability = Fraction(1, 4 * picked["scoring"]["candidate_count"]) + Fraction(1, 4)
        self.assertEqual(picked["exploration"]["chosen_probability_rational"],
                         {"numerator": probability.numerator, "denominator": probability.denominator})
        self.assertTrue(validate_selection_evidence(state, enumerate_candidates(state), picked))

    def test_score_is_deterministic_and_never_consumes_rng_or_choice_count(self):
        state = selection_state()
        base = CountingPolicy(lambda values: sum(values))
        base.choice_count = 8
        policy = SelectionPolicy(base, 20)
        before = base.rng.getstate()
        first = policy.score(state)
        second = policy.score(state)
        self.assertEqual(first, second)
        self.assertEqual(base.rng.getstate(), before)
        self.assertEqual(base.choice_count, 8)
        self.assertNotIn("request", first)
        self.assertEqual(first["selection_search"]["evaluations"], 20)

    def test_skip_deltas_recomputed_after_search_and_exploration(self):
        state = selection_state()
        base = CountingPolicy(lambda values: len(values) + 2.0, epsilon=1)
        count = enumerate_candidates(state)["candidate_count"]
        base.rng = FixedDraw(count - 1)
        picked = SelectionPolicy(base, 4).choose(state)
        for row in picked["scoring"]["scores"]:
            self.assertEqual(row["delta_from_skip"], row["score"] - 2)

    def test_explicit_delegation_preserves_global_counter_and_run_identity(self):
        base = InitialPolicy(prior_path=None, epsilon=.1, random_seed="counter")
        policy = SelectionPolicy(base, 16)
        implicit = selection_state()
        explicit = selection_state(n=0, maximum=0)
        first = policy.choose(explicit)
        second = policy.choose(implicit)
        third = policy.choose(explicit)
        self.assertEqual([r["policy_provenance"]["choice_count"] for r in (first, second, third)], [0, 1, 2])
        self.assertEqual(base.choice_count, 3)
        self.assertEqual(first["request"]["args"]["indices"], "")
        for result in (first, second, third):
            identity = {k: v for k, v in result["policy_provenance"].items() if k != "choice_count"}
            self.assertEqual(identity, policy.provenance)

    def test_real_base_subset_scores_keep_feature_contract(self):
        state = selection_state(n=4, minimum=2, maximum=3)
        implicit = enumerate_candidates(state, max_candidates=1)
        policy = SelectionPolicy(InitialPolicy(prior_path=None, epsilon=0), 20)
        picked = policy.choose(state, implicit, selection_purpose="remove")
        self.assertEqual(picked["scoring"]["candidate_space_representation"], "ordered_selection_implicit_v1")
        self.assertEqual(picked["scoring"]["policy_version"], policy.base.score_requests(
            state, [picked["request"]], selection_purpose="remove")["policy_version"])
        self.assertTrue(validate_selection_evidence(state, implicit, picked))

    def test_invalid_budgets_and_nonfinite_scores_rejected(self):
        for budget in (True, 0, 1, -1, 4097, 2.5):
            with self.subTest(budget=budget), self.assertRaises(DataContractError):
                SelectionPolicy(CountingPolicy(), budget)
        with self.assertRaises(DataContractError):
            SelectionPolicy(CountingPolicy(lambda values: math.nan)).choose(selection_state())

    def test_stale_or_extra_descriptor_envelope_rejected(self):
        state = selection_state()
        candidates = enumerate_candidates(state)
        candidates["unexpected"] = True
        with self.assertRaises(DataContractError):
            SelectionPolicy(CountingPolicy()).choose(state, candidates)
        candidates = enumerate_candidates(state)
        state["player"]["hp"] = 39
        with self.assertRaises(DataContractError):
            SelectionPolicy(CountingPolicy()).choose(state, candidates)

    def test_auditor_rejects_tampering_without_rescoring(self):
        state = selection_state()
        candidates = enumerate_candidates(state)
        base = CountingPolicy(epsilon=.5)
        base.rng = FixedDraw(candidates["candidate_count"] - 1)
        picked = SelectionPolicy(base, 8).choose(state)
        mutations = [
            lambda p: p["scoring"].update(evaluated_candidates_complete=True),
            lambda p: p["scoring"].update(candidate_count=99),
            lambda p: p["scoring"]["scores"].append(copy.deepcopy(p["scoring"]["scores"][0])),
            lambda p: p["scoring"]["scores"][0].update(selection_rank=99),
            lambda p: p["scoring"]["scores"][0].update(score=math.inf),
            lambda p: p["scoring"]["selection_search"].update(frozen_greedy_ranks=[999]),
            lambda p: p["scoring"]["selection_search"].update(evaluations=100),
            lambda p: p["scoring"]["selection_search"].update(search_evaluation_budget=8),
            lambda p: p["scoring"]["selection_search"].update(stop_reason="frontier_exhausted"),
            lambda p: p["scoring"]["selection_search"]["proposals"][0].update(status="already_evaluated"),
            lambda p: p["exploration"].update(chosen_probability=1.0),
            lambda p: p["exploration"]["chosen_probability_rational"].update(numerator=True),
            lambda p: p["exploration"].update(explored=False),
            lambda p: p["policy_provenance"].update(choice_count=99),
            lambda p: p["request"]["args"].update(indices="0,0"),
            lambda p: p.update(candidate_id="unscored"),
        ]
        before = len(base.requests)
        self.assertTrue(validate_selection_evidence(state, candidates, picked))
        for mutate in mutations:
            tampered = copy.deepcopy(picked)
            mutate(tampered)
            with self.subTest(mutation=mutate), self.assertRaises(DataContractError):
                validate_selection_evidence(state, candidates, tampered)
        self.assertEqual(len(base.requests), before)

    def test_frontier_exhaustion_and_duplicate_lineage_are_audited(self):
        state = selection_state(n=3, maximum=3)
        candidates = enumerate_candidates(state, max_candidates=1)
        picked = SelectionPolicy(CountingPolicy(epsilon=0), 40).choose(state, candidates)
        search = picked["scoring"]["selection_search"]
        self.assertEqual(search["stop_reason"], "frontier_exhausted")
        self.assertEqual(search["evaluations"], candidates["candidate_count"])
        self.assertIs(picked["scoring"]["evaluated_candidates_complete"], False)
        self.assertTrue(validate_selection_evidence(state, candidates, picked))
        tampered = copy.deepcopy(picked)
        duplicate = next(p for p in tampered["scoring"]["selection_search"]["proposals"]
                         if p["status"] == "already_evaluated")
        duplicate["operation"] = "invented"
        duplicate["parent_rank"] = 999
        with self.assertRaises(DataContractError):
            validate_selection_evidence(state, candidates, tampered)

    def test_duplicate_proposals_cannot_escape_cpu_budget(self):
        state = selection_state(n=60, minimum=1, maximum=1)
        candidates = enumerate_candidates(state, max_candidates=1)
        base = CountingPolicy(epsilon=0)
        picked = SelectionPolicy(base, 64).choose(state, candidates)
        search = picked["scoring"]["selection_search"]
        self.assertEqual(search["stop_reason"], "proposal_budget")
        self.assertEqual(len(search["proposals"]), 64 * 32)
        self.assertEqual(len(base.requests), 60)
        self.assertTrue(validate_selection_evidence(state, candidates, picked))

    def test_v2_decimal_epsilon_is_exact_and_v1_remains_readable_as_nominal(self):
        state = selection_state()
        candidates = enumerate_candidates(state)
        base = CountingPolicy(epsilon=.1)
        base.rng = FixedDraw(0)
        picked = SelectionPolicy(base, 4).choose(state)
        self.assertEqual(base.rng.range_arguments, [10, candidates["candidate_count"]])
        self.assertEqual(validate_selection_evidence(state, candidates, picked)["probability_precision"],
                         "exact_decimal_rational")
        legacy = copy.deepcopy(picked)
        for parameters in (legacy["scoring"]["selection_search"], legacy["policy_provenance"]["selection_search"]):
            parameters["version"] = "bounded-ordered-selection-v1"
            parameters.pop("epsilon_draw")
        legacy["exploration"].pop("probability_precision")
        self.assertEqual(validate_selection_evidence(state, candidates, legacy)["probability_precision"],
                         "nominal_float_threshold")
        legacy["exploration"]["probability_precision"] = "exact_decimal_rational"
        with self.assertRaises(DataContractError):
            validate_selection_evidence(state, candidates, legacy)


if __name__ == "__main__":
    unittest.main()
