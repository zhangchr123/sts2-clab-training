"""Synthetic protocol tests; no gameplay outcomes or natural training samples."""
import copy
import unittest
from combat_executor import CombatExecutor, DEFAULT_CONFIG
from replay_evidence import validate_replay_evidence
from test_combat_executor import FakeEngine, solved, state


class TargetReplanTests(unittest.TestCase):
    def fixture(self):
        action = {"Kind": "PlayCard", "Turn": 1, "CardStateKey": "ball", "CardStateOccurrence": 0,
            "TargetIndex": 1, "TargetCombatId": 4}
        meta = {"type": "combat_meta", "hand": [{"key": "ball", "index": 0}],
            "enemies": [{"index": 0, "combat_id": 3}, {"index": 1, "combat_id": 5}]}
        return action, meta

    def test_absent_target_replans_without_submitting_stale_action_and_audits(self):
        action, meta = self.fixture()
        reward = state("card_reward", active=False)
        engine = FakeEngine([solved([action]), meta, solved([{"Kind": "EndTurn", "Turn": 1}]), reward])
        traces = [{"request": {"cmd": "start_run"}, "response": state()}]
        def send(**request):
            response = engine(**request)
            traces.append({"request": request, "response": copy.deepcopy(response)})
            return response
        executor = CombatExecutor(send)
        self.assertEqual(executor.advance(state()), reward)
        self.assertEqual([r.get("action") for r in engine.requests if r["cmd"] == "action"], ["end_turn"])
        self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)["verified"])
        for change in ("omit", "target", "state"):
            calls = copy.deepcopy(executor.solve_calls)
            if change == "omit": del calls[0]["plan_invalidation"]
            elif change == "target": calls[0]["plan_invalidation"]["action"]["TargetCombatId"] = 5
            else: calls[0]["plan_invalidation"]["state"]["player_turn"] = 9
            with self.assertRaises(ValueError): validate_replay_evidence(calls, traces)

    def test_persistently_absent_target_respects_replan_bound(self):
        action, meta = self.fixture()
        engine = FakeEngine([solved([action]), meta] * 2)
        executor = CombatExecutor(engine, {**DEFAULT_CONFIG, "max_replans": 2})
        with self.assertRaisesRegex(RuntimeError, "Too many combat replans"):
            executor.advance(state())
        self.assertEqual(len(executor.solve_calls), 2)
        self.assertFalse(any(r["cmd"] == "action" for r in engine.requests))

    def test_duplicate_and_invalid_actual_identity_never_retargets(self):
        action, baseline = self.fixture()
        for enemies in ([{"index": 0, "combat_id": 4}, {"index": 1, "combat_id": 4}],
                        [{"index": 0, "combat_id": True}], [{"index": 0}],
                        [{"index": 0, "combat_id": 3}, {"index": 0, "combat_id": 5}]):
            engine = FakeEngine([solved([action]), {**baseline, "enemies": enemies}])
            with self.assertRaisesRegex(RuntimeError, "Invalid or duplicate"):
                CombatExecutor(engine).advance(state())
            self.assertFalse(any(r["cmd"] == "action" for r in engine.requests))

    def test_invalid_metadata_error_remains_auditable_without_success_proof(self):
        action, meta = self.fixture()
        meta['enemies'] = [{'index': 0, 'combat_id': True}]
        engine = FakeEngine([solved([action]), meta])
        traces = [{'request': {'cmd': 'start_run'}, 'response': state()}]
        def send(**request):
            response = engine(**request)
            traces.append({'request': request, 'response': copy.deepcopy(response)})
            return response
        executor = CombatExecutor(send)
        with self.assertRaises(RuntimeError): executor.advance(state())
        self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
        executor.solve_calls[0]['plan_invalidation'] = {'invented': True}
        with self.assertRaises(ValueError): validate_replay_evidence(executor.solve_calls, traces)


if __name__ == "__main__": unittest.main()
