"""Optimizer and initialization tests only; mocked games are never rollout data."""
import copy
import json
from pathlib import Path
import random
import sys
import tempfile
import unittest
from unittest.mock import patch

STAGE = Path(__file__).resolve().parent
sys.path.insert(0, str(STAGE.parents[2]))
sys.path.insert(0, str(STAGE))
import train_contextual_run as trainer
import contextual_policy as v2
import whole_run_policy as v1
from run_metadata import file_evidence


class ContextualTrainingTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(); self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.config = json.loads((v1.ROOT / 'configs/defect-v3-base.json').read_text())
        self.old = {name: (i - 9) / 10 for i, name in enumerate(v1.PARAMETERS)}
        self.extended = {name: self.old.get(name, 0.) for name in v2.PARAMETERS}
        self.parent = self.root / 'parent.json'
        self.parent.write_text(json.dumps({'training_seeds': [['ancestor-train']],
            'reserved_evaluation_seeds': ['ancestor-test'], 'ancestor_seeds': ['grandparent-test']}))
        self.model = self.root / 'old-model.json'
        self.model.write_text(json.dumps(v1.make_artifact(self.old, self.config,
            training={'protocol': file_evidence(self.parent), 'synthetic_test_only': True})))

    def prepare(self, **kwargs):
        path = self.root / 'new' / 'protocol.json'
        doc = trainer.prepare(path, name='context-synthetic', generations=2, seeds_per_generation=2,
                              initial_model=self.model, **kwargs)
        return path, doc

    def test_legacy_zero_extension_is_explicit_and_all_ancestors_are_excluded(self):
        _, doc = self.prepare()
        center, std = trainer.initial_distribution(doc)
        self.assertEqual(center, self.extended)
        self.assertEqual(len(center), 51)
        self.assertIn('19_parameter_model_zero_extended_to_51', doc['initialization'])
        self.assertEqual(set(doc['ancestor_seeds']), {'ancestor-train', 'ancestor-test', 'grandparent-test'})
        self.assertEqual(std, dict.fromkeys(v2.PARAMETERS, 1.5))
        self.assertIn(file_evidence(self.model), doc['frozen_sources'])
        for name in trainer.STAGED_SOURCES:
            self.assertIn(file_evidence(STAGE / name), doc['frozen_sources'])
        self.assertEqual(doc['planned_training_games'], 68)
        self.assertEqual(doc['method']['population'], 17)
        self.assertEqual(doc['method']['elites'], 5)

    def test_lineage_center_method_and_source_tampering_cannot_start_games(self):
        path, doc = self.prepare()
        for kind in ('center', 'lineage', 'train', 'test', 'initialization'):
            bad = copy.deepcopy(doc)
            if kind == 'center': bad['initial_center'][v2.PARAMETERS[-1]] = 1.
            if kind == 'lineage': bad['ancestor_seeds'] = []
            if kind == 'train': bad['training_seeds'][0][0] = 'grandparent-test'
            if kind == 'test': bad['reserved_evaluation_seeds'][0] = 'ancestor-train'
            if kind == 'initialization': bad['initialization'] = 'fitted_51_parameters'
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                trainer.initial_distribution(bad)
        bad = copy.deepcopy(doc); bad['method']['population'] = 9
        path.write_text(json.dumps(bad))
        with patch.object(trainer, 'run_one') as run, self.assertRaises(ValueError):
            trainer.run(path)
        run.assert_not_called()
        path.write_text(json.dumps(doc))
        self.model.write_text('{}')
        with patch.object(trainer, 'run_one') as run, self.assertRaises(ValueError):
            trainer.run(path)
        run.assert_not_called()
        self.assertFalse((path.parent / 'execution-started.json').exists())

    def test_population_51_dimensions_antithetic_and_goal_first_elites(self):
        center = dict.fromkeys(v2.PARAMETERS, 0.)
        std = dict.fromkeys(v2.PARAMETERS, 1.5)
        vectors = trainer.population(center, std, random.Random('synthetic'))
        self.assertEqual(len(vectors), 17)
        for i in range(1, 17, 2):
            self.assertEqual(set(vectors[i]), set(v2.PARAMETERS))
            for name in v2.PARAMETERS:
                self.assertEqual(vectors[i][name], -vectors[i + 1][name])
                self.assertLessEqual(abs(vectors[i][name]), 4.)
        scores = [{'goal_successes': int(i == 16), 'mean_fitness': -i / 10} for i in range(17)]
        updated, deviation, elites = trainer.update_distribution(vectors, scores, center, std)
        self.assertEqual(elites, [16, 0, 1, 2, 3])
        for name in v2.PARAMETERS:
            self.assertEqual(updated[name], .5 * sum(vectors[i][name] for i in elites) / 5)
            self.assertGreaterEqual(deviation[name], .15)
        with self.assertRaises(ValueError):
            trainer.update_distribution(vectors, scores[:-1], center, std)

    def test_fresh_generations_execute_complete_17_candidate_allocations(self):
        path, _ = self.prepare()
        def fake_run(label, seed, **kwargs):
            artifact = json.loads(kwargs['model_path'].read_text())
            self.assertEqual(artifact['format'], v2.VERSION)
            self.assertEqual(set(artifact['parameters']), set(v2.PARAMETERS))
            return {'run_id': label, 'seed': seed, 'outcome': 'defeat'}
        def fake_audit(report, destination, *, seed):
            return {'fitness': .17, 'goal_success_for_search': False,
                    'audit_passed': True, 'report': report}
        with patch.object(trainer, 'run_one', side_effect=fake_run) as run, \
                patch.object(trainer, 'audit_training_run', side_effect=fake_audit), patch('builtins.print'):
            trainer.run(path)
        self.assertEqual(run.call_count, 68)
        a = json.loads((path.parent / 'generation-00/allocation.json').read_text())
        b = json.loads((path.parent / 'generation-01/allocation.json').read_text())
        summary = json.loads((path.parent / 'generation-00/summary.json').read_text())
        self.assertEqual(a['vectors'][0], self.extended)
        self.assertEqual(len({(row['candidate'], row['seed']) for row in a['order']}), 34)
        self.assertEqual(b['vectors'][0], summary['center_after'])
        self.assertEqual(len(summary['evaluations']), 17)
        self.assertTrue(all(row['actual_games'] == 2 for row in summary['evaluations']))
        self.assertTrue((path.parent / 'training-completed.json').exists())
        with self.assertRaises(FileExistsError): trainer.run(path)

    def test_contextual_warmstart_retains_nonzero_extra_parameters(self):
        vector = dict(self.extended); vector[v2.PARAMETERS[-1]] = 2.5
        self.model.write_text(json.dumps(v2.make_artifact(vector, self.config,
            training={'protocol': file_evidence(self.parent), 'synthetic_test_only': True})))
        _, doc = self.prepare()
        self.assertEqual(trainer.initial_distribution(doc)[0], vector)
        self.assertEqual(doc['initialization'], 'inherit_frozen_51_parameters_then_fresh_natural_games')

    def test_zero_initialization_and_default_budget_are_explicit(self):
        path = self.root / 'zero' / 'protocol.json'
        doc = trainer.prepare(path, name='zero-synthetic')
        self.assertEqual(doc['planned_training_games'], 1632)
        self.assertEqual(len(doc['training_seeds']), 4)
        self.assertTrue(all(len(seeds) == 24 for seeds in doc['training_seeds']))
        self.assertEqual(trainer.initial_distribution(doc)[0], dict.fromkeys(v2.PARAMETERS, 0.))
        self.assertEqual(len(set(sum(doc['training_seeds'], []) + doc['reserved_evaluation_seeds'])), 126)
        for value in (float('nan'), float('inf'), True, 0., 2.1):
            with self.assertRaises(ValueError): trainer.initial_distribution({**doc, 'initial_std': value})


if __name__ == '__main__':
    unittest.main(verbosity=2)
