import copy
import random
import unittest

from decision_data import enumerate_candidates, state_hash
from route_features import FEATURE_NAMES, KNOWN_TYPES, route_features


def fixtures():
    context = {"act": 1, "floor": 3, "ascension": 10}
    state = {"type": "decision", "decision": "map_select", "context": context,
             "choices": [{"col": 0, "row": 1, "type": "Monster"}, {"col": 1, "row": 1, "type": "Monster"}]}
    def node(col, row, kind, *children):
        return {"col": col, "row": row, "type": kind,
                "children": [{"col": c, "row": r} for c, r in children]}
    game_map = {"type": "map", "context": dict(context), "current_coord": {"col": -1, "row": 0},
        "rows": [[node(0, 1, "Monster", (0, 2)), node(1, 1, "Monster", (1, 2))],
                 [node(0, 2, "RestSite", (2, 6)), node(1, 2, "Elite", (1, 3))],
                 [node(1, 3, "Unknown", (1, 4))], [node(1, 4, "RestSite", (2, 6))]],
        "boss": {"col": 2, "row": 6, "type": "Boss", "id": "PUBLIC_BOSS"}}
    return state, game_map


def evaluate(state, game_map):
    return route_features(state, game_map, {"request": {"cmd": "get_map"},
        "decision_state_hash": state_hash(state), "response_hash": state_hash(game_map)})


def graph_fixture(nodes, choices=((0, 1),), boss=(9, 9)):
    """Synthetic public graph only; tuples are (coordinate, type, children)."""
    state, game_map = fixtures()
    kinds = {pos: kind for pos, kind, _ in nodes}
    kinds[boss] = "Boss"
    state["choices"] = [{"col": c, "row": r, "type": kinds[(c, r)]} for c, r in choices]
    grouped = {}
    for (col, row), kind, children in nodes:
        grouped.setdefault(row, []).append({"col": col, "row": row, "type": kind,
            "children": [{"col": c, "row": r} for c, r in children]})
    game_map["rows"] = [grouped[row] for row in sorted(grouped)]
    game_map["boss"] = {"col": boss[0], "row": boss[1], "type": "Boss"}
    return state, game_map


class RouteFeatureTests(unittest.TestCase):
    def test_same_room_type_can_have_different_public_supply_paths(self):
        state, game_map = fixtures()
        result = evaluate(state, game_map)
        self.assertTrue(result["complete"], result)
        left, right = [row["features"] for row in result["per_candidate"]]
        self.assertEqual((left["route_rest_min_steps"], right["route_rest_min_steps"]), (1, 3))
        self.assertEqual((left["route_rest_min_known_fights"], right["route_rest_min_known_fights"]), (1, 2))
        self.assertEqual((left["route_rest_without_elite_possible"], right["route_rest_without_elite_possible"]), (1, 0))
        self.assertEqual(right["route_rest_witness_unknowns"], 1)
        self.assertEqual(result["per_candidate"][1]["witness_paths"]["rest_minimum_known_fights"],
                         [[1, 1], [1, 2], [1, 3], [1, 4], [2, 6]])
        candidates = enumerate_candidates(state)["candidates"]
        self.assertEqual([r["candidate_id"] for r in result["per_candidate"]], [c["candidate_id"] for c in candidates])
        self.assertEqual([r["request"] for r in result["per_candidate"]], [c["request"] for c in candidates])

    def test_rest_distance_zero_and_absent_rest_is_explicit(self):
        state, game_map = fixtures()
        state["choices"] = [{"col": 0, "row": 2, "type": "RestSite"}, {"col": 2, "row": 6, "type": "Boss"}]
        rows = evaluate(state, game_map)["per_candidate"]
        self.assertEqual(rows[0]["features"]["route_rest_min_steps"], 0)
        self.assertEqual(rows[0]["features"]["route_rest_reachable"], 1)
        self.assertEqual(rows[1]["features"]["route_rest_reachable"], 0)
        self.assertEqual(rows[1]["features"]["route_available"], 1)

    def test_unexported_start_candidate_remains_in_action_space(self):
        state, game_map = fixtures()
        state["choices"].append({"col": -1, "row": 0, "type": "Ancient"})
        result = evaluate(state, game_map)
        self.assertFalse(result["complete"])
        self.assertEqual(len(result["per_candidate"]), 3)
        self.assertEqual(result["per_candidate"][-1]["features"]["route_available"], 0)

    def test_malformed_graphs_and_stale_queries_never_delete_legal_actions(self):
        for damage in ("cycle", "dangling", "duplicate", "stale", "act"):
            with self.subTest(damage=damage):
                state, game_map = fixtures()
                if damage == "cycle": game_map["rows"][1][0]["children"] = [{"col": 0, "row": 1}]
                if damage == "dangling": game_map["rows"][0][0]["children"] = [{"col": 9, "row": 9}]
                if damage == "duplicate": game_map["rows"][0].append(copy.deepcopy(game_map["rows"][0][0]))
                if damage == "act": game_map["context"]["act"] = 2
                evidence = {"request": {"cmd": "get_map"}, "decision_state_hash": state_hash(state), "response_hash": state_hash(game_map)}
                if damage == "stale": state["context"]["floor"] += 1
                result = route_features(state, game_map, evidence)
                self.assertFalse(result["complete"])
                self.assertEqual(len(result["per_candidate"]), 2)
                self.assertTrue(all(row["features"]["route_available"] == 0 for row in result["per_candidate"]))

    def test_hidden_or_irrelevant_metadata_does_not_change_topology_features(self):
        state, game_map = fixtures()
        first = evaluate(state, game_map)
        game_map["boss"]["id"] = "ANOTHER_ID"
        game_map["secret_reward"] = "FORBIDDEN_POLICY_INPUT"
        game_map["rows"][0][0]["seed"] = "do-not-look-ahead"
        second = evaluate(state, game_map)
        self.assertEqual(first["public_map_hash"], second["public_map_hash"])
        self.assertEqual(first["per_candidate"], second["per_candidate"])

    def test_different_extrema_keep_their_own_concrete_witness(self):
        state, game_map = fixtures()
        state["choices"] = state["choices"][:1]
        # Direct one-step rest wins distance; an Unknown detour has the same
        # fight count and loses on length, preserving its actual unknown count.
        game_map["rows"][0][0]["children"].append({"col": 1, "row": 3})
        row = evaluate(state, game_map)["per_candidate"][0]
        self.assertEqual(row["features"]["route_future_choice_reachable"], 1)
        self.assertEqual(row["features"]["route_rest_witness_unknowns"], 0)
        self.assertEqual(row["witness_paths"]["rest_minimum_known_fights"], [[0, 1], [0, 2], [2, 6]])

    def test_dead_end_shop_does_not_create_a_supply_opportunity(self):
        state, game_map = fixtures()
        game_map["rows"][0][0]["children"].append({"col": 5, "row": 2})
        game_map["rows"][1].append({"col": 5, "row": 2, "type": "Shop", "children": []})
        row = evaluate(state, game_map)["per_candidate"][0]
        self.assertEqual(row["features"]["route_shop_reachable"], 0)
        self.assertIn("non_boss_dead_end", row["missing"])

    def test_distinct_extrema_do_not_mix_a_fast_fighting_path_with_unknown_free_path(self):
        state, game_map = graph_fixture([
            ((0, 1), "Monster", [(0, 2), (1, 2)]),
            ((0, 2), "Elite", [(0, 4)]), ((0, 4), "RestSite", [(9, 9)]),
            ((1, 2), "Unknown", [(1, 3)]), ((1, 3), "Unknown", [(1, 4)]),
            ((1, 4), "RestSite", [(9, 9)])])
        row = evaluate(state, game_map)["per_candidate"][0]
        feature = row["features"]
        self.assertEqual(feature["route_rest_min_steps"], 2)
        self.assertEqual(feature["route_rest_min_known_fights"], 1)
        self.assertEqual(feature["route_rest_witness_unknowns"], 2)
        self.assertEqual(row["witness_paths"]["rest_minimum_steps"], [[0, 1], [0, 2], [0, 4], [9, 9]])
        self.assertEqual(row["witness_paths"]["rest_minimum_known_fights"],
                         [[0, 1], [1, 2], [1, 3], [1, 4], [9, 9]])

    def test_fight_ties_use_coordinates_instead_of_cherry_picking_minimum_unknowns(self):
        state, game_map = graph_fixture([
            ((0, 1), "Monster", [(0, 2), (1, 2)]),
            ((0, 2), "Unknown", [(0, 3)]), ((0, 3), "RestSite", [(9, 9)]),
            ((1, 2), "Treasure", [(1, 3)]), ((1, 3), "RestSite", [(9, 9)])])
        row = evaluate(state, game_map)["per_candidate"][0]
        self.assertEqual(row["features"]["route_rest_witness_unknowns"], 1)
        self.assertEqual(row["witness_paths"]["rest_minimum_known_fights"],
                         [[0, 1], [0, 2], [0, 3], [9, 9]])

    def test_both_rest_and_shop_require_a_real_continuation_to_boss(self):
        state, game_map = graph_fixture([
            ((0, 1), "Monster", [(9, 9), (5, 2)]),
            ((5, 2), "RestSite", [(6, 3)]), ((6, 3), "Shop", [])], choices=((0, 1), (5, 2)))
        result = evaluate(state, game_map)
        first, dead = result["per_candidate"]
        self.assertEqual(first["features"]["route_available"], 1)
        self.assertEqual(first["features"]["route_rest_reachable"], 0)
        self.assertEqual(first["features"]["route_shop_reachable"], 0)
        self.assertIn("non_boss_dead_end", first["missing"])
        self.assertEqual(dead["features"]["route_available"], 0)
        self.assertIn("no_exported_boss_path", dead["missing"])
        self.assertEqual(len(result["per_candidate"]), 2)

    def test_first_rest_stops_fight_and_choice_counts_but_not_shop_reachability(self):
        state, game_map = graph_fixture([
            ((0, 1), "RestSite", [(0, 2), (1, 2)]),
            ((0, 2), "Shop", [(9, 9)]), ((1, 2), "Elite", [(9, 9)])])
        row = evaluate(state, game_map)["per_candidate"][0]
        self.assertEqual(row["features"]["route_rest_min_known_fights"], 0)
        self.assertEqual(row["features"]["route_rest_without_elite_possible"], 1)
        self.assertEqual(row["features"]["route_future_choice_reachable"], 0)
        self.assertEqual(row["features"]["route_shop_reachable"], 1)
        self.assertEqual(row["features"]["route_shop_min_steps"], 1)

    def test_unexported_second_boss_never_gets_an_invented_edge_or_victory_claim(self):
        state, game_map = fixtures()
        state["context"]["act"] = game_map["context"]["act"] = 3
        state["choices"] = [dict(game_map["boss"]), {"col": 5, "row": 20, "type": "Boss"}]
        game_map["context"]["second_boss"] = {"id": "HIDDEN_SECOND_BOSS", "col": 5, "row": 20}
        result = evaluate(state, game_map)
        self.assertEqual(len(result["per_candidate"]), 2)
        self.assertEqual([r["features"]["route_available"] for r in result["per_candidate"]], [1, 0])
        self.assertFalse(result["complete"])
        self.assertFalse(result["per_candidate"][1]["witness_paths"])
        self.assertIn("no healing, damage, rewards or A10 victory prediction", result["semantics"])
        game_map["context"]["second_boss"] = {"id": "SOME_OTHER_SECOND_BOSS"}
        changed = evaluate(state, game_map)
        self.assertEqual(result["per_candidate"], changed["per_candidate"])
        self.assertEqual(result["public_map_hash"], changed["public_map_hash"])

    def test_query_context_does_not_coerce_booleans_or_float_values_to_integers(self):
        for key, value in (("act", True), ("act", 1.0), ("floor", 3.0), ("ascension", 10.0)):
            state, game_map = fixtures()
            game_map["context"][key] = value
            with self.subTest(key=key, value=value):
                result = evaluate(state, game_map)
                self.assertFalse(result["complete"])
                self.assertEqual(len(result["per_candidate"]), 2)
                self.assertTrue(all(r["features"]["route_available"] == 0 for r in result["per_candidate"]))

    def test_small_dag_features_match_complete_path_oracle(self):
        # Bounded exhaustive oracle checks DP across merges, dead ends and ties.
        rng = random.Random("route-dp-oracle")
        kinds = ("Monster", "Elite", "Unknown", "RestSite", "Shop", "Treasure", "FutureType")
        for trial in range(30):
            positions = [(0, i + 1) for i in range(7)] + [(9, 9)]
            graph = {pos: (rng.choice(kinds), [p for p in positions[i + 1:] if rng.random() < .4])
                     for i, pos in enumerate(positions[:-1])}
            graph[positions[-1]] = ("Boss", [])
            state, game_map = graph_fixture([(p, *graph[p]) for p in positions[:-1]])
            row = evaluate(state, game_map)["per_candidate"][0]

            def walk(pos, prefix=()):
                path = prefix + (pos,)
                if not graph[pos][1]:
                    return [path]
                return [complete for child in graph[pos][1] for complete in walk(child, path)]

            paths = walk(positions[0])
            boss_paths = [p for p in paths if p[-1] == (9, 9)]
            expected = {name: 0. for name in FEATURE_NAMES}
            if boss_paths:
                expected["route_available"] = 1.
                expected["route_unknown_type_present"] = float(any(
                    graph[p][0] not in KNOWN_TYPES for path in paths for p in path))
                rests = []
                for path in boss_paths:
                    types = [graph[p][0] for p in path]
                    first = next((i for i, kind in enumerate(types) if kind == "RestSite"), None)
                    prefix = types[:first] if first is not None else types[:-1]
                    if first is not None:
                        rests.append((sum(k in {"Monster", "Elite"} for k in prefix), first,
                                      path[:first + 1], prefix.count("Unknown")))
                        expected["route_rest_without_elite_possible"] = max(
                            expected["route_rest_without_elite_possible"], float("Elite" not in prefix))
                    if any(len(graph[p][1]) >= 2 for p in path[:len(prefix)]):
                        expected["route_future_choice_reachable"] = 1.
                if rests:
                    best = min(rests, key=lambda r: r[:3])
                    expected.update(route_rest_reachable=1., route_rest_min_steps=float(min(r[1] for r in rests)),
                        route_rest_min_known_fights=float(best[0]), route_rest_witness_unknowns=float(best[3]))
                shops = [i for path in boss_paths for i, p in enumerate(path) if graph[p][0] == "Shop"]
                if shops:
                    expected.update(route_shop_reachable=1., route_shop_min_steps=float(min(shops)))
                for witness in row["witness_paths"].values():
                    self.assertIn(tuple(map(tuple, witness)), boss_paths)
            with self.subTest(trial=trial):
                self.assertEqual(row["features"], expected)


if __name__ == "__main__":
    unittest.main()
