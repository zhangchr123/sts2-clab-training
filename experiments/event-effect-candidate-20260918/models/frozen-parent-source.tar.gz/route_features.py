"""Pure public-map topology. No encounter inference, action execution, or route value."""
from functools import lru_cache

from decision_data import DataContractError, enumerate_candidates, state_hash

VERSION = "public-route-topology-v1"
FEATURE_NAMES = ("route_available", "route_rest_reachable", "route_rest_min_steps",
    "route_rest_min_known_fights", "route_rest_witness_unknowns", "route_rest_without_elite_possible",
    "route_shop_reachable", "route_shop_min_steps", "route_future_choice_reachable", "route_unknown_type_present")
KNOWN_TYPES = {"Monster", "Elite", "RestSite", "Shop", "Treasure", "Unknown", "Boss", "Ancient", "Unassigned"}
FIGHTS = {"Monster", "Elite"}


def coordinate(value):
    if not isinstance(value, dict) or any(type(value.get(k)) is not int for k in ("col", "row")):
        raise DataContractError("Map coordinates must be explicit integers")
    return value["col"], value["row"]


def project_map(response):
    """Whitelist the actual exported graph; ignore identifiers and hidden metadata."""
    if response.get("type") != "map" or not isinstance(response.get("rows"), list):
        raise DataContractError("Missing structured public map")
    graph = {}
    for row in response["rows"]:
        if not isinstance(row, list):
            raise DataContractError("Map rows must be lists")
        for item in row:
            pos = coordinate(item)
            if pos in graph or not isinstance(item.get("type"), str) or not isinstance(item.get("children"), list):
                raise DataContractError("Duplicate node or missing public type/children")
            children = [coordinate(child) for child in item["children"]]
            if len(set(children)) != len(children):
                raise DataContractError("Duplicate map edge")
            graph[pos] = {"type": item["type"], "children": tuple(sorted(children))}
    boss = coordinate(response.get("boss"))
    if response["boss"].get("type") != "Boss":
        raise DataContractError("Exported map endpoint must explicitly be Boss")
    if boss not in graph:
        graph[boss] = {"type": "Boss", "children": ()}
    elif graph[boss] != {"type": "Boss", "children": ()}:
        raise DataContractError("Exported boss conflicts with graph endpoint")
    for node in graph.values():
        if any(child not in graph for child in node["children"]):
            raise DataContractError("Dangling public map edge")
    active, done = set(), set()

    def visit(pos):
        if pos in active:
            raise DataContractError("Cycle in public map")
        if pos in done:
            return
        active.add(pos)
        for child in graph[pos]["children"]:
            visit(child)
        active.remove(pos)
        done.add(pos)

    for pos in graph:
        visit(pos)
    public = {"nodes": [{"col": pos[0], "row": pos[1], "type": graph[pos]["type"],
                         "children": [list(c) for c in graph[pos]["children"]]} for pos in sorted(graph)],
              "boss": list(boss)}
    return graph, boss, public


def route_features(state, map_response, query_evidence):
    """Keep every legal candidate, even when its topology cannot be established.

    query_evidence binds a read-only get_map response to the paused decision.
    Route distances begin at the candidate node (a rest candidate has distance 0).
    Witnesses are concrete paths to this map's exported boss, never A10 victory.
    """
    candidate_set = enumerate_candidates(state)
    if state.get("decision") != "map_select" or candidate_set["complete"] is not True:
        raise DataContractError("Route features require the complete current map candidates")
    rows = [{"candidate_id": c["candidate_id"], "request": c["request"],
             "features": {key: 0.0 for key in FEATURE_NAMES}, "missing": [], "witness_paths": {}}
            for c in candidate_set["candidates"]]
    result = {"version": VERSION, "state_hash": state_hash(state), "public_map_hash": None,
              "query_evidence": query_evidence, "complete": False, "per_candidate": rows,
              "semantics": "Public topology only; no healing, damage, rewards or A10 victory prediction"}
    try:
        if query_evidence != {"request": {"cmd": "get_map"}, "decision_state_hash": state_hash(state),
                              "response_hash": state_hash(map_response)}:
            raise DataContractError("Stale or unbound public map query evidence")
        left, right = state.get("context", {}), map_response.get("context", {})
        if any(type(left.get(key)) is not int or type(right.get(key)) is not int
               or left[key] != right[key] for key in ("act", "floor", "ascension")):
            raise DataContractError("Map query has another act, floor or ascension")
        graph, boss, public = project_map(map_response)
        result["public_map_hash"] = state_hash(public)

        @lru_cache(None)
        def paths(pos):
            node = graph[pos]
            children = [paths(child) for child in node["children"]]
            best = (pos,) if pos == boss else min(
                ((pos,) + child["boss"] for child in children if child["boss"]),
                key=lambda path: (len(path), path), default=None)
            answer = {"boss": best, "rest_distance": None, "rest_fights": None,
                      "shop_distance": None, "no_elite": False, "choice": False,
                      "unknown_type": node["type"] not in KNOWN_TYPES or any(c["unknown_type"] for c in children),
                      "dead_end": (not node["children"] and pos != boss) or any(c["dead_end"] for c in children)}
            if not best or pos == boss:
                return answer
            kind = node["type"]
            if kind == "RestSite":
                # Optimize the prefix through the first Rest. Its continuation
                # is a concrete shortest path to Boss, with coordinate ties.
                answer.update(rest_distance=(0, best), rest_fights=(0, 0, 0, best), no_elite=True)
            else:
                answer["rest_distance"] = min(
                    ((c["rest_distance"][0] + 1, (pos,) + c["rest_distance"][1])
                     for c in children if c["rest_distance"]), default=None)
                answer["rest_fights"] = min(
                    ((c["rest_fights"][0] + int(kind in FIGHTS), c["rest_fights"][1] + 1,
                      c["rest_fights"][2] + int(kind == "Unknown"), (pos,) + c["rest_fights"][3])
                     for c in children if c["rest_fights"]),
                    key=lambda item: (item[0], item[1], item[3]), default=None)
                answer["no_elite"] = kind != "Elite" and any(c["no_elite"] for c in children)
                answer["choice"] = len(node["children"]) >= 2 or any(c["choice"] for c in children)
            if kind == "Shop":
                answer["shop_distance"] = (0, best)
            else:
                answer["shop_distance"] = min(
                    ((c["shop_distance"][0] + 1, (pos,) + c["shop_distance"][1])
                     for c in children if c["shop_distance"]), default=None)
            return answer

        for candidate, row in zip(candidate_set["candidates"], rows):
            if candidate["request"]["action"] == "use_potion":
                row["missing"].append("not_a_route_action")
                continue
            pos = coordinate(candidate["request"]["args"])
            if pos not in graph or graph[pos]["type"] != candidate["evidence"]["type"]:
                row["missing"].append("candidate_missing_or_type_mismatch_in_public_map")
                continue
            info = paths(pos)
            if info["boss"] is None:
                row["missing"].append("no_exported_boss_path")
                continue
            feature = row["features"]
            feature.update(route_available=1.0, route_rest_reachable=float(info["rest_distance"] is not None),
                route_shop_reachable=float(info["shop_distance"] is not None),
                route_rest_without_elite_possible=float(info["no_elite"]),
                route_future_choice_reachable=float(info["choice"]), route_unknown_type_present=float(info["unknown_type"]))
            for name in ("rest", "shop"):
                path_info = info[name + "_distance"]
                if path_info is not None:
                    feature["route_" + name + "_min_steps"] = float(path_info[0])
                    row["witness_paths"][name + "_minimum_steps"] = [list(c) for c in path_info[1]]
            if info["rest_fights"] is not None:
                fights, _, unknowns, witness = info["rest_fights"]
                feature.update(route_rest_min_known_fights=float(fights), route_rest_witness_unknowns=float(unknowns))
                row["witness_paths"]["rest_minimum_known_fights"] = [list(c) for c in witness]
            row["missing"].extend(["unknown_room_outcomes", "encounter_damage_distribution", "supply_benefit_model"])
            if info["dead_end"]:
                row["missing"].append("non_boss_dead_end")
        result["complete"] = all(row["features"]["route_available"] == 1
            or row["request"]["action"] == "use_potion" for row in rows)
    except (DataContractError, TypeError, AttributeError, KeyError, RecursionError) as exc:
        for row in rows:
            row["features"] = {key: 0.0 for key in FEATURE_NAMES}
            row["witness_paths"] = {}
            row["missing"].append(str(exc))
    return result
