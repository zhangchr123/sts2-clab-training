"""Synthetic contracts; these fixtures are never natural training samples."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sample_runs
from audit_batch import _Audit
from decision_data import DataContractError,enumerate_candidates,read_decisions,state_hash
from map_observation import make_map_observation
import public_route_learning as f
import public_route_policy as p
from test_initial_policy import state,card
from test_route_features import fixtures

def map_fixture():
    sketch,response=fixtures();value=state([])
    value.update(decision='map_select',choices=sketch['choices'])
    value['context'].update(sketch['context'],combat_in_progress=False)
    value['player'].update(hp=15,max_hp=75,gold=100)
    return value,response

class PublicRouteTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=p.ROOT/'outputs');self.addCleanup(self.temp.cleanup)
        self.folder=Path(self.temp.name)
        self.config=json.loads((p.ROOT/'configs/defect-v3-base.json').read_text(encoding='utf-8'))
    def model(self,weights=None):
        path=self.folder/('model-'+str(len(list(self.folder.glob('model-*'))))+'.json')
        path.write_text(json.dumps(p.make_artifact(weights or dict.fromkeys(p.PARAMETERS,0.),self.config,
            training={'synthetic_contract_only':True})),encoding='utf-8')
        return sample_runs.build_policy('route-contract',self.config,ascension=10,epsilon=0.,model_path=path)
    def test_311_parameters_keep_all_289_and_nonmap_features(self):
        self.assertEqual(len(f.PARAMETERS),311);self.assertEqual(len(set(f.PARAMETERS)),311)
        s=state([card('BALL_LIGHTNING',damage=7)]);s['context']['act']=2;model=self.model()
        result=model.choose(s)
        for row in result['scoring']['scores']:
            candidate=next(c for c in enumerate_candidates(s)['candidates'] if c['candidate_id']==row['candidate_id'])
            self.assertEqual({k:row['search_features'][k] for k in f.ORIGINAL_PARAMETERS},f.original_features(s,row,candidate))
            self.assertTrue(all(row['search_features'][k]==0 for k in f.EXTRA_PARAMETERS))
    def test_projection_excludes_hidden_fields_and_query_details(self):
        s,response=map_fixture();clean=f.policy_input(s,make_map_observation(s,response))
        response['hidden_rng']='never-model-input';response['rows'][0][0]['future_encounter']='secret'
        other=f.policy_input(s,make_map_observation(s,response))
        self.assertEqual(clean,other)
        self.assertNotIn('secret',json.dumps(other));self.assertNotIn('raw_response',other)
        other['hidden_rng']='forged'
        with self.assertRaises(DataContractError):f.validate_input(s,other)
    def test_known_fight_weight_distinguishes_same_current_room(self):
        s,response=map_fixture();weights=dict.fromkeys(p.PARAMETERS,0.)
        weights['public_route_rest_min_known_fights']=-4.
        model=self.model(weights);model.base.set_public_route_input(s,f.policy_input(s,make_map_observation(s,response)))
        picked=model.choose(s)
        self.assertEqual(picked['request']['args'],{'col':0,'row':1})
        rows=picked['scoring']['scores']
        self.assertEqual(rows[0]['rule_score'],rows[1]['rule_score'])
        self.assertGreater(rows[0]['score'],rows[1]['score'])
        self.assertAlmostEqual(rows[0]['search_features']['low_hp_route_rest_min_known_fights'],.8/16)
        self.assertEqual(rows[1]['search_features']['public_route_rest_witness_unknowns'],1/16)
    def test_stale_missing_and_incomplete_candidate_binding_rejected(self):
        s,response=map_fixture();model=self.model()
        with self.assertRaises(DataContractError):model.choose(s)
        value=f.policy_input(s,make_map_observation(s,response));changed=copy.deepcopy(s);changed['player']['hp']-=1
        with self.assertRaises(DataContractError):model.base.set_public_route_input(changed,value)
        value['per_candidate'].pop()
        with self.assertRaises(DataContractError):model.base.set_public_route_input(s,value)
    def test_missing_map_keeps_all_candidates_and_zero_route_terms(self):
        s,_=map_fixture();value=f.policy_input(s,make_map_observation(s,{'type':'error','error':'unavailable'}))
        model=self.model();model.base.set_public_route_input(s,value);rows=model.choose(s)['scoring']['scores']
        self.assertEqual(len(rows),2)
        self.assertTrue(all(all(row['search_features'][k]==0 for k in f.EXTRA_PARAMETERS) for row in rows))
    def test_deck_cap_and_whole_run_build_exception_retained(self):
        weights=dict.fromkeys(p.PARAMETERS,4.);model=self.model(weights)
        s=state([card('BALL_LIGHTNING',damage=7)]);s['context']['act']=2;s['player'].update(deck=[card('DEFEND_DEFECT',block=5)]*36,deck_size=36)
        self.assertEqual(model.choose(s)['request']['action'],'skip_card_reward')
        s['player']['relics']=[{'id':'RELIC.BING_BONG'}];model.choose(s)
        s['player']['relics']=[]
        self.assertTrue(all(not row['deck_discipline']['hard_blocked'] for row in model.score(s)['scores']))
    def test_observation_query_only_for_maps_and_does_not_mutate_state(self):
        s,response=map_fixture();before=copy.deepcopy(s);requests=[]
        def send(**request):requests.append(request);return response
        observation,value=f.observe_before_choice(s,send)
        self.assertEqual(requests,[{'cmd':'get_map'}]);self.assertEqual(s,before)
        f.observe_before_choice(state([]),send);self.assertEqual(len(requests),1)
        self.assertTrue(f.validate_input(s,value))
    def test_real_sampler_path_and_full_auditor_bind_query_before_choice(self):
        s,response=map_fixture();requests=[]
        final=copy.deepcopy(s);final.update(decision='game_over',victory=False);final['player']['hp']=0
        class FixtureBridge:
            def send(self,**request):
                requests.append(copy.deepcopy(request))
                if request['cmd']=='start_run':return copy.deepcopy(s)
                if request['cmd']=='get_map':return copy.deepcopy(response)
                return copy.deepcopy(final)
            def close(self):pass
        model=self.model();path=model.base.path
        with patch.object(sample_runs,'ROOT',self.folder),patch.object(sample_runs,'Bridge',return_value=FixtureBridge()):
            report=sample_runs.run_one('synthetic-public-route','route-contract',settings=self.config,epsilon=0.,model_path=path)
        self.assertIsNone(report['error'],report['error'])
        self.assertEqual([q['cmd'] for q in requests],['start_run','get_map','action'])
        out=self.folder/'outputs/synthetic-public-route';audit=_Audit(out);audit.run(report)
        self.assertEqual(audit.issues,[])
        records=read_decisions(out/'decisions.jsonl')
        policies={r['decision_id']:r for r in map(json.loads,(out/'policy.jsonl').read_text(encoding='utf-8').splitlines())}
        traces=list(map(json.loads,(out/'trace.jsonl').read_text(encoding='utf-8').splitlines()))
        self.assertTrue(f.validate_trace_observations(records,policies,traces))
        for damage in ('hash','response','duplicate','missing','forged_scores'):
            ts=copy.deepcopy(traces);ps=copy.deepcopy(policies)
            if damage=='hash':ts[1]['decision_state_hash']='forged'
            if damage=='response':ts[1]['response']['rows'][0][0]['type']='RestSite'
            if damage=='duplicate':ts.insert(1,copy.deepcopy(ts[1]))
            if damage=='missing':ts.pop(1)
            if damage=='forged_scores':next(iter(ps.values()))['scoring']['public_route_input']['per_candidate'][0]['features']['route_rest_min_steps']=0
            with self.subTest(damage=damage),self.assertRaises((DataContractError,KeyError)):
                f.validate_trace_observations(records,ps,ts)

if __name__=='__main__':unittest.main(verbosity=2)
