"""Known abandonment entry stays legal but is scored below continuing."""
import copy
import json
import unittest
import uuid
from initial_policy import InitialPolicy
from probe import Bridge, ROOT


class TrialAbandonPolicyTests(unittest.TestCase):
    def test_exact_original_key_only_and_all_candidates_retained(self):
        state = {'type':'decision','decision':'event_choice','context':{'combat_in_progress':False},
            'options':[{'index':0,'is_locked':False,'text_key':'TRIAL.pages.REJECT.options.ACCEPT'},
                       {'index':1,'is_locked':False,'text_key':'TRIAL.pages.REJECT.options.DOUBLE_DOWN'}]}
        for seed in range(8):
            choice = InitialPolicy(random_seed=seed,epsilon=0.).choose(state)
            self.assertEqual(choice['request']['args']['option_index'], 0)
            self.assertEqual(len(choice['scoring']['scores']), 2)
        other = copy.deepcopy(state); other['options'][1]['text_key'] = 'UNKNOWN.DOUBLE_DOWN'
        self.assertEqual([r['score'] for r in InitialPolicy().score(other)['scores']], [0.,0.])

    def test_original_trial_reject_page_continues_without_abandonment(self):
        label='trial-abandon-rule-'+uuid.uuid4().hex[:10]; b=Bridge(label); trace=[]
        def send(**q):
            s=b.send(**q);trace.append({'request':q,'response':s})
            self.assertNotEqual(s.get('type'),'error',s);return s
        try:
            send(cmd='start_run',character='Defect',ascension=10,seed='trial-abandon-rule')
            state=send(cmd='enter_room',type='event',event='TRIAL')
            reject=next(o for o in state['options'] if o['text_key']=='TRIAL.pages.INITIAL.options.REJECT')
            state=send(cmd='action',action='choose_option',args={'option_index':reject['index']})
            choice=InitialPolicy(epsilon=0.).choose(state)
            after=send(**choice['request'])
            self.assertEqual(after['decision'],'event_choice')
            self.assertNotEqual(after['options'],state['options'])
            self.assertEqual(after['player']['hp'],state['player']['hp'])
            self.assertFalse(after['context']['integrity_recovery_used'])
        finally:
            b.close();(ROOT/'outputs'/(label+'.json')).write_text(json.dumps({'origin':'artificial_fixture',
                'training_eligible':False,'trace':trace},ensure_ascii=False),encoding='utf-8')


if __name__=='__main__': unittest.main()
