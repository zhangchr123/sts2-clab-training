"""Public topology inputs and learnable context terms; no hidden room prediction."""
import copy
import math
from decision_data import DataContractError, enumerate_candidates, state_hash
from map_observation import validate_map_observation
from route_features import FEATURE_NAMES
from selection_target_features import PARAMETERS as ORIGINAL_PARAMETERS, features as original_features

VERSION='public-route-policy-input-v1'
EXTRA_PARAMETERS=tuple('public_'+k for k in FEATURE_NAMES)+tuple('low_hp_'+k for k in FEATURE_NAMES)+(
    'gold_route_shop_reachable','gold_route_shop_min_steps')
PARAMETERS=tuple(ORIGINAL_PARAMETERS)+EXTRA_PARAMETERS
COUNT_FEATURES={'route_rest_min_steps','route_rest_min_known_fights','route_rest_witness_unknowns','route_shop_min_steps'}
CONTRACT=dict(version=VERSION,original_parameters=289,route_parameters=22,
    input='whitelisted_public_topology_and_current_hp_gold',raw_get_map_response_is_policy_input=False,
    unknown_rooms_are_safe=False,rest_guarantees_healing=False,hidden_future_encounters_used=False,
    count_normalizer=16,gold_normalizer=300,all_parameters_trainable=True)

def require(ok,message):
    if not ok:raise DataContractError(message)

def policy_input(state,observation):
    """Project an audited observation into the only object seen by the policy."""
    validate_map_observation(state,observation)
    result=dict(version=VERSION,decision_state_hash=state_hash(state),
        candidate_set_hash=state_hash(enumerate_candidates(state)),
        public_map_hash=observation['public_map_hash'],status=observation['status'],
        per_candidate=[dict(candidate_id=row['candidate_id'],features=copy.deepcopy(row['features']))
            for row in observation['route_features']['per_candidate']])
    validate_input(state,result)
    return result

def validate_input(state,value):
    require(state.get('decision')=='map_select','Public route input requires map_select')
    require(isinstance(value,dict) and set(value)=={'version','decision_state_hash','candidate_set_hash',
        'public_map_hash','status','per_candidate'},'Route policy input contains missing or unapproved fields')
    candidates=enumerate_candidates(state)
    require(value['version']==VERSION and value['decision_state_hash']==state_hash(state)
        and value['candidate_set_hash']==state_hash(candidates),'Stale public route policy input')
    require(value['status'] in ('available','partial','unavailable') and isinstance(value['per_candidate'],list),
        'Invalid public route input status')
    require([row.get('candidate_id') for row in value['per_candidate']]==[c['candidate_id'] for c in candidates['candidates']],
        'Route input must retain every current legal candidate in order')
    for row in value['per_candidate']:
        require(set(row)=={'candidate_id','features'} and isinstance(row['features'],dict)
            and set(row['features'])==set(FEATURE_NAMES),'Unapproved route candidate fields')
        for key,number in row['features'].items():
            require(type(number) in (int,float) and math.isfinite(number) and number>=0
                and (key in COUNT_FEATURES or number in (0,1)),'Invalid numeric route feature')
        if not row['features']['route_available']:
            require(all(v==0 for v in row['features'].values()),'Unavailable route must keep zero topology terms')
    return True

def zero_extend(parameters):
    require(set(parameters)==set(ORIGINAL_PARAMETERS),'Expected all original 289 parameters')
    return {**parameters,**dict.fromkeys(EXTRA_PARAMETERS,0.)}

def features(state,row,candidate,route_input=None):
    result={**original_features(state,row,candidate),**dict.fromkeys(EXTRA_PARAMETERS,0.)}
    if state.get('decision')!='map_select':return result
    validate_input(state,route_input)
    route=next(r['features'] for r in route_input['per_candidate'] if r['candidate_id']==candidate['candidate_id'])
    player=state.get('player',{});hp=player.get('hp');maximum=player.get('max_hp');gold=player.get('gold')
    require(all(type(v) in (int,float) and math.isfinite(v) for v in (hp,maximum,gold))
        and maximum>0 and hp>=0 and gold>=0,'Route context requires actual public HP/max HP/gold')
    deficit=max(0.,min(1.,1-hp/maximum));gold_level=min(1.,gold/300.)
    for key,value in route.items():
        normalized=min(1.,value/16.) if key in COUNT_FEATURES else float(value)
        result['public_'+key]=normalized
        result['low_hp_'+key]=deficit*normalized
    result['gold_route_shop_reachable']=gold_level*route['route_shop_reachable']
    result['gold_route_shop_min_steps']=gold_level*min(1.,route['route_shop_min_steps']/16.)
    return result

def observe_before_choice(state,send):
    """Execute exactly one real read-only query before each map choice."""
    if state.get('decision')!='map_select':return None,None
    from map_observation import make_map_observation
    observation=make_map_observation(state,send(cmd='get_map'))
    return observation,policy_input(state,observation)

def validate_trace_observations(records,policies,traces):
    """Require immediate query-before-action and reconstruct only public inputs."""
    from public_route_policy import VERSION as POLICY_VERSION
    from reference_archetype_policy import VERSION as REFERENCE_VERSION
    from neow_preference_policy import VERSION as NEOW_VERSION
    from persistent_acquisition_policy import VERSION as PERSISTENT_VERSION
    if not records or records[0]['metadata']['provenance'].get('id') not in (POLICY_VERSION,REFERENCE_VERSION,NEOW_VERSION,PERSISTENT_VERSION):return True
    current={'type':'initializing'};before=[]
    for trace in traces:
        before.append(current)
        response=trace.get('response')
        if isinstance(response,dict) and (response.get('type')=='decision' or
            (trace['request'].get('cmd') in ('start_run','action') and response.get('type')=='error')):
            current=response
    cursor=0;used=[]
    for record in records:
        picked=policies[record['decision_id']];state=record['state']
        if state.get('decision')!='map_select':
            require('map_observation' not in picked,'Non-map decision has map observation');continue
        observation=picked.get('map_observation')
        match=next((i for i in range(cursor,len(traces)) if traces[i]['request']==picked['request']
            and state_hash(before[i])==state_hash(state)),None)
        require(match is not None and match>0,'Map action has no actual trace match')
        query=traces[match-1]
        validate_map_observation(state,observation,query)
        require(state_hash(before[match-1])==state_hash(state),'Map query belongs to different real trace state')
        require(picked['scoring']['public_route_input']==policy_input(state,observation),'Scored topology differs from actual map')
        used.append(match-1);cursor=match+1
    # A terminal error before a journal intent may retain one final failed query.
    queries=[i for i,x in enumerate(traces) if x['request'].get('cmd')=='get_map']
    extras=[i for i in queries if i not in used]
    require(not extras or (len(extras)==1 and extras[0]==len(traces)-1
        and (traces[-1].get('transport_error') or traces[-1].get('response',{}).get('type')=='error')),
        'Unaccounted or duplicated public map query')
    return True
