"""Original EndTurn tasks and uncropped recorded solve; never natural samples."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers


class ToastyEndTurnOriginTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def test_full_original_plan_and_joint_corruption_rejection(self):
        root = Path('D:/sts2-training/staging/secret-catastrophe-return/sts2-solver-bridge')
        batch = root / 'outputs/defect-contextual-d8-20260914b'
        name = batch.name + '-g01-c11-s15'
        source = root / 'outputs' / name
        receipt = read_json(batch / 'generation-01' / (name + '-audit.json'))
        self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        gate = max(i for i, r in enumerate(rows) if r['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'toasty-end-full-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        executor, matched, passed = None, 0, False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
            real_solve, supplied = executor.solve, False
            def recorded_then_actual(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied: return real_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertEqual(setup, original['request'].get('include_turn_setup', False))
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded_then_actual
            final = executor.advance(before)
            self.assertEqual(final['decision'], 'card_reward')
            self.assertEqual(checked_public(final), checked_public(rows[-1]['response']))
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            proofs = [p for p in executor.solve_calls[0].get('replay', [])
                if p['kind'] == 'end_turn_setup_choice_not_executed']
            self.assertEqual(len(proofs), 1)
            proof = proofs[0]
            self.assertEqual(proof['plan']['Cards'][0]['CardId'], 'DUALCAST')
            self.assertEqual(proof['selected_cards'], [])
            self.assertFalse(proof['selection_request_sent'])
            self.assertTrue(proof['remaining_battle_plan_stopped'])
            verified = validate_replay_evidence(executor.solve_calls, traces)
            self.assertTrue(verified['verified'])
            binding = next(b for b in verified['bindings'] if b['kind'] == proof['kind'])
            query = binding['query_trace_index']
            self.assertEqual(query, len(traces)-1)
            changes = [(('closed',),False), (('action_id',),-1), (('setup_capture_before',),-1),
                (('parent','player_turn'),3), (('before_action','player_phase'),'Start'),
                (('after_action','same_original_combat'),False), (('after_action','selector_invocations'),-1),
                (('after_action','selector_pending'),True), (('after_action','combat_active'),True),
                (('setup_origin','live_same_combat'),False), (('setup_origin','capture_id'),-1)]
            for i in range(4):
                changes += [(('calls',i,'original_task_completed_successfully'),False),
                    (('calls',i,'original_task_status'),'WaitingForActivation'),
                    (('calls',i,'setup_capture_id'),-1), (('calls',i,'index'),-1),
                    (('calls',i,'entry','selector_pending'),True),
                    (('calls',i,'at_method_return','combat_ending'),False)]
                if i: changes.append((('calls',i,'source_is_original_player_object'),False))
            changes += [(('calls',3,'entry','combat_ending'),False),
                (('calls',3,'returned_count'),1), (('calls',3,'returned_card_keys'),['DUALCAST+0']),
                (('calls',3,'original_returned_collection'),'List<CardModel>'),
                (('calls',3,'filter_is_null'),False), (('calls',3,'min_select'),0),
                (('calls',3,'require_manual_confirmation'),True), (('calls',3,'raw_hand_count'),-1)]
            for path, value in changes:
                bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                bp = next(p for p in bad_calls[0]['replay'] if p['kind'] == proof['kind'])
                for obj in (bp['actual_turn_end_origin'], bad_traces[query]['response']['turn_end_origin']):
                    for key in path[:-1]: obj = obj[key]
                    obj[path[-1]] = value
                with self.subTest(path=path), self.assertRaises(ValueError):
                    validate_replay_evidence(bad_calls, bad_traces)
            for field, value in [('selection_request_sent', True), ('selected_cards', proof['plan']['Cards']),
                    ('remaining_battle_plan_stopped', False), ('plan', dict(proof['plan'], Timing='PlayerTurnEnd'))]:
                bad_calls = copy.deepcopy(executor.solve_calls)
                next(p for p in bad_calls[0]['replay'] if p['kind'] == proof['kind'])[field] = value
                with self.subTest(field=field), self.assertRaises(ValueError):
                    validate_replay_evidence(bad_calls, traces)
            bad_calls = copy.deepcopy(executor.solve_calls)
            bad_calls[0]['replay'].remove(proof)
            with self.assertRaises(ValueError): validate_replay_evidence(bad_calls, traces)
            bad_traces = copy.deepcopy(traces)
            bad_traces[query]['response'].pop('turn_end_origin')
            with self.assertRaises(ValueError): validate_replay_evidence(executor.solve_calls, bad_traces)
            # Even a rejected actual action invalidates the completed receipt.
            invalid = bridge.send(cmd='action', action='play_card', args={'card_index':-1})
            self.assertEqual(invalid['type'], 'error')
            stale = bridge.send(cmd='choice_meta')
            self.assertNotIn('turn_end_origin', stale)
            self.assertTrue(unchanged(receipt['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='recorded_full_solver_envelope_diagnostic',
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                original_source=receipt['actual_source_evidence'], original_run=name,
                public_prefix_responses_verified=matched, solver_calls=executor.solve_calls if executor else [],
                hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_live_toasty_selection_is_not_an_ending_return(self):
        label = 'toasty-end-manual-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed = False
        try:
            send(cmd='start_run', character='Defect', ascension=10, seed='toasty-end-manual')
            send(cmd='set_player', hp=1000, max_hp=1000, relics=['TOASTY_MITTENS'],
                potions=[], deck=['DEFEND_DEFECT']*15)
            state = send(cmd='enter_room', type='combat', encounter='FOGMOG_NORMAL')
            self.assertEqual(state['decision'], 'card_select')
            before = send(cmd='action', action='select_cards', args={'indices':'0'})
            self.assertEqual(before['decision'], 'combat_play')
            after = send(cmd='action', action='end_turn')
            self.assertEqual(after['decision'], 'card_select')
            self.assertTrue(after['context']['combat_in_progress'])
            meta = send(cmd='choice_meta')
            origin = meta['turn_end_origin']
            self.assertTrue(origin['after_action']['selector_pending'])
            self.assertTrue(any(not c['original_task_completed_successfully'] for c in origin['calls']))
            executor = CombatExecutor(send)
            length = len(traces)
            self.assertFalse(executor.resolve_original_automatic_choice(before, after,
                {'Kind':'EndTurn','TurnStartChoices':[{'SourceId':'TOASTY_MITTENS'}]}))
            self.assertEqual(len(traces), length)
            final = send(cmd='action', action='select_cards', args={'indices':'0'})
            self.assertEqual(final['decision'], 'combat_play')
            self.assertEqual(final['player_turn'], 2)
            self.assertNotIn('turn_end_origin', send(cmd='choice_meta'))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='synthetic_original_manual_boundary',
                hidden_state_or_rng_equality_claimed=False)
            bridge.close()


if __name__ == '__main__': unittest.main()
