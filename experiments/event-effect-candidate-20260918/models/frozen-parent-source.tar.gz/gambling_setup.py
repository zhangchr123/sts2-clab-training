"""Retain a GamblingChip setup plan only after authenticating its original task."""
import copy

FIELDS={'Effect':'DiscardAndDraw','SourcePile':'Hand','Timing':'PlayerTurnStart',
        'SourceId':'GAMBLING_CHIP','ContextId':'AFTER_PLAYER_TURN_START'}


def require(ok,message):
    if not ok:raise RuntimeError('GamblingChip setup: '+message)


def known(plans):
    return (isinstance(plans,list) and len(plans)==1 and isinstance(plans[0],dict)
        and all(plans[0].get(k)==v for k,v in FIELDS.items()) and isinstance(plans[0].get('Cards'),list))


def verify(executor,state,plan,meta,origin):
    executor.verify_setup_origin(origin,phase='Start')
    executor.verify_setup_origin(meta.get('setup_origin'),phase='Start')
    audit=meta.get('setup_choice')
    require(known([plan]) and origin['captured_turn']==1 and meta['setup_origin']==origin and isinstance(audit,dict), 'wrong plan or capture')
    expected=dict(schema_version='gambling-chip-setup-choice-v1',capture_id=origin['capture_id'],
        source_method='CardSelectCmd.FromHand',source_id='GAMBLING_CHIP',source_is_current_live_relic=True,
        original_task_pending=True,player_id=origin['player_id'],player_turn=1,effect='DiscardAndDraw',
        source_pile='Hand',timing='PlayerTurnStart',context_id='AFTER_PLAYER_TURN_START',
        min_select=0,max_select=999999999,filter_is_null=True,require_manual_confirmation=True)
    require(all(type(audit.get(k)) is type(v) and audit[k]==v for k,v in expected.items()), 'original live task not bound')
    require(type(state.get('min_select')) is int and state['min_select']==0
        and type(state.get('max_select')) is int and state['max_select']==999999999, 'wrong actual selection bounds')
    require(any(r.get('id')=='RELIC.GAMBLING_CHIP' for r in state.get('player',{}).get('relics',[])), 'live relic missing')


def resolve(executor,before,result):
    plans=result.get('turn_setup_choices');require(known(plans),'unsupported plan shape')
    origin=result.get('setup_origin');executor.verify_setup_origin(origin,phase='Start')
    actions=result.get('actions');identity=executor.setup_state_identity(before)
    require(before.get('decision')=='card_select' and before.get('context',{}).get('combat_in_progress') is True
        and type(identity['combat_id']) is int and identity['combat_id']>0 and all(v is not None for v in identity.values())
        and origin['captured_turn']==1 and isinstance(actions,list) and bool(actions)
        and type(actions[0].get('Turn')) is int and actions[0]['Turn']==1
        and type(result.get('summary',{}).get('StartTurnNumber')) is int and result['summary']['StartTurnNumber']==1
        and executor.solve_calls and executor.solve_calls[-1]['request'].get('include_turn_setup') is True
        and executor.solve_calls[-1]['response']==result,'missing matching current setup solve or identity')
    choices=[]
    after=executor.resolve(before,plans,setup_capture=origin,setup_choices=choices)
    # A completed combat has no remaining plan to execute. Keep the existing
    # macro-boundary behavior; this path makes no continuation claim.
    if after.get('context',{}).get('combat_in_progress') is False:
        executor.solve_calls[-1]['setup_plan_reuse']={'schema_version':'setup-plan-reuse-v1',
            'reused':False,'reason':'gambling_original_setup_ended_combat'}
        return after,None
    require(executor.setup_state_identity(after)==identity and after.get('decision')=='combat_play'
        and type(after.get('player_turn')) is int and after['player_turn']==1,'setup did not finish in the same player turn')
    audit=after.get('choice_audit',{});parent=audit.get('parent',{})
    require(audit.get('closed') is True and parent.get('action')=='select_cards'
        and parent.get('player_id')==origin['player_id'] and type(parent.get('combat_id')) is int
        and parent['combat_id']==identity['combat_id'] and type(parent.get('player_turn')) is int
        and parent['player_turn']==1 and parent.get('combat_active_before') is True,'selection completion is not bound')
    meta=executor.checked(cmd='choice_meta')
    require(meta.get('type')=='choice_meta' and meta.get('selection')=='none' and meta.get('cards')==[]
        and meta.get('setup_choice') is None and meta.get('completion_audit')==audit,'task still pending or completion changed')
    executor.verify_setup_origin(meta.get('setup_origin'),phase='Play')
    require(meta['setup_origin']=={**origin,'live_phase':'Play'} and len(choices)==1,'capture changed after selection')
    return after,dict(kind='turn_setup_plan_continued',setup_origin=copy.deepcopy(origin),
        turn_setup_choices=copy.deepcopy(plans),actual_choices=choices,post_setup_metadata=copy.deepcopy(meta),
        combat_identity=identity,identity_basis='original_live_GamblingChip_FromHand_capture_and_exact_tokens')
