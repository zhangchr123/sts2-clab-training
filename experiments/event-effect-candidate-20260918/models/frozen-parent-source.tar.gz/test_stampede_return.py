"""Actual power/child task evidence, never a natural training or win-rate sample."""
import copy
import unittest
import uuid
from pathlib import Path

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

SOURCE_ROOT = Path('D:/sts2-training/staging/secret-catastrophe-return/sts2-solver-bridge')


class StampedeReturns(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def test_original_pending_multioption_child_remains_manual(self):
        source = SOURCE_ROOT / 'outputs/defect-acquisition-grid-20260914a-training-1-023'
        rows = read_lines(source / 'trace.jsonl')
        # Keep the actual Frantic Escape skill in hand and play the other
        # attacks, leaving only Dagger Throw eligible for original Stampede RNG.
        # This alternate action sequence is a declared diagnostic intervention.
        self.assertEqual([c['id'] for c in rows[988]['response']['hand']],
            ['CARD.EXTERMINATE', 'CARD.TESLA_COIL', 'CARD.DAGGER_THROW', 'CARD.FRANTIC_ESCAPE'])
        label = 'stampede-manual-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        matched, passed = 0, False
        try:
            for row in rows[:989]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                response = send(row['request'])
                self.assertEqual(checked_public(response), checked_public(row['response']))
                matched += 1
            send(cmd='action', action='play_card', args={'card_index':0})
            kept = send(cmd='action', action='play_card', args={'card_index':0,'target_index':0})
            self.assertEqual([c['id'] for c in kept['hand']], ['CARD.DAGGER_THROW','CARD.FRANTIC_ESCAPE'])
            after = send(cmd='action', action='end_turn')
            self.assertEqual(after['decision'], 'card_select')
            self.assertEqual(len(after['cards']), 2)
            event = after['choice_audit']['original_returns'][0]
            self.assertEqual(event['source_id'], 'DAGGER_THROW')
            self.assertEqual(event['raw_source_count_at_entry'], 2)
            self.assertFalse(event['verified'])
            self.assertFalse(event['original_task_completed_successfully'])
            self.assertFalse(event['nested_auto_play_task_completed_successfully'])
            self.assertFalse(event['nested_power_hook_task_completed_successfully'])
            actual = send(cmd='action', action='select_cards', args={'indices':'0'})
            self.assertEqual(actual['decision'], 'combat_play')
            self.assertEqual(actual['player_turn'], 5)
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='original_public_prefix_then_early_end_turn_diagnostic',
                public_prefix_responses_verified=matched, original_trace=str(source / 'trace.jsonl'),
                historical_prefix_last_index=988,
                intervention='Play Exterminate and Tesla Coil, keep Frantic Escape, then end turn and choose option 0',
                hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_original_full_solver_plan_and_corrupted_task_rejection(self):
        batch = SOURCE_ROOT / 'outputs/defect-acquisition-grid-20260914a'
        name = batch.name + '-training-1-023'
        source = SOURCE_ROOT / 'outputs' / name
        audit = read_json(batch / 'training' / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'stampede-full-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        executor, matched, passed = None, 0, False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
            real_solve = executor.solve
            supplied = False
            def recorded_then_actual(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied: return real_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded_then_actual
            final = executor.advance(before)
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            proofs = [p for p in executor.solve_calls[0].get('replay', [])
                if p.get('kind') == 'original_choice_return_completed'
                and p['actual_choice_audit']['parent']['action'] == 'end_turn']
            self.assertEqual(len(proofs), 1)
            proof = proofs[0]
            self.assertEqual(proof['selected_cards'][0]['CardId'], 'GO_FOR_THE_EYES')
            self.assertEqual(proof['plan']['Timing'], 'PlayerTurnEnd')
            self.assertFalse(proof['selection_request_sent'])
            self.assertFalse(proof['remaining_battle_plan_stopped'])
            verified = validate_replay_evidence(executor.solve_calls, traces)
            self.assertTrue(verified['verified'])
            binding = next(b for b in verified['bindings'] if b['call_index'] == 0
                and traces[b['parent_trace_index']]['request'].get('action') == 'end_turn')
            parent_index, query_index = binding['parent_trace_index'], binding['query_trace_index']
            self.assertEqual(traces[parent_index]['response']['player_turn'], 5)
            self.assertEqual(traces[parent_index]['response']['decision'], 'combat_play')
            self.assertIn(final['decision'], ('card_reward', 'map_select', 'game_over'))
            # Change both retained proof and original trace observer data. The
            # independent replay validator must still reconstruct and reject it.
            mutations = [('nested_auto_play_task_completed_successfully', False),
                ('nested_power_hook_task_completed_successfully', False),
                ('original_task_completed_successfully', False), ('source_is_actual_parent_object', True),
                ('nested_power_hook_source_is_original_object', False), ('nested_auto_play_source_is_original_object', False),
                ('nested_parent_power_id', 'UNRELATED'), ('nested_parent_power_amount', 2),
                ('nested_auto_play_callsite', 'Catastrophe.OnPlay.CardCmd.AutoPlay'),
                ('nested_auto_play_source_key_at_entry', 'STRIKE_DEFECT+0'),
                ('nested_source_card_key', 'STRIKE_DEFECT+0'), ('nested_auto_play_index', 1),
                ('nested_auto_play_total_calls', 2), ('nested_power_hook_total_calls', 2),
                ('player_phase_at_entry', 'Play'), ('player_phase_after_action', 'End'),
                ('player_turn_after_action', 4), ('raw_source_count_at_entry', 2),
                ('raw_source_count_at_return', 2), ('selector_invocations_after', -1),
                ('selector_pending_after', True), ('filter_is_null', False), ('min_select', 0)]
            for field, value in mutations:
                bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                bad_proof = next(p for p in bad_calls[0]['replay'] if p.get('actual_choice_audit', {}).get('parent', {}).get('action') == 'end_turn')
                for record in (bad_proof['actual_choice_audit'],
                        bad_traces[parent_index]['response']['choice_audit'],
                        bad_traces[query_index]['response']['completion_audit']):
                    record['original_returns'][0][field] = value
                with self.subTest(field=field), self.assertRaises(ValueError):
                    validate_replay_evidence(bad_calls, bad_traces)
            for field in ('CardId', 'StateKey', 'UpgradeLevel', 'SourceOccurrence', 'OptionOccurrence'):
                bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                bad_proof = next(p for p in bad_calls[0]['replay'] if p.get('actual_choice_audit', {}).get('parent', {}).get('action') == 'end_turn')
                for record in (bad_proof['actual_choice_audit'],
                        bad_traces[parent_index]['response']['choice_audit'],
                        bad_traces[query_index]['response']['completion_audit']):
                    card = record['original_returns'][0]['returned_cards'][0]
                    card[field] = card[field]+1 if type(card[field]) is int else 'UNRELATED'
                with self.subTest(token=field), self.assertRaises(ValueError): validate_replay_evidence(bad_calls,bad_traces)
            for mutation in ('missing', 'submitted', 'stopped', 'setup'):
                bad_calls = copy.deepcopy(executor.solve_calls)
                bad_proof = next(p for p in bad_calls[0]['replay'] if p.get('actual_choice_audit', {}).get('parent', {}).get('action') == 'end_turn')
                if mutation == 'missing': bad_calls[0]['replay'].remove(bad_proof)
                elif mutation == 'submitted': bad_proof['selection_request_sent'] = True
                elif mutation == 'stopped': bad_proof['remaining_battle_plan_stopped'] = True
                else: bad_proof['actual_next_turn_setup']['live_same_combat'] = False
                with self.assertRaises(ValueError): validate_replay_evidence(bad_calls, traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='recorded_full_solver_envelope_diagnostic',
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                public_prefix_responses_verified=matched, original_source=audit['actual_source_evidence'],
                solver_calls=executor.solve_calls if executor else [], hidden_state_or_rng_equality_claimed=False)
            bridge.close()


if __name__ == '__main__': unittest.main()
