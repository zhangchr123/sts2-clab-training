"""Bounded JSON protocol smoke test against the isolated solver bridge."""
import json
import os
from pathlib import Path
import queue
import subprocess
import threading

ROOT = Path(__file__).resolve().parent


class Bridge:
    def __init__(self, label="probe"):
        (ROOT / "outputs").mkdir(exist_ok=True)
        self.log = (ROOT / "outputs" / f"{label}.stderr.log").open("w", encoding="utf-8")
        self.proc = subprocess.Popen(
            ["dotnet", str(ROOT / "runtime/host/bin/Debug/net9.0/SolverBridge.dll"), str(ROOT)],
            cwd=ROOT.parent / "sts2-cli", stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=self.log, text=True, encoding="utf-8",
        )
        self.responses = queue.Queue()
        self.rows = []
        def read():
            for line in self.proc.stdout:
                if line.startswith("{"):
                    self.responses.put(json.loads(line))
            self.responses.put(None)
        self.reader = threading.Thread(target=read, daemon=True)
        self.reader.start()
        try:
            ready = self.receive()
            if ready.get("type") != "ready":
                raise RuntimeError("Bridge did not initialize: " + json.dumps(ready))
        except Exception:
            self.close()
            raise

    def receive(self):
        try:
            response = self.responses.get(timeout=45)
        except queue.Empty:
            raise TimeoutError("Bridge response timed out after 45 seconds; inspect this worker's stderr log") from None
        if response is None:
            raise RuntimeError("Bridge closed; inspect stderr log")
        self.rows.append(response)
        return response

    def send(self, **cmd):
        self.proc.stdin.write(json.dumps(cmd) + "\n")
        self.proc.stdin.flush()
        return self.receive()

    def close(self):
        self.proc.terminate()
        try:
            self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait(timeout=5)
        self.reader.join(timeout=5)
        self.proc.stdin.close()
        self.proc.stdout.close()
        self.log.close()


def main():
    bridge = Bridge()
    try:
        bridge.send(cmd="start_run", character="Defect", ascension=10, seed="solver-bridge-1")
        state = bridge.send(cmd="enter_room", type="combat", encounter="SHRINKER_BEETLE_WEAK")
        result = bridge.send(cmd="solve", budget_ms=1000)
        assert result["type"] == "solver_result", result
        state = replay_basic(bridge, state, result)
        comparison = {"predicted": result["snapshot"], "actual_decision": state.get("decision"),
                      "actual_hp": state["player"]["hp"], "unmirrored": result["unmirrored"],
                      "compensated": result["compensated"]}
        print(json.dumps(comparison, ensure_ascii=True))
        assert state["player"]["hp"] == result["snapshot"]["PlayerHp"], comparison
        assert state.get("decision") != "combat_play" and result["snapshot"]["AllEnemiesDead"], comparison
        bridge.send(cmd="quit")
    finally:
        (ROOT / "outputs/probe.json").write_text(json.dumps(bridge.rows, ensure_ascii=False, indent=2), encoding="utf-8")
        bridge.close()


def replay_basic(bridge, state, result):
    """Test executor for ordinary cards/potions. Reject unsupported choice flows."""
    for action in result["actions"]:
        if state.get("decision") != "combat_play":
            break
        assert not action.get("Choice") and not action.get("NestedChoices") and not action.get("TurnStartChoices"), "Choice replay requires adapter"
        if action["Kind"] == "EndTurn":
            state = bridge.send(cmd="action", action="end_turn")
        elif action["Kind"] in ("PlayCard", "UsePotion"):
            if action["Kind"] == "PlayCard":
                matches = [c for c in state["hand"] if c["id"].split(".")[-1] == action["CardId"]]
                card = matches[action["CardOccurrence"]]
                args = {"card_index": card["index"]}
                method = "play_card"
            else:
                args = {"potion_index": action["PotionSlot"]}
                method = "use_potion"
            if action["TargetIndex"] >= 0:
                # Solver indices refer to original enemies; CLI indexes living enemies.
                # Restrict this smoke executor to single-enemy fixtures.
                assert len(state["enemies"]) == 1, "Multi-enemy targets require combat-id mapping"
                args["target_index"] = state["enemies"][0]["index"]
            state = bridge.send(cmd="action", action=method, args=args)
        else:
            raise AssertionError(f"Unsupported replay action: {action['Kind']}")
        assert state.get("type") != "error", state
    return state


if __name__ == "__main__":
    main()
