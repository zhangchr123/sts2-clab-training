"""Synthetic predictor fixtures only; no engine, game, model training or LLM."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from decision_data import DataContractError, enumerate_candidates
from initial_policy import FEATURE_NAMES, InitialPolicy, POLICY_VERSION
from mechanism_facts import ENGINE_SHA256
from selection_policy import SelectionPolicy, validate_selection_evidence
from survival_policy import SurvivalPolicy, VERSION
from test_initial_policy import card, state as reward_state
from test_selection_policy import selection_state
from train_act_survival import TARGET, VERSION as MODEL_FORMAT


FACTS = {"version": "synthetic-facts-v1", "engine_sha256": ENGINE_SHA256,
         "registry_sha256": "a" * 64, "coverage": "synthetic fixture, not engine evidence"}
CONFIG = {"solver_backend": "beam", "first_budget_ms": 2500,
          "search_profile": {"beam_width": 30, "recover_deferred_turn_frontier": False}}


class Draw:
    def __init__(self, coin, index):
        self.coin, self.index = coin, index
        self.pool_sizes = []

    def random(self):
        return self.coin

    def choice(self, values):
        self.pool_sizes.append(len(values))
        return values[self.index]


def current(act=1):
    value = reward_state([card("STRIKE_DEFECT", damage=6), card("BALL_LIGHTNING", damage=7)])
    value["context"].update(act=act, integrity_recovery_used=False)
    return value


class SurvivalPolicyTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.directory = Path(temp.name)
        facts = patch("initial_policy.verified_source", side_effect=lambda _: copy.deepcopy(FACTS))
        facts.start()
        self.addCleanup(facts.stop)

    def artifact(self, weights=None, *, changes=None):
        fallback = InitialPolicy(prior_path=None, random_seed="untouched")
        model = {"format": MODEL_FORMAT, "mode": "act1_survival", "target_semantics": TARGET,
            "feature_policy_version": POLICY_VERSION, "feature_names": list(FEATURE_NAMES),
            "means": [0.] * len(FEATURE_NAMES), "scales": [1.] * len(FEATURE_NAMES),
            "weights": [0.] + [float((weights or {}).get(name, 0.)) for name in FEATURE_NAMES],
            "feature_min": [0.] * len(FEATURE_NAMES), "feature_max": [1.] * len(FEATURE_NAMES),
            "feature_prior_sha256": fallback.prior.source["sha256"], "feature_mechanism_facts": FACTS,
            "calibrated_probability": False, "counterfactual_labels": False,
            "chosen_action_is_optimal_label": False,
            "deployment_scope": {"character": "Defect", "ascension": 10, "mode": "standard", "act": 1},
            "frozen_followup": {"solver": copy.deepcopy(CONFIG), "policy": fallback.provenance,
                "run_conditions": {"character": "Defect", "ascension": 10, "mode": "standard"},
                "runtime": {}, "sampling_sources": {}, "sampling_limits": {}}}
        model.update(changes or {})
        path = self.directory / "synthetic-model.json"
        path.write_text(json.dumps(model), encoding="utf-8")
        return path, fallback

    def policy(self, weights=None, **kwargs):
        path, fallback = self.artifact(weights)
        return SurvivalPolicy(path, solver_config=copy.deepcopy(CONFIG), fallback=fallback, **kwargs)

    def test_act1_is_pure_model_ranking_and_score_has_no_rng_or_execution(self):
        policy = self.policy({"is_skip": 2.}, epsilon=0)
        state = current()
        before = copy.deepcopy(state)
        rng = policy.rng.getstate(), policy.fallback.rng.getstate()
        rule = policy.fallback.score(state)
        scored = policy.score(state)
        self.assertEqual(state, before)
        self.assertEqual((policy.rng.getstate(), policy.fallback.rng.getstate()), rng)
        self.assertEqual((policy.choice_count, policy.fallback.choice_count), (0, 0))
        self.assertTrue(scored["model"]["active"])
        self.assertEqual(scored["effective_scorer"], MODEL_FORMAT)
        self.assertEqual(scored["score_semantics"], "uncalibrated_Act1_survival_proxy_score_not_A10_win_probability")
        self.assertEqual(scored["feature_policy_version"], POLICY_VERSION)
        self.assertTrue(all(r["score"] == (2. if r["is_skip"] else 0.) for r in scored["scores"]))
        self.assertEqual([r["rule_score"] for r in scored["scores"]], [r["score"] for r in rule["scores"]])
        self.assertEqual([r["delta_from_skip"] for r in scored["scores"]], [-2., -2., 0.])
        self.assertTrue(any(r["model_coverage"]["out_of_training_range"] for r in scored["scores"]))
        self.assertFalse(scored["calibrated"])
        self.assertIn("changing_policy_changes_the_label_distribution", scored["policy_limitations"])
        self.assertEqual(policy.choose(state)["request"]["action"], "skip_card_reward")
        self.assertNotEqual(max(rule["scores"], key=lambda r: r["score"])["request"]["action"], "skip_card_reward")

    def test_later_acts_never_call_act1_scorer_and_keep_rule_meaning(self):
        policy = self.policy({"is_skip": 999.})
        identity = policy.provenance
        with patch.object(policy.scorer, "score_requests", side_effect=AssertionError("Act1 model escaped scope")):
            for act in (2, 3):
                state = current(act)
                rule = policy.fallback.score(state)
                score = policy.score(state)
                self.assertFalse(score["model"]["active"])
                self.assertEqual(score["effective_scorer"], POLICY_VERSION)
                self.assertEqual(score["score_semantics"], rule["score_semantics"])
                self.assertEqual(score["feature_policy_version"], POLICY_VERSION)
                self.assertNotIn("target_semantics", score)
                for actual, expected in zip(score["scores"], rule["scores"]):
                    for key in ("score", "delta_from_skip", "features", "missing", "uncertainty"):
                        self.assertEqual(actual[key], expected[key])
                self.assertEqual(policy.provenance, identity)

    def test_constructor_rejects_wrong_scope_solver_and_feature_sources(self):
        path, fallback = self.artifact()
        for setting in ({"character": "Ironclad"}, {"ascension": 9}, {"ascension": True}, {"mode": "daily"}):
            with self.subTest(setting=setting), self.assertRaises(DataContractError):
                SurvivalPolicy(path, solver_config=CONFIG, fallback=fallback, **setting)
        for config in (None, {}, {**CONFIG, "first_budget_ms": 1},
                       {**CONFIG, "search_profile": {"beam_width": 30, "recover_deferred_turn_frontier": 0}}):
            with self.subTest(config=config), self.assertRaises(DataContractError):
                SurvivalPolicy(path, solver_config=config, fallback=fallback)
        for changes in ({"feature_policy_version": "initial-stat-mechanism-v2"},
                        {"feature_prior_sha256": "f" * 64},
                        {"feature_mechanism_facts": {**FACTS, "registry_sha256": "b" * 64}},
                        {"frozen_followup": {"solver": CONFIG, "run_conditions": {"character": "Defect"}}}):
            path, fallback = self.artifact(changes=changes)
            with self.subTest(changes=changes), self.assertRaises(DataContractError):
                SurvivalPolicy(path, solver_config=CONFIG, fallback=fallback)
        for epsilon in (True, -1, 2, float("nan")):
            with self.subTest(epsilon=epsilon), self.assertRaises(DataContractError):
                self.policy(epsilon=epsilon)

    def test_actual_scope_is_checked_for_both_model_and_fallback(self):
        policy = self.policy()
        for changes in ({"act": True}, {"act": 0}, {"act": 4}, {"act": "1"}, {"ascension": 9},
                        {"integrity_recovery_used": True}, {"combat_in_progress": True}):
            for act in (1, 2):
                state = current(act)
                state["context"].update(changes)
                with self.subTest(changes=changes, act=act), self.assertRaises(DataContractError):
                    policy.score(state)
        state = current()
        del state["context"]["integrity_recovery_used"]
        with self.assertRaises(DataContractError):
            policy.score(state)

    def test_explicit_epsilon_and_tie_probabilities_match_base_policy(self):
        policy = self.policy({"base_damage_per_cost": 1.})
        state = current()
        state["cards"][1]["stats"]["damage"] = 6
        policy.rng = Draw(.9, 1)
        exploit = policy.choose(state)
        self.assertEqual(policy.rng.pool_sizes, [2])
        self.assertFalse(exploit["exploration"]["explored"])
        self.assertAlmostEqual(exploit["exploration"]["chosen_probability"], .1/3 + .9/2)
        self.assertEqual(exploit["exploration"]["greedy_tie_count"], 2)
        policy.rng = Draw(.0, -1)
        explore = policy.choose(state)
        self.assertTrue(explore["exploration"]["explored"])
        self.assertEqual(policy.rng.pool_sizes, [3])
        self.assertEqual(explore["request"]["action"], "skip_card_reward")
        self.assertAlmostEqual(explore["exploration"]["chosen_probability"], .1/3)
        self.assertEqual(explore["policy_provenance"]["choice_count"], 1)
        self.assertEqual(policy.choice_count, 2)
        self.assertEqual(policy.fallback.choice_count, 0)

    def test_strict_requests_and_partial_coverage_are_not_full_enumeration(self):
        policy = self.policy()
        state = current()
        requests = [enumerate_candidates(state)["candidates"][0]["request"]]
        score = policy.score_requests(state, requests)
        self.assertFalse(score["evaluated_candidates_complete"])
        self.assertEqual(score["candidate_count"], 3)
        self.assertEqual(len(score["scores"]), 1)
        for invalid in ([], requests * 2, [{"cmd": "action", "action": "set_hp"}]):
            with self.assertRaises(DataContractError):
                policy.score_requests(state, invalid)
        candidates = enumerate_candidates(state)
        candidates["candidates"].pop()
        with self.assertRaises(DataContractError):
            policy.score(state, candidates)

    def test_implicit_selection_wrap_preserves_exact_evidence_and_act_scope(self):
        base = self.policy({"selected_count": 1.}, seed="implicit-survival")
        policy = SelectionPolicy(base, max_evaluations=9)
        for act in (1, 2):
            state = selection_state()
            state["context"].update(act=act, ascension=10, integrity_recovery_used=False)
            before = base.rng.getstate()
            scored = policy.score(state, selection_purpose="acquire")
            self.assertEqual(base.rng.getstate(), before)
            self.assertEqual(scored["model"]["active"], act == 1)
            self.assertEqual(scored["candidate_count"], 3554627472076)
            self.assertEqual(scored["evaluated_candidate_count"], 9)
            self.assertFalse(scored["evaluated_candidates_complete"])
            picked = policy.choose(state, selection_purpose="acquire")
            self.assertTrue(validate_selection_evidence(state, enumerate_candidates(state), picked)["valid"])
            self.assertEqual(picked["policy_provenance"]["id"], VERSION)
            self.assertEqual(picked["scoring"]["feature_policy_version"], POLICY_VERSION)
        self.assertEqual(base.choice_count, 2)

    def test_provenance_has_immutable_artifact_scope_and_fallback_identity(self):
        path, fallback = self.artifact()
        config = copy.deepcopy(CONFIG)
        policy = SurvivalPolicy(path, solver_config=config, fallback=fallback)
        expected = hashlib.sha256(path.read_bytes()).hexdigest()
        identity = policy.provenance
        self.assertEqual(identity["version"], expected)
        self.assertEqual(identity["kind"], "model")
        self.assertEqual(identity["fallback"]["version"], POLICY_VERSION)
        self.assertEqual(identity["fallback"]["acts"], [2, 3])
        self.assertEqual(identity["model_scope"]["act"], 1)
        identity["mechanism_facts"]["registry_sha256"] = "b" * 64
        policy.model["weights"][0] = 999
        policy.source["sha256"] = "changed"
        config["first_budget_ms"] = 9
        self.assertEqual(policy.sha256, expected)
        self.assertEqual(policy.model["weights"][0], 0.)
        self.assertEqual(policy.provenance["solver_requested_config"], CONFIG)
        policy.score(current())
        policy.scorer.model["weights"][0] = 999
        for act in (1, 2):
            with self.assertRaisesRegex(DataContractError, "changed after model loading"):
                policy.score(current(act))

    def test_changed_fallback_sources_are_rejected_even_outside_model_scope(self):
        policy = self.policy()
        policy.fallback.mechanism_source["registry_sha256"] = "b" * 64
        with self.assertRaisesRegex(DataContractError, "frozen model"):
            policy.score(current(2))


if __name__ == "__main__":
    unittest.main()
