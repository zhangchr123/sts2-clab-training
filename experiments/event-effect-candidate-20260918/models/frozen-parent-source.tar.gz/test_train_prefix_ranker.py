"""Meaningful paired-data invariants on synthetic observations; no game or fit data."""
import copy
import unittest

from decision_data import enumerate_candidates
from train_prefix_ranker import candidate_features, pair_examples, gate_observations, build_groups
from test_prefix_interventions import state


class PrefixTrainingTests(unittest.TestCase):
    def fixture(self):
        current = state()
        candidates = enumerate_candidates(current)["candidates"]
        arms = [{"arm_id": str(i), "candidate_id": row["candidate_id"], "request": row["request"],
                 "is_duplicate_control": False} for i, row in enumerate(candidates)]
        skip = next(a for a in arms if a["request"]["action"] == "skip_card_reward")
        arms.append({**skip, "arm_id": "repeat", "is_duplicate_control": True})
        gate = {"gate_id": "test", "seed": "synthetic-train", "state": current, "candidates": candidates, "arms": arms}
        audit = {"passed": True, "gates": [{"gate_id": "test", "complete_candidate_group": True}],
                 "arms": [{"gate_id": "test", "arm": arm, "usable_observation": True,
                            "observed_label": {"hp": hp}} for arm, hp in zip(arms, [55, 45, 49])]}
        return gate, audit

    def test_skip_control_average_and_pair_direction_weight(self):
        gate, audit = self.fixture()
        rows = gate_observations(gate, audit)
        chosen = next(r for r in rows if not r["is_skip"])
        skipped = next(r for r in rows if r["is_skip"])
        self.assertEqual(skipped["actual_hp"], 47)
        self.assertEqual(chosen["target"], 8 / 75)
        examples = pair_examples(rows)
        self.assertEqual(sum(r["weight"] for r in examples), 1)
        self.assertEqual(sum(r["target"] for r in examples), 0)
        self.assertTrue(all(examples[0]["features"][k] == -examples[1]["features"][k]
                            for k in examples[0]["features"]))

    def test_state_only_features_cancel_and_skip_is_zero(self):
        gate, _ = self.fixture()
        features = candidate_features(gate)
        self.assertTrue(all(value == 0 for row in features.values() if row["is_skip"]
                            for value in row["features"].values()))
        self.assertEqual({len(row["features"]) for row in features.values()}, {119})

    def test_missing_one_candidate_or_control_excludes_whole_gate(self):
        for position in (0, 1, 2):
            gate, audit = self.fixture()
            audit["arms"][position]["usable_observation"] = False
            with self.assertRaises(ValueError):
                gate_observations(gate, audit)

    def test_planned_seeds_are_retained_and_failed_group_never_becomes_label(self):
        gate, audit = self.fixture()
        second = {**copy.deepcopy(gate), "gate_id": "second", "seed": "synthetic-second"}
        protocol = {"gates": [gate, second]}
        audit["gates"].append({"gate_id": "second", "complete_candidate_group": False})
        groups = build_groups(protocol, audit)
        self.assertEqual(sum(len(g["planned_gates"]) for g in groups.values()), 2)
        self.assertEqual(sum(len(g["complete_gates"]) for g in groups.values()), 1)
        self.assertTrue(all(row["run_id"] != "second" for g in groups.values() for row in g["complete_gates"]))


if __name__ == "__main__":
    unittest.main()
