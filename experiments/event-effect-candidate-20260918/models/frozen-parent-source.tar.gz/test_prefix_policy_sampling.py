"""Factory and mixed explicit/implicit choices on synthetic fixtures, no worker."""
import copy
import json
import unittest
from unittest.mock import patch

import sample_runs
import test_prefix_health_policy as fixtures
from compare_batches import policy_identity
from decision_data import DataContractError, enumerate_candidates
from initial_policy import InitialPolicy, POLICY_VERSION
from prefix_health_policy import PrefixHealthPolicy, VERSION
from selection_policy import SelectionPolicy, validate_selection_evidence
from test_prefix_interventions import state
from test_selection_policy import selection_state


class PrefixPolicySamplingTests(unittest.TestCase):
    setUp = fixtures.PrefixHealthPolicyTests.setUp
    write = fixtures.PrefixHealthPolicyTests.write
    fixture = fixtures.PrefixHealthPolicyTests.fixture
    register = fixtures.PrefixHealthPolicyTests.register

    def factory(self, seed="prefix-factory", **kwargs):
        return sample_runs.build_policy(seed, copy.deepcopy(fixtures.CONFIG), model_path=self.model_path,
                                        selection_budget=8, **kwargs)

    @staticmethod
    def implicit():
        current = selection_state(n=9, minimum=0, maximum=9)
        current["context"].update(act=1, ascension=10, floor=1, integrity_recovery_used=False)
        return current

    def test_factory_loads_registered_prefix_protocol_and_wraps_scoped_model(self):
        self.fixture()
        with patch.object(sample_runs, "Bridge") as bridge:
            policy = self.factory(epsilon=.27)
        bridge.assert_not_called()
        self.assertIsInstance(policy, SelectionPolicy)
        self.assertIsInstance(policy.base, PrefixHealthPolicy)
        self.assertEqual(policy.max_evaluations, 8)
        self.assertEqual(policy.provenance["id"], VERSION)
        self.assertEqual(policy.provenance["source_protocol"], self.model_data["source_protocol"])
        self.assertEqual(policy.provenance["epsilon"], .27)
        self.assertEqual(policy.provenance["version"], self.receipt["model"]["sha256"])
        self.assertEqual(policy.provenance["selection_search"], policy.parameters)
        self.assertFalse((self.directory / "outputs").exists())

    def test_implicit_choices_keep_first_reward_scope_and_one_global_rng_and_counter(self):
        self.fixture()
        policy = self.factory(seed="mixed", epsilon=.37)
        reference = SelectionPolicy(InitialPolicy(epsilon=.37, random_seed="mixed"), max_evaluations=8)
        implicit = self.implicit()
        space = enumerate_candidates(implicit)
        self.assertEqual(space["representation"], "ordered_selection_implicit_v1")
        before_rng = policy.base.rng.getstate()
        first_preview = policy.score(implicit, selection_purpose="remove")
        self.assertEqual(first_preview, policy.score(implicit, selection_purpose="remove"))
        self.assertEqual(policy.base.rng.getstate(), before_rng)
        self.assertEqual(policy.base.choice_count, 0)
        self.assertIsNone(policy.base.gate_use)
        with patch("prefix_health_policy.predict", side_effect=AssertionError("Implicit selection called HP model")):
            picked = policy.choose(implicit, selection_purpose="remove")
        expected = reference.choose(implicit, selection_purpose="remove")
        self.assertEqual(picked["request"], expected["request"])
        self.assertEqual(picked["exploration"], expected["exploration"])
        self.assertEqual(policy.base.rng.getstate(), reference.base.rng.getstate())
        self.assertEqual(policy.base.choice_count, 1)
        self.assertFalse(picked["scoring"]["model"]["active"])
        self.assertIsNone(policy.base.gate_use)
        validate_selection_evidence(implicit, space, picked)
        # A pending model gate preview also leaves the global RNG at position 1.
        gate = state()
        saved_rng = policy.base.rng.getstate()
        gate_preview = policy.score(gate)
        self.assertTrue(gate_preview["model"]["active"])
        self.assertEqual(policy.base.rng.getstate(), saved_rng)
        first_reward = policy.choose(gate)
        self.assertEqual(first_reward["exploration"]["choice_count"], 1)
        self.assertEqual(policy.base.gate_use["choice_count"], 1)
        self.assertTrue(first_reward["scope_transition"]["consumed_first_eligible_gate"])
        self.assertEqual(policy.base.choice_count, 2)
        # Match the new RNG position, then verify later implicit + explicit
        # fallback advances exactly like the existing v3 wrapper.
        reference.base.rng.setstate(policy.base.rng.getstate())
        reference.base.choice_count = policy.base.choice_count
        commit = policy.base.gate_use
        for current, purpose in ((implicit, "remove"), (state(floor=3), None)):
            actual = policy.choose(current, selection_purpose=purpose)
            expected = reference.choose(current, selection_purpose=purpose)
            self.assertEqual(actual["request"], expected["request"])
            for key, value in expected["exploration"].items():
                self.assertEqual(actual["exploration"][key], value)
            self.assertEqual(policy.base.rng.getstate(), reference.base.rng.getstate())
            self.assertEqual(policy.base.choice_count, reference.base.choice_count)
            self.assertFalse(actual["scoring"]["model"]["active"])
            self.assertEqual(policy.base.gate_use, commit)
        self.assertEqual(policy.base.choice_count, 4)

    def test_run_identity_is_constant_across_choices_and_macro_seeds(self):
        self.fixture()
        first, second = self.factory("first-seed"), self.factory("second-seed")
        self.assertEqual(policy_identity(first.provenance), policy_identity(second.provenance))
        self.assertNotIn("random_seed", first.provenance["fallback"])
        identity = first.provenance
        for current in (self.implicit(), state(), state(floor=3)):
            picked = first.choose(current)
            self.assertEqual(first.provenance, identity)
            self.assertEqual({k: v for k, v in picked["policy_provenance"].items() if k != "choice_count"}, identity)
        self.assertEqual(second.base.choice_count, 0)
        self.assertIsNone(second.base.gate_use)
        self.assertTrue(second.choose(state())["scoring"]["model"]["active"])

    def test_missing_relative_or_tampered_protocol_is_rejected_before_worker(self):
        for source in (None, {}, {"path": "protocol.json"}, {"path": ""}, {"path": 123}):
            self.fixture()
            self.model_data["source_protocol"] = source
            self.register()
            with patch.object(sample_runs, "Bridge") as bridge, self.assertRaises(ValueError):
                self.factory()
            bridge.assert_not_called()
        self.fixture()
        self.model_data["source_protocol"]["sha256"] = "0" * 64
        self.register()
        with self.assertRaises(ValueError):
            self.factory()
        self.fixture()
        self.receipt["status"] = "fit_started"
        self.write(self.receipt_path, self.receipt)
        with self.assertRaises(ValueError):
            self.factory()

    def test_declared_scope_and_solver_mismatch_stay_fail_closed(self):
        self.fixture()
        with self.assertRaises(DataContractError):
            self.factory(ascension=9)
        with self.assertRaises(DataContractError):
            sample_runs.build_policy("bad-config", {**fixtures.CONFIG, "first_budget_ms": 3000},
                                     model_path=self.model_path)
        self.assertFalse((self.directory / "outputs").exists())


if __name__ == "__main__":
    unittest.main()
