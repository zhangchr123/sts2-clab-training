"""Public card identity residual policy; no calibrated values or deployment.

Individual acquisitions retain their existing 227 features. Known bundles and
ordered acquisitions sum those features over their selected public cards.
Every term comes from the current public candidate; unknown effects stay unknown.
"""
import copy
import json
import math
from pathlib import Path

from decision_data import DataContractError, enumerate_candidates, state_hash
from initial_policy import InitialPolicy, POLICY_VERSION
from run_metadata import file_evidence

from whole_run_policy import ROOT as BASE_ROOT, FEATURE_SOURCES as BASE_SOURCES
from contextual_policy import PARAMETERS as CONTEXT_PARAMETERS, FEATURE_SOURCES as CONTEXT_SOURCES
from card_identity_features import PARAMETERS as IDENTITY_PARAMETERS, features as identity_features
from contextual_policy import residual_features as contextual_residual
from acquisition_residual_features import features as acquisition_features

VERSION = "whole-run-card-identity-residual-v2"
ROOT = Path(__file__).resolve().parent
PARAMETERS = (*CONTEXT_PARAMETERS, *IDENTITY_PARAMETERS)
LOCAL_SOURCES = ("card_identity_policy.py", "card_identity_features.py", "card_identity_vocabulary.py",
                 "acquisition_residual_features.py")
FEATURE_SOURCES = (*CONTEXT_SOURCES, *LOCAL_SOURCES)


def feature_sources():
    return {name: file_evidence(ROOT / name) for name in FEATURE_SOURCES}


def residual_features(state, row, candidate):
    values = acquisition_features(state, row, candidate)
    if values is None:
        values = contextual_residual(state, row, candidate)
        values.update(identity_features(row, candidate))
    if tuple(values) != PARAMETERS:
        raise DataContractError("Card identity parameter schema drift")
    return values


def make_artifact(parameters, solver_config, *, training):
    base = InitialPolicy()
    return {"format": VERSION, "parameters": dict(parameters), "parameter_names": list(PARAMETERS),
        "solver_requested_config": copy.deepcopy(solver_config), "training": copy.deepcopy(training),
        "source_files": feature_sources(),
        "prior_source": base.prior.source, "mechanism_facts": base.mechanism_source,
        "score_semantics": "current_rule_score_plus_learned_public_residual_not_outcome_probability",
        "rule_policy_version": POLICY_VERSION,
        "calibrated_probability": False, "first_boss_success_verified": False,
        "automatic_deployment": False}


class CardIdentityPolicy(InitialPolicy):
    def __init__(self, path, *, solver_config, seed, epsilon=0.):
        super().__init__(random_seed=seed, epsilon=epsilon)
        self.path = Path(path).resolve()
        self.artifact = json.loads(self.path.read_text(encoding="utf-8"))
        a = self.artifact
        if (a.get("format") != VERSION or a.get("parameter_names") != list(PARAMETERS)
                or set(a.get("parameters", {})) != set(PARAMETERS)
                or any(type(v) not in (float, int) or not math.isfinite(v) or abs(v) > 4
                       for v in a["parameters"].values())
                or a.get("solver_requested_config") != solver_config
                or a.get("prior_source") != self.prior.source or a.get("mechanism_facts") != self.mechanism_source
                or a.get("source_files") != feature_sources()
                or a.get("calibrated_probability") is not False):
            raise DataContractError("Invalid whole-run policy parameters, scope or frozen feature source")
        self.source = file_evidence(self.path)
        self._artifact_hash = state_hash(a)

    @property
    def provenance(self):
        original = super().provenance
        return {**original, "kind": "search", "id": VERSION, "version": self.source["sha256"],
                "policy_source": copy.deepcopy(self.source), "score_semantics": self.artifact["score_semantics"],
                "solver_requested_config": self.artifact["solver_requested_config"],
                "training_method": "whole_original_run_parameter_search", "automatic_deployment": False}

    def _adjust(self, state, packet):
        if (file_evidence(self.path) != self.source or state_hash(self.artifact) != self._artifact_hash
                or self.artifact["source_files"] != feature_sources()):
            raise DataContractError("Whole-run policy changed after loading")
        ctx = state.get("context", {})
        if ctx.get("ascension") != 10 or ctx.get("act") not in (1, 2, 3) or ctx.get("combat_in_progress") is not False:
            raise DataContractError("Whole-run search policy requires actual noncombat Defect A10 state")
        from decision_data import materialize_candidate
        space = enumerate_candidates(state)
        # Fresh enumeration already validates these candidates. Revalidating the
        # full explicit set for each row makes N-candidate rewards O(N squared).
        # Implicit spaces still materialize against their complete descriptor.
        by_id = None if space.get("representation") == "ordered_selection_implicit_v1" else {
            c["candidate_id"]: c for c in space["candidates"]}
        for row in packet["scores"]:
            candidate = (materialize_candidate(space, row["request"]) if by_id is None
                         else by_id[row["candidate_id"]])
            if candidate["request"] != row["request"]:
                raise DataContractError("Residual row does not match current legal action")
            features = residual_features(state, row, candidate)
            residual = sum(self.artifact["parameters"][name] * features[name] for name in PARAMETERS)
            row.update(rule_score=row["score"], search_features=features, learned_residual=residual)
            row["score"] += residual
            row["reasons"] = [{"source": POLICY_VERSION, "score": row["rule_score"]},
                              {"source": VERSION, "score": residual,
                               "explanation": "linear public residual; known multi-card acquisition sums per-card features without deck-hook simulation"}]
        skip = next((r["score"] for r in packet["scores"] if r["is_skip"]), None)
        for row in packet["scores"]:
            row["delta_from_skip"] = None if skip is None else row["score"] - skip
        packet.update(policy_id=VERSION, policy_version=self.source["sha256"],
            feature_policy_version=POLICY_VERSION, search_policy_source=self.source,
            score_semantics=self.artifact["score_semantics"])
        return packet

    def score(self, state, candidates=None, *, selection_purpose=None):
        return self._adjust(state, super().score(state, candidates, selection_purpose=selection_purpose))

    def score_requests(self, state, requests, *, selection_purpose=None):
        return self._adjust(state, super().score_requests(state, requests, selection_purpose=selection_purpose))
