"""Bind repeated, actually empty Neow's Fury effects to completed engine calls."""
import copy
import re
from hologram_series import equal_fields, integer, require

KIND='neows_empty_series_completed'


def eligible(action,state):
    from combat_executor import choice_plans
    plans=choice_plans(action)
    return (action.get('Kind')=='PlayCard' and action.get('CardId')=='NEOWS_FURY'
        and len(plans)>=2 and all(p.get('Cards')==[] for p in plans)
        and state.get('decision')!='card_select')


def proof(before,state,action,request,meta):
    from combat_executor import CombatExecutor, choice_plans
    require(eligible(action,state),'Not an empty repeated Neows action')
    plans=choice_plans(action);audit=state.get('choice_audit',{});parent=audit.get('parent',{})
    play=state.get('play_action',{})
    equal_fields(action,{'Kind':'PlayCard','CardId':'NEOWS_FURY','CardEnchantmentId':'',
        'NestedChoicesBeforePrimary':0,'EndsPlayerTurn':False},'Unsupported empty Neows repeat shape')
    require(2<=len(plans)<=64 and action.get('Choice')==plans[0] and action.get('NestedChoices')==plans[1:]
        and not action.get('TurnStartChoices') and not action.get('RelicEffects'),'Neows choice ordering differs')
    key=action.get('CardStateKey');require(isinstance(key,str),'Missing Neows fingerprint')
    replay=re.findall(r'\|replay=(\d+)\|',key)
    require(len(replay)==1 and integer(action,'ReplayCount',0,63)==int(replay[0])
        and len(plans)>=1+action['ReplayCount'],'Neows base replay fingerprint differs')
    variables=re.search(r'\|vars=([^|]*)\|',key)
    limits=re.findall(r'(?:^|;)Cards=([1-9][0-9]*)(?=;|$)',variables[1]) if variables else []
    require(len(limits)==1,'Missing original Neows card limit')
    for plan in plans:
        require(plan==dict(Effect='MoveToHand',SourcePile='Discard',Cards=[],SourceId='',ContextId='',Timing='Action'),
            'Empty series cannot discard any planned selection')
    equal_fields(before,{'type':'decision','decision':'combat_play','discard_pile_count':0,
        'player_turn':integer(action,'Turn',1)},'Original Neows discard was not empty')
    require(before.get('context',{}).get('combat_in_progress') is True,'Neows origin not in combat')
    equal_fields(audit,{'schema_version':'combat-choice-return-v2','closed':True,
        'coverage':'FromCombatPile.IsEnding_or_NeowsFury.empty_source.synchronous_empty_return_only'},'Open Neows call audit')
    require(audit.get('original_returns')==[] and not audit.get('neows_continuation'),
        'Manual or nested completion is outside empty series')
    equal_fields(parent,{'action':'play_card','card_id':'NEOWS_FURY','card_key':key,
        'player_turn':action['Turn'],'combat_active_before':True,
        'combat_id':before['player']['combat_metrics']['combat_id']},'Neows parent identity differs')
    require(isinstance(parent.get('player_id'),str) and parent['player_id'],'Missing original Neows player')
    require(isinstance(request,dict) and request.get('cmd')=='action' and request.get('action')=='play_card'
        and set(request.get('args',{}))=={'card_index','target_index'}
        and request['args']['card_index']==integer(parent,'card_index')
        and type(request['args']['target_index']) is int and request['args']['target_index']>=0,
        'Neows original action request differs')
    integer(action,'TargetIndex');integer(action,'TargetCombatId',1);integer(play,'action_id')
    equal_fields(play,{'schema_version':'original-play-action-v1','card_id':'NEOWS_FURY',
        'target_combat_id':action['TargetCombatId'],'outcome':'completed','state':'Finished',
        'completion_task_status':'RanToCompletion','on_play_entered':True,'cancellation_observed':False},
        'Neows original play did not complete')
    require(CombatExecutor.setup_state_identity(before)==CombatExecutor.setup_state_identity(state),
        'Neows completion crossed combat identity')
    events=audit.get('events');require(isinstance(events,list) and len(events)==len(plans),'Missing or extra Neows original calls')
    counter=integer(events[0],'selector_invocations_before');ending=False
    for i,event in enumerate(events):
        reason=event.get('reason');require(reason in {'empty_source_pile','combat_ending'},'Unknown Neows empty return')
        require(reason!='empty_source_pile' or not ending,'Active empty return followed combat ending')
        require(i!=0 or reason=='empty_source_pile','This bounded series must begin with an observed empty pile')
        ending |= reason=='combat_ending'
        expected=dict(event_index=i,action_id=integer(audit,'action_id',1),source_method='CardSelectCmd.FromCombatPile',
            source_pile='Discard',player_id=parent['player_id'],reason=reason,is_ending_at_entry=ending,
            original_task_completed_successfully=True,original_returned_empty_array=True,
            selector_invocations_before=counter,selector_invocations_after=counter,
            selection_executed=False,selected_cards=[])
        if not ending:
            limit=integer(event,'max_select',1,int(limits[0]))
            expected.update(combat_active_at_entry=True,combat_active_at_return=True,source_pile_count_at_entry=0,
                source_pile_count_at_return=0,min_select=0,max_select=limit,require_manual_confirmation=True,
                selector_is_headless=True,selector_pending_before=False,selector_pending_after=False)
        require(set(event)==set(expected),'Unknown Neows call fields')
        equal_fields(event,expected,'Neows original empty call did not complete without a selector')
    if ending:
        require(state.get('decision') in {'card_reward','map','game_over'}
            and state.get('type')=='decision' and state.get('context',{}).get('combat_in_progress') is False
            and state.get('context',{}).get('integrity_recovery_used') is False,'Neows ending lacks a clean terminal boundary')
    else:
        equal_fields(state,{'type':'decision','decision':'combat_play','player_turn':action['Turn'],'discard_pile_count':0},
            'Empty Neows series changed turn or discard')
        require(state.get('context',{}).get('combat_in_progress') is True,'Live Neows series lost combat')
    equal_fields(meta,{'type':'choice_meta','selection':'none','cards':[],'completion_audit':audit},
        'Stale or pending Neows completion query')
    return dict(kind=KIND,plan=copy.deepcopy(plans[0]),all_plans=copy.deepcopy(plans),
        actual_choice_audit=copy.deepcopy(audit),actual_original_play=copy.deepcopy(play),
        observed_empty_returns=len(events),selected_cards=[],manual_selection_requests_sent=0,
        automatic_selection_request_sent=False,remaining_battle_plan_stopped=ending)


def resolve(executor,before,state,action):
    if not eligible(action,state):return False
    request=copy.deepcopy(executor.last_action_request)
    meta=executor.checked(cmd='choice_meta')
    evidence=proof(before,state,action,request,meta)
    require(executor.solve_calls,'No solver owns the original empty Neows sequence')
    executor.solve_calls[-1].setdefault('replay',[]).append(evidence)
    return True
