import copy
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from prefix_interventions import read_json, read_lines, unchanged
from run_metadata import file_evidence
t=SimpleNamespace(HERE=Path('D:/sts2-training/inspection'),
    ROOT=Path('D:/sts2-training/staging/replay-parent-order-311/sts2-solver-bridge'),
    read_json=read_json,read_lines=read_lines,unchanged=unchanged,file_evidence=file_evidence)
from decision_data import read_decisions
import audit_batch
original_spec=importlib.util.spec_from_file_location('razor_original_auditor',t.ROOT/'replay_evidence.py')
original=importlib.util.module_from_spec(original_spec);original_spec.loader.exec_module(original)

CANDIDATE = Path(__file__).resolve().parent/'replay_evidence.py'
spec = importlib.util.spec_from_file_location('hologram_razor_candidate', CANDIDATE)
candidate = importlib.util.module_from_spec(spec); spec.loader.exec_module(candidate)
RUN = t.ROOT/'outputs/defect-public-route-order-search-20260916a-training-route_prior-015'


class HologramRazorAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.failure = t.read_json('E:/sts2-training-archives/inspection/route-order-audit-stop-20260916/HOLOGRAM_EFFECT_FAILURE.json')['failure']
        cls.traces = t.read_lines(RUN/'trace.jsonl')
        cls.calls = [c for d in read_decisions(RUN/'decisions.jsonl') for c in d['solver_calls']]
        cls.before = []; state = {'type':'initializing'}
        for row in cls.traces:
            cls.before.append(state)
            response = row.get('response')
            if isinstance(response, dict) and (response.get('type') == 'decision' or
                row['request'].get('cmd') in {'action','start_run'} and response.get('type') == 'error'):
                state = response
        cls.call_index = next(i for i,c in enumerate(cls.calls) if c['response'] == cls.failure['original_solve']['response'])

    def check(self, action=None, before=None, traces=None, module=candidate):
        return module.checked_choice_free_hologram(self.failure['action'] if action is None else action,
            self.failure['index'], self.traces if traces is None else traces, self.before if before is None else before)

    def test_original_failure_and_candidate_accepts_actual_completed_empty_return(self):
        with self.assertRaisesRegex(ValueError, 'planned effects'):
            self.check(module=original)
        self.assertTrue(self.check())

    def test_absent_relic_summary_keeps_original_empty_return_behavior(self):
        action=copy.deepcopy(self.failure['action']); action['RelicEffects']=[]
        self.assertTrue(self.check(action=action, module=original))
        self.assertTrue(self.check(action=action))

    def test_unowned_or_unknown_relic_summary_rejected(self):
        before=copy.deepcopy(self.before)
        state=before[self.failure['index']]
        state['player']['relics']=[r for r in state['player']['relics'] if r['id']!='RELIC.RAZOR_TOOTH']
        with self.assertRaisesRegex(ValueError,'not owned'):
            self.check(before=before)
        action=copy.deepcopy(self.failure['action']); action['RelicEffects'][0]['RelicId']='UNREVIEWED_RELIC'
        with self.assertRaisesRegex(ValueError,'Unsupported'):
            self.check(action=action)

    def test_display_summary_cannot_smuggle_choice_fields_or_wrong_shape(self):
        for effects in ({'RelicId':'RAZOR_TOOTH'}, [dict(self.failure['action']['RelicEffects'][0], Choice={})],
                        self.failure['action']['RelicEffects']*2):
            action=copy.deepcopy(self.failure['action']); action['RelicEffects']=effects
            with self.assertRaisesRegex(ValueError,'Unsupported'):
                self.check(action=action)

    def test_planned_choices_still_require_completion_query(self):
        for key in ('Choice','NestedChoices','TurnStartChoices'):
            action=copy.deepcopy(self.failure['action']); action[key]={'ContextId':'invented'} if key=='Choice' else [{'ContextId':'invented'}]
            with self.assertRaisesRegex(ValueError,'planned choices'):
                self.check(action=action)

    def test_nonempty_source_or_changed_selector_counter_rejected(self):
        before=copy.deepcopy(self.before); before[self.failure['index']]['discard_pile_count']=1
        with self.assertRaises((ValueError, RuntimeError)):
            self.check(before=before)
        traces=copy.deepcopy(self.traces)
        traces[self.failure['index']]['response']['choice_audit']['original_returns'][0]['selector_invocations_after']+=1
        with self.assertRaises((ValueError, RuntimeError)):
            self.check(traces=traces)

    def test_unfinished_actual_parent_is_rejected(self):
        traces=copy.deepcopy(self.traces)
        traces[self.failure['index']]['response']['play_action']['outcome']='pending'
        with self.assertRaises((ValueError, RuntimeError)):
            self.check(traces=traces)

    def test_full_solver_projection_tamper_is_rejected(self):
        calls=copy.deepcopy(self.calls)
        calls[self.call_index]['response']['actions'][0]['RelicEffects'][0]['Summary']='changed'
        with self.assertRaisesRegex(ValueError,'projection differs'):
            candidate.validate_replay_evidence(calls,self.traces)

    def test_full_original_replay_and_whole_game_audit_pass_without_new_game(self):
        self.assertTrue(candidate.validate_replay_evidence(self.calls,self.traces)['verified'])
        # The original model binds original feature-source hashes. Audit those
        # in a fresh original-runtime process while substituting only this
        # staged offline auditor; do not loosen policy provenance validation.
        import subprocess, sys, json
        code = '''import sys,json,importlib.util
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,sys.argv[1])
import audit_batch
from prefix_interventions import read_json,unchanged
spec=importlib.util.spec_from_file_location('staged_razor_auditor',sys.argv[2])
candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
run=Path(sys.argv[3])
with patch.object(audit_batch,'validate_replay_evidence',candidate.validate_replay_evidence):
    audit=audit_batch._Audit(run);audit.run(read_json(run/'report.json'))
print(json.dumps(dict(issues=audit.issues,unchanged=unchanged(list(audit.evidence.values())))))
'''
        result=subprocess.run([sys.executable,'-c',code,str(t.ROOT),str(CANDIDATE),str(RUN)],
            cwd=t.ROOT,capture_output=True,text=True,check=True)
        proof=json.loads(result.stdout)
        self.assertEqual(proof['issues'],[])
        self.assertTrue(proof['unchanged'])


if __name__=='__main__':
    unittest.main(verbosity=2)
