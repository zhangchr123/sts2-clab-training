"""Original SecretTechnique automatic return contracts; diagnostics are not training data."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers


class SecretTechniqueReturnTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def test_original_full_plan_and_joint_corruption_rejection(self):
        source_root = Path('D:/sts2-training/staging/card-identity-residual/sts2-solver-bridge')
        name = 'defect-identity-cem-20260914a-generation-03-1-017'
        run = source_root / 'outputs' / name
        audit = read_json(source_root / 'outputs/defect-identity-cem-20260914a/generation-03' / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        self.assertEqual(audit['outcome'], 'environment_error')
        rows = read_lines(run / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'secret-technique-full-fixed-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, matched, executor = False, 0, None
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}:
                    continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(run / 'manifest.json')['solver_requested_config'])
            actual_solve, supplied = executor.solve, False
            def recorded_first(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied:
                    return actual_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded_first
            final = executor.advance(before)
            self.assertIn(final['decision'], {'card_reward', 'game_over', 'map_select'})
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            proofs = [p for p in executor.solve_calls[0].get('replay', [])
                if p.get('actual_choice_audit', {}).get('parent', {}).get('card_id') == 'SECRET_TECHNIQUE']
            self.assertEqual(len(proofs), 1)
            proof = proofs[0]
            self.assertEqual(proof['kind'], 'original_choice_return_completed')
            self.assertEqual(proof['selected_cards'][0]['CardId'], 'RAINBOW')
            self.assertFalse(proof['selection_request_sent'])
            for field, value in [('source_is_actual_parent_object', False),
                ('original_task_completed_successfully', False), ('returned_objects_match_original_source', False),
                ('filter_is_null', True), ('filter_reexecuted_by_observer', True),
                ('selector_pending_after', True), ('selector_invocations_after', -1),
                ('min_select', 2), ('returned_count', 0), ('player_turn', -1),
                ('source_id', 'DAGGER_THROW'), ('effect_callsite', 'DaggerThrow.OnPlay')]:
                def corrupt(data):
                    if isinstance(data, dict):
                        for key in data:
                            if key == field: data[key] = value
                            else: corrupt(data[key])
                    elif isinstance(data, list):
                        for item in data: corrupt(item)
                bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                corrupt(bad_calls)
                corrupt(bad_traces)
                with self.subTest(field=field), self.assertRaises((ValueError, RuntimeError)):
                    validate_replay_evidence(bad_calls, bad_traces)
            bad_calls = copy.deepcopy(executor.solve_calls)
            bad_calls[0]['replay'].remove(proof)
            with self.assertRaises(ValueError): validate_replay_evidence(bad_calls, traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='recorded_full_original_solver_envelope_diagnostic',
                public_prefix_responses_verified=matched, original_sources=audit['actual_source_evidence'],
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                hidden_state_or_rng_equality_claimed=False,
                solver_calls=executor.solve_calls if executor else [])
            bridge.close()

    def boundary(self, count, upgrade):
        exercised = False
        for attempt in range(40):
            label = f'secret-technique-boundary-u{upgrade}-n{count}-a{attempt}-' + uuid.uuid4().hex[:8]
            bridge, traces, send = self.worker(label)
            passed, action, proofs = False, None, []
            try:
                send(cmd='start_run', character='Defect', ascension=10, seed=f'secret-technique-boundary-{attempt}')
                send(cmd='set_player', hp=1000, max_hp=1000, relics=[], potions=[],
                    deck=['SECRET_TECHNIQUE'] + ['STRIKE_DEFECT'] * 8 + ['DEFEND_DEFECT'] * count)
                if upgrade:
                    rest = send(cmd='enter_room', type='rest_site')
                    smith = next(o for o in rest['options'] if o['option_id'] == 'SMITH' and o['is_enabled'])
                    selection = send(cmd='action', action='choose_option', args={'option_index': smith['index']})
                    if selection['decision'] == 'card_select':
                        selected = next(c for c in selection['cards'] if c['id'] == 'CARD.SECRET_TECHNIQUE')
                        selection = send(cmd='action', action='select_cards', args={'indices': str(selected['index'])})
                    self.assertTrue(next(c for c in selection['player']['deck'] if c['id'] == 'CARD.SECRET_TECHNIQUE')['upgraded'])
                before = send(cmd='enter_room', type='combat', encounter='FOGMOG_NORMAL')
                # Explicit synthetic boundary construction, never natural training seed selection.
                actors = [c for c in before['hand'] if c['id'] == 'CARD.SECRET_TECHNIQUE']
                if not actors or any(c['id'] == 'CARD.DEFEND_DEFECT' for c in before['hand']):
                    continue
                index = actors[0]['index']
                meta = send(cmd='combat_meta')
                key = next(c['key'] for c in meta['hand'] if c['index'] == index)
                self.assertTrue(key.startswith(f'SECRET_TECHNIQUE+{upgrade}|'))
                request = {'cmd': 'action', 'action': 'play_card', 'args': {'card_index': index}}
                after = send(request)
                event = after['choice_audit']['original_returns'][0]
                self.assertEqual(event['source_id'], 'SECRET_TECHNIQUE')
                self.assertEqual(event['effect_callsite'], 'SecretTechnique.OnPlay')
                self.assertFalse(event['filter_is_null'])
                self.assertFalse(event['filter_reexecuted_by_observer'])
                self.assertEqual(event['min_select'], 1)
                self.assertEqual(event['max_select'], 1)
                self.assertTrue(event['source_is_actual_parent_object'])
                if count == 2:
                    self.assertEqual(after['decision'], 'card_select')
                    self.assertEqual(len(after['cards']), 2)
                    self.assertFalse(event['verified'])
                    self.assertFalse(event['original_task_completed_successfully'])
                    self.assertTrue(event['selector_pending_after'])
                    self.assertFalse(CombatExecutor(send).resolve_original_automatic_choice(before, after, {}))
                    selected = after['cards'][0]
                    self.assertEqual(selected['id'], 'CARD.DEFEND_DEFECT')
                    after = send(cmd='action', action='select_cards', args={'indices': str(selected['index'])})
                    self.assertEqual(after['decision'], 'combat_play')
                else:
                    cards = [] if count == 0 else [{'CardId': 'DEFEND_DEFECT', 'UpgradeLevel': 0,
                        'StateKey': 'DEFEND_DEFECT+0|energy=False:1|stars=False:-1|replay=0|exhaust=False|sly=False|retain=False|deck=True|keywords=|vars=Block=5|-|:0|baselib=-',
                        'SourceOccurrence': 0, 'OptionOccurrence': 0}]
                    action = {'Kind': 'PlayCard', 'CardId': 'SECRET_TECHNIQUE', 'CardStateKey': key,
                        'CardUpgradeLevel': upgrade, 'CardStateOccurrence': 0, 'Turn': before['player_turn'],
                        'Choice': {'Effect': 'MoveToHand', 'SourcePile': 'Draw', 'SourceId': '',
                            'ContextId': '', 'Timing': 'Action', 'Cards': cards},
                        'NestedChoices': [], 'NestedChoicesBeforePrimary': 0, 'EndsPlayerTurn': False, 'ReplayCount': 0}
                    executor = CombatExecutor(send)
                    executor.last_action_request = request
                    executor.solve_calls = [{'request': {'cmd': 'solve'},
                        'response': {'type': 'solver_result', 'actions': [action]}}]
                    self.assertEqual(after['decision'], 'combat_play')
                    self.assertTrue(event['original_task_completed_successfully'])
                    self.assertEqual(event['returned_cards'], cards)
                    self.assertEqual(event['selector_invocations_before'], event['selector_invocations_after'])
                    self.assertTrue(executor.resolve_original_automatic_choice(before, after, action))
                    proofs = executor.solve_calls[0]['replay']
                    self.assertEqual(proofs[0]['selected_cards'], cards)
                    self.assertFalse(proofs[0]['selection_request_sent'])
                    synthetic = [{'request': {'cmd': 'start_run'}, 'response': before},
                        {'request': executor.solve_calls[0]['request'], 'response': executor.solve_calls[0]['response']},
                        {'request': {'cmd': 'combat_meta'}, 'response': meta},
                        {'request': request, 'response': after}, traces[-1]]
                    self.assertTrue(validate_replay_evidence(executor.solve_calls, synthetic)['verified'])
                    self.assertEqual(after['draw_pile_count'], before['draw_pile_count'] - count)
                self.assertTrue(after['context']['combat_in_progress'])
                self.assertEqual(after['player_turn'], before['player_turn'])
                exercised, passed = True, True
                break
            finally:
                self.save(label, traces, passed=passed, boundary_exercised=exercised,
                    origin='synthetic_filtered_skill_boundary', eligible_skills=count, upgrade=upgrade,
                    constructed_plan_is_not_solver_output=True, synthetic_plan=action, direct_unit_proofs=proofs,
                    hidden_state_or_rng_equality_claimed=False)
                bridge.close()
        self.assertTrue(exercised, f'Boundary not exercised: skills={count}, upgrade={upgrade}')

    def test_unupgraded_filtered_empty_singleton_and_manual(self):
        for count in (0, 1, 2):
            with self.subTest(count=count): self.boundary(count, 0)

    def test_upgraded_filtered_empty_singleton_and_manual(self):
        for count in (0, 1, 2):
            with self.subTest(count=count): self.boundary(count, 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
