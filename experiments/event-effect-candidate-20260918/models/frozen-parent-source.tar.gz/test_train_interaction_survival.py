"""Temporary synthetic wire fixtures only; no real or holdout runs are read."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from decision_data import DataContractError, state_hash
from initial_policy import FEATURE_NAMES as BASE_NAMES, InitialPolicy
from interaction_features import FEATURE_NAMES, VERSION as TRANSFORM_VERSION, extend_scoring_packet
from test_initial_policy import card, state as reward_state
import test_train_act_survival as base_tests
from test_train_ranker import seed_in
from train_act_survival import load_dataset as load_base_dataset
import train_interaction_survival as trainer


class InteractionSurvivalTests(unittest.TestCase):
    fixture = base_tests.ActSurvivalTests.fixture
    inputs = base_tests.ActSurvivalTests.inputs
    read_lines = staticmethod(base_tests.ActSurvivalTests.read_lines)
    write_lines = staticmethod(base_tests.ActSurvivalTests.write_lines)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def model(self):
        path = self.root / "model.json"
        trainer.train(self.inputs(), path)
        return path

    @staticmethod
    def state():
        current = reward_state([card("GLACIER", block=6), card("DEFRAGMENT")])
        current["context"].update(act=1, integrity_recovery_used=False)
        return current

    def test_only_audited_chosen_act1_examples_are_extended_and_weights_preserved(self):
        seed = seed_in("train")
        paths = [self.fixture("short", seed=seed), self.fixture("long", seed=seed, steps=3, reached=True),
                 self.fixture("other", seed=seed_in("train", 1), steps=2)]
        base = load_base_dataset(paths)
        data = trainer.load_interaction_dataset(paths)
        self.assertEqual(len(data["examples"]), 6)
        self.assertEqual(len(data["records"]), 7)
        for before, after in zip(base["examples"], data["examples"]):
            self.assertEqual(set(after["features"]), set(FEATURE_NAMES))
            self.assertEqual({k: after["features"][k] for k in BASE_NAMES}, before["features"])
            for key in ("target", "seed", "run_id", "decision_id", "candidate_id", "weight"):
                self.assertEqual(before[key], after[key])
            self.assertEqual(after["base_features_sha256"], state_hash(before["features"]))
        self.assertEqual({name: sum(e["weight"] for e in data["examples"] if e["run_id"] == name)
                          for name in ("short", "long", "other")}, {"short": .5, "long": .5, "other": 1.})
        self.assertEqual(data["feature_transform"]["version"], TRANSFORM_VERSION)
        self.assertEqual(data["frozen_followup"], base["frozen_followup"])

    def test_rejects_bad_runs_through_shared_audit_without_relabeling_errors(self):
        with self.assertRaises(DataContractError):
            trainer.load_interaction_dataset([self.fixture("error", reached=True, termination="environment_error")])
        path = self.fixture("tampered")
        rows = self.read_lines(path / "policy.jsonl")
        next(row for row in rows[0]["scoring"]["scores"] if row["candidate_id"] ==
             rows[0]["candidate_id"])["features"]["health_deficit"] = 999.
        self.write_lines(path / "policy.jsonl", rows)
        with self.assertRaises(DataContractError):
            trainer.load_interaction_dataset([path])

    def test_recomputed_base_drift_between_shared_audit_and_extension_is_rejected(self):
        path = self.fixture("clean")
        audited = load_base_dataset([path])
        audited["examples"][0]["features"]["health_deficit"] += 1.
        with patch.object(trainer, "load_base_dataset", return_value=audited), self.assertRaisesRegex(
                DataContractError, "base features drifted"):
            trainer.load_interaction_dataset([path])

    def test_training_requires_ten_seeds_both_classes_fixed_regularization_and_new_path(self):
        output = self.root / "none.json"
        with self.assertRaisesRegex(DataContractError, "at least 10"):
            trainer.train([self.fixture("one")], output)
        paths = [self.fixture("negative" + str(i), seed=seed_in("train", i)) for i in range(10)]
        with self.assertRaisesRegex(DataContractError, "both actual"):
            trainer.train(paths, output)
        for regularization in (0., 2., True, float("nan")):
            with self.subTest(regularization=regularization), self.assertRaisesRegex(DataContractError, "fixes"):
                trainer.train([], output, regularization=regularization)
        output.write_text("preserve", encoding="utf-8")
        with self.assertRaisesRegex(DataContractError, "new model"):
            trainer.train([], output)
        self.assertEqual(output.read_text(encoding="utf-8"), "preserve")

    def test_whole_seed_split_train_only_fit_and_frozen_sources(self):
        paths = self.inputs()
        repeat = self.fixture("same-seed", seed=seed_in("train"), reached=True, steps=2)
        held_out = self.fixture("synthetic-test", seed=seed_in("test"), reached=True, steps=4)
        validation = self.fixture("synthetic-validation", seed=seed_in("validation"), reached=True)
        baseline = trainer.train(paths + [repeat], self.root / "training-only.json")
        model = trainer.train(paths + [repeat, held_out, validation], self.root / "all-splits.json")
        for key in ("weights", "means", "scales", "feature_min", "feature_max"):
            self.assertEqual(model[key], baseline[key])
        self.assertEqual(model["feature_names"], list(FEATURE_NAMES))
        self.assertEqual(model["feature_policy_version"], TRANSFORM_VERSION)
        self.assertEqual(model["format"], trainer.VERSION)
        self.assertEqual(model["mode"], trainer.MODE)
        self.assertEqual(model["training_seed_count"], 10)
        self.assertIn("same-seed", model["split_runs"]["train"])
        self.assertEqual(model["split_runs"]["test"], ["synthetic-test"])
        self.assertEqual(set(model["validation"]), {"train", "validation"})
        self.assertNotIn("synthetic-test", model["observed_labels"])
        self.assertFalse(model["test_used_for_fit_or_tuning"])
        self.assertFalse(model["counterfactual_labels"])
        self.assertFalse(model["automatic_deployment"])
        self.assertEqual(model["regularization"], 1.)
        self.assertEqual(model["feature_prior_source"]["sha256"], model["feature_prior_sha256"])
        for name in trainer.FEATURE_SOURCE_FILES:
            evidence = model["feature_transform_sources"][name]
            self.assertEqual(len(evidence["sha256"]), 64)
            self.assertGreater(evidence["bytes"], 0)
        self.assertEqual(model["feature_transform"]["mechanism_facts"], model["feature_mechanism_facts"])

    def test_live_score_features_recompute_scores_and_skip_deltas_without_rng_or_mutation(self):
        path = self.model()
        fallback = InitialPolicy(prior_path=None, random_seed="unchanged")
        scorer = trainer.InteractionSurvivalScorer(path, fallback=fallback)
        current = self.state()
        requests = [row["request"] for row in fallback.score(current)["scores"]]
        before_state, before_requests = copy.deepcopy(current), copy.deepcopy(requests)
        before_model, before_rng = copy.deepcopy(scorer.model), fallback.rng.getstate()
        base = fallback.score_requests(current, requests)
        pure = extend_scoring_packet(current, base)
        packet = scorer.score_requests(current, requests, character="Defect", mode="standard")
        self.assertEqual(packet["feature_policy_version"], TRANSFORM_VERSION)
        self.assertEqual(packet["required_followup"], scorer.model["frozen_followup"])
        self.assertEqual(packet["model"]["sha256"], scorer.source["sha256"])
        self.assertTrue(packet["interaction_scores_applied"])
        self.assertFalse(packet["calibrated"])
        skip = packet["scores"][-1]["score"]
        for original, expected, row in zip(base["scores"], pure["scores"], packet["scores"]):
            self.assertEqual(row["features"], expected["features"])
            self.assertEqual(row["base_features_sha256"], state_hash(original["features"]))
            self.assertEqual(row["rule_score"], original["score"])
            self.assertEqual(row["score"], trainer.predict(scorer.model, expected["features"]))
            self.assertEqual(row["delta_from_skip"], row["score"] - skip)
        self.assertEqual(current, before_state)
        self.assertEqual(requests, before_requests)
        self.assertEqual(scorer.model, before_model)
        self.assertEqual(fallback.rng.getstate(), before_rng)
        self.assertEqual(fallback.choice_count, 0)
        self.assertFalse(hasattr(scorer, "choose"))

    def test_scope_illegal_requests_and_live_model_or_feature_drift_are_refused(self):
        path = self.model()
        current = self.state()
        request = {"cmd": "action", "action": "skip_card_reward"}
        scorer = trainer.InteractionSurvivalScorer(path, fallback=InitialPolicy(prior_path=None))
        for changes, character, mode in (({"act": 2}, "Defect", "standard"),
            ({}, "Ironclad", "standard"), ({}, "Defect", "daily"),
            ({"ascension": 9}, "Defect", "standard"), ({"combat_in_progress": True}, "Defect", "standard"),
            ({"integrity_recovery_used": True}, "Defect", "standard")):
            invalid = copy.deepcopy(current)
            invalid["context"].update(changes)
            with self.subTest(changes=changes), self.assertRaises(DataContractError):
                scorer.score_requests(invalid, [request], character=character, mode=mode)
        with self.assertRaises(DataContractError):
            scorer.score_requests(current, [{"cmd": "action", "action": "set_hp"}], character="Defect", mode="standard")
        with patch.object(trainer, "_code_sources", return_value={}):
            with self.assertRaises(DataContractError):
                scorer.score_requests(current, [request], character="Defect", mode="standard")
        scorer.model["weights"][0] += 1.
        with self.assertRaisesRegex(DataContractError, "in memory"):
            scorer.score_requests(current, [request], character="Defect", mode="standard")
        scorer = trainer.InteractionSurvivalScorer(path, fallback=InitialPolicy(prior_path=None))
        scorer.fallback.mechanism_source["registry_sha256"] = "0" * 64
        with self.assertRaisesRegex(DataContractError, "frozen interaction"):
            scorer.score_requests(current, [request], character="Defect", mode="standard")

    def test_huge_ordered_subset_scoring_is_partial_and_ordered_without_invented_labels(self):
        scorer = trainer.InteractionSurvivalScorer(self.model(), fallback=InitialPolicy(prior_path=None))
        current = self.state()
        current.update(decision="card_select", min_select=0, max_select=15,
                       cards=[dict(card("GLACIER", block=6), index=i) for i in range(15)])
        requests = [{"cmd": "action", "action": "select_cards", "args": {"indices": indices}}
                    for indices in ("", "14,0,8", "8,0,14")]
        result = scorer.score_requests(current, requests, character="Defect", mode="standard", selection_purpose="acquire")
        self.assertFalse(result["evaluated_candidates_complete"])
        self.assertEqual(result["candidate_count"], 3554627472076)
        self.assertEqual([row["request"] for row in result["scores"]], requests)
        self.assertTrue(all("target" not in row for row in result["scores"]))

    def test_format_transform_hash_facts_and_prior_mismatches_rejected(self):
        path = self.model()
        model = json.loads(path.read_text(encoding="utf-8"))
        mutations = [lambda m: m.update(format="defect-act1-survival-ridge-v1"),
                     lambda m: m.update(feature_policy_version="initial-stat-mechanism-v3"),
                     lambda m: m["feature_transform"].update(definition_sha256="0" * 64),
                     lambda m: m["feature_transform_sources"]["interaction_features.py"].update(sha256="0" * 64),
                     lambda m: m["feature_mechanism_facts"].update(registry_sha256="0" * 64),
                     lambda m: m.update(feature_prior_sha256="0" * 64)]
        for index, mutate in enumerate(mutations):
            broken = copy.deepcopy(model)
            mutate(broken)
            target = self.root / ("broken" + str(index) + ".json")
            target.write_text(json.dumps(broken), encoding="utf-8")
            with self.subTest(index=index), self.assertRaises(DataContractError):
                trainer.InteractionSurvivalScorer(target, fallback=InitialPolicy(prior_path=None))


if __name__ == "__main__":
    unittest.main()
