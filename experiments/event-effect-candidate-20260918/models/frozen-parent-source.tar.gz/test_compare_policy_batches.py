"""Synthetic temporary macro-policy evidence; no model is run and no games start."""
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import unittest

from combat_executor import DEFAULT_CONFIG
from compare_policy_batches import POLICY_SOURCES, INTERACTION_POLICY_SOURCES, required_policy_sources, compare_policy_batches, load_policy_protocol
import test_compare_batches as batch_fixtures

write = batch_fixtures.write


class ComparePolicyBatchTests(unittest.TestCase):
    def setUp(self):
        self.fixture = batch_fixtures.CompareBatchTests(methodName="run")
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.root = self.fixture.root
        self.config = copy.deepcopy(DEFAULT_CONFIG)
        self.config["solver_backend"] = "coordinator"

    def declare(self, seeds=None):
        model = self.root / "model.json"
        write(model, {"purpose": "synthetic artifact hash fixture, never executable"})
        model_hash = hashlib.sha256(model.read_bytes()).hexdigest()
        left = {"origin": "natural", "kind": "rules", "id": "synthetic-policy", "version": "1",
                "llm_involved": False, "epsilon": .1}
        right = {**left, "kind": "model", "id": "synthetic-act1-policy", "version": model_hash,
                 "scope": {"act1": "observed_act2_entry_proxy", "act2_plus": "synthetic-policy-v1"}}
        sample = {"epsilon": .1, "max_seconds": 600, "max_decisions": 500,
                  "model_path": None, "hidden_audit_features_used": False, "selection_budget": 256}
        self.document = {"schema_version": "paired-macro-policy-v1",
            "created_utc": datetime.now(timezone.utc).isoformat(), "seeds": seeds or ["seed-0", "seed-1"],
            "conditions": {"character": "Defect", "ascension": 10}, "arms": {
                "left": {"batch": "a", "solver_config": self.config, "policy_identity": left,
                         "sampling": sample, "model_artifacts": []},
                "right": {"batch": "b", "solver_config": self.config, "policy_identity": right,
                    "sampling": {**sample, "model_path": str(model)}, "model_artifacts": [{
                        "sampling_field": "model_path", "path": str(model), "sha256": model_hash,
                        "bytes": model.stat().st_size, "policy_hash_field": "version"}]}}}
        self.protocol = self.root / "protocol.json"
        write(self.protocol, self.document)
        return self.protocol

    def rewrite_run(self, run_id, mutate):
        directory = self.root / run_id
        metadata = json.loads((directory / "manifest.json").read_text())
        mutate(metadata)
        write(directory / "manifest.json", metadata)
        rows = [json.loads(line) for line in (directory / "decisions.jsonl").read_text().splitlines()]
        rows[0]["metadata"].update(metadata)
        for row in rows:
            if "policy_provenance" in row:
                row["policy_provenance"] = {**metadata["provenance"], "choice_count": 3}
        (directory / "decisions.jsonl").write_text("\n".join(json.dumps(row) for row in rows) + "\n")

    def batches(self, left=("defeat", "timeout"), right=("defeat", "defeat")):
        paths = []
        for arm, outcomes in (("left", left), ("right", right)):
            spec = self.document["arms"][arm]
            paths.append(self.fixture.batch(spec["batch"], "coordinator", list(outcomes), config=self.config))
            for index in range(len(outcomes)):
                def update(metadata, spec=spec):
                    metadata["provenance"] = {**spec["policy_identity"], "random_seed": metadata["seed"]}
                    metadata["sampling"] = copy.deepcopy(spec["sampling"])
                    metadata["versions"]["sources"].update({name: {"sha256": "a" * 64, "bytes": 100}
                                                            for name in POLICY_SOURCES})
                self.rewrite_run(f"{spec['batch']}-{index}", update)
                if outcomes[index] in {"timeout", "environment_error"}:
                    # This fixture fails in Act1; other rows genuinely reach Act2.
                    trace_path = self.root / f"{spec['batch']}-{index}" / "trace.jsonl"
                    trace = [json.loads(line) for line in trace_path.read_text().splitlines()]
                    trace[1]["response"]["context"]["act"] = 1
                    trace_path.write_text("\n".join(json.dumps(row) for row in trace) + "\n")
        return paths

    def test_declared_model_comparison_keeps_failures_and_proxy_reach_separate_from_wins(self):
        self.declare()
        a, b = self.batches()
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertTrue(result["comparable"], result["errors"])
        self.assertTrue(result["predeclaration_chronology_verified"])
        self.assertTrue(result["right"]["model_artifact_verification"][0]["verified"])
        self.assertEqual(result["left"]["summary"]["timeouts"], 1)
        self.assertEqual(result["left"]["summary"]["runs_in_denominator"], 2)
        self.assertEqual(result["paired"]["verified_a10_victory"]["difference_right_minus_left"], 0)
        self.assertEqual(result["paired"]["act_reach"]["2"]["difference_right_minus_left"], .5)
        self.assertEqual(result["right"]["summary"]["verified_a10_victories"], 0)
        self.assertIsNone(result["right"]["summary"]["seconds_per_verified_victory"])
        self.assertIsNotNone(result["right"]["summary"]["act_reach"]["2"]["wilson_95"])

    def test_interaction_declares_shared_union_without_breaking_historical_sources(self):
        self.declare()
        self.assertEqual(required_policy_sources(self.document), POLICY_SOURCES)
        self.document["arms"]["right"]["policy_identity"]["id"] = "act1-interaction-survival-with-v3-fallback-v1"
        write(self.protocol, self.document)
        self.assertEqual(required_policy_sources(self.document), (*POLICY_SOURCES, *INTERACTION_POLICY_SOURCES))
        a, b = self.batches()
        self.assertFalse(compare_policy_batches(a, b, protocol=self.protocol)["comparable"])
        for batch in ("a", "b"):
            for index in range(2):
                self.rewrite_run(f"{batch}-{index}", lambda m: m["versions"]["sources"].update({
                    name: {"sha256": "a" * 64, "bytes": 100} for name in INTERACTION_POLICY_SOURCES}))
        self.assertFalse(compare_policy_batches(a, b, protocol=self.protocol)["comparable"])
        for batch in ("a", "b"):
            for index in range(2):
                self.rewrite_run(f"{batch}-{index}", lambda m: m["versions"].update(godot={"sha256": "a" * 64, "bytes": 100}))
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertTrue(result["comparable"], result["errors"])
        for index in range(2):
            self.rewrite_run(f"a-{index}", lambda m: m["versions"]["sources"]["interaction_features.py"].update(sha256="b" * 64))
        self.assertFalse(compare_policy_batches(a, b, protocol=self.protocol)["comparable"])

    def test_undeclared_policy_and_sampling_drift_are_rejected(self):
        self.declare()
        a, b = self.batches()
        self.rewrite_run("b-0", lambda m: m["provenance"].update(id="different-policy"))
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("policy" in e.lower() for e in result["errors"]))
        self.rewrite_run("b-0", lambda m: m["provenance"].update(id=self.document["arms"]["right"]["policy_identity"]["id"]))
        for index in range(2):
            self.rewrite_run(f"b-{index}", lambda m: m["sampling"].update(max_seconds=601))
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("sampling differs" in e for e in result["errors"]))

    def test_runtime_and_model_implementation_sources_must_stay_frozen(self):
        self.declare()
        a, b = self.batches()
        for index in range(2):
            self.rewrite_run(f"b-{index}", lambda m: m["versions"]["sources"]["survival_policy.py"].update(sha256="b" * 64))
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("Policy implementation sources differ" in e for e in result["errors"]))
        for index in range(2):
            self.rewrite_run(f"b-{index}", lambda m: m["versions"]["sources"]["survival_policy.py"].update(sha256="a" * 64))
            self.rewrite_run(f"b-{index}", lambda m: m["versions"]["engine"].update(sha256="c" * 64))
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("Runtime, solver" in e for e in result["errors"]))

    def test_artifact_bytes_and_hash_binding_allowlist_are_enforced(self):
        self.declare()
        a, b = self.batches()
        artifact = Path(self.document["arms"]["right"]["model_artifacts"][0]["path"])
        write(artifact, {"modified": "after protocol"})
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("Model artifact bytes/hash" in e for e in result["errors"]))
        self.document["arms"]["right"]["model_artifacts"][0]["policy_hash_field"] = "id"
        write(self.protocol, self.document)
        with self.assertRaisesRegex(ValueError, "allowlist"):
            load_policy_protocol(self.protocol)

    def test_predeclared_missing_seeds_and_late_protocol_are_never_silently_removed(self):
        self.declare(["seed-0", "seed-1", "seed-2"])
        a, b = self.batches()
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertIsNone(result["paired"])
        for arm in ("left", "right"):
            self.assertEqual(result[arm]["summary"]["runs_in_denominator"], 3)
            self.assertEqual(result[arm]["summary"]["missing_runs"], 1)
        self.document["created_utc"] = datetime.now(timezone.utc).isoformat()
        write(self.protocol, self.document)
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["predeclaration_chronology_verified"])
        self.assertTrue(any("precede every journal run_start" in e for e in result["errors"]))


if __name__ == "__main__":
    unittest.main()
