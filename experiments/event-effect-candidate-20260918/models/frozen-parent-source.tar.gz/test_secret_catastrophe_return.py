"""Real original failure prefixes; all repeats and boundary cases are diagnostics."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

SOURCE = Path('D:/sts2-training/staging/uproar-neows-ending/sts2-solver-bridge')
BATCH = SOURCE / 'outputs/defect-contextual-d8-20260914a'


class SecretCatastropheTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def run_original(self, suffix, generation, card):
        name = BATCH.name + '-' + suffix
        source = SOURCE / 'outputs' / name
        audit = read_json(BATCH / f'generation-{generation:02d}' / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        recorded_solve = next(r for r in reversed(rows) if r['request']['cmd'] == 'solve')
        actions = [a for a in recorded_solve['response']['actions'] if a.get('CardId') == card]
        self.assertEqual(len(actions), 1)
        action = copy.deepcopy(actions[0])
        label = 'secret-catastrophe-' + card.lower() + '-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        matched = 0
        proof = None
        passed = False
        final = None
        try:
            for row in rows[:-1]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            meta = send(cmd='combat_meta')
            after = send(rows[-1]['request'])
            self.assertEqual(checked_public(after), checked_public(rows[-1]['response']))
            matched += 1
            observer = CombatExecutor(send)
            observer.last_action_request = copy.deepcopy(rows[-1]['request'])
            observer.solve_calls = [{'request': {'cmd': 'solve'},
                'response': {'type': 'solver_result', 'actions': [copy.deepcopy(action)]}}]
            self.assertTrue(observer.resolve_original_automatic_choice(before, after, action))
            proof = copy.deepcopy(observer.solve_calls[0]['replay'][0])
            event = after['choice_audit']['original_returns'][0]
            self.assertEqual(event['raw_source_count_at_entry'], 5 if card == 'SECRET_WEAPON' else 1)
            self.assertEqual(event['source_id'], 'SECRET_WEAPON' if card == 'SECRET_WEAPON' else 'HOLOGRAM')
            self.assertEqual(event['returned_cards'][0]['CardId'], 'BEAM_CELL' if card == 'SECRET_WEAPON' else 'LEAP')
            self.assertFalse(proof['selection_request_sent'])
            synthetic = [{'request': {'cmd': 'start_run'}, 'response': before},
                {'request': observer.solve_calls[0]['request'], 'response': observer.solve_calls[0]['response']},
                {'request': {'cmd': 'combat_meta'}, 'response': meta},
                {'request': rows[-1]['request'], 'response': after}, traces[-1]]
            self.assertTrue(validate_replay_evidence(observer.solve_calls, synthetic)['verified'])
            fields = ['source_id', 'effect_callsite', 'source_is_actual_parent_object',
                'original_task_completed_successfully', 'filter_reexecuted_by_observer', 'filter_is_null',
                'min_select', 'max_select', 'selector_invocations_after', 'selector_pending_after',
                'raw_source_count_at_return', 'returned_count']
            if card == 'CATASTROPHE':
                self.assertTrue(event['nested_auto_play_task_completed_successfully'])
                self.assertEqual(event['nested_auto_play_total_calls'], 2)
                fields += ['nested_parent_card_id', 'nested_source_card_key', 'nested_relation',
                    'nested_source_owner_matches_parent', 'nested_auto_play_callsite',
                    'nested_auto_play_source_is_original_object', 'nested_auto_play_source_key_at_entry',
                    'nested_auto_play_task_completed_successfully']
            for field in fields:
                with self.subTest(corruption=field):
                    bad = copy.deepcopy(after)
                    value = bad['choice_audit']['original_returns'][0][field]
                    bad['choice_audit']['original_returns'][0][field] = (
                        not value if type(value) is bool else value + 1 if type(value) is int else 'unrelated')
                    with self.assertRaises(RuntimeError):
                        observer.resolve_original_automatic_choice(before, bad, action)
            for field in ('CardId', 'StateKey', 'SourceOccurrence', 'OptionOccurrence', 'UpgradeLevel'):
                bad = copy.deepcopy(after)
                token = bad['choice_audit']['original_returns'][0]['returned_cards'][0]
                token[field] = token[field] + 1 if type(token[field]) is int else 'UNRELATED'
                with self.assertRaises(RuntimeError):
                    observer.resolve_original_automatic_choice(before, bad, action)
            if card == 'CATASTROPHE':
                for field, value in [('nested_auto_play_index', -1), ('nested_auto_play_index', 2),
                        ('nested_auto_play_index', True), ('nested_auto_play_total_calls', 0),
                        ('nested_auto_play_total_calls', 3)]:
                    bad = copy.deepcopy(after)
                    bad['choice_audit']['original_returns'][0][field] = value
                    with self.assertRaises(RuntimeError):
                        observer.resolve_original_automatic_choice(before, bad, action)
            for mutation in ('missing', 'selected', 'submitted', 'binding'):
                bad = copy.deepcopy(observer.solve_calls)
                if mutation == 'missing': bad[0]['replay'] = []
                elif mutation == 'selected': bad[0]['replay'][0]['selected_cards'] = []
                elif mutation == 'submitted': bad[0]['replay'][0]['selection_request_sent'] = True
                else: bad[0]['replay'][0]['nested_effect_binding'] = 'unrelated'
                with self.assertRaises(ValueError): validate_replay_evidence(bad, synthetic)
            executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
            final = executor.advance(after)
            self.assertIn(final['decision'], {'card_reward', 'map_select', 'game_over'})
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='original_public_prefix_diagnostic',
                public_prefix_responses_verified=matched, original_source=audit['actual_source_evidence'],
                original_solver_action=action, actual_return_proof=proof,
                synthetic_single_action_boundary=True, final_decision=final and final['decision'],
                hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_secret_weapon_original_filtered_singleton(self):
        self.run_original('g01-c12-s22', 1, 'SECRET_WEAPON')

    def test_catastrophe_original_nested_return(self):
        self.run_original('g02-c01-s08', 2, 'CATASTROPHE')

    def test_secret_filtered_empty_singleton_and_manual_pair(self):
        for count in (0, 1, 2):
            exercised = False
            for attempt in range(30):
                label = f'secret-boundary-{count}-{attempt}-' + uuid.uuid4().hex[:8]
                bridge, traces, send = self.worker(label)
                try:
                    send(cmd='start_run', character='Defect', ascension=10, seed=f'secret-boundary-{attempt}')
                    send(cmd='set_player', hp=1000, max_hp=1000, relics=[], potions=[],
                         deck=['SECRET_WEAPON'] * 5 + ['DEFEND_DEFECT'] * 5 + ['STRIKE_DEFECT'] * count)
                    before = send(cmd='enter_room', type='combat', encounter='FOGMOG_NORMAL')
                    # Deliberately constructed boundary fixtures, never training seed selection.
                    if any(c['id'] == 'CARD.STRIKE_DEFECT' for c in before['hand']): continue
                    options = [c for c in before['hand'] if c['id'] == 'CARD.SECRET_WEAPON']
                    if not options: continue
                    index = options[0]['index']
                    meta = send(cmd='combat_meta')
                    key = next(c['key'] for c in meta['hand'] if c['index'] == index)
                    request = {'cmd': 'action', 'action': 'play_card', 'args': {'card_index': index}}
                    after = send(request)
                    if count == 2:
                        self.assertEqual(after['decision'], 'card_select')
                        self.assertEqual(len(after['cards']), 2)
                        self.assertFalse(CombatExecutor(send).resolve_original_automatic_choice(before, after, {}))
                        event = after['choice_audit']['original_returns'][0]
                        self.assertFalse(event['verified'])
                        self.assertFalse(event['original_task_completed_successfully'])
                        final = send(cmd='action', action='select_cards', args={'indices': '0'})
                        self.assertEqual(final['decision'], 'combat_play')
                    else:
                        cards = [] if count == 0 else [{'CardId': 'STRIKE_DEFECT', 'UpgradeLevel': 0,
                            'StateKey': 'STRIKE_DEFECT+0|energy=False:1|stars=False:-1|replay=0|exhaust=False|sly=False|retain=False|deck=True|keywords=|vars=Damage=6|-|:0|baselib=-',
                            'SourceOccurrence': 0, 'OptionOccurrence': 0}]
                        action = {'Kind': 'PlayCard', 'CardId': 'SECRET_WEAPON', 'CardStateKey': key,
                            'Turn': before['player_turn'], 'Choice': {'Effect': 'MoveToHand', 'SourcePile': 'Draw',
                            'SourceId': '', 'ContextId': '', 'Timing': 'Action', 'Cards': cards},
                            'NestedChoices': [], 'NestedChoicesBeforePrimary': 0, 'EndsPlayerTurn': False, 'ReplayCount': 0}
                        observer = CombatExecutor(send)
                        observer.last_action_request = request
                        observer.solve_calls = [{'request': {'cmd': 'solve'},
                            'response': {'type': 'solver_result', 'actions': [action]}}]
                        self.assertTrue(observer.resolve_original_automatic_choice(before, after, action))
                        self.assertEqual(observer.solve_calls[0]['replay'][0]['selected_cards'], cards)
                        synthetic = [{'request': {'cmd': 'start_run'}, 'response': before},
                            {'request': observer.solve_calls[0]['request'], 'response': observer.solve_calls[0]['response']},
                            {'request': {'cmd': 'combat_meta'}, 'response': meta},
                            {'request': request, 'response': after}, traces[-1]]
                        self.assertTrue(validate_replay_evidence(observer.solve_calls, synthetic)['verified'])
                        self.assertEqual(after['draw_pile_count'], before['draw_pile_count'] - count)
                    self.save(label, traces, passed=True, origin='synthetic_filtered_boundary', eligible_attacks=count)
                    exercised = True
                    break
                finally:
                    bridge.close()
            self.assertTrue(exercised, f'No synthetic boundary exercised for {count}')


if __name__ == '__main__': unittest.main()
