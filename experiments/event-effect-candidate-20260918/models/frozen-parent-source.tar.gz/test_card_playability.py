"""Actual original CanPlay and complete solve regression; no natural samples."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor, DEFAULT_CONFIG
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
from test_combat_executor import FakeEngine, solved, state
import test_liquid_memories as helpers


class PlayabilityTests(unittest.TestCase):
    def fixture(self):
        before = state()
        before['energy'] = 2
        before['player']['combat_metrics']['combat_id'] = 7
        before['hand'] = [{'index':0,'id':'CARD.REFRACT','cost':3,'can_play':False}]
        action = {'Kind':'PlayCard','Turn':1,'CardId':'REFRACT','CardUpgradeLevel':0,
            'CardStateKey':'REFRACT+0|energy=False:3','CardStateOccurrence':0,
            'TargetIndex':0,'TargetCombatId':1}
        row = {'index':0,'id':'REFRACT','key':action['CardStateKey'],'upgrade_level':0,
            'original_can_play':False,'original_reason':'EnergyCostTooHigh',
            'original_preventing_model_id':None,'source_is_original_hand_card':True,
            'fingerprint_unchanged_after_query':True,'energy_cost':3,'costs_x':False,'star_cost':-1}
        meta = {'type':'combat_meta','hand':[{'index':0,'key':row['key']}],
            'enemies':[{'index':0,'combat_id':1}],
            'playability_preflight':{'schema_version':'original-card-playability-preflight-v1',
                'source_method':'CardModel.CanPlay','player_id':'1','player_turn':1,'player_phase':'Play',
                'energy':2,'stars':0,'combat_id':7,'combat_active':True,'cards':[row]}}
        return before, action, meta

    def run_fake(self):
        before, action, meta = self.fixture()
        final = state('card_reward', active=False)
        engine = FakeEngine([solved([action]), meta, solved([{'Kind':'EndTurn','Turn':1}]), final])
        traces=[{'request':{'cmd':'start_run'},'response':before}]
        def send(**request):
            response=engine(**request);traces.append({'request':request,'response':copy.deepcopy(response)})
            return response
        executor=CombatExecutor(send)
        self.assertEqual(executor.advance(before),final)
        self.assertEqual([r.get('action') for r in engine.requests if r['cmd']=='action'],['end_turn'])
        self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
        return executor.solve_calls,traces

    def test_replans_without_submitting_and_binds_offline(self):
        calls,traces=self.run_fake()
        proof=calls[0]['plan_invalidation']
        self.assertFalse(proof['action_submitted'])
        self.assertEqual(proof['original_rejection_reason'],'EnergyCostTooHigh')
        mutations=[('energy',3),('player_turn',2),('combat_id',8),('player_phase','Start'),
            ('combat_active',False),('source_method','simulated'),('stars',-1)]
        card_changes=[('original_reason','None'),('source_is_original_hand_card',False),
            ('original_can_play',True),('fingerprint_unchanged_after_query',False),('energy_cost',2),
            ('costs_x',True),('key','other'),('id','OTHER'),('index',1),('upgrade_level',1)]
        for card, changes in ((False,mutations),(True,card_changes)):
            for key,value in changes:
                bc,bt=copy.deepcopy(calls),copy.deepcopy(traces)
                for m in (bc[0]['plan_invalidation']['combat_meta'],bt[2]['response']):
                    obj=m['playability_preflight']['cards'][0] if card else m['playability_preflight']
                    obj[key]=value
                with self.subTest(card=card,key=key),self.assertRaises(ValueError):validate_replay_evidence(bc,bt)

    def test_missing_or_jointly_erased_invalidation_cannot_hide_replan(self):
        calls,traces=self.run_fake()
        for erase_meta in (False,True):
            bc,bt=copy.deepcopy(calls),copy.deepcopy(traces)
            del bc[0]['plan_invalidation']
            if erase_meta:del bt[2]['response']['playability_preflight']
            with self.assertRaises(ValueError):validate_replay_evidence(bc,bt)
        bc,bt=copy.deepcopy(calls),copy.deepcopy(traces)
        del bc[0]['plan_invalidation']
        bt[0]['response']['hand'][0]['can_play']=True
        r=bt[2]['response']['playability_preflight']['cards'][0]
        r.update(original_can_play=True,original_reason='None')
        with self.assertRaises(ValueError):validate_replay_evidence(bc,bt)

    def test_playable_original_card_is_not_skipped(self):
        before,action,meta=self.fixture()
        before['energy']=3;before['hand'][0]['can_play']=True
        meta['playability_preflight']['energy']=3
        meta['playability_preflight']['cards'][0].update(original_can_play=True,original_reason='None')
        self.assertIsNone(CombatExecutor.unplayable_card_proof(before,action,meta,0))

    def test_malformed_or_missing_preflight_never_submits(self):
        before,action,meta=self.fixture()
        for change in ('absent','owner','turn','cost'):
            bad=copy.deepcopy(meta)
            if change=='absent':del bad['playability_preflight']
            elif change=='owner':bad['playability_preflight']['cards'][0]['source_is_original_hand_card']=False
            elif change=='turn':bad['playability_preflight']['player_turn']=9
            else:bad['playability_preflight']['cards'][0]['energy_cost']=2
            engine=FakeEngine([solved([action]),bad])
            with self.assertRaises(RuntimeError):CombatExecutor(engine).advance(before)
            self.assertFalse(any(r['cmd']=='action' for r in engine.requests))

    def test_repeated_invalid_plan_respects_existing_bound(self):
        before,action,meta=self.fixture()
        engine=FakeEngine([solved([action]),meta]*2)
        executor=CombatExecutor(engine,{**DEFAULT_CONFIG,'max_replans':2})
        with self.assertRaisesRegex(RuntimeError,'Too many combat replans'):executor.advance(before)
        self.assertEqual(len(executor.solve_calls),2)
        self.assertFalse(any(r['cmd']=='action' for r in engine.requests))


class OriginalPlayabilityTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def test_complete_original_refract_plan_then_actual_replan(self):
        root=Path('D:/sts2-training/staging/secret-catastrophe-return/sts2-solver-bridge')
        name='defect-contextual-d8-20260914b-reserved-trained-014'
        source=root/'outputs'/name
        receipt=read_json(root/'outputs/defect-contextual-d8-eval-20260914b'/(name+'-audit.json'))
        self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
        self.assertEqual(receipt['outcome'],'environment_error')
        rows=read_lines(source/'trace.jsonl')
        gate=max(i for i,r in enumerate(rows) if r['request']['cmd']=='solve')
        original=copy.deepcopy(rows[gate])
        label='playability-full-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label)
        executor,matched,passed=None,0,False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve','combat_meta','choice_meta'}:continue
                before=send(row['request'])
                self.assertEqual(checked_public(before),checked_public(row['response']));matched+=1
            executor=CombatExecutor(send,read_json(source/'manifest.json')['solver_requested_config'])
            real_solve,supplied=executor.solve,False
            def recorded_then_actual(s,budget,used=0,setup=False):
                nonlocal supplied
                if supplied:return real_solve(s,budget,used,setup)
                self.assertEqual(s,before);self.assertEqual(setup,original['request'].get('include_turn_setup',False))
                supplied=True;call=copy.deepcopy(original)
                traces.append(copy.deepcopy(call));executor.solve_calls.append(call)
                return call['response']
            executor.solve=recorded_then_actual
            final=executor.advance(before)
            self.assertEqual(executor.solve_calls[0]['response'],original['response'])
            proof=executor.solve_calls[0]['plan_invalidation']
            self.assertEqual(proof['action']['CardId'],'REFRACT')
            self.assertEqual(proof['original_rejection_reason'],'EnergyCostTooHigh')
            self.assertEqual(proof['state']['energy'],2)
            self.assertFalse(proof['action_submitted'])
            self.assertGreaterEqual(len(executor.solve_calls),2)
            self.assertIn(final['decision'],('card_reward','map_select','game_over'))
            self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
            self.assertTrue(unchanged(receipt['actual_source_evidence']))
            passed=True
        finally:
            self.save(label,traces,passed=passed,origin='recorded_full_solver_envelope_diagnostic',
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                original_source=receipt['actual_source_evidence'],original_run=name,
                public_prefix_responses_verified=matched,solver_calls=executor.solve_calls if executor else [],
                heldout_used_for_strategy_fit_or_parameter_selection=False,
                original_heldout_outcome_and_denominator_unchanged=True,hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_original_live_other_card_and_query_identity(self):
        label='playability-boundary-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);passed=False
        try:
            send(cmd='start_run',character='Defect',ascension=10,seed='playability-boundary')
            send(cmd='set_player',hp=1000,max_hp=1000,relics=[],potions=[],deck=['DEFEND_DEFECT']*5)
            before=send(cmd='enter_room',type='combat',encounter='FOGMOG_NORMAL')
            for _ in range(3):before=send(cmd='action',action='play_card',args={'card_index':0})
            self.assertEqual(before['energy'],0)
            a=send(cmd='combat_meta');b=send(cmd='combat_meta')
            self.assertEqual(a,b)
            row=a['playability_preflight']['cards'][0]
            self.assertEqual(row['original_reason'],'EnergyCostTooHigh')
            self.assertFalse(row['original_can_play'])
            action={'Kind':'PlayCard','Turn':before['player_turn'],'CardId':'DEFEND_DEFECT','CardUpgradeLevel':0,
                'CardStateKey':row['key'],'CardStateOccurrence':0,'TargetIndex':-1}
            proof=CombatExecutor.unplayable_card_proof(before,action,a,0)
            self.assertEqual(proof['selected_hand_index'],0)
            after=send(cmd='action',action='end_turn')
            self.assertEqual(after['decision'],'combat_play')
            self.assertEqual(after['player_turn'],2)
            passed=True
        finally:
            self.save(label,traces,passed=passed,origin='synthetic_original_card_boundary',hidden_state_or_rng_equality_claimed=False)
            bridge.close()


if __name__=='__main__':unittest.main()
