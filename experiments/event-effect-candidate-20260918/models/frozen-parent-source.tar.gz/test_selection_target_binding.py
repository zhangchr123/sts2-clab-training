"""Exercise the real natural-run policy factory and retained hard cap."""
import json
from pathlib import Path
import tempfile
import unittest
from decision_data import DataContractError
from sample_runs import build_policy
from test_initial_policy import card,state
import selection_target_policy as p

class SelectionTargetBindingTests(unittest.TestCase):
    def test_natural_factory_loads_bound_289_model_and_preserves_cap(self):
        config=json.loads((p.ROOT/'configs/defect-v3-base.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory(dir=p.ROOT/'outputs') as folder:
            path=Path(folder)/'model.json';path.write_text(json.dumps(p.make_artifact(dict.fromkeys(p.PARAMETERS,4.),config,training={'synthetic':True})),encoding='utf-8')
            policy=build_policy('binding-test',config,ascension=10,epsilon=0.,model_path=path)
            self.assertIsInstance(policy,p.SelectionTargetSelectionPolicy)
            self.assertEqual(policy.provenance['id'],p.VERSION)
            s=state([card('BALL_LIGHTNING',damage=7)]);s['context']['act']=2
            s['player'].update(deck=[card('DEFEND_DEFECT',block=5)]*36,deck_size=36)
            self.assertEqual(policy.choose(s)['request']['action'],'skip_card_reward')
            with self.assertRaises(DataContractError):build_policy('binding-test',config,ascension=9,epsilon=0.,model_path=path)
            with self.assertRaises(DataContractError):build_policy('binding-test',config,ascension=10,epsilon=.1,model_path=path)

if __name__=='__main__':unittest.main()
