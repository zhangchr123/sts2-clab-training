"""Verify a new isolated session: read Neow, query map, choose, stop. Not training data."""
import json
from pathlib import Path
import subprocess
import sys
import time
import uuid

ROOT=Path(__file__).resolve().parent


def main():
    name='handoff-smoke-'+uuid.uuid4().hex[:10]
    out=ROOT/'outputs'/name
    proc=subprocess.Popen([sys.executable,str(ROOT/'run_session.py'),'--run-name',name,'--seed','handoff-smoke-1'],
                          cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
    try:
        until=time.monotonic()+20
        while not (out/'status.json').exists():
            if proc.poll() is not None:raise RuntimeError(proc.communicate())
            if time.monotonic()>until:raise TimeoutError('Session did not start')
            time.sleep(.1)
        def control(request=None):
            args=[sys.executable,str(ROOT/'control.py'),'--run-name',name]
            if request is not None:
                path=out/'smoke-request.json';path.write_text(json.dumps(request),encoding='utf-8')
                args+=['--request-file',str(path)]
            result=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',timeout=50,check=True)
            return json.loads(result.stdout)
        initial=control()
        assert initial['state']['decision']=='event_choice'
        mapped=control({'cmd':'get_map'})
        assert mapped['state']['decision']=='event_choice' and mapped['query_result']['type']=='map'
        option=next(o for o in initial['state']['options'] if not o.get('is_locked'))
        chosen=control({'cmd':'action','action':'choose_option','args':{'option_index':option['index']}})
        assert chosen['state']['type']!='error',chosen
        after_choice=chosen['state'].get('decision')
        if after_choice=='card_select':
            state=chosen['state']
            count=state['min_select']
            indices=','.join(str(c['index']) for c in state['cards'][:count])
            chosen=control({'cmd':'action','action':'select_cards','args':{'indices':indices}})
            assert chosen['state']['type']!='error',chosen
        stopped=control({'cmd':'stop'})
        assert stopped['status']['status']=='finished'
        proc.wait(timeout=10)
        report={'passed':True,'run_name':name,'initial':'event_choice','after_choice':after_choice,'after_selection':chosen['state'].get('decision'),'stopped':True,'training_sample':False}
        (out/'smoke-result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(json.dumps(report))
    finally:
        if proc.poll() is None:proc.terminate()
        try:proc.communicate(timeout=10)
        except subprocess.TimeoutExpired:proc.kill();proc.communicate(timeout=10)


if __name__=='__main__':main()
