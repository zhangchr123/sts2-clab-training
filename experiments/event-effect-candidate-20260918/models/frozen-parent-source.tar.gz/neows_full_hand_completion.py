"""Strict completion of a manual Neow selection followed by original no-room branches.

Runtime integration is separate. This asset never fabricates a selection or an
engine response; completion requires the observed Math.Min branch and tasks.
"""
import copy
import re
from hologram_series import require, equal_fields, integer


def complete(executor, before, state, action, root_audit, root_play, choices):
    from combat_executor import CombatExecutor, choice_plans
    plans=choice_plans(action)
    audit=state.get('choice_audit',{})
    data=audit.get('neows_full_hand_diagnostic')
    require(isinstance(data,dict) and set(data)=={'checks','continuation'},'Missing original Neows capacity evidence')
    c=data['continuation'];checks=data['checks'];parent=root_audit['parent']
    equal_fields(state,{'type':'decision','decision':'combat_play','player_turn':action['Turn']},
        'Full-hand continuation changed the live turn')
    require(state.get('context',{}).get('combat_in_progress') is True
        and CombatExecutor.setup_state_identity(before)==CombatExecutor.setup_state_identity(state),
        'Full-hand continuation changed the original combat')
    equal_fields(audit,{'schema_version':'combat-choice-return-v2','closed':True,'events':[],
        'original_returns':[],'coverage':root_audit['coverage']},'Unexpected original full-hand return')
    true_fields={'original_task_pending_at_resume','selector_task_identity_matches','source_is_original_card_object',
        'original_branch_context_verified','original_play_task_pending_at_resume','original_play_task_completed_successfully',
        'original_task_completed_successfully','selector_task_completed_successfully','original_and_selector_return_same_card_objects'}
    ints={'origin_action_id','original_source_count_at_entry','selector_invocation_at_resume','original_play_action_id',
        'original_play_target_combat_id','selector_invocation_at_end','original_task_returned_count'}
    keys=true_fields|ints|{'schema_version','origin_parent','original_play_card_id','original_play_state_at_end',
        'original_play_cancelled','selector_pending_at_end'}
    require(isinstance(c,dict) and set(c)==keys,'Unknown Neows completion schema')
    equal_fields(c,{**dict.fromkeys(true_fields,True),'schema_version':'neows-pending-task-continuation-v1',
        'original_play_state_at_end':'Finished','original_play_card_id':'NEOWS_FURY',
        'original_play_cancelled':False,'selector_pending_at_end':False,
        'origin_action_id':root_audit['action_id'],'origin_parent':parent,
        'original_play_action_id':root_play['action_id'],'original_play_target_combat_id':action['TargetCombatId']},
        'Neows original tasks are unfinished, cancelled, or belong to another action')
    for key in ints:integer(c,key,0)
    require(c['origin_action_id']>=1 and c['original_play_action_id']>=1
        and c['original_source_count_at_entry']>=1 and c['selector_invocation_at_resume']>=1
        and c['selector_invocation_at_resume']==c['selector_invocation_at_end']
        and integer(audit,'action_id',1)==c['origin_action_id']+1,'Invalid Neows task/counter bounds')
    expected_parent={**parent,'action':'select_cards','card_index':-1,'card_id':None,'card_key':None}
    require(audit['parent']==expected_parent and len(choices)==1,'Different original manual selection parent')
    choice=choices[0]
    require(executor.last_action_request==choice['actual_request']
        and executor.last_action_request.get('action')=='select_cards'
        and c['original_task_returned_count']==len(plans[0]['Cards'])
        and c['original_source_count_at_entry']==len(choice['actual_choice_metadata']['cards']),
        'Original selected objects/count differ from the solver plan')
    original=root_audit.get('original_returns')
    require(isinstance(original,list) and len(original)==1,'Missing first original pending call')
    equal_fields(original[0],{'source_id':'NEOWS_FURY','effect_callsite':'NeowsFury.OnPlay','effect':'MoveToHand',
        'source_method':'CardSelectCmd.FromCombatPile','source_pile':'Discard','source_is_actual_parent_object':True,
        'verified':False,'original_task_completed_successfully':False,'filter_is_null':False,
        'filter_reexecuted_by_observer':False,'require_manual_confirmation':True,'min_select':0,
        'selector_pending_before':False,'selector_pending_after':True,
        'selector_invocations_before':c['selector_invocation_at_resume']-1,
        'selector_invocations_after':c['selector_invocation_at_resume'],
        'raw_source_count_at_entry':c['original_source_count_at_entry'],'action_id':root_audit['action_id'],
        'invocation_index':0,'player_id':parent['player_id'],'player_turn':action['Turn'],
        'is_over_or_ending_at_entry':False,'is_over_or_ending_at_return':False},
        'First Neows pending task was not authenticated')
    variables=re.search(r'\|vars=([^|]*)\|',action['CardStateKey'])
    limits=re.findall(r'(?:^|;)Cards=([1-9][0-9]*)(?=;|$)',variables[1]) if variables else []
    require(len(limits)==1,'Missing original Neows card limit')
    limit=int(limits[0])
    require(1<=integer(original[0],'max_select',1)<=limit,'Invalid first manual limit')
    require(isinstance(checks,list) and len(checks)==len(plans)-1 and 1<=len(checks)<=64,
        'Full-hand evidence does not cover every remaining original effect')
    require(all(plan==dict(Effect='MoveToHand',SourcePile='Discard',Cards=[],SourceId='',ContextId='',Timing='Action')
        for plan in plans[1:]),'Cannot discard a nonempty or differently timed remaining selection')
    require(len(state.get('hand',[]))==10,'Original full-hand state changed')
    for index,check in enumerate(checks):
        expected={'schema_version':'original-neows-hand-capacity-v1','index':index,'action_id':audit['action_id'],
            'original_play_action_id':c['original_play_action_id'],'source_is_original_card_object':True,
            'method':'NeowsFury.OnPlay.Math.Min','requested_cards':limit,'available_slots':0,'original_min_result':0,
            'hand_count':10,'hand_capacity':10,'source_cards_var':limit,
            'selector_invocations':c['selector_invocation_at_resume'],'selector_pending':False,
            'combat_active':True,'combat_over_or_ending':False,'player_id':parent['player_id'],'player_turn':action['Turn']}
        require(isinstance(check,dict) and set(check)==set(expected),'Unknown full-hand branch observation')
        equal_fields(check,expected,'Original branch/selector/action identity differs')
    meta=executor.checked(cmd='choice_meta')
    require(meta.get('type')=='choice_meta' and meta.get('selection')=='none' and meta.get('cards')==[]
        and meta.get('completion_audit')==audit and executor.solve_calls,
        'Full-hand completion is stale or a selector remains pending')
    executor.solve_calls[-1].setdefault('replay',[]).append(dict(
        kind='original_choice_continuation_completed',plan=copy.deepcopy(plans[1]),
        primary_plan=copy.deepcopy(plans[0]),remaining_empty_plans=copy.deepcopy(plans[1:]),
        actual_root_audit=copy.deepcopy(root_audit),actual_root_play_action=copy.deepcopy(root_play),
        manual_choice=copy.deepcopy(choice),actual_choice_audit=copy.deepcopy(audit),
        remaining_selection_request_sent=False,remaining_battle_plan_stopped=False,
        reason='original_full_hand_branch_skipped_remaining_selections'))
    return state
