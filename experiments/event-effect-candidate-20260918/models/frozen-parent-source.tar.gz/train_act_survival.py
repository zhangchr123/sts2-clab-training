"""Experimental Defect A10 Act-1 survival ridge scores; never auto-deployed.

Only executed Act-1 macro choices receive the observed label of entering Act 2
under one frozen follow-up policy. Error/incomplete/constructed trajectories are
rejected as entire inputs. Scores are neither causal action values nor calibrated
probabilities, and this proxy is not A10 victory. No game or LLM is invoked here.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import copy
import json
import math
from pathlib import Path

from decision_data import DataContractError, split_by_seed, state_hash
from initial_policy import ACTION_NAMES, FEATURE_NAMES, POLICY_VERSION, InitialPolicy
from run_metadata import atomic_json, file_evidence
from selection_context import direct_action_evidence
from replay_evidence import solver_projection, validate_replay_evidence
from train_ranker import (examples_for, feature_facts_for, fit, load_runs,
                          predict, validate_mechanism_facts, validate_model)


VERSION = "defect-act1-survival-ridge-v1"
TARGET = "observed_act2_entry_under_frozen_followup_policy"
RUNTIME_KEYS = ("engine", "solver", "cli", "bridge", "ritsu")
SOURCE_KEYS = ("initial_policy.py", "combat_executor.py", "sample_runs.py", "decision_data.py",
               "selection_space.py", "selection_policy.py", "mechanism_facts.py", "selection_context.py")
ALLOWED_ACTIONS = set(ACTION_NAMES) | {"play_card", "end_turn", "use_potion"}


def _same(a, b):
    return state_hash(a) == state_hash(b)


def _require(ok, message):
    if not ok:
        raise DataContractError(message)


def _read_lines(path):
    def pairs(items):
        value = {}
        for key, item in items:
            _require(key not in value, "Duplicate JSON field: " + key)
            value[key] = item
        return value
    def constant(value):
        raise DataContractError("Nonfinite JSON value: " + value)
    return [json.loads(line, object_pairs_hook=pairs, parse_constant=constant)
            for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def _hash_evidence(value, field):
    _require(isinstance(value, dict), "Missing immutable source evidence: " + field)
    sha = value.get("sha256")
    _require(isinstance(sha, str) and len(sha) == 64
             and all(c in "0123456789abcdef" for c in sha), "Invalid source SHA256: " + field)
    _require(type(value.get("bytes")) is int and value["bytes"] > 0,
             "Missing source byte count: " + field)
    # Paths may move; identity is frozen file content, not a machine's directory.
    return {"sha256": sha, "bytes": value["bytes"]}


def _act(state):
    value = state.get("context", {}).get("act")
    _require(type(value) is int and 1 <= value <= 3, "Missing or invalid actual act index")
    _require(state["context"].get("ascension") == 10
             and type(state["context"].get("ascension")) is int, "Trace is not A10")
    _require(state["context"].get("integrity_recovery_used") is False,
             "Missing clean engine recovery evidence")
    return value


def frozen_identity(records):
    identities = []
    for row in records:
        meta = row["metadata"]
        _require(meta.get("character") == "Defect" and type(meta.get("ascension")) is int
                 and meta["ascension"] == 10 and meta.get("mode") == "standard",
                 "Act1Survival requires standard Defect A10")
        _require(meta.get("branch_restore_enabled") is False and meta.get("llm_used_for_combat") is False
                 and not meta.get("lineage_root_seed"), "Constructed, restored or LLM combat inputs are forbidden")
        policy = {k: v for k, v in row["policy_provenance"].items() if k not in {"random_seed", "choice_count"}}
        original = {k: v for k, v in meta["provenance"].items() if k not in {"random_seed", "choice_count"}}
        _require(_same(policy, original), "Follow-up policy changed within a run")
        _require(policy.get("origin") == "natural" and policy.get("llm_involved") is False
                 and policy.get("kind") in {"rules", "model", "search", "exploration"},
                 "Only natural non-LLM follow-up policies are accepted")
        _require(meta.get("sampling", {}).get("hidden_audit_features_used") is False,
                 "Missing assurance that hidden audit features were not used")
        versions = meta["versions"]
        identities.append({"policy": policy, "solver": meta["solver_requested_config"],
            "runtime": {k: _hash_evidence(versions.get(k), k) for k in RUNTIME_KEYS},
            "sampling_sources": {k: _hash_evidence(versions.get("sources", {}).get(k), k) for k in SOURCE_KEYS},
            "run_conditions": {k: meta[k] for k in ("character", "ascension", "mode")},
            "sampling_limits": {k: meta["sampling"].get(k) for k in ("max_seconds", "max_decisions")}})
    _require(bool(identities) and all(_same(v, identities[0]) for v in identities),
             "Cannot mix follow-up policies, sampling limits or engine/solver/source configurations")
    return copy.deepcopy(identities[0])


def trace_label(records, traces):
    """Reconcile chosen actions, direct results and label against a natural trace."""
    _require(bool(records) and all(r["training_eligible"] for r in records),
             "Entire input run must be clean, natural, complete and training eligible")
    meta = records[0]["metadata"]
    _require(all(r["run_id"] == meta["run_id"] for r in records), "Expected one complete run")
    expected_start = {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": meta["seed"]}
    _require(bool(traces) and _same(traces[0].get("request"), expected_start),
             "Trace must start exactly once from a natural Defect A10 seed")
    previous = {"type": "initializing"}
    before, first_act2, previous_act = [], None, 1
    terminal_count = 0
    calls = []
    for index, trace in enumerate(traces):
        request, response = trace.get("request"), trace.get("response")
        _require(isinstance(request, dict) and isinstance(response, dict)
                 and not trace.get("transport_error") and response.get("type") != "error",
                 "Any transport or engine error excludes the entire run")
        command = request.get("cmd")
        _require(command in {"start_run", "action", "solve", "combat_meta", "choice_meta"}
                 and (command != "start_run" or index == 0),
                 "Injection, save/load, restart or unknown trace commands are forbidden")
        if command == "action":
            _require(set(request) <= {"cmd", "action", "args"}
                     and request.get("action") in ALLOWED_ACTIONS,
                     "Unknown or fixture engine action")
        if command == "solve":
            calls.append({"request": request, "response": response})
            config = meta["solver_requested_config"]
            for key in ("solver_backend", "potion_policy", "growth_budgets", "act_boss_hp_strategy",
                        "final_boss_hp_strategy", "search_profile"):
                default = "beam" if key == "solver_backend" else None
                _require(_same(request.get(key, default), config.get(key, default)),
                         "Solver trace differs from frozen requested settings: " + key)
            budgets = [config[k] for k in ("budget_ms", "first_budget_ms", "replan_budget_ms",
                                           "setup_budget_ms", "retry_budget_ms") if k in config]
            _require(type(request.get("budget_ms")) is int and request["budget_ms"] in budgets,
                     "Solver budget differs from frozen requested settings")
        before.append(previous)
        if response.get("type") == "decision":
            _require(command in {"start_run", "action"}, "Decision state must be an actual engine action response")
            _require(terminal_count == 0, "Engine actions continue after terminal state")
            act = _act(response)
            _require(previous_act <= act <= previous_act + 1, "Act sequence regresses or skips an unobserved act")
            if index == 0:
                _require(act == 1, "Natural run must start in Act 1")
            if act == 2 and first_act2 is None:
                first_act2 = {"trace_index": index, "state_hash": state_hash(response),
                              "request": copy.deepcopy(request), "decision": response.get("decision")}
            previous_act, previous = act, response
            terminal_count += int(response.get("decision") == "game_over")
    outcome = records[0]["run_outcome"]
    _require(terminal_count == 1 and previous.get("decision") == "game_over"
             and _same(previous, outcome["final_state"]), "Trace must prove the recorded clean terminal state")
    _require(outcome["outcome"] in {"victory", "defeat"}
             and previous.get("victory") is (outcome["outcome"] == "victory"), "Outcome differs from engine terminal")
    journal_calls = [c for r in records for c in r["solver_calls"]]
    _require(_same(calls, solver_projection(journal_calls)),
             "Solver trace and verified journal calls differ")
    try:
        validate_replay_evidence(journal_calls, traces)
    except ValueError as exc:
        raise DataContractError(str(exc)) from exc
    _require(all(_same(a["next_state"], b["state"]) for a, b in zip(records, records[1:]))
             and _same(records[-1]["next_state"], previous), "Broken macro state chain")
    cursor = 1
    for record in records:
        _act(record["state"])
        found = next((i for i in range(cursor, len(traces))
                      if _same(before[i], record["state"])
                      and _same(traces[i]["request"], record["chosen"]["request"])), None)
        _require(found is not None, "Chosen macro action is not present in the actual trace")
        _require(_same(record.get("execution", {}).get("direct_action_result"),
                       direct_action_evidence(traces[found]["response"])),
                 "Direct result differs from the actual chosen action response")
        cursor = found + 1
    if first_act2 is None:
        _require(outcome["outcome"] == "defeat" and _act(previous) == 1,
                 "No observed Act2 entry cannot stand in for a verified Act1 defeat")
    return {"target": float(first_act2 is not None), "act2_entry": first_act2,
            "terminal_state_hash": state_hash(previous), "terminal_outcome": outcome["outcome"]}


def load_dataset(paths):
    """Reject bad inputs explicitly; never silently relabel errors as failures."""
    paths = [Path(p) for p in paths]
    trace_rows, source_rows = {}, []
    for path in paths:
        # Parse every source strictly before using the shared journal/model audits.
        for name in ("decisions.jsonl", "policy.jsonl", "trace.jsonl"):
            rows = _read_lines(path / name)
            source_rows.append(file_evidence(path / name))
            if name == "trace.jsonl":
                trace_rows[str(path.resolve())] = rows
    records, scores, _ = load_runs(paths)
    _require(bool(records), "No complete decision observations")
    identity = frozen_identity(records)
    facts = feature_facts_for(records, scores)
    _require(identity["runtime"]["engine"]["sha256"] == facts["engine_sha256"],
             "Recorded engine differs from the feature mechanism facts engine")
    # Shared auditor verifies legal complete requests, selection contexts, source
    # chains, scores, natural provenance and actual solver configuration evidence.
    audited = {e["decision_id"]: e for e in examples_for(records, scores, "outcome")}
    by_run = defaultdict(list)
    for record in records:
        by_run[record["run_id"]].append(record)
    labels = {}
    for path in paths:
        run_id = _read_lines(path / "decisions.jsonl")[0]["metadata"]["run_id"]
        labels[run_id] = trace_label(by_run[run_id], trace_rows[str(path.resolve())])
    priors = {state_hash(scores[r["decision_id"]]["scoring"]["prior_source"]) for r in records}
    _require(len(priors) == 1, "Feature prior source must be fixed across all data splits")
    prior = scores[records[0]["decision_id"]]["scoring"]["prior_source"]
    fallback = InitialPolicy(prior_path=prior.get("path"))
    _require(_same(fallback.mechanism_source, facts) and fallback.prior.source["sha256"] == prior.get("sha256"),
             "Current feature extractor differs from recorded facts or prior source")
    examples = []
    for record in records:
        if _act(record["state"]) != 1:
            continue
        example = copy.deepcopy(audited[record["decision_id"]])
        picked = scores[record["decision_id"]]
        current = fallback.score_requests(record["state"], [record["chosen"]["request"]],
            selection_purpose=picked["scoring"].get("selection_purpose"))["scores"][0]
        _require(_same(example["features"], current["features"]),
                 "Chosen features cannot be reproduced solely from the recorded pre-action state")
        example.update(target=labels[record["run_id"]]["target"], seed=record["seed"],
                       candidate_id=record["chosen"]["candidate_id"])
        examples.append(example)
    _require(bool(examples), "No actual Act1 chosen actions")
    decisions_per_run = Counter(e["run_id"] for e in examples)
    runs_per_seed = defaultdict(set)
    for example in examples:
        runs_per_seed[example["seed"]].add(example["run_id"])
    for example in examples:
        example["weight"] = 1 / (len(runs_per_seed[example["seed"]]) * decisions_per_run[example["run_id"]])
    for evidence in source_rows:
        _require(_same(file_evidence(evidence["path"]), evidence), "Input changed while reading")
    return {"records": records, "examples": examples, "labels": labels, "sources": source_rows,
            "frozen_followup": identity, "feature_mechanism_facts": facts,
            "feature_prior_sha256": prior.get("sha256")}


def _metrics(model, examples):
    weight = sum(e["weight"] for e in examples)
    if not examples:
        return {"examples": 0, "seeds": 0, "weighted_rmse": None, "weighted_mae": None}
    errors = [(predict(model, e["features"]) - e["target"], e["weight"]) for e in examples]
    return {"examples": len(examples), "seeds": len({e["seed"] for e in examples}),
            "weighted_rmse": math.sqrt(sum(v*v*w for v, w in errors) / weight),
            "weighted_mae": sum(abs(v)*w for v, w in errors) / weight}


def train(paths, output, *, regularization=1.0):
    _require(not Path(output).exists(), "Choose a new model output path")
    dataset = load_dataset(paths)
    grouped = split_by_seed(dataset["records"])
    groups = {key: {r["run_id"] for r in rows} for key, rows in grouped.items()}
    examples = {key: [e for e in dataset["examples"] if e["run_id"] in runs] for key, runs in groups.items()}
    train_seeds = {e["seed"] for e in examples["train"]}
    _require(len(train_seeds) >= 10, "Act1Survival requires at least 10 clean training seeds")
    _require({e["target"] for e in examples["train"]} == {0., 1.},
             "Act1Survival training seeds must contain both actual Act2 entry and Act1 defeat")
    model = fit(examples["train"], FEATURE_NAMES, regularization)
    model.update({"format": VERSION, "mode": "act1_survival", "target_semantics": TARGET,
        "feature_policy_version": POLICY_VERSION, "feature_prior_sha256": dataset["feature_prior_sha256"],
        "feature_mechanism_facts": dataset["feature_mechanism_facts"],
        "frozen_followup": dataset["frozen_followup"], "calibrated_probability": False,
        "counterfactual_labels": False, "chosen_action_is_optimal_label": False,
        "deployment_scope": {"character": "Defect", "ascension": 10, "mode": "standard", "act": 1},
        "automatic_deployment": False, "regularization": regularization,
        "weighting": "equal_seed_then_equal_run_then_equal_Act1_chosen_decision",
        "normalization": "train_decisions_only_shared_ridge_fit",
        "training_seed_count": len(train_seeds), "sources": dataset["sources"],
        "split_runs": {k: sorted(v) for k, v in groups.items()},
        "split_seeds": {k: sorted({r["seed"] for r in rows}) for k, rows in grouped.items()},
        "observed_labels": {run: label for run, label in dataset["labels"].items() if run not in groups["test"]},
        "test_label_evidence_retained_in_sources_only": True,
        "validation": {k: _metrics(model, examples[k]) for k in ("train", "validation")},
        "test_used_for_fit_or_tuning": False,
        "limitations": ["Act1_survival_is_not_A10_victory", "uncalibrated_relative_score",
            "observational_return_is_not_causal_action_value", "changing_policy_changes_the_label_distribution",
            "short_horizon_may_avoid_growth_needed_in_later_acts", "whole_run_errors_excluded_even_after_Act2",
            "future_actions_require_prospective_full_A10_evaluation", "evaluated_unchosen_actions_have_no_labels"]})
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    atomic_json(output, model)
    return model


class Act1SurvivalScorer:
    """Prediction only. No choose(), policy replacement, game worker or RNG draw."""
    def __init__(self, path, *, fallback=None):
        self.model = json.loads(Path(path).read_text(encoding="utf-8"))
        self.source = file_evidence(path)
        self.fallback = fallback or InitialPolicy()
        model = self.model
        validate_model(model)
        _require(model.get("format") == VERSION and model.get("mode") == "act1_survival"
                 and model.get("target_semantics") == TARGET, "Wrong Act1Survival model schema or target")
        _require(model.get("calibrated_probability") is False and model.get("counterfactual_labels") is False
                 and model.get("chosen_action_is_optimal_label") is False, "Invalid Act1Survival label semantics")
        _require(model.get("deployment_scope") == {"character": "Defect", "ascension": 10, "mode": "standard", "act": 1},
                 "Model scope differs from Act1-only Defect A10")
        _require(model.get("feature_policy_version") == POLICY_VERSION and model["feature_names"] == list(FEATURE_NAMES),
                 "Model feature version mismatch; historical models cannot score live features")
        self.facts = validate_mechanism_facts(model.get("feature_mechanism_facts"))
        self._check_features()

    def _check_features(self):
        _require(_same(self.facts, self.fallback.mechanism_source)
                 and self.model.get("feature_prior_sha256") == self.fallback.prior.source["sha256"],
                 "Live feature facts or prior differ from the frozen model")

    def score_requests(self, state, requests, *, character, mode, selection_purpose=None):
        self._check_features()
        _require(character == "Defect" and mode == "standard" and _act(state) == 1
                 and state.get("type") == "decision" and state.get("decision") != "game_over"
                 and state.get("context", {}).get("combat_in_progress") is False,
                 "Act1Survival can only advise actual noncombat Act1 Defect A10 choices")
        packet = self.fallback.score_requests(state, requests, selection_purpose=selection_purpose)
        packet = copy.deepcopy(packet)
        packet.update(advisor_format=VERSION, target_semantics=TARGET, calibrated=False,
                      automatic_deployment=False, act1_proxy_only=True,
                      policy_id=VERSION, policy_version=VERSION, feature_policy_version=POLICY_VERSION,
                      score_semantics="uncalibrated_Act1_survival_proxy_score_not_A10_win_probability",
                      model={**self.source, "mode": "act1_survival", "calibrated_probability": False},
                      required_followup=copy.deepcopy(self.model["frozen_followup"]))
        for row in packet["scores"]:
            row["rule_score"] = row["score"]
            row["score"] = predict(self.model, row["features"])
            row["mechanism_evidence_source"] = "feature_rules; not the model's reasoning"
        skip = next((r["score"] for r in packet["scores"] if r["is_skip"]), None)
        for row in packet["scores"]:
            row["delta_from_skip"] = None if skip is None else row["score"] - skip
        return packet


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", nargs="+")
    parser.add_argument("--output", required=True)
    parser.add_argument("--regularization", type=float, default=1.)
    args = parser.parse_args()
    model = train(args.runs, args.output, regularization=args.regularization)
    print(json.dumps({"format": model["format"], "training_seed_count": model["training_seed_count"],
                      "validation": model["validation"], "automatic_deployment": False}))


if __name__ == "__main__":
    main()
