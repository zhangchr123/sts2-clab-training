"""Validate recorded actual solver configuration, including coordinator stages."""
import math


PROFILE_FIELDS = {"beam_width", "max_expanded_nodes", "max_card_branches_per_node",
                  "max_pile_choice_branches_per_action", "max_hand_choice_branches_per_action",
                  "soft_time_budget_ms", "recover_deferred_turn_frontier"}


def _profile(value):
    return (isinstance(value, dict) and PROFILE_FIELDS <= set(value)
            and all(type(value[k]) is int and value[k] > 0 for k in PROFILE_FIELDS - {"recover_deferred_turn_frontier"})
            and type(value["recover_deferred_turn_frontier"]) is bool)


def verified_solver_call(call):
    """Historical beam records remain readable; staged records require reconciliation."""
    try:
        request, response = call["request"], call["response"]
        settings = response["settings"]
        if (request.get("cmd") != "solve" or response.get("type") != "solver_result"
                or settings.get("search_profile_verified") is not True
                or not _profile(settings.get("search_profile"))
                or not {"max_degree_of_parallelism", "potion_policy", "potions", "growth_budgets"} <= set(settings)):
            return False
        backend = settings.get("solver_backend", "beam")
        if backend not in {"beam", "coordinator"} or request.get("solver_backend", "beam") != backend:
            return False
        modern = backend == "coordinator" or "search_stages" in settings or "solver_backend" in settings
        if not modern:
            return True
        stages, audit = settings.get("search_stages"), settings.get("search_stage_audit", {})
        if (not isinstance(stages, list) or not stages or audit.get("verified") is not True
                or audit.get("hook_verified") is not True or audit.get("top_level_outcome") != "solver_result"
                or settings.get("configured_search_profile") != settings["search_profile"]
                or audit.get("started_stage_count") != len(stages) or audit.get("finished_stage_count") != len(stages)):
            return False
        nodes = failures = 0
        for index, stage in enumerate(stages):
            if (type(stage.get("index")) is not int or stage["index"] != index
                    or not _profile(stage.get("search_profile")) or stage.get("observation_error") is not None
                    or type(stage.get("expanded_nodes")) is not int or stage["expanded_nodes"] < 0
                    or type(stage.get("elapsed_ms")) not in (int, float)
                    or not math.isfinite(stage["elapsed_ms"]) or stage["elapsed_ms"] < 0
                    or stage.get("effective_potion_policy") not in {"Disabled", "Smart", "RequireAtLeastOne"}
                    or not isinstance(stage.get("policy_snapshot"), dict)
                    or not isinstance(stage.get("battle_damage_snapshot"), dict)
                    or type(stage.get("minimum_potion_uses")) is not int or stage["minimum_potion_uses"] < 0
                    or "maximum_potion_uses" not in stage
                    or (stage["maximum_potion_uses"] is not None and
                        (type(stage["maximum_potion_uses"]) is not int or stage["maximum_potion_uses"] < 0))):
                return False
            if stage.get("status") == "failed":
                failures += 1
                if backend != "coordinator" or stage.get("handled_by_coordinator") is not True or not stage.get("error"):
                    return False
            elif stage.get("status") != "completed" or stage.get("error") is not None:
                return False
            nodes += stage["expanded_nodes"]
        if audit.get("observed_expanded_nodes") != nodes or audit.get("failed_stage_count") != failures:
            return False
        if backend == "coordinator" and (audit.get("total_nodes_reconciled") is not True
                or audit.get("reported_total_expanded_nodes") != nodes
                or response.get("summary", {}).get("TotalExpandedNodes") != nodes):
            return False
        return True
    except (KeyError, TypeError, AttributeError, ValueError):
        return False
