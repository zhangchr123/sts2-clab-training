"""Real engine fixtures for Dense Vegetation's headless presentation boundary.

These use set_player/enter_room and are never eligible for natural-run training.
Each run writes unique evidence, preserving earlier failures.
"""
import json
import unittest
import uuid

from combat_executor import CombatExecutor
from probe import Bridge, ROOT


class DenseVegetationTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.bridge = Bridge(self.label)
        self.send(cmd="start_run", character="Defect", ascension=10,
                  seed="dense-vegetation-fixture-v1")

    def tearDown(self):
        try:
            with (ROOT / "outputs" / (self.label + ".json")).open("x", encoding="utf-8") as handle:
                json.dump({"fixture": True, "training_eligible": False,
                           "rows": self.bridge.rows}, handle, ensure_ascii=False, indent=2)
        finally:
            self.bridge.close()

    def send(self, **request):
        result = self.bridge.send(**request)
        self.assertNotEqual(result.get("type"), "error", result)
        return result

    def enter(self, hp):
        self.send(cmd="set_player", hp=hp, max_hp=75)
        state = self.send(cmd="enter_room", type="event", event="DENSE_VEGETATION")
        self.assertEqual(state.get("decision"), "event_choice", state)
        return state

    def choose(self, state, suffix):
        matches = [option for option in state["options"]
                   if option["text_key"].endswith(suffix)]
        self.assertEqual(len(matches), 1, state)
        return self.send(cmd="action", action="choose_option",
                         args={"option_index": matches[0]["index"]})

    def test_dense_rest_then_first_combat_solver_replay(self):
        state = self.enter(40)
        heal = next(o for o in state["options"] if o["text_key"].endswith(".REST"))["vars"]["Heal"]
        state = self.choose(state, ".REST")
        self.assertEqual(state["player"]["hp"], 40 + heal)
        self.assertEqual(state["decision"], "event_choice")
        self.assertEqual(len(state["options"]), 1)
        state = self.choose(state, ".FIGHT")
        self.assertEqual(state["decision"], "combat_play", state)
        self.assertEqual(state["context"]["encounter_id"], "DENSE_VEGETATION_EVENT_ENCOUNTER")
        self.assertIs(state["context"]["combat_in_progress"], True)
        executor = CombatExecutor(self.bridge.send)
        state = executor.advance(state)
        self.assertIs(state["context"]["combat_in_progress"], False)
        self.assertIs(state["context"]["integrity_recovery_used"], False)
        self.assertIn(state["decision"], ("card_reward", "event_choice", "map_select"))
        self.assertGreater(state["player"]["hp"], 0)
        self.assertTrue(executor.solve_calls)
        self.assertTrue(all(c["response"]["type"] == "solver_result" for c in executor.solve_calls))

    def test_dense_rest_healing_is_capped_by_original_engine(self):
        state = self.choose(self.enter(74), ".REST")
        self.assertEqual(state["player"]["hp"], 75)
        self.assertEqual(state["decision"], "event_choice")
        self.assertTrue(state["options"][0]["text_key"].endswith(".FIGHT"))

    def test_dense_trudge_keeps_original_cost_and_gold(self):
        state = self.enter(40)
        choice = next(o for o in state["options"] if not o["text_key"].endswith(".REST"))
        old_gold = state["player"]["gold"]
        state = self.choose(state, choice["text_key"])
        self.assertEqual(state["player"]["hp"], 40 - choice["vars"]["HpLoss"])
        self.assertEqual(state["player"]["gold"], old_gold + choice["vars"]["Gold"])
        self.assertEqual(state["decision"], "map_select")
        self.assertIs(state["context"]["integrity_recovery_used"], False)


if __name__ == "__main__":
    unittest.main()
