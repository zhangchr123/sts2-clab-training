"""Sparse public identity and observed cost/upgrade descriptors, not card values."""
import math

from card_identity_vocabulary import CARD_IDS
from decision_data import DataContractError
from initial_policy import card_id

ID_PARAMETERS = {cid:'card_identity_' + cid.lower() for cid in CARD_IDS}
PARAMETERS = (*ID_PARAMETERS.values(), 'card_identity_unknown', 'card_actual_cost',
              'card_cost_unknown', 'card_upgrade_level', 'card_upgrade_unknown')
assert len(CARD_IDS) == len(set(CARD_IDS)) and tuple(sorted(CARD_IDS)) == CARD_IDS


def features(row, candidate):
    if row['request'] != candidate['request']:
        raise DataContractError('Card identity row/candidate mismatch')
    values = dict.fromkeys(PARAMETERS, 0.)
    action = row['request']['action']
    if action not in {'select_card_reward', 'buy_card'}:
        return values
    card = candidate['evidence']
    parameter = ID_PARAMETERS.get(card_id(card), 'card_identity_unknown')
    values[parameter] = 1.
    # In shops cost is gold. Never interpret a missing card_cost as energy.
    cost = card.get('card_cost') if action == 'buy_card' else card.get('cost')
    if type(cost) in (int,float) and math.isfinite(cost) and cost >= 0:
        values['card_actual_cost'] = min(10., float(cost)) / 10.
    else:
        values['card_cost_unknown'] = 1.
    upgrade = card.get('current_upgrade_level')
    if type(upgrade) is int and upgrade >= 0:
        values['card_upgrade_level'] = min(4,upgrade) / 4.
    else:
        values['card_upgrade_unknown'] = 1.
    return values


def zero_extend(parameters):
    from contextual_policy import PARAMETERS as ORIGINAL
    if set(parameters) != set(ORIGINAL) or any(type(v) not in (int,float)
            or not math.isfinite(v) or abs(v) > 4 for v in parameters.values()):
        raise DataContractError('Invalid original 51-parameter vector')
    return {**{n:float(parameters[n]) for n in ORIGINAL}, **dict.fromkeys(PARAMETERS,0.)}
