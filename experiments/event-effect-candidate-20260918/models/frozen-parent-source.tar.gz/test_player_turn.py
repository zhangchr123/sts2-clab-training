"""Real Ambergris extra-turn fixtures; artificial setup, never training data."""
import copy
import json
import unittest
import uuid

from combat_executor import CombatExecutor, solver_config
from probe import Bridge, ROOT


class PlayerTurnTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.b = Bridge(self.label)
        self.requests = []
        self.send(cmd="start_run", character="Defect", ascension=10,
                  seed="solver-bridge-1")
        self.send(cmd="set_player", hp=35, potions=["AMBERGRIS"])
        self.state = self.send(cmd="enter_room", type="combat",
                               encounter="SHRINKER_BEETLE_WEAK")
        self.assertEqual((self.state["round"], self.state["player_turn"]), (1, 1))
        self.state = self.send(cmd="action", action="end_turn")
        self.assertEqual((self.state["round"], self.state["player_turn"]), (2, 2))

    def tearDown(self):
        (ROOT / "outputs" / f"{self.label}.json").write_text(
            json.dumps({"provenance": "artificial Ambergris integrity fixture; not training data",
                        "requests": self.requests, "responses": self.b.rows},
                       ensure_ascii=False, indent=2), encoding="utf-8")
        self.b.close()

    def send(self, **request):
        self.requests.append(copy.deepcopy(request))
        response = self.b.send(**request)
        self.assertNotEqual(response.get("type"), "error", response)
        return response

    def finish(self, state, *, force_first_potion=False):
        config = solver_config()
        config.update(first_budget_ms=5000, replan_budget_ms=5000, max_replans=3)
        first_solve = True

        def send(**request):
            nonlocal first_solve
            if request.get("cmd") == "solve" and first_solve:
                first_solve = False
                if force_first_potion:
                    # This explicit solver directive is a regression fixture.
                    # Every plan and action still comes from the actual DLL.
                    request["potions"] = [{"slot": 0, "id": "AMBERGRIS", "directive": "Force"}]
                    request["stop_at_acceptable_hp_loss"] = False
            return self.send(**request)

        observed = []
        executor = CombatExecutor(send, config, publish=lambda s: observed.append(copy.deepcopy(s)))
        final = executor.advance(state)
        self.assertEqual(final.get("decision"), "card_reward", final)
        self.assertIs(final["context"]["combat_in_progress"], False)
        self.assertIs(final["context"]["integrity_recovery_used"], False)
        self.assertEqual(len(executor.solve_calls), 1, "Fixture must replay one real plan across the boundary")
        result = executor.solve_calls[0]["response"]
        self.assertTrue(result["snapshot"]["AllEnemiesDead"])
        self.assertEqual(final["player"]["hp"], result["snapshot"]["PlayerHp"])
        return result, observed

    def test_solver_plan_replays_ambergris_extra_turn_without_global_round_advance(self):
        result, observed = self.finish(self.state, force_first_potion=True)
        actions = result["actions"]
        potion_index = next(i for i, a in enumerate(actions)
                            if a["Kind"] == "UsePotion" and a["PotionId"] == "AMBERGRIS")
        end_index = next(i for i in range(potion_index + 1, len(actions))
                         if actions[i]["Kind"] == "EndTurn")
        self.assertEqual(actions[potion_index]["Turn"], 2)
        self.assertEqual(actions[end_index]["Turn"], 2)
        self.assertEqual(actions[end_index + 1]["Turn"], 3)
        extra = [s for s in observed if s.get("decision") == "combat_play"
                 and s["player_turn"] == 3]
        self.assertTrue(extra, "The extra player turn must be observed live")
        self.assertTrue(all(s["round"] == 2 for s in extra))
        self.assertTrue(all(not s["player"]["potions"] for s in extra))

    def test_solver_captures_actual_player_turn_after_extra_turn(self):
        state = self.send(cmd="action", action="use_potion", args={"potion_index": 0})
        self.assertEqual((state["round"], state["player_turn"]), (2, 2))
        state = self.send(cmd="action", action="end_turn")
        self.assertEqual((state["round"], state["player_turn"]), (2, 3))
        result, observed = self.finish(state)
        self.assertEqual(result["actions"][0]["Turn"], 3)
        # Ordinary turns after the extra turn retain the one-turn offset.
        later = [s for s in observed if s.get("decision") == "combat_play"
                 and s["player_turn"] > 3]
        self.assertTrue(later)
        self.assertTrue(all(s["player_turn"] == s["round"] + 1 for s in later))


if __name__ == "__main__":
    unittest.main()
