"""Original full Seeker failure replay against the repaired stage; not a natural sample."""
import copy
from pathlib import Path
import sys
import unittest
import uuid

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from combat_executor import CombatExecutor
from replay_evidence import validate_replay_evidence
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
import test_liquid_memories as helpers


class SeekerManualRepeatTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    @classmethod
    def setUpClass(cls):
        cls().replay_original_failure()

    def test_original_failure(self):
        self.assertTrue(validate_replay_evidence(*self.retained)['verified'])

    def replay_original_failure(self):
        source = Path('D:/sts2-training/staging/card-identity-residual/sts2-solver-bridge')
        name = 'defect-identity-cem-20260914a-evaluation-initial-023'
        run = source / 'outputs' / name
        audit = read_json(source / 'outputs/defect-identity-cem-20260914a/evaluation' / (name + '-audit.json'))
        self.assertTrue(not audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        self.assertEqual(audit['outcome'], 'environment_error')
        rows = read_lines(run / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'seeker-manual-repeat-fixed-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, matched, executor = False, 0, None
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(run / 'manifest.json')['solver_requested_config'])
            actual_solve, supplied = executor.solve, False
            def recorded(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied: return actual_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded
            final = executor.advance(before)
            self.assertIn(final['decision'], ('card_reward', 'map_select', 'game_over'))
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            proofs = [p for c in executor.solve_calls for p in c.get('replay', [])]
            automatic = [p for p in proofs if p['kind'] == 'seeker_automatic_continuation_completed']
            self.assertEqual(len(automatic), 1)
            self.assertEqual(automatic[0]['plan']['Cards'][0]['CardId'], 'BEAM_CELL')
            origin_id = automatic[0]['actual_origin_audit']['action_id']
            manual = [p for p in proofs if p['kind'] == 'seeker_option_choice'
                and p['actual_selection_audit'].get('seeker_continuation', {}).get('origin_action_id') == origin_id]
            self.assertEqual(len(manual), 2)
            self.assertEqual([p['plan']['Cards'][0]['CardId'] for p in manual], ['SUNDER', 'CLAW'])
            self.__class__.retained = copy.deepcopy((executor.solve_calls, traces))
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, original_failure_fixed=passed,
                origin='recorded_full_original_solver_envelope_diagnostic',
                reserved_failure_used_only_for_environment_diagnosis_not_policy_training=True,
                original_sources=audit['actual_source_evidence'], public_prefix_responses_verified=matched,
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                hidden_state_or_rng_equality_claimed=False, solver_calls=executor.solve_calls if executor else [])
            bridge.close()
            print({'label': label, 'passed': passed, 'public_prefix_responses': matched}, flush=True)

    def test_missing_duplicate_and_reordered_proofs_rejected(self):
        for variant in ('missing_manual', 'missing_automatic', 'duplicate', 'order', 'unknown'):
            calls, traces = copy.deepcopy(self.retained)
            call = next(c for c in calls if any(p['kind'] == 'seeker_automatic_continuation_completed' for p in c.get('replay', [])))
            proofs = call['replay']
            index = next(i for i, p in enumerate(proofs) if p['kind'] == 'seeker_automatic_continuation_completed')
            if variant == 'missing_manual': del proofs[index - 1]
            elif variant == 'missing_automatic': del proofs[index]
            elif variant == 'duplicate': proofs.append(copy.deepcopy(proofs[index]))
            elif variant == 'order': proofs[index - 1], proofs[index] = proofs[index], proofs[index - 1]
            else: proofs[index]['invented_claim'] = True
            with self.subTest(variant=variant), self.assertRaises(ValueError):
                validate_replay_evidence(calls, traces)

    def test_omitted_automatic_plan_proof_and_query_cannot_hide_original_return(self):
        calls, traces = copy.deepcopy(self.retained)
        proof = next(p for c in calls for p in c.get('replay', [])
            if p['kind'] == 'seeker_automatic_continuation_completed')
        original_action = proof['original_action']
        for call in calls + [row for row in traces if row['request']['cmd'] == 'solve']:
            for action in call['response'].get('actions', []):
                if action == original_action: action['NestedChoices'].pop()
        for call in calls:
            call['replay'] = [p for p in call.get('replay', []) if p['kind'] != 'seeker_automatic_continuation_completed']
        traces = [row for row in traces if not (row['request'] == {'cmd': 'choice_meta'}
            and row['response'].get('selection') == 'none'
            and row['response'].get('completion_audit', {}).get('seeker_continuation')
            and row['response']['completion_audit'].get('original_returns'))]
        with self.assertRaisesRegex(ValueError, 'original automatic return has no corresponding solver plan'):
            validate_replay_evidence(calls, traces)

    def test_joint_trace_and_proof_continuation_tampering_rejected(self):
        proof = next(p for c in self.retained[0] for p in c.get('replay', []) if p['kind'] == 'seeker_automatic_continuation_completed')
        data = proof['actual_choice_metadata']['completion_audit']['seeker_continuation']
        def alter(obj, key, missing):
            if isinstance(obj, dict):
                continuation = obj.get('seeker_continuation')
                if isinstance(continuation, dict) and key in continuation:
                    if missing: del continuation[key]
                    else:
                        value = continuation[key]
                        continuation[key] = (not value if type(value) is bool else value + 7 if type(value) is int
                            else {} if isinstance(value, dict) else 'wrong')
                for value in obj.values(): alter(value, key, missing)
            elif isinstance(obj, list):
                for value in obj: alter(value, key, missing)
        for key in data:
            for missing in (False, True):
                calls, traces = copy.deepcopy(self.retained)
                alter(calls, key, missing); alter(traces, key, missing)
                with self.subTest(key=key, missing=missing), self.assertRaises(ValueError):
                    validate_replay_evidence(calls, traces)

    def test_joint_original_singleton_return_tampering_rejected(self):
        proof = next(p for c in self.retained[0] for p in c.get('replay', []) if p['kind'] == 'seeker_automatic_continuation_completed')
        event = proof['actual_choice_metadata']['completion_audit']['original_returns'][0]
        def alter(obj, key):
            if isinstance(obj, dict):
                if obj.get('effect_callsite') == 'SeekerStrike.OnPlay' and obj.get('source_pile') == 'Draw':
                    obj.pop(key, None)
                for value in obj.values(): alter(value, key)
            elif isinstance(obj, list):
                for value in obj: alter(value, key)
        for key in event:
            calls, traces = copy.deepcopy(self.retained)
            alter(calls, key); alter(traces, key)
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_replay_evidence(calls, traces)

    def test_changed_second_selection_request_and_missing_sample_metadata_rejected(self):
        for variant in ('selection', 'missing_meta', 'source_key', 'sample_order'):
            calls, traces = copy.deepcopy(self.retained)
            query = next(i for i, t in enumerate(traces) if t['request'] == {'cmd': 'choice_meta'}
                and t['response'].get('seeker_choice') is not None
                and t['response'].get('completion_audit', {}).get('seeker_continuation') is not None)
            meta = traces[query]['response']
            if variant == 'selection': traces[query + 1]['request']['args']['indices'] = '0'
            elif variant == 'missing_meta': del meta['seeker_choice']
            elif variant == 'source_key': meta['seeker_choice']['source_cards'][0]['StateKey'] = 'wrong'
            else: meta['seeker_choice']['sample_cards'].reverse()
            with self.subTest(variant=variant), self.assertRaises(ValueError):
                validate_replay_evidence(calls, traces)


if __name__ == '__main__': unittest.main(verbosity=2)
