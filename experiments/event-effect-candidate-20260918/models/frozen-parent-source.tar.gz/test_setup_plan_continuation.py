"""Pure tests: authenticated original setup plan continuation and trace evidence."""
import copy
import unittest

from combat_executor import CombatExecutor
from replay_evidence import validate_replay_evidence
from test_combat_executor import FakeEngine, card, choice_meta, solved, state, token


def fixture():
    cards = [card("zap+1", level=1, id="ZAP"), card("strike", id="STRIKE_DEFECT")]
    before = state("card_select", cards=cards)
    after = state()
    for s in (before, after):
        s["player"].update(name="The Defect", hp=60, relics=[{"id": "RELIC.TOASTY_MITTENS"}])
        s["player"]["combat_metrics"]["combat_id"] = 4
        s["context"].update(act=3, floor=15, encounter_id="AEONGLASS_BOSS")
    origin = {"schema_version": "turn-setup-origin-v1", "capture_id": 37,
        "capture_method": "CombatManager.SetupPlayerTurn.prefix", "player_id": "1",
        "captured_turn": 1, "captured_phase": "Start", "live_player_turn": 1,
        "live_phase": "Start", "live_same_combat": True, "current_side": "Player"}
    plan = {"Effect": "Exhaust", "SourcePile": "Hand", "Timing": "PlayerTurnStart",
        "SourceId": "TOASTY_MITTENS", "ContextId": "", "Cards": [token("zap+1", id="ZAP", level=1)]}
    meta = choice_meta(cards)
    meta["setup_origin"] = copy.deepcopy(origin)
    meta["setup_choice"] = {"schema_version": "toasty-mittens-setup-choice-v1", "capture_id": 37,
        "source_method": "CardSelectCmd.FromHand", "source_id": "TOASTY_MITTENS",
        "source_is_current_live_relic": True, "original_task_pending": True,
        "player_id": "1", "player_turn": 1, "effect": "Exhaust", "source_pile": "Hand",
        "timing": "PlayerTurnStart", "context_id": "", "min_select": 1, "max_select": 1, "filter_is_null": True}
    after["choice_audit"] = {"schema_version": "combat-choice-return-v2", "action_id": 42, "closed": True,
        "parent": {"action": "select_cards", "card_index": -1, "player_id": "1", "combat_id": 4,
                   "player_turn": 1, "combat_active_before": True}, "events": []}
    post = choice_meta([], "none")
    post.update(setup_choice=None, setup_origin={**origin, "live_phase": "Play"}, completion_audit=copy.deepcopy(after["choice_audit"]))
    first = {"Kind": "UsePotion", "Turn": 1, "PotionSlot": 1, "PotionId": "FOCUS_POTION", "TargetIndex": -1}
    end = {"Kind": "EndTurn", "Turn": 1}
    result = solved([first, end])
    result.update(setup_origin=origin, summary={"StartTurnNumber": 1}, turn_setup_choices=[plan])
    return before, after, meta, post, result


def run_fixture():
    before, after, meta, post, result = fixture()
    final = state("game_over", active=False)
    combat_meta = {"type": "combat_meta", "hand": [], "enemies": [],
        "potions": [{"slot": 1, "id": "FOCUS_POTION", "index": 0}]}
    after_potion = copy.deepcopy(after)
    after_potion["player_powers"] = [{"name": "Focus", "amount": 2}]
    engine = FakeEngine([result, meta, after, post, combat_meta, after_potion, final])
    traces = [{"request": {"cmd": "start_run"}, "response": copy.deepcopy(before)}]
    def send(**request):
        response = engine(**request)
        traces.append({"request": copy.deepcopy(request), "response": copy.deepcopy(response)})
        return response
    executor = CombatExecutor(send)
    executor.advance(before)
    return executor, engine, traces


class SetupContinuationTests(unittest.TestCase):
    def test_verified_setup_reuses_original_first_potion_without_a_second_solve(self):
        executor, engine, traces = run_fixture()
        self.assertEqual(sum(r.get("cmd") == "solve" for r in engine.requests), 1)
        self.assertEqual([r.get("action") for r in engine.requests if r.get("cmd") == "action"],
            ["select_cards", "use_potion", "end_turn"])
        self.assertEqual(engine.requests[2]["args"], {"indices": "0"})
        proof = executor.solve_calls[0]["replay"][0]
        self.assertEqual(proof["first_action"]["PotionId"], "FOCUS_POTION")
        self.assertEqual(proof["actual_first_request"]["args"], {"potion_index": 0})
        original = copy.deepcopy((executor.solve_calls, traces))
        self.assertEqual(validate_replay_evidence(executor.solve_calls, traces)["replay_count"], 1)
        self.assertEqual((executor.solve_calls, traces), original)

    def test_source_capture_task_and_exact_token_mismatches_block_before_selection(self):
        for key, value in [("capture_id", 38), ("player_id", "2"), ("player_turn", 2),
            ("source_is_current_live_relic", False), ("original_task_pending", False),
            ("source_method", "Another"), ("filter_is_null", False), ("timing", "Action")]:
            before, after, meta, post, result = fixture()
            meta["setup_choice"][key] = value
            engine = FakeEngine([result, meta])
            with self.subTest(key=key), self.assertRaises(RuntimeError): CombatExecutor(engine).advance(before)
            self.assertFalse(any(r.get("cmd") == "action" for r in engine.requests))
        before, after, meta, post, result = fixture()
        meta["cards"][0]["key"] = "other-zap"
        engine = FakeEngine([result, meta])
        with self.assertRaisesRegex(RuntimeError, "Choice token mismatch"): CombatExecutor(engine).advance(before)
        self.assertFalse(any(r.get("cmd") == "action" for r in engine.requests))

    def test_post_setup_pending_cross_combat_turn_or_phase_never_executes_original_actions(self):
        for mutation in ("combat", "turn", "phase", "pending", "parent", "terminal"):
            before, after, meta, post, result = fixture()
            if mutation == "combat": after["player"]["combat_metrics"]["combat_id"] = 5
            if mutation == "turn": after["player_turn"] = 2
            if mutation == "phase": post["setup_origin"]["live_phase"] = "Start"
            if mutation == "pending": post["selection"] = "card_select"
            if mutation == "parent": after["choice_audit"]["parent"]["player_id"] = "another"
            if mutation == "terminal": after.update(decision="game_over", context={"combat_in_progress": False})
            engine = FakeEngine([result, meta, after, post])
            with self.subTest(mutation=mutation), self.assertRaises(RuntimeError): CombatExecutor(engine).advance(before)
            self.assertEqual([r.get("action") for r in engine.requests if r.get("cmd") == "action"], ["select_cards"])

    def test_unknown_setup_keeps_previous_replan_behavior_and_explicit_nonreuse_reason(self):
        before, after, meta, post, result = fixture()
        result["turn_setup_choices"][0]["SourceId"] = "UNKNOWN_RELIC"
        engine = FakeEngine([result, meta, after, solved([{"Kind": "EndTurn", "Turn": 1}]), state("game_over", active=False)])
        executor = CombatExecutor(engine)
        executor.advance(before)
        self.assertEqual(len(executor.solve_calls), 2)
        self.assertEqual(executor.solve_calls[0]["setup_plan_reuse"],
            {"schema_version": "setup-plan-reuse-v1", "reused": False, "reason": "unsupported_setup_source_or_shape"})
        self.assertNotIn("replay", executor.solve_calls[0])

    def test_first_action_card_fingerprint_change_replans_without_claiming_original_execution(self):
        before, after, meta, post, result = fixture()
        result["actions"][0] = {"Kind": "PlayCard", "Turn": 1, "CardId": "GUNK_UP",
            "CardStateKey": "gunk+1", "TargetIndex": -1}
        engine = FakeEngine([result, meta, after, post, {"type": "combat_meta", "hand": [{"index": 0, "key": "gunk+0"}]},
            solved([{"Kind": "EndTurn", "Turn": 1}]), state("game_over", active=False)])
        executor = CombatExecutor(engine)
        executor.advance(before)
        self.assertEqual(len(executor.solve_calls), 2)
        self.assertEqual(executor.solve_calls[0]["setup_plan_reuse"]["reason"], "first_action_fingerprint_changed")
        self.assertNotIn("replay", executor.solve_calls[0])
        self.assertEqual([r.get("action") for r in engine.requests if r.get("cmd") == "action"], ["select_cards", "end_turn"])

    def test_setup_evidence_missing_unknown_tampered_or_wrong_first_action_fails_audit(self):
        for mutation in ("missing", "source", "capture", "indices", "first", "actual_first", "cross_solve", "extra"):
            executor, engine, traces = run_fixture()
            calls = executor.solve_calls
            proof = calls[0]["replay"][0]
            if mutation == "missing": calls[0].pop("replay")
            if mutation == "source": proof["actual_choices"][0]["actual_choice_metadata"]["setup_choice"]["source_id"] = "OTHER"
            if mutation == "capture": proof["setup_origin"]["capture_id"] += 1
            if mutation == "indices": traces[3]["request"]["args"]["indices"] = "1"
            if mutation == "first": proof["first_action"]["PotionSlot"] = 0
            if mutation == "actual_first": traces[6]["request"]["args"]["potion_index"] = 1
            if mutation == "cross_solve":
                extra = {"request": copy.deepcopy(calls[0]["request"]), "response": copy.deepcopy(calls[0]["response"])}
                calls.append(extra)
                traces.insert(5, extra)
            if mutation == "extra": proof["winning_plan_verified"] = True
            with self.subTest(mutation=mutation), self.assertRaises(ValueError): validate_replay_evidence(calls, traces)

    def test_optional_reuse_diagnostic_is_strict_and_matches_observed_execution(self):
        for mutation in ({"reused": False, "reason": "first_action_fingerprint_changed"},
                         {"reused": 1}, {"reason": "unknown"}, {"schema_version": "unknown"}, {"extra": True}):
            executor, _, traces = run_fixture()
            executor.solve_calls[0]["setup_plan_reuse"].update(mutation)
            with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, "diagnostic"):
                validate_replay_evidence(executor.solve_calls, traces)
        executor, _, traces = run_fixture()
        del executor.solve_calls[0]["setup_plan_reuse"]
        self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)["verified"])


if __name__ == "__main__": unittest.main()
