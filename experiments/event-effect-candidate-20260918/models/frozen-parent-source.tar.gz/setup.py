"""Prepare isolated local DLL copies; never modify Steam or workshop files."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CLI = ROOT.parent / "sts2-cli"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--game", type=Path, required=True, help="Steam game root")
    parser.add_argument("--solver", type=Path, required=True, help="CombatSolver.dll")
    parser.add_argument("--ritsu", type=Path, required=True, help="version-compatible STS2-RitsuLib.dll")
    args = parser.parse_args()
    game = args.game.resolve()
    engine = game / "data_sts2_windows_x86_64"
    sources = [engine / name for name in (
        "sts2.dll", "SmartFormat.dll", "SmartFormat.ZString.dll", "Sentry.dll", "Sentry.Godot.dll",
        "Steamworks.NET.dll", "MonoMod.Backports.dll", "MonoMod.ILHelpers.dll", "0Harmony.dll", "System.IO.Hashing.dll")]
    sources += [args.solver.resolve(), args.ritsu.resolve()]
    for path in sources:
        if not path.is_file():
            raise FileNotFoundError(path)
    for folder in (CLI / "lib", ROOT / "lib", ROOT / "patcher", ROOT / "outputs"):
        folder.mkdir(parents=True, exist_ok=True)
    checksums = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    for path in sources:
        target = ROOT / "lib" if path in sources[-2:] else CLI / "lib"
        shutil.copy2(path, target / path.name)
    shutil.copy2(CLI / "lib/sts2.dll", CLI / "lib/sts2.dll.original")
    # Use the pinned CLI's own IL adapter on its local copy only.
    setup = (CLI / "setup.sh").read_text(encoding="utf-8")
    for tag, name in (("PROJ", "Patcher.csproj"), ("CSHARP", "Program.cs")):
        content = re.search(r"<< '" + tag + r"'\n(.*?)\n" + tag, setup, re.S).group(1)
        (ROOT / "patcher" / name).write_text(content, encoding="utf-8")
    subprocess.run(["dotnet", "run", "--project", str(ROOT / "patcher"), "--", str(CLI / "lib/sts2.dll")], check=True)
    for target in (CLI, ROOT):
        subprocess.run([sys.executable, str(CLI / "scripts/extract_localization.py"), str(game / "SlayTheSpire2.pck"), "--root", str(target)], check=True)
    for project in (CLI / "src/Sts2Headless/Sts2Headless.csproj", ROOT / "SolverBridge.csproj"):
        subprocess.run(["dotnet", "build", str(project), "--nologo", "-v", "quiet"], check=True)
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == digest for p, digest in checksums.items())
    (ROOT / "outputs/source-manifest.json").write_text(json.dumps(checksums, indent=2), encoding="utf-8")
    print("Prepared and built; original Steam/workshop file hashes unchanged.")


if __name__ == "__main__":
    main()
