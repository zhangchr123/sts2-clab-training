"""Original Dredge mandatory discard-pile return and shared online/offline evidence contracts."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers
from inspection.trial_cosmetic_projection import project_trial_number


class DredgeReturnTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def original_case(self, candidate):
        source = Path('D:/sts2-training/staging/seeker-manual-repeat-return/sts2-solver-bridge')
        batch = 'defect-identity-warm-cem-20260915a'
        name = batch + f'-generation-03-{candidate}-002'
        run = source / 'outputs' / name
        audit = read_json(source / 'outputs' / batch / 'generation-03' / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        self.assertEqual(audit['report']['outcome'], 'environment_error')
        rows = read_lines(run / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'dredge-full-fixed-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, matched, executor = False, 0, None
        display_differences = []
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}:
                    continue
                before = send(row['request'])
                actual_public, actual_display = project_trial_number(checked_public(before))
                original_public, original_display = project_trial_number(checked_public(row['response']))
                self.assertEqual(actual_public, original_public)
                if actual_display or original_display:
                    display_differences.append({'public_prefix_index': matched, 'actual': actual_display, 'original': original_display})
                matched += 1
            executor = CombatExecutor(send, read_json(run / 'manifest.json')['solver_requested_config'])
            actual_solve, supplied = executor.solve, False
            def recorded(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied:
                    return actual_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded
            final = executor.advance(before)
            self.assertIn(final['decision'], {'card_reward', 'game_over', 'map_select'})
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            proofs = [p for p in executor.solve_calls[0].get('replay', [])
                if p.get('actual_choice_audit', {}).get('parent', {}).get('card_id') == 'DREDGE']
            self.assertEqual(len(proofs), 1)
            self.assertEqual(proofs[0]['kind'], 'original_choice_return_completed')
            original_choice = next(a['Choice'] for a in original['response']['actions'] if a.get('CardId') == 'DREDGE')
            self.assertEqual([c['CardId'] for c in proofs[0]['selected_cards']], [c['CardId'] for c in original_choice['Cards']])
            self.assertFalse(proofs[0]['selection_request_sent'])
            for field, value in [('source_is_actual_parent_object', False),
                ('original_task_completed_successfully', False), ('returned_objects_match_original_source', False),
                ('filter_is_null', True), ('filter_reexecuted_by_observer', True),
                ('selector_pending_after', True), ('selector_invocations_after', -1),
                ('raw_source_count_at_entry', -1), ('returned_count', 0), ('player_turn', -1),
                ('dredge_hand_capacity', 11), ('dredge_cards_at_entry', 4), ('dredge_hand_count_at_entry', -1), ('source_id', 'SCAVENGE'), ('effect_callsite', 'Scavenge.OnPlay')]:
                def corrupt(data):
                    if isinstance(data, dict):
                        for key in data:
                            if key == field:
                                data[key] = value
                            else:
                                corrupt(data[key])
                    elif isinstance(data, list):
                        for item in data:
                            corrupt(item)
                bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                corrupt(bad_calls)
                corrupt(bad_traces)
                with self.subTest(field=field), self.assertRaises((ValueError, RuntimeError)):
                    validate_replay_evidence(bad_calls, bad_traces)
            bad_calls = copy.deepcopy(executor.solve_calls)
            bad_calls[0]['replay'].remove(proofs[0])
            with self.assertRaises(ValueError):
                validate_replay_evidence(bad_calls, traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='recorded_full_original_solver_envelope_diagnostic',
                public_prefix_responses_verified=matched, original_sources=audit['actual_source_evidence'],
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                hidden_state_or_rng_equality_claimed=False, all_public_fields_identical_claimed=False,
                diagnostic_only_Trial_display_number_projection=display_differences,
                solver_calls=executor.solve_calls if executor else [])
            bridge.close()

    def test_three_valid_original_full_plans_and_joint_corruption_rejection(self):
        # c12's recorded solver plan has the separate forced-selection ordering
        # bug. Its preserved failure and fresh corrected search are verified in
        # test_forced_choice_order; do not pretend that old plan is executable.
        for candidate in (1, 6, 13):
            with self.subTest(candidate=candidate): self.original_case(candidate)

    def boundary(self, count, upgraded=False, full_hand=False):
        label = f'dredge-discard-n{count}-u{int(upgraded)}-full{int(full_hand)}-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, action, proofs = False, None, []
        try:
            self.assertFalse(full_hand and upgraded)
            send(cmd='start_run', character='Defect', ascension=10, seed='dredge-original-boundaries')
            potions = ['SWIFT_POTION', 'SWIFT_POTION'] if full_hand else ['BLESSING_OF_THE_FORGE'] if upgraded else []
            deck = ['DREDGE'] * (10 if full_hand else 1) + ['DEFLECT'] * count
            send(cmd='set_player', hp=1000, max_hp=1000, relics=['BAG_OF_PREPARATION'] if full_hand and count == 3 else [], potions=potions, deck=deck)
            before = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
            if full_hand:
                self.assertEqual(len(before['hand']), 7 if count == 3 else 5)
                # Only arrange the already-visible synthetic draw-pile fixture;
                # all drawing, discarding and hand limits use original actions.
                send(cmd='set_draw_order', cards=['DEFLECT'] * count)
                before = send(cmd='action', action='use_potion', args={'potion_index': 0})
            elif upgraded:
                before = send(cmd='action', action='use_potion', args={'potion_index': 0})
            meta = send(cmd='combat_meta')
            defend = next((c for c in before['hand'] if c['id'] == 'CARD.DEFLECT'), None)
            token_key = next((c['key'] for c in meta['hand'] if defend and c['index'] == defend['index']), None)
            for _ in range(count):
                defend = next(c for c in before['hand'] if c['id'] == 'CARD.DEFLECT')
                before = send(cmd='action', action='play_card', args={'card_index': defend['index']})
            if full_hand:
                before = send(cmd='action', action='use_potion', args={'potion_index': 0})
                self.assertEqual(len(before['hand']), 10)
            self.assertEqual(before['discard_pile_count'], count)
            actor = next(c for c in before['hand'] if c['id'] == 'CARD.DREDGE')
            meta = send(cmd='combat_meta')
            key = next(c['key'] for c in meta['hand'] if c['index'] == actor['index'])
            limit = min(3, 11 - len(before['hand']))
            selected = min(limit, count)
            cards = [{'CardId': 'DEFLECT', 'UpgradeLevel': int(upgraded), 'StateKey': token_key,
                'SourceOccurrence': i, 'OptionOccurrence': i} for i in range(selected)]
            action = {'Kind': 'PlayCard', 'CardId': 'DREDGE', 'CardStateKey': key,
                'CardUpgradeLevel': int(upgraded), 'CardStateOccurrence': 0, 'ReplayCount': 0,
                'Turn': before['player_turn'], 'TargetIndex': -1, 'TargetCombatId': None,
                'Choice': {'Effect': 'MoveToHand', 'SourcePile': 'Discard', 'SourceId': '',
                    'ContextId': '', 'Timing': 'Action', 'Cards': cards}}
            request = {'cmd': 'action', 'action': 'play_card', 'args': {'card_index': actor['index']}}
            after = send(request)
            executor = CombatExecutor(send); executor.last_action_request = request
            executor.solve_calls = [{'test_only_synthetic_plan': True}]
            if count <= limit:
                self.assertEqual(after['decision'], 'combat_play')
                event = after['choice_audit']['original_returns'][0]
                self.assertEqual(event['min_select'], limit)
                self.assertEqual(event['max_select'], limit)
                self.assertEqual(event['raw_source_count_at_entry'], count)
                self.assertEqual(event['dredge_hand_count_at_entry'], len(before['hand']) - 1)
                self.assertEqual(event['returned_cards'], cards)
                self.assertEqual(event['original_returned_collection'], 'List<CardModel>' if count else 'CardModel[]')
                self.assertTrue(executor.resolve_original_automatic_choice(before, after, action))
                proofs = executor.solve_calls[0]['replay']
                self.assertFalse(proofs[0]['selection_request_sent'])
                self.assertFalse(proofs[0]['remaining_battle_plan_stopped'])
            else:
                self.assertEqual(after['decision'], 'card_select')
                self.assertEqual(len(after['cards']), count)
                self.assertEqual(after['choice_audit']['original_returns'], [])
                self.assertFalse(executor.resolve_original_automatic_choice(before, after, action))
                after = send(cmd='action', action='select_cards', args={'indices': ','.join(str(i) for i in range(limit))})
                self.assertEqual(after['decision'], 'combat_play')
            self.assertEqual(len(after['hand']), len(before['hand']) - 1 + selected)
            self.assertEqual(after['discard_pile_count'], count - selected)
            self.assertEqual(after['player_turn'], before['player_turn'])
            self.assertTrue(after['context']['combat_in_progress'])
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='synthetic_original_discard_pile_boundary',
                constructed_plan_is_not_solver_output=True, synthetic_plan=action, direct_unit_proofs=proofs,
                upgraded=upgraded, full_hand=full_hand, original_draw_order_arranged=full_hand,
                hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_original_empty_one_two_three_and_manual_four_base_and_upgraded(self):
        for upgraded in (False, True):
            for count in range(5):
                with self.subTest(upgraded=upgraded, count=count): self.boundary(count, upgraded=upgraded)

    def test_original_full_hand_caps_automatic_and_manual_return(self):
        for count in (0, 1, 3):
            with self.subTest(count=count): self.boundary(count, full_hand=True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
