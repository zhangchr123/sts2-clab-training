"""Original full combat, pending task ownership, and false replay-proof rejection."""
import copy
import json
from pathlib import Path
import unittest
import uuid
from prefix_interventions import read_json,read_lines,unchanged
from inspection.replay_cheese_event import checked_public
from inspection.trial_cosmetic_projection import project_trial_number
from combat_executor import CombatExecutor
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT.parent.with_name('unpredicted-toasty-setup-replan')/'sts2-solver-bridge'
NAME='defect-identity-local-search-20260915a-training-candidate-15-022'

class SecretTechniqueRepeat(unittest.TestCase):
    worker=helpers.LiquidMemoriesTests.worker
    save=helpers.LiquidMemoriesTests.save

    def prefix(self):
        audit=read_json(ORIGINAL/'outputs/defect-identity-local-search-20260915a'/(NAME+'-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        rows=read_lines(ORIGINAL/'outputs'/NAME/'trace.jsonl')
        label='secret-technique-fixed-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);matched=0
        try:
            for row in rows[:382]:
                if row['request']['cmd'] in ('solve','combat_meta','choice_meta'):continue
                state=send(row['request'])
                self.assertEqual(project_trial_number(checked_public(state))[0],project_trial_number(checked_public(row['response']))[0])
                matched+=1
            self.assertEqual(matched,231)
            return bridge,traces,send,state,rows,audit,label
        except BaseException:bridge.close();raise

    def recorded(self,corrupt,swap=False):
        bridge,traces,send,state,rows,audit,label=self.prefix();passed=False;executor=None;final=None
        try:
            original=copy.deepcopy(rows[382]);self.assertEqual(len(original['response']['actions']),27)
            if swap:
                action=original['response']['actions'][20]
                action['Choice']['Cards'],action['NestedChoices'][0]['Cards']=action['NestedChoices'][0]['Cards'],action['Choice']['Cards']
            class RecordedPlan(CombatExecutor):
                def solve(inner,state,budget,used=0,setup=False):
                    if swap and inner.solve_calls:
                        return super().solve(state,budget,used,setup)
                    self.assertEqual(len(inner.solve_calls),0,'Original complete plan requested replacement')
                    call=copy.deepcopy(original);traces.append(copy.deepcopy(call));inner.solve_calls.append(call)
                    return call['response']
            executor=RecordedPlan(send,read_json(ORIGINAL/'outputs'/NAME/'manifest.json')['solver_requested_config'])
            start=len(traces);final=executor.advance(state)
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertFalse(final['context']['integrity_recovery_used'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
            if swap:self.assertGreater(len(executor.solve_calls),1)
            proof=next(p for p in executor.solve_calls[0]['replay'] if p.get('actual_choice_audit',{}).get('secret_technique_continuation'))
            self.assertEqual([c['CardId'] for c in proof['selected_cards']],['CHAOS' if swap else 'RAINBOW'])
            self.assertTrue(proof['manual_selection_request_sent']);self.assertFalse(proof['automatic_selection_request_sent'])
            event=proof['actual_choice_audit']['original_returns'][0]
            self.assertEqual(event['raw_source_count_at_entry'],2)
            self.assertEqual(proof['actual_choice_audit']['secret_technique_continuation']['original_source_count_at_entry'],3)
            if corrupt:
                at=next(i for i in range(start,len(traces)) if traces[i]['request'].get('action')=='play_card'
                    and traces[i]['response'].get('choice_audit',{}).get('parent',{}).get('card_id')=='SECRET_TECHNIQUE'
                    and traces[i]['response'].get('choice_audit',{}).get('parent',{}).get('player_turn')==5)
                before=next(r['response'] for r in reversed(traces[:at]) if 'context' in r['response'])
                action=original['response']['actions'][20];pending=traces[at]['response']
                true_fields=['original_task_pending_at_resume','selector_task_identity_matches','source_is_original_card_object',
                    'original_branch_context_verified','original_play_task_pending_at_resume','original_play_task_completed_successfully',
                    'original_task_completed_successfully','selector_task_completed_successfully','original_and_selector_return_same_card_objects']
                mutations=[('secret_technique_continuation',k,False) for k in true_fields]
                mutations += [('secret_technique_continuation',k,v) for k,v in {
                    'original_source_count_at_entry':2,'original_play_card_id':'HAND_TRICK',
                    'original_play_action_id':999,'original_play_cancelled':True,'selector_invocation_at_end':999,
                    'original_task_returned_count':0,'origin_action_id':True}.items()]
                mutations += [('return',k,v) for k,v in {'returned_cards':[],'returned_count':0,
                    'source_id':'HAND_TRICK','source_method':'CardSelectCmd.FromHand','filter_reexecuted_by_observer':True,
                    'selector_invocations_after':999,'raw_source_count_at_entry':3,'verified':False}.items()]
                for location,key,value in mutations:
                    with self.subTest(location=location,key=key):
                        following=copy.deepcopy(traces[at+1:at+4]);changed=following[1]['response']['choice_audit']
                        obj=changed['original_returns'][0] if location=='return' else changed[location];obj[key]=value
                        following[2]['response']['completion_audit']=copy.deepcopy(changed)
                        cursor=iter(following)
                        def observed(**request):
                            row=next(cursor);self.assertEqual(request,row['request']);return copy.deepcopy(row['response'])
                        checker=CombatExecutor(observed);checker.solve_calls=[{}];checker.last_action_request=traces[at]['request']
                        with self.assertRaises(RuntimeError):checker.resolve_secret_technique_continuation(before,pending,action)
                for mutation in ('omit','selected','manual_request','source'):
                    calls=copy.deepcopy(executor.solve_calls);index=next(i for i,p in enumerate(calls[0]['replay']) if p==proof)
                    if mutation=='omit':calls[0]['replay'].pop(index)
                    elif mutation=='selected':calls[0]['replay'][index]['selected_cards']=[]
                    elif mutation=='manual_request':calls[0]['replay'][index]['manual_choice']['actual_request']['args']['indices']='1'
                    else:calls[0]['replay'][index]['actual_choice_audit']['secret_technique_continuation']['original_play_card_id']='HAND_TRICK'
                    with self.subTest(replay=mutation),self.assertRaises(ValueError):validate_replay_evidence(calls,traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']));passed=True
        finally:
            self.save(label,traces,passed=passed,diagnostic_only=True,training_sample=False,
                original_sources=audit['actual_source_evidence'],public_prefix_responses=231,actual_final=final,
                explicit_recorded_full_plan=not swap,legal_choice_order_intervention=swap,
                first_plan_is_fresh_search=False,subsequent_original_solver_calls=max(0,len(executor.solve_calls)-1) if executor else 0,
                solver_calls=executor.solve_calls if executor else [],complete_hidden_state_or_rng_equality_claimed=False)
            bridge.close();print(json.dumps({'label':label,'passed':passed,'hp':final.get('player',{}).get('hp') if final else None}),flush=True)

    def test_original_twenty_seven_action_plan_completes(self):self.recorded(False)
    def test_original_task_and_return_tampering_rejected(self):self.recorded(True)
    def test_opposite_legal_first_selection_returns_other_original_skill(self):self.recorded(False,swap=True)

    def test_fresh_original_solver_finishes_combat(self):
        bridge,traces,send,state,rows,audit,label=self.prefix();passed=False;executor=None;final=None
        try:
            executor=CombatExecutor(send,read_json(ORIGINAL/'outputs'/NAME/'manifest.json')['solver_requested_config'])
            final=executor.advance(state)
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertFalse(final['context']['integrity_recovery_used'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
            self.assertTrue(unchanged(audit['actual_source_evidence']));passed=True
        finally:
            self.save(label,traces,passed=passed,diagnostic_only=True,training_sample=False,
                original_sources=audit['actual_source_evidence'],public_prefix_responses=231,actual_final=final,
                solver_calls=executor.solve_calls if executor else [],complete_hidden_state_or_rng_equality_claimed=False)
            bridge.close();print(json.dumps({'label':label,'passed':passed,'fresh_solver':True,'hp':final.get('player',{}).get('hp') if final else None}),flush=True)

if __name__=='__main__':unittest.main(verbosity=2)
