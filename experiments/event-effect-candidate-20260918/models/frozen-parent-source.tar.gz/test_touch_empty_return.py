"""Original empty filtered potion return, live filter boundaries, and offline corruption rejection."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers


class TouchEmptyReturnTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def test_original_full_plan_and_joint_corruption_rejection(self):
        source = Path('D:/sts2-training/staging/seeker-manual-repeat-return/sts2-solver-bridge')
        batch = 'defect-identity-warm-cem-20260915a'
        name = batch + '-generation-02-6-001'
        run = source / 'outputs' / name
        audit = read_json(source / 'outputs' / batch / 'generation-02' / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        self.assertEqual(audit['outcome'], 'environment_error')
        rows = read_lines(run / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'touch-empty-full-fixed-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, matched, executor = False, 0, None
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}:
                    continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(run / 'manifest.json')['solver_requested_config'])
            actual_solve, supplied = executor.solve, False
            def recorded(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied:
                    return actual_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded
            final = executor.advance(before)
            self.assertIn(final['decision'], {'card_reward', 'game_over', 'map_select'})
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            proofs = [p for p in executor.solve_calls[0].get('replay', [])
                if p.get('actual_choice_audit', {}).get('parent', {}).get('potion_id') == 'TOUCH_OF_INSANITY']
            self.assertEqual(len(proofs), 1)
            self.assertEqual(proofs[0]['kind'], 'original_choice_return_completed')
            self.assertEqual(proofs[0]['selected_cards'], [])
            self.assertEqual(proofs[0]['reason'], 'engine_empty_filtered_selection')
            self.assertFalse(proofs[0]['remaining_battle_plan_stopped'])
            self.assertEqual(proofs[0]['actual_choice_audit']['original_returns'][0]['raw_source_count_at_entry'], 5)
            self.assertFalse(proofs[0]['selection_request_sent'])
            for field, value in [('source_is_actual_parent_object', False),
                ('original_task_completed_successfully', False), ('returned_objects_match_original_source', False),
                ('filter_is_null', True), ('filter_reexecuted_by_observer', True),
                ('selector_pending_after', True), ('selector_invocations_after', -1),
                ('raw_source_count_at_return', 6), ('returned_count', 1), ('player_turn', -1),
                ('source_id', 'SCAVENGE'), ('effect_callsite', 'Scavenge.OnPlay')]:
                def corrupt(data):
                    if isinstance(data, dict):
                        for key in data:
                            if key == field:
                                data[key] = value
                            else:
                                corrupt(data[key])
                    elif isinstance(data, list):
                        for item in data:
                            corrupt(item)
                bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                corrupt(bad_calls)
                corrupt(bad_traces)
                with self.subTest(field=field), self.assertRaises((ValueError, RuntimeError)):
                    validate_replay_evidence(bad_calls, bad_traces)
            bad_calls = copy.deepcopy(executor.solve_calls)
            bad_calls[0]['replay'].remove(proofs[0])
            with self.assertRaises(ValueError):
                validate_replay_evidence(bad_calls, traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='recorded_full_original_solver_envelope_diagnostic',
                public_prefix_responses_verified=matched, original_sources=audit['actual_source_evidence'],
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                hidden_state_or_rng_equality_claimed=False,
                solver_calls=executor.solve_calls if executor else [])
            bridge.close()

    def boundary(self, eligible, free):
        label = f'touch-boundary-e{eligible}-f{free}-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, action, proofs = False, None, []
        try:
            send(cmd='start_run', character='Defect', ascension=10, seed='touch-boundary')
            send(cmd='set_player', hp=1000, max_hp=1000, relics=[],
                 deck=['ICE_LANCE'] * eligible + ['CLAW'] * free, potions=['TOUCH_OF_INSANITY'])
            before = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
            self.assertEqual(len(before['hand']), eligible + free)
            meta = send(cmd='combat_meta')
            potion = next(p for p in meta['potions'] if p['id'] == 'TOUCH_OF_INSANITY')
            eligible_indices = {c['index'] for c in before['hand'] if c['id'] == 'CARD.ICE_LANCE'}
            cards = [{'CardId': 'ICE_LANCE', 'UpgradeLevel': 0, 'StateKey': c['key'],
                      'SourceOccurrence': 0, 'OptionOccurrence': 0}
                     for c in meta['hand'] if c['index'] in eligible_indices][:1]
            action = {'Kind': 'UsePotion', 'PotionId': 'TOUCH_OF_INSANITY', 'PotionSlot': potion['slot'],
                'Turn': before['player_turn'], 'ReplayCount': 0,
                'Choice': {'Effect': 'SetFreeThisCombat', 'SourcePile': 'Hand', 'SourceId': 'TOUCH_OF_INSANITY',
                           'ContextId': '', 'Timing': 'Action', 'Cards': cards}}
            request = {'cmd': 'action', 'action': 'use_potion', 'args': {'potion_index': potion['index']}}
            after = send(request)
            event = after['choice_audit']['original_returns'][0]
            self.assertEqual(event['raw_source_count_at_entry'], eligible + free)
            self.assertFalse(event['filter_is_null'])
            self.assertFalse(event['filter_reexecuted_by_observer'])
            executor = CombatExecutor(send)
            executor.last_action_request = request
            executor.solve_calls = [{'test_only_synthetic_plan': True}]
            if eligible <= 1:
                self.assertEqual(after['decision'], 'combat_play')
                self.assertTrue(event['original_task_completed_successfully'])
                self.assertEqual(event['returned_cards'], cards)
                self.assertEqual(event['original_returned_collection'], 'List<CardModel>')
                self.assertEqual(event['selector_invocations_before'], event['selector_invocations_after'])
                self.assertTrue(executor.resolve_original_automatic_choice(before, after, action))
                proofs = executor.solve_calls[0]['replay']
                self.assertFalse(proofs[0]['selection_request_sent'])
                self.assertFalse(proofs[0]['remaining_battle_plan_stopped'])
                if eligible == 0:
                    self.assertEqual(proofs[0]['reason'], 'engine_empty_filtered_selection')
                    self.assertEqual(checked_public(after)['hand'], checked_public(before)['hand'])
                else:
                    self.assertIn('energy=False:3', cards[0]['StateKey'])
            else:
                self.assertEqual(after['decision'], 'card_select')
                self.assertFalse(event['verified'])
                self.assertTrue(event['selector_pending_after'])
                self.assertFalse(executor.resolve_original_automatic_choice(before, after, action))
                self.assertEqual(len(after['cards']), eligible)
                after = send(cmd='action', action='select_cards', args={'indices': '0'})
                self.assertEqual(after['decision'], 'combat_play')
            if eligible:
                costs = [c['cost'] for c in after['hand'] if c['id'] == 'CARD.ICE_LANCE']
                self.assertEqual(sorted(costs), [0] + [3] * (eligible - 1))
            self.assertEqual(len(after['hand']), eligible + free)
            self.assertTrue(after['context']['combat_in_progress'])
            self.assertEqual(after['player_turn'], before['player_turn'])
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='synthetic_original_potion_filter_boundary',
                constructed_plan_is_not_solver_output=True, synthetic_plan=action, direct_unit_proofs=proofs,
                hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_original_empty_filtered_hand_boundaries(self):
        for free in (0, 1, 5):
            with self.subTest(free=free):
                self.boundary(0, free)

    def test_original_singleton_and_manual_filtered_boundaries(self):
        for eligible, free in ((1, 0), (1, 4), (2, 0), (2, 3)):
            with self.subTest(eligible=eligible, free=free):
                self.boundary(eligible, free)


if __name__ == '__main__':
    unittest.main(verbosity=2)

