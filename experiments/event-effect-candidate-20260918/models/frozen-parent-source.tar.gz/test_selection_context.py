"""Pure source-chain fixtures; no game workers or natural training data."""
import copy
import unittest

from decision_data import DataContractError, enumerate_candidates
from mechanism_facts import ENGINE_SHA256
from selection_context import (bind_selection_context, direct_action_evidence, validate_selection_contexts,
                               validate_interaction_scoring)


def fixtures():
    source = {"type": "decision", "decision": "event_choice", "context": {"combat_in_progress": False},
              "options": [{"index": 0, "is_locked": False, "text_key": "OROBAS.pages.INITIAL.options.SEA_GLASS"}]}
    pending = {"type": "decision", "decision": "card_select", "context": {"combat_in_progress": False},
               "cards": [{"index": 0, "id": "CARD.TEST"}], "min_select": 0, "max_select": 1}
    second = {**pending, "cards": [{"index": 7, "id": "CARD.OTHER"}]}
    final = {"type": "decision", "decision": "game_over", "victory": False}
    records, policies, context = [], {}, None
    for index, (state, after) in enumerate(((source, pending), (pending, second), (second, final))):
        chosen = enumerate_candidates(state)["candidates"][0]
        token = f"run:{index:06d}"
        purpose = context["purpose"] if context else None
        records.append({"run_id": "run", "decision_id": token, "state": state, "next_state": after,
            "chosen": chosen, "environment_error": None, "metadata": {"versions": {"engine": {"sha256": ENGINE_SHA256}}},
            "execution": {"selection_context": context, "selection_purpose": purpose,
                          "direct_action_result": direct_action_evidence(after)}})
        policies[token] = {"selection_context": context, "scoring": {
            "policy_version": "initial-stat-mechanism-v5", "selection_purpose": purpose}}
        context = bind_selection_context(chosen, token, state, after, after)
    return records, policies


class SelectionContextTests(unittest.TestCase):
    def interaction_fixtures(self):
        from initial_policy import InitialPolicy
        from interaction_features import extend_scoring_packet
        records, policies = fixtures()
        base = InitialPolicy(prior_path=None)
        for record in records:
            policy = policies[record["decision_id"]]
            purpose = policy["scoring"]["selection_purpose"]
            policy["scoring"] = extend_scoring_packet(record["state"],
                base.score(record["state"], selection_purpose=purpose))
        return records, policies

    def test_exact_source_binds_once_and_clears_at_next_selection_phase(self):
        records, policies = fixtures()
        self.assertTrue(validate_selection_contexts(records, policies))
        self.assertEqual(policies["run:000001"]["selection_context"]["purpose"], "acquire")
        self.assertIsNone(policies["run:000002"]["selection_context"])

    def test_no_binding_across_combat_or_changed_pending_state(self):
        records, _ = fixtures()
        first = records[0]
        combat = {"type": "decision", "decision": "combat_play", "context": {"combat_in_progress": True}}
        self.assertIsNone(bind_selection_context(first["chosen"], first["decision_id"], first["state"], combat, first["next_state"]))
        changed = {**first["next_state"], "max_select": 0}
        self.assertIsNone(bind_selection_context(first["chosen"], first["decision_id"], first["state"], first["next_state"], changed))

    def test_context_tampering_missing_evidence_and_engine_mismatch_are_rejected(self):
        for tamper in ("policy_only", "source", "returned_hash", "missing", "engine"):
            with self.subTest(tamper=tamper):
                records, policies = copy.deepcopy(fixtures())
                context = policies["run:000001"]["selection_context"]
                if tamper == "policy_only":
                    policies["run:000001"]["selection_context"] = None
                elif tamper == "source":
                    context["source_decision_id"] = "invented"
                elif tamper == "returned_hash":
                    records[0]["execution"]["direct_action_result"]["state_hash"] = "0" * 64
                elif tamper == "missing":
                    del policies["run:000001"]["selection_context"]
                else:
                    records[1]["metadata"]["versions"]["engine"]["sha256"] = "0" * 64
                with self.assertRaises(DataContractError):
                    validate_selection_contexts(records, policies)

    def test_failed_action_keeps_its_context_and_v2_remains_readable(self):
        records, policies = fixtures()
        failed = records[:2]
        failed[-1]["environment_error"] = {"kind": "timeout"}
        failed[-1]["execution"]["direct_action_result"] = None
        self.assertTrue(validate_selection_contexts(failed, policies))
        for record in records:
            record["execution"] = {}
        for policy in policies.values():
            policy["scoring"]["policy_version"] = "initial-stat-mechanism-v2"
            policy.pop("selection_context")
        self.assertTrue(validate_selection_contexts(records, policies))

    def test_verified_interaction_packets_keep_the_same_strict_source_chain(self):
        records, policies = self.interaction_fixtures()
        self.assertTrue(validate_selection_contexts(records, policies))
        packet = policies[records[1]["decision_id"]]["scoring"]
        self.assertTrue(validate_interaction_scoring(records[1]["state"], packet)["valid"])
        records[1]["environment_error"] = {"kind": "timeout"}
        records[1]["execution"]["direct_action_result"] = None
        self.assertTrue(validate_selection_contexts(records[:2], policies))
        policies[records[1]["decision_id"]]["selection_context"] = None
        with self.assertRaisesRegex(DataContractError, "contexts disagree"):
            validate_selection_contexts(records[:2], policies)

    def test_arbitrary_base_v3_or_downgraded_version_cannot_bypass_validation(self):
        for version in ("invented-transform-v1", "initial-stat-mechanism-v2", "initial-stat-mechanism-v3"):
            records, policies = self.interaction_fixtures()
            policies[records[0]["decision_id"]]["scoring"]["feature_policy_version"] = version
            with self.subTest(version=version), self.assertRaises(DataContractError):
                validate_selection_contexts(records, policies)

    def test_interaction_transform_source_schema_state_and_derived_evidence_are_rebuilt(self):
        for tamper in ("definition", "facts", "schema", "state", "request", "number", "evidence", "base_hash"):
            with self.subTest(tamper=tamper):
                records, policies = self.interaction_fixtures()
                packet = policies[records[0]["decision_id"]]["scoring"]
                row = packet["scores"][0]
                if tamper == "definition":
                    packet["interaction_feature_source"]["complete_orb_source_coverage"] = True
                elif tamper == "facts":
                    packet["interaction_feature_source"]["mechanism_facts"]["registry_sha256"] = "0" * 64
                elif tamper == "schema":
                    packet["feature_names"] = packet["feature_names"][:-1]
                elif tamper == "state":
                    packet["state_hash"] = "0" * 64
                elif tamper == "request":
                    row["request"] = {"cmd": "action", "action": "choose_option", "index": 999}
                elif tamper == "number":
                    row["features"]["ix_missing_health"] = 0.
                elif tamper == "evidence":
                    row["interaction_evidence"]["public_inputs"]["held_potions"] = 999
                else:
                    row["base_features_sha256"] = "0" * 64
                with self.assertRaises(DataContractError):
                    validate_selection_contexts(records, policies)

    def test_interaction_origin_evidence_cannot_be_missing(self):
        records, policies = self.interaction_fixtures()
        del records[0]["execution"]["direct_action_result"]
        with self.assertRaisesRegex(DataContractError, "evidence is missing"):
            validate_selection_contexts(records, policies)


if __name__ == "__main__":
    unittest.main()
