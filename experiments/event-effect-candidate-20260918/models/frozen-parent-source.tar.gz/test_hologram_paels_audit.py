import copy
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

from decision_data import read_decisions
import audit_batch
from prefix_interventions import read_json,read_lines,unchanged

HERE=Path(__file__).resolve().parent
SOURCE=Path('D:/sts2-training/staging/cheese-razor-311/sts2-solver-bridge')
RUN=SOURCE/'outputs/defect-acquisition-recovery-search-20260916b-training-public_mid_calibrated-009'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


original=load('paels_original_auditor',SOURCE/'replay_evidence.py')
candidate=load('paels_candidate_auditor',HERE/'replay_evidence.py')


class HologramPaelsAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.traces=read_lines(RUN/'trace.jsonl')
        cls.calls=[call for row in read_decisions(RUN/'decisions.jsonl') for call in row['solver_calls']]
        cls.before=[];state={'type':'initializing'}
        for row in cls.traces:
            cls.before.append(state);response=row.get('response')
            if isinstance(response,dict) and (response.get('type')=='decision' or
                row['request'].get('cmd') in {'action','start_run'} and response.get('type')=='error'):
                state=response
        returned=[i for i,row in enumerate(cls.traces) if row['request'].get('cmd')=='solve' and row.get('response') is not None]
        found=[]
        for call,start in zip(cls.calls,returned):
            end=next((i for i,row in enumerate(cls.traces[start+1:],start+1) if row['request'].get('cmd')=='solve'),len(cls.traces))
            for index in range(start+1,end):
                meta=cls.traces[index].get('response')
                if cls.traces[index]['request'].get('action')!='play_card' or not isinstance(meta,dict):continue
                audit=meta.get('choice_audit',{});parent=audit.get('parent',{})
                if parent.get('card_id')!='HOLOGRAM' or not any(e.get('raw_source_count_at_entry')==0
                    and e.get('returned_count')==0 for e in audit.get('original_returns',[])):continue
                if index+1<len(cls.traces) and cls.traces[index+1]['request']=={'cmd':'choice_meta'}:continue
                executed=sum(row['request'].get('cmd')=='action' and row['request'].get('action') in
                    {'play_card','use_potion','end_turn'} for row in cls.traces[start+1:index])
                actions=call['response']['actions']
                if executed<len(actions) and any(e.get('RelicId')=='PAELS_LEGION' for e in
                    (actions[executed].get('RelicEffects') or [])):
                    found.append((actions[executed],index,call))
        if len(found)!=1:raise AssertionError(f'Expected one Paels choice-free Hologram, got {len(found)}')
        cls.action,cls.index,cls.call=found[0]

    def check(self,action=None,before=None,traces=None,module=candidate):
        return module.checked_choice_free_hologram(self.action if action is None else action,self.index,
            self.traces if traces is None else traces,self.before if before is None else before)

    def test_original_rejects_and_candidate_accepts_actual_completed_empty_return(self):
        with self.assertRaisesRegex(ValueError,'Unsupported choice-free relic summary'):self.check(module=original)
        self.assertTrue(self.check())

    def test_paels_legion_is_owned_and_source_has_no_selection_call(self):
        relics=self.before[self.index]['player']['relics']
        self.assertTrue(any(r.get('id')=='RELIC.PAELS_LEGION' for r in relics))
        source=(HERE.parent/'validation_support/PaelsLegion.cs').read_text(encoding='utf-8-sig')
        after=source[source.index('public override async Task AfterCardPlayed'):source.index('public override async Task AfterSideTurnStart')]
        self.assertNotIn('choiceContext.',after);self.assertNotIn('Select',after)
        self.assertIn('Cooldown = base.DynamicVars["Turns"].IntValue',after)

    def test_absent_relic_summary_remains_supported(self):
        action=copy.deepcopy(self.action);action['RelicEffects']=[]
        self.assertTrue(self.check(action=action,module=original));self.assertTrue(self.check(action=action))

    def test_unowned_or_unknown_relic_summary_is_rejected(self):
        before=copy.deepcopy(self.before);state=before[self.index]
        state['player']['relics']=[r for r in state['player']['relics'] if r['id']!='RELIC.PAELS_LEGION']
        with self.assertRaisesRegex(ValueError,'not owned'):self.check(before=before)
        action=copy.deepcopy(self.action);action['RelicEffects'][0]['RelicId']='UNREVIEWED_RELIC'
        with self.assertRaisesRegex(ValueError,'Unsupported'):self.check(action=action)

    def test_shape_extra_field_and_multiple_effects_are_rejected(self):
        effect=self.action['RelicEffects'][0]
        for effects in ({'RelicId':'PAELS_LEGION'},[dict(effect,Choice={})],[effect,effect]):
            action=copy.deepcopy(self.action);action['RelicEffects']=effects
            with self.assertRaisesRegex(ValueError,'Unsupported'):self.check(action=action)

    def test_planned_choices_still_require_completion_query(self):
        for key in ('Choice','NestedChoices','TurnStartChoices'):
            action=copy.deepcopy(self.action);action[key]={'ContextId':'invented'} if key=='Choice' else [{'ContextId':'invented'}]
            with self.assertRaisesRegex(ValueError,'planned choices'):self.check(action=action)

    def test_nonempty_source_or_changed_selector_counter_is_rejected(self):
        before=copy.deepcopy(self.before);before[self.index]['discard_pile_count']=1
        with self.assertRaises((ValueError,RuntimeError)):self.check(before=before)
        traces=copy.deepcopy(self.traces)
        traces[self.index]['response']['choice_audit']['original_returns'][0]['selector_invocations_after']+=1
        with self.assertRaises((ValueError,RuntimeError)):self.check(traces=traces)

    def test_solver_summary_tamper_is_rejected_by_full_projection(self):
        calls=copy.deepcopy(self.calls);target=next(c for c in calls if c['response']==self.call['response'])
        action=next(a for a in target['response']['actions'] if a==self.action)
        action['RelicEffects'][0]['Summary']='changed'
        with self.assertRaisesRegex(ValueError,'projection differs'):candidate.validate_replay_evidence(calls,self.traces)

    def test_full_original_replay_and_whole_game_audit_pass_without_new_game(self):
        self.assertTrue(candidate.validate_replay_evidence(self.calls,self.traces)['verified'])
        import subprocess,sys,json
        code = '''import sys,json,importlib.util
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,sys.argv[1])
import audit_batch
from prefix_interventions import read_json,unchanged
spec=importlib.util.spec_from_file_location('staged_paels_auditor',sys.argv[2])
candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
run=Path(sys.argv[3])
with patch.object(audit_batch,'validate_replay_evidence',candidate.validate_replay_evidence):
    audit=audit_batch._Audit(run);audit.run(read_json(run/'report.json'))
print(json.dumps(dict(issues=audit.issues,unchanged=unchanged(list(audit.evidence.values())))))
'''
        result=subprocess.run([sys.executable,'-c',code,str(SOURCE),str(HERE/'replay_evidence.py'),str(RUN)],
            cwd=SOURCE,capture_output=True,text=True,check=True)
        proof=json.loads(result.stdout);self.assertEqual(proof['issues'],[]);self.assertTrue(proof['unchanged'])


if __name__=='__main__':unittest.main(verbosity=2)

