"""119-feature Act1 model with unchanged v3 rules in later acts."""
import copy

from initial_policy import POLICY_VERSION as BASE_VERSION
from survival_policy import SurvivalPolicy
from train_interaction_survival import InteractionSurvivalScorer, MODE, VERSION as MODEL_FORMAT


VERSION = "act1-interaction-survival-with-v3-fallback-v1"


class InteractionSurvivalPolicy(SurvivalPolicy):
    SCORER_CLASS = InteractionSurvivalScorer
    FORMAT = MODEL_FORMAT
    POLICY_ID = VERSION

    @property
    def provenance(self):
        return {**super().provenance,
            "active_feature_policy_version": self._model["feature_policy_version"],
            "base_feature_policy_version": BASE_VERSION,
            "feature_transform": copy.deepcopy(self._model["feature_transform"]),
            "feature_transform_sources": copy.deepcopy(self._model["feature_transform_sources"])}

    def score_requests(self, state, requests, *, selection_purpose=None):
        packet = super().score_requests(state, requests, selection_purpose=selection_purpose)
        packet["model"]["mode"] = MODE
        if packet["model"]["active"]:
            packet["feature_policy_version"] = self._model["feature_policy_version"]
            packet["score_semantics"] = "uncalibrated_Act1_interaction_survival_proxy_not_A10_win_probability"
        return packet
