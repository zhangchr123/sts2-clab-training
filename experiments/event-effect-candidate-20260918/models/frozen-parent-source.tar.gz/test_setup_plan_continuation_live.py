"""Artificial Toasty setup fixture using original effects and original solver."""
import copy
import json
import unittest
import uuid

from combat_executor import CombatExecutor, solver_config
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence
from run_metadata import file_evidence


class SetupContinuationLiveTests(unittest.TestCase):
    def test_original_toasty_setup_effects_finish_then_same_plan_reaches_terminal(self):
        label = "toasty-setup-continuation-" + uuid.uuid4().hex[:12]
        bridge = Bridge(label)
        self.addCleanup(bridge.close)
        traces, calls = [], []
        versions = {"engine": file_evidence(ROOT.parent / "sts2-cli/lib/sts2.dll"),
            "solver": file_evidence(ROOT / "lib/CombatSolver.dll"),
            "bridge": file_evidence(ROOT / "runtime/host/bin/Debug/net9.0/SolverBridge.dll"),
            "cli": file_evidence(ROOT.parent / "sts2-cli/src/Sts2Headless/bin/Debug/net9.0/Sts2Headless.dll")}
        def send(**request):
            response = bridge.send(**request)
            traces.append({"request": copy.deepcopy(request), "response": copy.deepcopy(response)})
            self.assertNotEqual(response.get("type"), "error", response)
            return response
        executor = None
        try:
            send(cmd="start_run", character="Defect", ascension=10, seed="toasty-setup-continuation-fixture-v1")
            send(cmd="set_player", hp=1000, max_hp=1000,
                deck=["STRIKE_DEFECT", "STRIKE_DEFECT", "FOCUSED_STRIKE", "BALL_LIGHTNING", "ZAP"],
                relics=["CRACKED_CORE", "TOASTY_MITTENS"], potions=["FOCUS_POTION"])
            state = send(cmd="enter_room", type="combat", encounter="SHRINKER_BEETLE_WEAK")
            self.assertEqual(state["decision"], "card_select")
            config = solver_config()
            config.update(solver_backend="coordinator", setup_budget_ms=1500,
                first_budget_ms=1500, replan_budget_ms=1500, retry_budget_ms=1500, max_replans=3)
            executor = CombatExecutor(send, config)
            final = executor.advance(state)
            calls = executor.solve_calls
            self.assertEqual(len(calls), 1, "A verified original setup plan should not be discarded for another search")
            self.assertTrue(calls[0]["request"]["include_turn_setup"])
            proofs = [p for c in calls for p in c.get("replay", []) if p["kind"] == "turn_setup_plan_continued"]
            self.assertEqual(len(proofs), 1)
            proof = proofs[0]
            self.assertEqual(proof["actual_choices"][0]["actual_choice_metadata"]["setup_choice"]["source_id"], "TOASTY_MITTENS")
            self.assertEqual(proof["post_setup_metadata"]["setup_origin"]["live_phase"], "Play")
            self.assertIsNone(proof["post_setup_metadata"]["setup_choice"])
            selection = next(t["response"] for t in traces if t["request"].get("action") == "select_cards")
            self.assertTrue(any(p["name"] == "Strength" and p["amount"] >= 1 for p in selection["player_powers"]))
            self.assertEqual(final["decision"], "card_reward")
            self.assertFalse(final["context"]["integrity_recovery_used"])
            self.assertEqual(final["player"]["hp"], calls[-1]["response"]["snapshot"]["PlayerHp"])
            self.assertTrue(calls[-1]["response"]["snapshot"]["AllEnemiesDead"])
            self.assertTrue(validate_replay_evidence(calls, traces)["verified"])
        finally:
            if executor is not None: calls = executor.solve_calls
            with (ROOT / "outputs" / (label + ".json")).open("x", encoding="utf-8") as handle:
                json.dump({"fixture": True, "training_eligible": False,
                    "provenance": "artificial deck/relic/HP fixture; original solver and engine effects, not natural training",
                    "versions": versions, "trace": traces, "solver_calls": calls}, handle, ensure_ascii=False, indent=2)


if __name__ == "__main__": unittest.main()
