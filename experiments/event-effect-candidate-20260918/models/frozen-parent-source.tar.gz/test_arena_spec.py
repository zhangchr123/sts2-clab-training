"""Pure arena protocol/readback tests; no worker, search, RNG or training data."""
import copy
import json
import unittest

from arena_spec import (ArenaSpecError, ENGINE_SHA256, ENCOUNTER, PROTOCOL_VERSION,
                        build_spec, canonical_card, validate_spec, verify_readback)


def card(identifier="STRIKE_DEFECT"):
    facts = {"STRIKE_DEFECT": ("Attack", {"damage": 6}), "DEFEND_DEFECT": ("Skill", {"block": 5}),
             "ZAP": ("Skill", None), "DUALCAST": ("Skill", None), "ASCENDERS_BANE": ("Curse", None)}
    kind, stats = facts[identifier]
    return {"id": "CARD." + identifier, "cost": 0 if identifier == "ASCENDERS_BANE" else 1, "type": kind, "stats": copy.deepcopy(stats),
            "keywords": ["Eternal", "Unplayable", "Ethereal"] if identifier == "ASCENDERS_BANE" else None,
            "upgraded": False, "current_upgrade_level": 0,
            "name": "display only", "description": "display text does not define the card"}


def protocol():
    return {"schema_version": PROTOCOL_VERSION, "engine_sha256": ENGINE_SHA256,
        "projection": "explicit_canonical_deck_hp_gold_v1", "relic_mode": "fresh_default_relics",
        "inventory_mode": "empty_potions", "arena_seed": "declared-arena-0000", "seed_origin": "predeclared_external",
        "encounter_id": ENCOUNTER, "encounter_origin": "predeclared_external", "character": "Defect", "ascension": 10}


def state():
    return {"type": "decision", "decision": "map_select", "context": {"act": 2, "floor": 8, "ascension": 10,
        "combat_in_progress": False, "integrity_recovery_used": False, "boss": {"id": "NOT_THE_ARENA"}},
        "player": {"name": "The Defect", "hp": 41, "max_hp": 75, "gold": 99, "block": 0,
            "deck": [card(), card("ZAP"), card()], "deck_size": 3,
            "relics": [{"id": "RELIC.MOLTEN_EGG", "vars": {"unexported_counter_is_not_claimed": 9}}],
            "potions": [], "potion_capacity": 2, "potion_empty_slots": 2,
            "combat_metrics": {"combat_id": 17, "hp_lost": 3}},
        "map_metadata": {"future_path": "never_used"}}


def transcript(spec, *, include_entry=False):
    player = {"name": "The Defect", **copy.deepcopy(spec["projected_player"]),
        "deck_size": len(spec["projected_player"]["deck"]), "block": 0,
        "relics": [{"id": "RELIC.CRACKED_CORE", "vars": {"Lightning": 1}}],
        "potions": [], "potion_capacity": 2, "potion_empty_slots": 2}
    context = {"act": 1, "ascension": 10, "combat_in_progress": False, "integrity_recovery_used": False}
    responses = [{"type": "decision", "decision": "event_choice", "context": context, "player": copy.deepcopy(player)},
                 {"type": "ok", "player": copy.deepcopy(player)}]
    if include_entry:
        responses.append({"type": "decision", "decision": "combat_play", "player_turn": 1, "energy": 3,
            "context": {**context, "encounter_id": ENCOUNTER, "room_type": "Monster",
                        "combat_in_progress": True, "is_second_boss": False}, "player": copy.deepcopy(player)})
    return [{"request": copy.deepcopy(request), "response": response}
            for request, response in zip(spec["wire_requests"], responses)]


class ArenaSpecTests(unittest.TestCase):
    def reject(self, callback, code=None):
        with self.assertRaises(ArenaSpecError) as caught:
            callback()
        value = caught.exception.to_dict()
        self.assertEqual(value["status"], "rejected")
        self.assertFalse(value["training_eligible"])
        if code is not None:
            self.assertEqual(value["code"], code)

    def test_explicit_canonical_projection_is_not_clone_and_does_not_mutate_inputs(self):
        source, declaration = state(), protocol()
        original = copy.deepcopy((source, declaration))
        spec = build_spec(source, declaration)
        self.assertEqual((source, declaration), original)
        self.assertEqual(spec["origin"], "diagnostic_fixture")
        for key in ("training_eligible", "natural_labels_allowed", "exact_restore", "acquisition_hooks_replayed", "candidate_pick_benefit_supported"):
            self.assertIs(spec[key], False)
        self.assertIs(spec["not_current_state_clone"], True)
        self.assertEqual(spec["wire_requests"][1], {"cmd": "set_player", "hp": 41, "max_hp": 75,
            "gold": 99, "deck": ["STRIKE_DEFECT", "ZAP", "STRIKE_DEFECT"]})
        self.assertNotIn("relics", spec["wire_requests"][1])
        self.assertNotIn("potions", spec["wire_requests"][1])
        self.assertTrue(any(x["path"] == "$.player.relics" for x in spec["source_audit"]["omitted_fields"]))
        self.assertEqual(validate_spec(json.loads(json.dumps(spec)), source), spec)

    def test_projection_acceptance_and_fresh_default_relic_mode_have_no_silent_default(self):
        for field, value in (("projection", None), ("projection", "copy"), ("relic_mode", "copy"), ("relic_mode", None)):
            declaration = protocol()
            if value is None: declaration.pop(field)
            else: declaration[field] = value
            with self.subTest(field=field, value=value):
                self.reject(lambda: build_spec(state(), declaration), "projection_not_accepted")

    def test_energy_hooks_mutations_and_potion_slot_requests_are_explicitly_unsupported(self):
        for field, value in (("energy", 5), ("max_energy", 4), ("acquire_card", "ZAP"),
                             ("relic_counters", {}), ("potion_slots", []), ("mutation", {"append": "ZAP"})):
            declaration = {**protocol(), field: value}
            with self.subTest(field=field):
                self.reject(lambda: build_spec(state(), declaration),
                            "unsupported_energy" if "energy" in field else "invalid_protocol")

    def test_encounter_and_seed_are_only_external_inputs_not_actual_source_future(self):
        source = state()
        spec = build_spec(source, protocol())
        changed = copy.deepcopy(source)
        changed["context"].update(act=3, floor=14, boss={"id": "DIFFERENT_BOSS"}, second_boss="HIDDEN")
        changed["seed"] = "natural-seed-not-used"
        changed["hidden_rng_audit"] = {"state": [123, 456]}
        other = build_spec(changed, protocol())
        self.assertEqual(spec["wire_requests"], other["wire_requests"])
        self.assertEqual(spec["projected_player"], other["projected_player"])
        self.assertNotEqual(spec["source_audit"]["state_sha256"], other["source_audit"]["state_sha256"])
        self.assertEqual(other["wire_requests"][0]["seed"], "declared-arena-0000")
        self.assertEqual(other["wire_requests"][2]["encounter"], ENCOUNTER)
        self.reject(lambda: build_spec(source, {**protocol(), "encounter_id": "DIFFERENT_BOSS"}), "invalid_protocol")

    def test_missing_public_card_scalars_inventory_or_ownership_reject(self):
        for field in ("hp", "max_hp", "gold", "name", "deck", "deck_size", "relics", "potions", "potion_capacity", "potion_empty_slots"):
            source = state(); source["player"].pop(field)
            with self.subTest(field=field):
                self.reject(lambda: build_spec(source, protocol()), "missing_public_field")
        for field in ("id", "cost", "type", "stats", "keywords", "upgraded", "current_upgrade_level"):
            source = state(); source["player"]["deck"][0].pop(field)
            with self.subTest(card_field=field):
                self.reject(lambda: build_spec(source, protocol()), "missing_public_field")

    def test_only_audited_starter_card_types_are_supported_and_factory_is_detached(self):
        for identifier in ("STRIKE_DEFECT", "DEFEND_DEFECT", "ZAP", "DUALCAST", "ASCENDERS_BANE"):
            self.assertEqual(canonical_card(identifier), {k:v for k,v in card(identifier).items() if k not in {"name", "description"}})
        template = canonical_card("STRIKE_DEFECT"); template["stats"]["damage"] = 900
        self.assertEqual(canonical_card("STRIKE_DEFECT")["stats"], {"damage": 6})
        for identifier in ("CARD.ZAP", "RELIC.ZAP", "GENETIC_ALGORITHM", "BALL_LIGHTNING", "ZAP+1"):
            self.reject(lambda: canonical_card(identifier), "unsupported_card")

    def test_unmodified_a10_starter_deck_and_ascenders_bane_readback(self):
        # Deck facts match the already completed original 0029 start response;
        # this test's map decision/transcript are explicitly synthetic.
        source=state()
        ids=["STRIKE_DEFECT"]*4+["DEFEND_DEFECT"]*4+["ZAP","DUALCAST","ASCENDERS_BANE"]
        source["player"].update(deck=[card(i) for i in ids],deck_size=11)
        spec=build_spec(source,protocol())
        self.assertEqual(spec["wire_requests"][1]["deck"],ids)
        self.assertEqual(spec["projected_player"]["deck"][-1]["cost"],0)
        self.assertTrue(verify_readback(spec,source,transcript(spec,include_entry=True))["entry_verified"])
        self.assertFalse(spec["candidate_pick_benefit_supported"])
        mutations=[lambda c:c.update(cost=-1),lambda c:c.update(cost=1),
            lambda c:c.update(current_upgrade_level=1,upgraded=True),lambda c:c.update(keywords=["Unplayable"]),
            lambda c:c.update(keywords=["Ethereal","Unplayable","Eternal"]),lambda c:c.update(stats={"damage":0})]
        for change in mutations:
            modified=copy.deepcopy(source);change(modified["player"]["deck"][-1])
            self.reject(lambda: build_spec(modified,protocol()))

    def test_upgrade_growth_enchantment_and_unknown_instance_fields_never_downgrade(self):
        mutations = [lambda c:c.update(upgraded=True, current_upgrade_level=1),
            lambda c:c.update(current_upgrade_level=True), lambda c:c.update(id="CARD.GENETIC_ALGORITHM", stats={"block":4}),
            lambda c:c.update(enchantment="Unverified"), lambda c:c.update(affliction=None),
            lambda c:c.update(permanent_growth=0), lambda c:c.update(stats={"damage":9}),
            lambda c:c.update(cost=0), lambda c:c.update(keywords=["Retain"])]
        for change in mutations:
            source = state(); change(source["player"]["deck"][0])
            with self.subTest(change=change): self.reject(lambda: build_spec(source, protocol()))

    def test_scalar_types_ranges_card_count_and_nonempty_inventory_reject(self):
        mutations = [lambda p:p.update(hp=True), lambda p:p.update(hp=0), lambda p:p.update(hp=76),
            lambda p:p.update(max_hp=2**31), lambda p:p.update(gold=-1), lambda p:p.update(gold=3.0),
            lambda p:p.update(deck_size=2), lambda p:p.update(deck=[]), lambda p:p.update(energy=3),
            lambda p:p.update(potion_capacity=True), lambda p:p.update(potion_capacity=3, potion_empty_slots=3),
            lambda p:p.update(potions=[{"id":"POTION.FIRE_POTION","index":0}], potion_empty_slots=1)]
        for change in mutations:
            source=state(); change(source["player"])
            with self.subTest(change=change): self.reject(lambda: build_spec(source, protocol()))

    def test_combat_pending_missing_integrity_or_other_character_reject(self):
        mutations = [lambda s:s.update(decision="combat_play"), lambda s:s.update(decision="card_select"),
            lambda s:s["context"].update(combat_in_progress=True), lambda s:s["context"].pop("integrity_recovery_used"),
            lambda s:s["context"].update(ascension=True), lambda s:s["player"].update(name="The Silent")]
        for change in mutations:
            source=state();change(source)
            self.reject(lambda: build_spec(source, protocol()), "unsupported_source")

    def test_full_spec_envelope_and_original_audit_state_are_reconstructed(self):
        source=state();spec=build_spec(source,protocol())
        mutations=[lambda s:s.update(training_eligible=True),lambda s:s.update(exact_restore=True),
            lambda s:s["wire_requests"][1]["deck"].pop(), lambda s:s["source_audit"].update(omitted_fields=[]),
            lambda s:s.update(extra="forged"),lambda s:s["card_codec"]["ids"].append("GENETIC_ALGORITHM")]
        for change in mutations:
            damaged=copy.deepcopy(spec);change(damaged)
            self.reject(lambda: validate_spec(damaged,source), "invalid_spec")
        altered=state();altered["map_metadata"]={"different":True}
        self.reject(lambda: validate_spec(spec,altered), "invalid_spec")

    def test_readback_gate_requires_complete_real_shape_before_entry(self):
        source=state();spec=build_spec(source,protocol());rows=transcript(spec)
        receipt=verify_readback(spec,source,rows)
        self.assertTrue(receipt["ready_to_enter"])
        self.assertFalse(receipt["entry_verified"])
        self.assertFalse(receipt["transport_authenticity_verified"])
        self.assertFalse(receipt["energy_setting_verified"])
        receipt=verify_readback(spec,source,transcript(spec,include_entry=True))
        self.assertTrue(receipt["entry_verified"])
        self.assertFalse(receipt["training_eligible"])

    def test_set_player_ok_with_missing_reordered_or_silently_dropped_cards_rejects(self):
        source=state();spec=build_spec(source,protocol())
        mutations=[lambda p:p["deck"].pop(), lambda p:p.update(deck=p["deck"][:-1],deck_size=2),
            lambda p:p["deck"].reverse(), lambda p:p["deck"].__setitem__(1,card("DUALCAST")),
            lambda p:p.pop("deck"),lambda p:p.update(hp=40),lambda p:p.update(gold=True),
            lambda p:p.update(relics=[]),lambda p:p.update(potion_empty_slots=1)]
        # Reverse a non-palindromic sequence to verify physical order, while the
        # baseline test retains explicit repeated-ID multiplicity.
        source["player"]["deck"].append(card("DUALCAST"));source["player"]["deck_size"]=4
        spec=build_spec(source,protocol())
        for change in mutations:
            rows=transcript(spec);change(rows[1]["response"]["player"])
            with self.subTest(change=change): self.reject(lambda: verify_readback(spec,source,rows))

    def test_start_entry_or_wire_order_failures_cannot_pass_as_readback(self):
        source=state();spec=build_spec(source,protocol())
        mutations=[lambda r:r[0]["response"].update(context=[]),
            lambda r:r[0]["response"]["context"].update(combat_in_progress=True),
            lambda r:r[1]["response"].update(type="error"),
            lambda r:r[1]["request"]["deck"].pop(),lambda r:r.reverse(),
            lambda r:r[2]["response"]["context"].update(encounter_id="FUTURE_BOSS"),
            lambda r:r[2]["response"]["context"].update(act=2),
            lambda r:r[2]["response"].update(player_turn=2),
            lambda r:r[2]["response"].update(decision="card_select")]
        for change in mutations:
            rows=transcript(spec,include_entry=True);change(rows)
            self.reject(lambda: verify_readback(spec,source,rows), "readback_mismatch")
        self.reject(lambda: verify_readback(spec,source,transcript(spec)[:1]), "readback_mismatch")

    def test_invalid_nonfinite_json_cannot_enter_audit_hashes(self):
        for value in (float("nan"), float("inf"), object(), {1:"nonstring key"}):
            source=state();source["metadata"]=value
            self.reject(lambda: build_spec(source,protocol()), "invalid_json")


if __name__ == "__main__": unittest.main()
