import copy
import json
import math
from pathlib import Path
import tempfile
import unittest

from decision_data import DataContractError, enumerate_candidates
from initial_policy import CardPrior, FEATURE_NAMES, POLICY_VERSION, InitialPolicy, card_mechanisms, crystal_public_coverage
from mechanism_facts import ENGINE_SHA256


def card(identity, damage=0, block=0, cost=1, **kwargs):
    return {"id": "CARD." + identity, "stats": {"damage": damage, "block": block},
            "cost": cost, "type": "Attack" if damage else "Skill", "description": "Actual fixture card.", **kwargs}


def state(cards=None):
    options = cards or [card("STRIKE_DEFECT", damage=6), card("DEFRAGMENT", stats={"focuspower": 1})]
    return {"type": "decision", "decision": "card_reward", "cards": [dict(c, index=i) for i, c in enumerate(options)],
            "can_skip": True, "context": {"ascension": 10, "combat_in_progress": False},
            "player": {"hp": 25, "max_hp": 75, "gold": 100, "deck": [card("ZAP"), card("BALL_LIGHTNING", damage=7)]}}


class InitialPolicyTests(unittest.TestCase):
    def crystal_state(self):
        current = state()
        current.update(decision="crystal_sphere", grid_size={"x": 11, "y": 11},
                       divinations_left=3, tools=["small", "big"],
                       cells=[{"x": x, "y": y, "hidden": True} for y in range(11) for x in range(11)])
        return current

    def test_crystal_tools_have_weak_public_coverage_scores_and_bounded_geometry(self):
        current = self.crystal_state()
        packet = InitialPolicy(prior_path=None).score(current)
        rows = {(r["request"]["args"]["x"], r["request"]["args"]["y"], r["request"]["args"]["tool"]): r
                for r in packet["scores"]}
        self.assertEqual(len(rows), 242)
        self.assertEqual(rows[(5, 5, "big")]["score"], .09)
        self.assertEqual(rows[(5, 5, "small")]["score"], .01)
        self.assertEqual(rows[(0, 0, "big")]["score"], .04)
        self.assertEqual(rows[(5, 5, "big")]["features"]["crystal_hidden_cells_covered"], 9.)
        self.assertEqual(rows[(5, 5, "small")]["features"]["crystal_tool_small"], 1.)
        self.assertEqual(rows[(5, 5, "big")]["features"]["action_crystal_sphere_reveal"], 1.)
        self.assertIn("hidden_reward_value", rows[(5, 5, "big")]["missing"])
        self.assertFalse(packet["calibrated"])
        self.assertTrue(all(set(r["features"]) == set(FEATURE_NAMES) for r in rows.values()))

    def test_crystal_public_coverage_ignores_revealed_prize_kind_and_rejects_hidden_leaks(self):
        current = self.crystal_state()
        current["cells"][0].update(hidden=False, item_kind="Curse")
        policy = InitialPolicy(prior_path=None)
        before = policy.score(current)
        current["cells"][0]["item_kind"] = "Relic"
        after = policy.score(current)
        self.assertEqual([(r["request"], r["score"], r["features"]) for r in before["scores"]],
                         [(r["request"], r["score"], r["features"]) for r in after["scores"]])
        self.assertEqual(crystal_public_coverage(current, 1, 1, "big"), 8)
        with self.assertRaises(DataContractError):
            crystal_public_coverage(current, 0, 0, "small")
        current["cells"][1]["item_kind"] = "Hidden prize must never be exposed"
        with self.assertRaises(DataContractError):
            policy.score(current)

    def test_v3_facts_bind_the_engine_and_outputs_cannot_modify_the_registry(self):
        policy = InitialPolicy(prior_path=None)
        self.assertEqual(POLICY_VERSION, "initial-stat-mechanism-v5")
        self.assertEqual(policy.provenance["mechanism_facts"]["engine_sha256"], ENGINE_SHA256)
        self.assertEqual(len(policy.provenance["mechanism_facts"]["registry_sha256"]), 64)
        current = state([card("GLACIER", block=6, cost=2)])
        result = policy.score(current)
        result["scores"][0]["card_detail"]["verified_effect_facts"]["channel"]["count"] = 99
        result["mechanism_facts"]["engine_sha256"] = "bad"
        again = policy.score(current)
        self.assertEqual(again["scores"][0]["features"]["frost_channel_count"], 2.)
        self.assertEqual(again["mechanism_facts"]["engine_sha256"], ENGINE_SHA256)
        with tempfile.TemporaryDirectory() as directory:
            wrong = Path(directory) / "wrong-engine.dll"
            wrong.write_bytes(b"fixture engine mismatch")
            with self.assertRaisesRegex(DataContractError, "engine SHA mismatch"):
                InitialPolicy(prior_path=None, engine_path=wrong)

    def test_gunk_up_verified_hits_and_combat_status_do_not_generalize_repeat(self):
        policy = InitialPolicy(prior_path=None)
        current = state([card("GUNK_UP", stats={"damage": 4, "repeat": 3}, cost=1,
                              after_upgrade={"stats": {"damage": 5, "repeat": 3}, "cost": 1})])
        row = policy.score(current)["scores"][0]
        self.assertEqual(row["features"]["single_target_nominal_damage"], 12.)
        self.assertEqual(row["features"]["damage_per_hit"], 4.)
        self.assertEqual(row["features"]["attack_hit_count"], 3.)
        self.assertAlmostEqual(row["card_detail"]["components"]["base_damage_proxy"], 1.08)
        generated = row["card_detail"]["verified_effect_facts"]["generated_status"]
        self.assertEqual(generated, {"id": "CARD.SLIMED", "count": 1, "pile": "Discard", "persistence": "combat"})
        self.assertEqual(row["features"]["combat_discard_status_cards"], 1.)
        self.assertEqual(row["card_detail"]["components"]["status_creation_cost_proxy"], -.25)
        current.update(decision="card_select", min_select=1, max_select=1)
        upgraded = policy.score(current, selection_purpose="upgrade")["scores"][0]
        self.assertAlmostEqual(upgraded["score"], .27)
        self.assertIn("upgrade_preview_instance_modifications", upgraded["missing"])
        other = policy.score(state([card("ICE_LANCE", stats={"damage": 19, "repeat": 3}, cost=3)]))["scores"][0]
        self.assertEqual(other["features"]["attack_hit_count"], 0.)
        self.assertEqual(other["features"]["base_damage_per_cost"], 19 / 4)
        self.assertIn("unmodeled_stats:repeat", other["missing"])

    def test_glacier_has_exactly_two_frost_and_uses_current_block(self):
        policy = InitialPolicy(prior_path=None)
        low = policy.score(state([card("GLACIER", block=6, cost=2)]))["scores"][0]
        high = policy.score(state([card("GLACIER", block=9, cost=2)]))["scores"][0]
        self.assertEqual(low["features"]["frost_channel_count"], 2.)
        self.assertEqual(high["features"]["frost_channel_count"], 2.)
        self.assertEqual(low["features"]["base_block_per_cost"], 2.)
        self.assertEqual(high["features"]["base_block_per_cost"], 3.)
        self.assertEqual(low["card_detail"]["components"]["frost_source_proxy"], .5)
        self.assertGreater(high["score"], low["score"])

    def test_cold_snap_verified_one_frost_uses_existing_proxy_and_deck_tag(self):
        policy = InitialPolicy(prior_path=None)
        current = state([card("COLD_SNAP", damage=6)])
        current["player"]["deck"] = [card("COLD_SNAP", damage=6)]
        row = policy.score(current)["scores"][0]
        self.assertEqual(card_mechanisms(current["cards"][0]), {"frost_source"})
        self.assertEqual(row["features"]["frost_channel_count"], 1.)
        self.assertEqual(row["features"]["orb_sources"], 1.)
        self.assertEqual(row["card_detail"]["components"]["frost_source_proxy"], .375)
        self.assertEqual(row["card_detail"]["verified_effect_facts"]["channel"]["timing"], "on_play_after_attack")
        current["cards"][0]["stats"]["damage"] = 9
        upgraded = policy.score(current)["scores"][0]
        self.assertEqual(upgraded["features"]["frost_channel_count"], 1.)
        self.assertGreater(upgraded["score"], row["score"])

    def test_hailstorm_records_thresholded_end_turn_facts_without_inventing_a_bonus(self):
        policy = InitialPolicy(prior_path=None)
        current = state([card("HAILSTORM", type="Power", stats={"hailstormpower": 6})])
        no_source = policy.score(current)["scores"][0]
        self.assertEqual(no_source["features"]["base_damage_per_cost"], 0.)
        self.assertEqual(no_source["features"]["conditional_end_turn_aoe_damage"], 6.)
        self.assertNotIn("conditional_end_turn_aoe_potential_proxy", no_source["card_detail"]["components"])
        current["player"]["deck"] = [card("GLACIER")]
        one = policy.score(current)["scores"][0]
        current["player"]["deck"] = [card("GLACIER")] * 4
        four = policy.score(current)["scores"][0]
        self.assertEqual(no_source["score"], one["score"])
        self.assertEqual(one["score"], four["score"])
        self.assertEqual(one["features"]["conditional_end_turn_aoe_trigger_unknown"], 1.)
        self.assertNotIn("conditional_end_turn_aoe_deck_support", FEATURE_NAMES)
        fact = one["card_detail"]["verified_effect_facts"]["conditional_damage"]
        self.assertEqual(fact["condition"], {"orb": "Frost", "min_count": 1})
        self.assertEqual(fact["trigger_method"], "BeforeSideTurnEnd")
        self.assertEqual(fact["target"], "HittableEnemies")
        self.assertFalse(fact["per_orb_multiplier"])
        self.assertFalse(fact["immediate_damage"])
        self.assertIn("end_turn_frost_presence_distribution", one["missing"])

    def test_verified_draw_and_energy_have_independent_quantity_features(self):
        policy = InitialPolicy(prior_path=None)
        cards = [card("SKIM", stats={"cards": 3}), card("SKIM", stats={"cards": 4}),
                 card("TURBO", cost=0, stats={"energy": 2}), card("TURBO", cost=0, stats={"energy": 3}),
                 card("UNKNOWN", stats={"cards": 8, "energy": 9})]
        rows = policy.score(state(cards))["scores"]
        self.assertEqual([r["features"]["draw_cards"] for r in rows[:2]], [3., 4.])
        self.assertEqual([r["features"]["energy_gain"] for r in rows[2:4]], [2., 3.])
        self.assertNotEqual(rows[0]["features"], rows[1]["features"])
        self.assertEqual(rows[4]["features"]["draw_cards"], 0.)
        self.assertEqual(rows[4]["features"]["energy_gain"], 0.)
        self.assertIn("cards_effect_semantics", rows[4]["missing"])
        self.assertIn("energy_effect_semantics", rows[4]["missing"])

    def test_acquire_values_cards_and_counts_existing_and_in_sequence_duplicates(self):
        policy = InitialPolicy(prior_path=None)
        current = state([card("TEST", damage=20), card("TEST", damage=20), card("LOW", damage=0)])
        current.update(decision="card_select", min_select=0, max_select=3)
        current["player"]["deck"] = [card("TEST")]
        packet = policy.score(current, selection_purpose="acquire")
        rows = {r["request"]["args"]["indices"]: r for r in packet["scores"]}
        self.assertEqual(rows[""]["score"], 0.)
        self.assertGreater(rows["0"]["score"], 0.)
        self.assertLess(rows["2"]["score"], 0.)
        self.assertAlmostEqual(rows["0,1"]["features"]["acquisition_opportunity_cost"], .87 + .99)
        self.assertAlmostEqual(rows["0,1"]["score"], 3.6 - .87 - .99)
        self.assertEqual(rows["0,1"]["features"]["selection_acquire"], 1.)
        self.assertEqual(rows["0,1"]["features"]["selection_unknown"], 0.)
        self.assertIn("add_to_deck_hooks", rows["0,1"]["missing"])
        self.assertIn("ordered_acquisition_interactions", rows["0,1"]["missing"])
        self.assertNotEqual(rows["0,1"]["score"], -.02)

    def test_huge_acquire_scores_selected_cards_without_materializing_the_space(self):
        policy = InitialPolicy(prior_path=None)
        current = state([card(f"TEST{i}", damage=20) for i in range(15)])
        current.update(decision="card_select", min_select=0, max_select=15)
        request = {"cmd": "action", "action": "select_cards", "args": {"indices": ",".join(map(str, range(13)))}}
        packet = policy.score_requests(current, [request], selection_purpose="acquire")
        self.assertEqual(packet["candidate_count"], 3554627472076)
        self.assertFalse(packet["evaluated_candidates_complete"])
        self.assertAlmostEqual(packet["scores"][0]["score"], 13 * (1.8 - .75))
        self.assertEqual(packet["scores"][0]["features"]["selected_count"], 13.)

    def test_old_v2_model_is_refused_by_live_v3_feature_loader(self):
        from train_ranker import SmallValuePolicy, VERSION
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "old-v2-model.json"
            path.write_text(json.dumps({"format": VERSION, "feature_policy_version": "initial-stat-mechanism-v2"}), encoding="utf-8")
            with self.assertRaises(DataContractError) as rejected:
                SmallValuePolicy(path)
            self.assertIn("version", str(rejected.exception).lower())
            self.assertIn("live", str(rejected.exception).lower())

    def test_subset_scoring_is_legal_and_never_claims_full_coverage(self):
        current = state()
        policy = InitialPolicy(prior_path=None)
        full = policy.score(current)
        request = full["scores"][0]["request"]
        partial = policy.score_requests(current, [request])
        self.assertFalse(partial["evaluated_candidates_complete"])
        self.assertEqual(partial["candidate_count"], len(full["scores"]))
        self.assertEqual(partial["scores"][0]["features"], full["scores"][0]["features"])
        self.assertEqual(partial["scores"][0]["score"], full["scores"][0]["score"])

    def test_subset_scoring_rejects_duplicates_and_illegal_requests(self):
        current = state()
        policy = InitialPolicy(prior_path=None)
        request = policy.score(current)["scores"][0]["request"]
        for requests in ([], [request, request], [{"cmd":"action", "action":"leave_room"}]):
            with self.subTest(requests=requests), self.assertRaises(DataContractError):
                policy.score_requests(current, requests)

    def test_huge_selection_scores_only_requested_full_legal_sequences(self):
        current = state([card(f"TEST{i}", damage=i) for i in range(15)])
        current.update(decision="card_select", min_select=0, max_select=15)
        policy = InitialPolicy(prior_path=None)
        with self.assertRaisesRegex(DataContractError, "bounded selection"):
            policy.score(current)
        result = policy.score_requests(current, [
            {"cmd":"action", "action":"select_cards", "args":{"indices":""}},
            {"cmd":"action", "action":"select_cards", "args":{"indices":"14,0,8"}},
        ])
        self.assertEqual(result["candidate_count"], 3554627472076)
        self.assertFalse(result["evaluated_candidates_complete"])
        self.assertEqual(result["scores"][1]["features"]["selected_count"], 3.)
        self.assertEqual(result["scores"][1]["features"]["first_selected_damage_per_cost"], 7.)
        self.assertEqual(result["scores"][1]["features"]["last_selected_damage_per_cost"], 4.)

    def test_local_prior_is_bounded_and_retains_missing_context(self):
        prior = CardPrior()
        self.assertEqual(prior.source["row_count"], 566)
        row = prior.lookup(card("DEFRAGMENT"))
        self.assertLessEqual(abs(row["score"]), 0.15)
        self.assertTrue({"sample_size", "game_version", "ascension", "deck_context"} <= set(row["missing"]))
        self.assertEqual(len(prior.source["sha256"]), 64)
        absent = prior.lookup(card("FUTURE_NEW_CARD"))
        self.assertEqual(absent["score"], 0.0)
        self.assertIn("card_statistics", absent["missing"])

    def test_smokestack_furnace_and_temporary_focus_tags_are_correct(self):
        for identity in ("SMOKESTACK", "FURNACE"):
            self.assertFalse(card_mechanisms(card(identity)) & {"status_exhaust", "status_conversion"})
        self.assertIn("status_creation_trigger", card_mechanisms(card("SMOKESTACK")))
        self.assertIn("forge_per_turn", card_mechanisms(card("FURNACE")))
        self.assertEqual(card_mechanisms(card("SYNCHRONIZE")) & {"sustained_focus", "temporary_focus"}, {"temporary_focus"})
        self.assertIn("status_conversion", card_mechanisms(card("COMPACT")))

    def test_scores_cover_every_legal_candidate_and_skip_is_relative(self):
        current = state()
        policy = InitialPolicy(prior_path=None)
        packet = policy.score(current)
        self.assertFalse(packet["calibrated"])
        self.assertEqual(len(packet["scores"]), len(enumerate_candidates(current)["candidates"]))
        for row in packet["scores"]:
            self.assertEqual(row["delta_from_skip"], row["score"])
            self.assertEqual(set(row["features"]), set(FEATURE_NAMES))
            self.assertTrue(all(type(value) is float and math.isfinite(value) for value in row["features"].values()))
        self.assertNotIn("win_probability", packet)

    def test_runtime_card_stats_change_value_and_upgrade_uses_preview(self):
        policy = InitialPolicy(prior_path=None)
        low, high = state([card("TEST", damage=2)]), state([card("TEST", damage=12)])
        self.assertGreater(policy.score(high)["scores"][0]["score"], policy.score(low)["scores"][0]["score"])
        current = state([card("TEST_A", damage=6, after_upgrade={"stats": {"damage": 7}, "cost": 1}),
                         card("TEST_B", damage=6, after_upgrade={"stats": {"damage": 12}, "cost": 1})])
        current.update(decision="card_select", min_select=1, max_select=1)
        packet = policy.score(current, selection_purpose="upgrade")
        self.assertGreater(packet["scores"][1]["score"], packet["scores"][0]["score"])
        self.assertGreater(packet["scores"][1]["features"]["actual_upgrade_delta_proxy"],
                           packet["scores"][0]["features"]["actual_upgrade_delta_proxy"])
        self.assertNotEqual(packet["scores"][0]["features"], packet["scores"][1]["features"])
        self.assertTrue(all(row["delta_from_skip"] is None for row in packet["scores"]))

    def test_removal_prefers_curse_without_hardcoding_strike(self):
        current = state([card("STRIKE_DEFECT", damage=6), card("GUILTY", type="Curse")])
        current.update(decision="card_select", min_select=1, max_select=1)
        policy = InitialPolicy(prior_path=None, epsilon=0)
        choice = policy.choose(current, selection_purpose="remove")
        self.assertEqual(choice["request"]["args"]["indices"], "1")
        rows = choice["scoring"]["scores"]
        self.assertNotEqual(rows[0]["features"], rows[1]["features"])
        self.assertNotEqual(rows[0]["features"]["selected_card_utility_proxy"], rows[1]["features"]["selected_card_utility_proxy"])

    def test_rest_and_map_types_are_identifiable_without_using_teacher_score(self):
        policy = InitialPolicy(prior_path=None)
        current = state()
        current["player"]["deck"] = [card("STRIKE_DEFECT", damage=6, after_upgrade={"stats": {"damage": 9}, "cost": 1})]
        current.update(decision="rest_site", options=[{"index": 2, "option_id": "HEAL", "is_enabled": True},
                                                     {"index": 5, "option_id": "SMITH", "is_enabled": True}])
        heal, smith = policy.score(current)["scores"]
        self.assertNotEqual(heal["score"], smith["score"])
        self.assertEqual(heal["features"]["rest_heal"], 1.0)
        self.assertEqual(smith["features"]["rest_smith"], 1.0)
        self.assertGreater(smith["features"]["best_upgrade_delta_proxy"], 0.0)
        current.update(decision="map_select", choices=[{"col": 1, "row": 7, "type": "RestSite"},
                                                     {"col": 4, "row": 7, "type": "Elite"}])
        rest, elite = policy.score(current)["scores"]
        self.assertNotEqual(rest["score"], elite["score"])
        self.assertEqual(rest["features"]["map_rest"], 1.0)
        self.assertEqual(elite["features"]["map_elite"], 1.0)
        self.assertNotIn("teacher_score", rest["features"])

    def test_bundle_card_content_and_multiselect_order_have_features(self):
        policy = InitialPolicy(prior_path=None)
        current = state()
        current.update(decision="bundle_select", bundles=[
            {"index": 0, "cards": [card("STRIKE_DEFECT", damage=6)]},
            {"index": 1, "cards": [card("GLACIER", block=10), card("COOLHEADED", stats={"cards": 1})]},
        ])
        first, second = policy.score(current)["scores"]
        self.assertNotEqual(first["score"], second["score"])
        self.assertEqual(first["features"]["bundle_card_count"], 1.0)
        self.assertEqual(second["features"]["mechanism_frost_source"], 2.0)
        self.assertNotEqual(first["features"], second["features"])
        current = state([card("STRIKE_DEFECT", damage=6), card("GLACIER", block=10)])
        current.update(decision="card_select", min_select=2, max_select=2)
        forward, reverse = policy.score(current, selection_purpose="transform")["scores"]
        self.assertEqual(forward["score"], reverse["score"])
        self.assertNotEqual(forward["features"]["first_selected_damage_per_cost"], reverse["features"]["first_selected_damage_per_cost"])

    def test_empty_selection_preserves_fixed_numeric_feature_schema(self):
        current = state()
        current.update(decision="card_select", min_select=0, max_select=1)
        rows = InitialPolicy(prior_path=None).score(current)["scores"]
        self.assertTrue(rows[0]["is_skip"])
        self.assertTrue(all(type(value) is float for row in rows for value in row["features"].values()))

    def test_unknown_selection_effect_is_not_guessed_from_shop(self):
        current = state()
        current.update(decision="card_select", min_select=0, max_select=1)
        current["context"]["room_type"] = "Merchant"
        packet = InitialPolicy(prior_path=None).score(current)
        self.assertTrue(all("selection_effect_model" in row["missing"] for row in packet["scores"]))
        self.assertEqual(packet["selection_purpose"], None)

    def test_explicit_epsilon_explores_non_greedy_candidates_reproducibly(self):
        current = state([card("TEST", damage=40)])
        a = InitialPolicy(prior_path=None, epsilon=1, random_seed="fixture-exploration")
        b = InitialPolicy(prior_path=None, epsilon=1, random_seed="fixture-exploration")
        left, right = [a.choose(current) for _ in range(30)], [b.choose(current) for _ in range(30)]
        self.assertEqual(left, right)
        self.assertEqual({row["request"]["action"] for row in left}, {"select_card_reward", "skip_card_reward"})
        self.assertTrue(all(row["exploration"]["chosen_probability"] == 0.5 for row in left))
        self.assertTrue(all(row["policy_provenance"]["llm_involved"] is False for row in left))

    def test_event_rest_map_bundle_shop_have_explicit_fallback_coverage(self):
        policy = InitialPolicy(prior_path=None)
        base = state()
        fixtures = [
            dict(base, decision="event_choice", options=[{"index": 7, "is_locked": False, "text_key": "UNKNOWN"}]),
            dict(base, decision="rest_site", options=[{"index": 4, "is_enabled": True, "option_id": "UNKNOWN"}]),
            dict(base, decision="map_select", choices=[{"col": 4, "row": 6, "type": "Unknown"}]),
            dict(base, decision="bundle_select", bundles=[{"index": 2, "cards": [card("UNKNOWN")]}]),
            dict(base, decision="shop", cards=[], relics=[{"index": 0, "cost": 80, "can_purchase": True}],
                 potions=[], card_removal_available=False, can_leave=True,
                 player={**base["player"], "potions": []}),
        ]
        for current in fixtures:
            packet = policy.score(current)
            self.assertEqual(len(packet["scores"]), len(enumerate_candidates(current)["candidates"]))
            self.assertTrue(any(row["missing"] for row in packet["scores"]))
            self.assertTrue(all(set(row["features"]) == set(FEATURE_NAMES) for row in packet["scores"]))

    def test_active_combat_reward_bundle_and_selection_are_solver_only(self):
        current = state()
        current["context"]["combat_in_progress"] = True
        for decision in ("card_reward", "card_select", "bundle_select"):
            current["decision"] = decision
            with self.assertRaises(DataContractError):
                InitialPolicy(prior_path=None).choose(current)

    def test_no_prior_file_is_an_explicit_missing_input(self):
        prior = CardPrior(None)
        self.assertIn("source_file", prior.source["missing"])
        self.assertEqual(prior.lookup(card("ZAP"))["score"], 0)


if __name__ == "__main__":
    unittest.main()
