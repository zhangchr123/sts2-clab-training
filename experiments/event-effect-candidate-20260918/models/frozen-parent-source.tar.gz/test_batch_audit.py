"""Temporary synthetic evidence only: no engine processes or rollout sampling."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from audit_batch import audit_batch
from decision_data import DecisionJournal, enumerate_candidates, read_decisions, split_by_seed
from initial_policy import FEATURE_NAMES, POLICY_VERSION, InitialPolicy
from selection_policy import SelectionPolicy
from selection_context import direct_action_evidence
from test_decision_data import metadata as fixture_metadata
from train_ranker import VERSION as MODEL_VERSION, SmallValuePolicy


def write(path, value, *, lines=False):
    path.write_text(("\n".join(json.dumps(row) for row in value) + "\n") if lines
                    else json.dumps(value), encoding="utf-8")


def read(path, *, lines=False):
    text = path.read_text(encoding="utf-8")
    return [json.loads(line) for line in text.splitlines() if line.strip()] if lines else json.loads(text)


class BatchAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.batch = self.root / "arbitrary-batch-name"
        self.batch.mkdir()
        self.reports = []

    def model(self):
        source = self.root / "arbitrary-training-input.txt"
        source.write_text("Synthetic fixture source evidence; not training data.\n", encoding="utf-8")
        raw = source.read_bytes()
        model = {"format": MODEL_VERSION, "feature_policy_version": POLICY_VERSION, "mode": "prior",
            "feature_prior_sha256": InitialPolicy().prior.source["sha256"],
            "feature_mechanism_facts": InitialPolicy().mechanism_source,
            "feature_names": list(FEATURE_NAMES), "means": [0.0] * len(FEATURE_NAMES),
            "scales": [1.0] * len(FEATURE_NAMES), "weights": [0.0] * (len(FEATURE_NAMES) + 1),
            "feature_min": [0.0] * len(FEATURE_NAMES), "feature_max": [1.0] * len(FEATURE_NAMES),
            "calibrated_probability": False, "counterfactual_labels": False,
            "chosen_action_is_optimal_label": False,
            "sources": [{"path": str(source), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}]}
        path = self.root / "model-with-no-batch-prefix.json"
        write(path, model)
        return path, source

    def run_fixture(self, run_id="unrelated-run-name", seed="fixture-seed", *, implicit=False,
                    legacy=False, failure=False, blocked_legacy=False, model_path=None):
        out = self.root / run_id
        out.mkdir()
        base = InitialPolicy(epsilon=.25, random_seed=seed)
        if model_path:
            artifact = read(model_path)
            if artifact["format"] == "defect-act1-survival-ridge-v1":
                from survival_policy import SurvivalPolicy
                base = SurvivalPolicy(model_path, solver_config=artifact["frozen_followup"]["solver"],
                                      fallback=base, epsilon=.25, seed=seed)
            else:
                base = SmallValuePolicy(model_path, fallback=base, epsilon=.25, seed=seed)
        policy = SelectionPolicy(base, max_evaluations=4)
        manifest = fixture_metadata(run_id=run_id, seed=seed)
        manifest["versions"]["engine"] = {"sha256": base.mechanism_source["engine_sha256"]}
        manifest["provenance"] = policy.provenance
        manifest["sampling"] = {"epsilon": .25, "model_path": str(model_path) if model_path else None,
                                "selection_budget": 4}
        write(out / "manifest.json", manifest)
        state = {"type": "decision", "decision": "event_choice",
                 "options": [{"index": 3, "is_locked": False}, {"index": 7, "is_locked": False}],
                 "player": {"hp": 20, "max_hp": 75, "deck": [], "potions": [], "gold": 5},
                 "context": {"room_type": "Event", "combat_in_progress": False, "ascension": 10,
                             "act": 1, "integrity_recovery_used": False}}
        if implicit or blocked_legacy:
            state.update(decision="card_select", min_select=0, max_select=15 if blocked_legacy else 3,
                         cards=[{"index": i, "id": "CARD.STRIKE", "damage": i + 1}
                                for i in range(15 if blocked_legacy else 3)])
            del state["options"]
        traces = [{"request": {"cmd": "start_run", "seed": seed}, "response": state}]
        policies = []
        final_state = copy.deepcopy(state)
        error = {"kind": "environment_error", "traceback": "Synthetic transport failure"} if failure else None
        if blocked_legacy:
            error = {"kind": "environment_error", "traceback": "Historical no truncation limit refusal"}
        with DecisionJournal(out, manifest) as journal:
            if not blocked_legacy:
                candidates = enumerate_candidates(state, max_candidates=1 if implicit else 100000)
                picked = policy.choose(state, candidates)
                token = journal.begin(state, picked["request"], policy=picked["policy_provenance"], candidates=candidates)
                policies.append({"decision_id": token, **picked, "selection_context": None})
                if failure:
                    traces.append({"request": picked["request"], "response": None, "transport_error": "fixture"})
                else:
                    final_state = {"type": "decision", "decision": "game_over", "victory": False,
                                   "player": {"hp": 0}, "context": state["context"]}
                    traces.append({"request": picked["request"], "response": final_state})
                journal.complete(token, final_state, environment_error=error,
                    execution={"exploration": picked["exploration"], "selection_purpose": None, "selection_context": None,
                               "direct_action_result": direct_action_evidence(None if error else final_state)})
            finish = journal.finalize(final_state, termination="environment_error" if error else "engine_terminal",
                                      environment_error=error)
        if legacy:
            rows = read(out / "decisions.jsonl", lines=True)
            for row in rows:
                if "candidate_set" in row:
                    candidate_set = row["candidate_set"]
                    candidate_set["adapter_version"] = "runsimulator-candidates.v1"
                    for key in ("representation", "candidate_count", "enumeration_limit"):
                        del candidate_set[key]
            write(out / "decisions.jsonl", rows, lines=True)
            for picked in policies:
                for key in ("candidate_space_representation", "candidate_count", "evaluated_candidate_count",
                            "evaluated_candidates_complete"):
                    picked["scoring"].pop(key, None)
        write(out / "policy.jsonl", policies, lines=True)
        write(out / "trace.jsonl", traces, lines=True)
        write(out / "state.json", final_state)
        observations = read_decisions(out / "decisions.jsonl")
        report = {"run_id": run_id, "seed": seed, "outcome": finish["outcome"],
                  "decisions": int(not failure and not blocked_legacy), "solver_calls": 0, "seconds": 1.0,
                  "training_eligible_decisions": sum(row["training_eligible"] for row in observations),
                  "exclusion_reasons": sorted({reason for row in observations for reason in row["training_exclusion_reasons"]}),
                  "final_context": final_state["context"], "final_hp": final_state["player"]["hp"], "error": error}
        write(out / "report.json", report)
        write(out / "status.json", {"status": "finished", **report})
        self.reports.append(report)
        self.finish_batch()
        return out

    def finish_batch(self):
        records = [row for report in self.reports for row in read_decisions(self.root / report["run_id"] / "decisions.jsonl")]
        splits = split_by_seed(records)
        write(self.batch / "reports.json", self.reports)
        write(self.batch / "summary.json", {"runs": len(self.reports), "reports": self.reports,
            "training_eligible_decisions": sum(row["training_eligible"] for row in records), "purpose": "synthetic tests"})
        write(self.batch / "split-manifest.json", {key: sorted({row["run_id"] for row in values}) for key, values in splits.items()})

    def assert_issue(self, result, name):
        self.assertFalse(result["passed"])
        self.assertIn(name, {issue["check"] for issue in result["issues"]}, result["issues"])

    def test_legacy_explicit_passes_and_original_files_are_never_overwritten(self):
        out = self.run_fixture(legacy=True)
        original = (out / "decisions.jsonl").read_bytes()
        result = audit_batch(self.batch, expected_runs=1)
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual(result["counts"]["candidate_count"], 2)
        self.assertEqual(result["counts"]["evaluated_candidate_count"], 2)
        first = Path(result["output_path"]).read_bytes()
        second = audit_batch(self.batch)
        self.assertNotEqual(result["output_path"], second["output_path"])
        self.assertEqual(Path(result["output_path"]).read_bytes(), first)
        self.assertEqual((out / "decisions.jsonl").read_bytes(), original)
        with self.assertRaises(FileExistsError):
            audit_batch(self.batch, output=result["output_path"])

    def test_implicit_exact_size_is_separate_from_evaluation_and_probability_tamper_fails(self):
        out = self.run_fixture(implicit=True)
        result = audit_batch(self.batch)
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual(result["counts"]["candidate_count"], 16)
        self.assertLessEqual(result["counts"]["evaluated_candidate_count"], 4)
        self.assertEqual(result["counts"]["implicit_decisions"], 1)
        rows = read(out / "policy.jsonl", lines=True)
        rows[0]["exploration"]["chosen_probability_rational"]["numerator"] += 1
        write(out / "policy.jsonl", rows, lines=True)
        self.assert_issue(audit_batch(self.batch), "implicit_selection_evidence")

    def test_report_integer_tamper_is_not_bool_equal(self):
        self.run_fixture()
        self.reports[0]["training_eligible_decisions"] = True
        self.finish_batch()
        self.assert_issue(audit_batch(self.batch), "per_run_report_matches_batch")

    def test_scoring_mechanism_facts_must_match_policy(self):
        out = self.run_fixture()
        rows = read(out / "policy.jsonl", lines=True)
        rows[0]["scoring"]["mechanism_facts"]["registry_sha256"] = "0" * 64
        write(out / "policy.jsonl", rows, lines=True)
        self.assert_issue(audit_batch(self.batch), "scoring_mechanism_facts")

    def test_trace_selected_action_tamper_is_detected(self):
        out = self.run_fixture()
        rows = read(out / "trace.jsonl", lines=True)
        rows[1]["request"]["args"]["option_index"] = 999
        write(out / "trace.jsonl", rows, lines=True)
        self.assert_issue(audit_batch(self.batch), "macro_request_executed_in_order")

    def test_shared_seed_split_tamper_is_detected(self):
        self.run_fixture("first", "same-seed")
        self.run_fixture("second", "same-seed")
        self.assertTrue(audit_batch(self.batch)["passed"])
        write(self.batch / "split-manifest.json", {"train": ["first"], "validation": ["second"], "test": []})
        self.assert_issue(audit_batch(self.batch), "saved_split_matches_seed_lineage_reconstruction")

    def test_model_verifies_actual_artifact_and_sources_without_batch_name_assumptions(self):
        model, source = self.model()
        self.run_fixture(model_path=model)
        result = audit_batch(self.batch)
        self.assertTrue(result["passed"], result["issues"])
        source.write_text("tampered", encoding="utf-8")
        self.assert_issue(audit_batch(self.batch), "model_training_source_hash")

    def test_survival_model_scope_and_actual_effective_scorer_are_audited(self):
        model_path, _ = self.model()
        model = read(model_path)
        model.update(format="defect-act1-survival-ridge-v1", mode="act1_survival",
            target_semantics="observed_act2_entry_under_frozen_followup_policy",
            deployment_scope={"character": "Defect", "ascension": 10, "mode": "standard", "act": 1},
            frozen_followup={"solver": {"budget_ms": 1000},
                             "run_conditions": {"character": "Defect", "ascension": 10, "mode": "standard"}})
        write(model_path, model)
        out = self.run_fixture(model_path=model_path)
        result = audit_batch(self.batch)
        self.assertTrue(result["passed"], result["issues"])
        rows = read(out / "policy.jsonl", lines=True)
        rows[0]["scoring"]["model"]["active"] = False
        write(out / "policy.jsonl", rows, lines=True)
        self.assert_issue(audit_batch(self.batch), "survival_model_actual_scope")

    def test_old_large_space_failure_stays_excluded_without_new_enumeration(self):
        out = self.run_fixture(blocked_legacy=True)
        original = (out / "decisions.jsonl").read_bytes()
        result = audit_batch(self.batch)
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual(result["counts"]["outcomes"], {"environment_error": 1})
        self.assertEqual(result["counts"]["training_eligible_decisions"], 0)
        self.assertEqual(result["zero_decision_run_ids_absent_from_split"], ["unrelated-run-name"])
        self.assertEqual((out / "decisions.jsonl").read_bytes(), original)

    def test_transport_error_is_evidence_and_never_a_defeat(self):
        self.run_fixture(failure=True)
        result = audit_batch(self.batch)
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual(result["counts"]["outcomes"], {"environment_error": 1})
        self.assertEqual(result["counts"]["excluded_decisions"], 1)

    def test_bad_journal_in_one_run_does_not_hide_other_run_results(self):
        out = self.run_fixture("bad")
        self.run_fixture("good")
        rows = read(out / "decisions.jsonl", lines=True)
        rows[1]["schema_version"] = "invented-v999"
        write(out / "decisions.jsonl", rows, lines=True)
        result = audit_batch(self.batch)
        self.assert_issue(result, "run_evidence_readable")
        self.assertEqual(result["counts"]["audited_runs"], 1)
        self.assertEqual(result["runs"][0]["run_id"], "good")


if __name__ == "__main__":
    unittest.main()
