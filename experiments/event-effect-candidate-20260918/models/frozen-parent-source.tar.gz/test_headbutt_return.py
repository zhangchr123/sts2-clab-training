"""Original Headbutt diagnostics, excluded from all natural training/evaluation."""
import copy
import unittest
import uuid

from combat_executor import CombatExecutor
from decision_data import state_hash
from inspection.diagnose_boss_search_budget import replay
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from probe import ROOT
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers


class HeadbuttReturnTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def test_recorded_failed_action_returns_enchanted_card_and_continues(self):
        source = ROOT / 'outputs/defect-whole-run-cem-20260914c-reserved-trained-024'
        receipt = read_json(ROOT / 'outputs/defect-whole-run-eval-liquid-20260914a' / (source.name + '-audit.json'))
        self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        gate = {'trace_index': 389, 'public_hash': state_hash(checked_public(rows[389]['response']))}
        label = 'headbutt-prefix-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        try:
            state, checks = replay(rows, gate, send)
            self.assertEqual(state['discard_pile_count'], 1)
            historical = copy.deepcopy(rows[387])
            action = next(a for a in historical['response']['actions'] if a.get('CardId') == 'HEADBUTT')
            observer = CombatExecutor(send)
            observer.solve_calls = [historical]
            observer.last_action_request = rows[391]['request']
            after = send(rows[391]['request'], phase='recorded_solver_action', source_index=391)
            self.assertTrue(observer.resolve_original_automatic_choice(state, after, action))
            proof = observer.solve_calls[0]['replay'][0]
            self.assertFalse(proof['selection_request_sent'])
            self.assertIn('IMBUED', proof['selected_cards'][0]['StateKey'])
            executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
            final = executor.advance(after)
            self.assertIn(final['decision'], {'card_reward', 'game_over', 'map_select'})
            self.assertFalse(final['context']['integrity_recovery_used'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            self.save(label, traces, origin='reserved_error_reproduction_not_model_training',
                      prefix_responses_verified=checks, full_state_or_rng_equality_claimed=False,
                      historical_solver_source=receipt['actual_source_evidence'], historical_solve_trace_index=387,
                      historical_card_choice=action, actual_return_proof_for_recorded_action=proof,
                      solver_calls=executor.solve_calls, passed=True)
        finally:
            bridge.close()

    def test_original_singleton_and_multioption_draw_top(self):
        for count in (1, 2):
            with self.subTest(discard_count=count):
                label = 'headbutt-options-' + str(count) + '-' + uuid.uuid4().hex[:10]
                bridge, traces, send = self.worker(label)
                try:
                    send(cmd='start_run', character='Defect', ascension=10, seed='headbutt-options-fixture')
                    send(cmd='set_player', hp=1000, max_hp=1000, relics=[], potions=[],
                         deck=['STRIKE_DEFECT', 'DEFEND_DEFECT', 'HEADBUTT'])
                    state = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
                    for card in ['STRIKE_DEFECT', 'DEFEND_DEFECT'][:count]:
                        index = next(c['index'] for c in state['hand'] if c['id'].endswith(card))
                        state = send(cmd='action', action='play_card', args={'card_index': index, 'target_index': 0})
                    self.assertEqual(state['discard_pile_count'], count)
                    index = next(c['index'] for c in state['hand'] if c['id'].endswith('HEADBUTT'))
                    state = send(cmd='action', action='play_card', args={'card_index': index, 'target_index': 0})
                    if count == 1:
                        self.assertEqual(state['decision'], 'combat_play')
                        events = state['choice_audit']['original_returns']
                        self.assertEqual(len(events), 1)
                        self.assertEqual(events[0]['returned_cards'][0]['CardId'], 'STRIKE_DEFECT')
                        self.assertEqual(events[0]['effect'], 'MoveToDrawTop')
                    else:
                        self.assertEqual(state['decision'], 'card_select')
                        self.assertEqual(state['choice_audit']['original_returns'], [])
                        self.assertEqual(len(state['cards']), 2)
                        state = send(cmd='action', action='select_cards', args={'indices': '0'})
                        self.assertEqual(state['decision'], 'combat_play')
                    self.assertEqual(state['draw_pile_count'], 1)
                    self.assertEqual(state['discard_pile_count'], count)
                    self.save(label, traces, origin='artificial_fixture', passed=True)
                finally:
                    bridge.close()

    def test_solver_singletons_and_killing_headbutt_end_combat(self):
        label = 'headbutt-ending-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, executor = False, None
        try:
            send(cmd='start_run', character='Defect', ascension=10, seed='headbutt-ending-fixture')
            send(cmd='set_player', hp=1000, max_hp=1000, deck=['HEADBUTT'] * 5, relics=[], potions=[])
            state = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
            executor = CombatExecutor(send)
            final = executor.advance(state)
            self.assertEqual(final['decision'], 'card_reward')
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertEqual(final['choice_audit']['parent']['card_id'], 'HEADBUTT')
            self.assertEqual(final['choice_audit']['original_returns'], [])
            self.assertTrue(any(p.get('actual_choice_audit', {}).get('parent', {}).get('card_id') == 'HEADBUTT'
                                for c in executor.solve_calls for p in c.get('replay', [])))
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            endings = [p for c in executor.solve_calls for p in c.get('replay', [])
                       if p.get('reason') == 'engine_combat_ending_short_circuit']
            self.assertTrue(endings)
            self.assertTrue(all(p['selected_cards'] == [] and p['remaining_battle_plan_stopped'] for p in endings))
            corrupt = copy.deepcopy(executor.solve_calls)
            for call in corrupt:
                call['replay'] = [p for p in call.get('replay', [])
                                  if p.get('reason') != 'engine_combat_ending_short_circuit']
            with self.assertRaises(ValueError):
                validate_replay_evidence(corrupt, traces)
            passed = True
        finally:
            bridge.close()
            self.save(label, traces, origin='artificial_fixture',
                      solver_calls=executor.solve_calls if executor else [], passed=passed)


if __name__ == '__main__': unittest.main()
