"""Draft nominal effect counters from fixed original source; no strategic weights.

Not installed in any runtime. A future artifact must bind verified_source().
Counters are base exported stacks, not guaranteed triggers, cards added, damage,
block, actual power application after hooks, or a predicted combat outcome.
"""
import hashlib
import json
import math
from pathlib import Path

ENGINE_SHA='14b57dbaee1b58cb919625a662831054fd714b3b75b13b7449eac0e95b98a3e4'
SOURCE=Path(__file__).resolve().parent / 'reference_facts' / 'SOURCE_EXTRACTED.json'
FACTS={
    'LOOP':dict(card_type='Power',stat='loop',parameter='nominal_first_orb_passive_trigger_stacks',
        source_types=['Loop','LoopPower'],trigger='AfterPlayerTurnStart for owner, only if orb queue nonempty',
        target='OrbQueue.Orbs[0]',scope='combat power',immediate_effect=False),
    'LIGHTNING_ROD':dict(card_type='Skill',stat='lightningrodpower',parameter='nominal_delayed_lightning_turns',
        source_types=['LightningRod','LightningRodPower'],trigger='AfterEnergyReset for owner',
        per_trigger='Channel one LightningOrb then Decrement power; amount is remaining resets, not orbs per reset',
        immediate_block_already_separately_modeled=True,immediate_channel=False),
    'CREATIVE_AI':dict(card_type='Power',stat='creativeai',parameter='nominal_power_generation_attempts_per_draw_phase',
        source_types=['CreativeAi','CreativeAiPower'],trigger='BeforeHandDraw for owner',
        pool='owner unlocked character Power cards under multiplayer constraint',
        rng='CombatCardGeneration',destination='combat Hand',permanent_deck_addition=False,
        successful_addition_guaranteed=False,immediate_effect=False),
    'ECHO_FORM':dict(card_type='Power',stat='echoform',parameter='nominal_early_play_series_replay_limit',
        source_types=['EchoForm','EchoFormPower'],trigger='ModifyCardPlayCount for owner card',
        history='owner CardPlaysStarted where IsFirstInSeries and HappenedThisTurn',
        condition='prior counted plays < Amount',additional_play_count=1,
        multiplied_play_count=False,upgrade='Remove Ethereal; does not raise replay limit'),
    'STORM':dict(card_type='Power',stat='stormpower',parameter='nominal_lightning_per_later_power_play',
        source_types=['Storm','StormPower'],trigger='owner Power card, amount captured in BeforeCardPlayed',
        execution='AfterCardPlayed removes captured amount and channels that many LightningOrbs',
        newly_applied_stacks_trigger_on_same_play=False,immediate_channel=False),
}
PARAMETERS=tuple(f['parameter'] for f in FACTS.values())
CONTRACT=dict(version='nominal-persistent-power-counters-v1',engine_sha256=ENGINE_SHA,
    parameters=PARAMETERS,facts=FACTS,strategic_values_assigned=False,
    hidden_combat_state_used=False,unknown_cards_have_zero_features=True,
    recognized_card_missing_or_invalid_count_rejected=True,runtime_installed=False)


def evidence(path):
    path=Path(path);data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def verified_source(engine_path):
    engine=evidence(engine_path)
    if engine['sha256']!=ENGINE_SHA:raise ValueError('Wrong original engine for persistent effect facts')
    source=json.loads(SOURCE.read_text(encoding='utf-8'))
    if not source['passed'] or len(source['types'])!=10:raise ValueError('Incomplete source extraction')
    expected={f'MegaCrit.Sts2.Core.Models.{group}.{name}' for fact in FACTS.values()
        for group,name in zip(('Cards','Powers'),fact['source_types'])}
    if {r['type'] for r in source['types']}!=expected:raise ValueError('Source type set differs')
    for row in source['types']:
        if row['exit_code']!=0 or evidence(row['source']['path'])!=row['source']:
            raise ValueError('Persistent effect source changed')
    return dict(engine=engine,extraction=evidence(SOURCE),implementation=evidence(Path(__file__)),
        contract_sha256=hashlib.sha256(json.dumps(CONTRACT,sort_keys=True).encode()).hexdigest())


def features(card):
    if not isinstance(card,dict) or not isinstance(card.get('id'),str):raise ValueError('Missing card identity')
    cid=card['id'].split('.')[-1].upper();result=dict.fromkeys(PARAMETERS,0.)
    fact=FACTS.get(cid)
    if fact is None:return result
    if card.get('type')!=fact['card_type']:raise ValueError('Recognized card type differs from original')
    raw=card.get('stats')
    if not isinstance(raw,dict) or not all(isinstance(k,str) for k in raw):raise ValueError('Missing current card stats')
    stats={k.lower():v for k,v in raw.items()}
    if len(stats)!=len(raw):raise ValueError('Ambiguous exported stat casing')
    value=stats.get(fact['stat'])
    if type(value) not in (float,int) or not math.isfinite(value) or value<0 or not float(value).is_integer():
        raise ValueError('Missing or invalid nominal power counter')
    result[fact['parameter']]=float(value)
    return result
