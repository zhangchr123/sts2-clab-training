"""Public 261-parameter descriptors, retaining the exact original 233 terms.

Identity capabilities are observations about possible effects, not quantities,
combat eligibility, trigger probabilities, or loop executability. In particular,
conditional draw, next-turn energy and zero-cost-filtered retrieval stay distinct.
"""
import math
from collections.abc import Mapping
from circulation_context_features import PARAMETERS as ORIGINAL_PARAMETERS, features as original_features
from initial_policy import card_id, card_mechanisms
from decision_data import DataContractError

ENGINE_SHA256 = '14b57dbaee1b58cb919625a662831054fd714b3b75b13b7449eac0e95b98a3e4'
FACTS = {
    'FLASH_OF_STEEL': ('draw', 'OnPlay: draw after attack'),
    'FTL': ('conditional_draw', 'CanDrawCard: own finished card plays this turn < PlayMax'),
    'CHARGE_BATTERY': ('next_turn_energy', 'OnPlay: apply EnergyNextTurnPower after block'),
    'SCAVENGE': ('next_turn_energy', 'OnPlay: hand exhaust selection then EnergyNextTurnPower'),
    'ALL_FOR_ONE': ('zero_cost_retrieval', 'OnPlay/Filter: discard; modified zero non-X energy cost; allowed card type'),
}
LEGACY_TAGS = ('draw', 'energy', 'discard_retrieval')
NEW_TAGS = ('conditional_draw', 'next_turn_energy', 'zero_cost_retrieval')
TAGS = (*LEGACY_TAGS, *NEW_TAGS)
INTERACTIONS = tuple((a, b) for a in TAGS for b in TAGS if a != b and
                     (a, b) not in {('energy', 'discard_retrieval'), ('discard_retrieval', 'energy')})
# For legacy pairs, store ONLY the newly recognized contribution (FlashOfSteel).
# The two unchanged energy/retrieval legacy pairs are excluded because their added contribution is identically zero.
# Other pairs are entirely new. Never double-count or replace the old six terms.
EXTRA_PARAMETERS = tuple(f'capability_added_{a}_with_{b}_density' for a, b in INTERACTIONS)
PARAMETERS = (*ORIGINAL_PARAMETERS, *EXTRA_PARAMETERS)


def checked_card(card):
    if not isinstance(card, Mapping) or not isinstance(card.get('id'), str) or not card['id']:
        raise DataContractError('Capability descriptors require public identified cards')
    return card


def capabilities(card):
    checked_card(card)
    tags = card_mechanisms(card) & set(LEGACY_TAGS)
    fact = FACTS.get(card_id(card))
    if fact is not None: tags.add(fact[0])
    return tags


def extra_features(state, row, candidate):
    if row['request'] != candidate['request']:
        raise DataContractError('Capability row/candidate mismatch')
    result = dict.fromkeys(EXTRA_PARAMETERS, 0.)
    action = row['request']['action']
    if action in {'select_card_reward', 'buy_card'}:
        cards = [candidate['evidence']]
    elif action == 'select_bundle' or (action == 'select_cards' and row['features'].get('selection_acquire') == 1.):
        cards = candidate['evidence']['cards']
        if not isinstance(cards, list): raise DataContractError('Expected a public acquisition list')
    else:
        return result
    if not cards: return result
    player = state.get('player', {}); deck = player.get('deck')
    if not isinstance(deck, list) or not deck:
        raise DataContractError('Expected a nonempty pre-acquisition public deck')
    size = player.get('deck_size')
    if size is not None and (type(size) is not int or size != len(deck)):
        raise DataContractError('Public deck size differs')
    tags = [capabilities(c) for c in deck]
    old_tags = [card_mechanisms(c) for c in deck]
    density = {tag: sum(tag in v for v in tags) / len(deck) for tag in TAGS}
    old_density = {tag: sum(tag in v for v in old_tags) / len(deck) for tag in LEGACY_TAGS}
    for card in cards:
        active = capabilities(card); old = card_mechanisms(card)
        for key, (a, b) in zip(EXTRA_PARAMETERS, INTERACTIONS):
            value = float(a in active) * density[b]
            if a in LEGACY_TAGS and b in LEGACY_TAGS:
                value -= float(a in old) * old_density[b]
            result[key] += value
    return result


def features(state, row, candidate):
    original = original_features(state, row, candidate)
    if tuple(original) != ORIGINAL_PARAMETERS:
        raise DataContractError('Original 233-feature schema drift')
    return {**original, **extra_features(state, row, candidate)}


def zero_extend(parameters):
    if set(parameters) != set(ORIGINAL_PARAMETERS) or any(
        type(v) not in (int, float) or not math.isfinite(v) or abs(v) > 4 for v in parameters.values()
    ):
        raise DataContractError('Invalid original 233-parameter vector')
    return {**{k: parameters[k] for k in ORIGINAL_PARAMETERS}, **dict.fromkeys(EXTRA_PARAMETERS, 0.)}


