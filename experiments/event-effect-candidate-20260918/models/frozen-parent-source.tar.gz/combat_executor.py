"""Replay only original CombatSolver actions against the live engine."""
from __future__ import annotations

import copy
import json
import re


DEFAULT_CONFIG = {
    "first_budget_ms": 2500, "replan_budget_ms": 4000, "setup_budget_ms": 15000,
    "retry_budget_ms": 30000, "max_replans": 35,
    "solver_backend": "beam",
    "potion_policy": "Smart", "growth_budgets": {"GeneticAlgorithm": 3},
    "act_boss_hp_strategy": "ProgressionFirst", "final_boss_hp_strategy": "ProgressionFirst",
    "search_profile": {"beam_width": 30, "max_expanded_nodes": 5000,
        "max_card_branches_per_node": 24, "max_pile_choice_branches_per_action": 12,
        "max_hand_choice_branches_per_action": 12, "recover_deferred_turn_frontier": False},
}


def solver_config(path=None):
    result = copy.deepcopy(DEFAULT_CONFIG)
    if path:
        supplied = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(supplied, dict) or set(supplied) - set(result):
            raise ValueError("Unknown solver configuration field")
        result.update(supplied)
    for key in ("first_budget_ms", "replan_budget_ms", "setup_budget_ms", "retry_budget_ms"):
        if type(result[key]) is not int or not 100 <= result[key] <= 30000:
            raise ValueError(f"{key} must be 100..30000")
    if type(result["max_replans"]) is not int or not 1 <= result["max_replans"] <= 100:
        raise ValueError("max_replans must be 1..100")
    if result["solver_backend"] not in {"beam", "coordinator"}:
        raise ValueError("solver_backend must be beam or coordinator")
    return result


def choice_plans(action):
    nested = action.get("NestedChoices") or []
    before = action.get("NestedChoicesBeforePrimary", 0)
    return (nested[:before] + ([action["Choice"]] if action.get("Choice") else [])
            + nested[before:] + (action.get("TurnStartChoices") or []))


CHOICE_DECISIONS = {"card_select", "card_reward", "bundle_select"}


def combat_in_progress(state):
    flag = state.get("context", {}).get("combat_in_progress")
    if type(flag) is not bool:
        raise RuntimeError("Missing explicit combat_in_progress; choice ownership is unknown")
    return flag


def require_macro_boundary(state):
    """Never let a combat choice escape to a macro controller or policy."""
    # Terminal defeat is already authoritative even if the room retains its combat flag.
    hp = state.get("player", {}).get("hp")
    if (state.get("type") == "decision" and state.get("decision") == "game_over"
            and state.get("victory") is False and type(hp) in (int, float) and hp == 0
            and state.get("context", {}).get("integrity_recovery_used") is False):
        return
    if state.get("decision") in CHOICE_DECISIONS or state.get("context", {}).get("combat_in_progress") is True:
        if combat_in_progress(state):
            raise RuntimeError("Unplanned combat decision: " + str(state.get("decision")))


class CombatExecutor:
    def __init__(self, send, config=None, publish=None):
        self.send = send
        self.config = copy.deepcopy(config or DEFAULT_CONFIG)
        self.publish = publish or (lambda state: None)
        self.solve_calls = []
        self.last_state = None
        self.last_response = None
        self.last_error = None
        self.last_action_request = None

    def observe_response(self, response, *, is_action=False):
        self.last_response = copy.deepcopy(response)
        if response.get("type") == "decision" or is_action:
            self.last_state = copy.deepcopy(response)
        if response.get("type") == "error":
            self.last_error = copy.deepcopy(response)

    def checked(self, **request):
        if request.get("cmd") == "action":
            self.last_action_request = copy.deepcopy(request)
        response = self.send(**request)
        self.observe_response(response, is_action=request.get("cmd") == "action")
        if response.get("type") == "error":
            raise RuntimeError(json.dumps(response, ensure_ascii=False))
        return response

    @staticmethod
    def metrics(state):
        metrics = state.get("player", {}).get("combat_metrics", {})
        if (metrics.get("source") != "Creature.CurrentHpChanged" or type(metrics.get("hp_lost")) is not int
                or metrics["hp_lost"] < 0):
            raise RuntimeError("Missing actual engine HP-event accounting")
        return metrics

    def solve(self, state, budget, used=0, setup=False):
        config = self.config
        request = {"cmd": "solve", "budget_ms": budget,
            "solver_backend": config.get("solver_backend", "beam"),
            "potion_policy": config["potion_policy"], "growth_budgets": config["growth_budgets"],
            "act_boss_hp_strategy": config["act_boss_hp_strategy"],
            "final_boss_hp_strategy": config["final_boss_hp_strategy"],
            "search_profile": config["search_profile"], "include_turn_setup": setup,
            "hp_lost_so_far": self.metrics(state)["hp_lost"], "potions_used_so_far": used}
        response = self.send(**request)
        self.observe_response(response)
        self.solve_calls.append({"request": request, "response": response})
        if response.get("type") == "error":
            if "OperationCanceledException" in str(response) and budget != config["retry_budget_ms"]:
                return self.solve(state, config["retry_budget_ms"], used, setup)
            raise RuntimeError(json.dumps(response))
        if response.get("settings", {}).get("search_profile_verified") is not True:
            raise RuntimeError("Solver did not verify its effective search profile")
        return response

    def resolve(self, state, plans, *, setup_capture=None, setup_choices=None, allow_pending=False):
        for plan in plans:
            if state.get("decision") not in CHOICE_DECISIONS or not combat_in_progress(state):
                raise RuntimeError("Expected solver choice surface: " + json.dumps(plan))
            if state["decision"] == "bundle_select":
                raise RuntimeError("Combat bundle token mapping is not verified")
            meta = self.checked(cmd="choice_meta")
            if meta.get("type") != "choice_meta" or meta.get("selection") != state["decision"]:
                raise RuntimeError("Current choice metadata does not match decision surface")
            cards = meta.get("cards")
            if not isinstance(cards, list) or any(
                    not isinstance(card, dict) or type(card.get("index")) is not int or card["index"] < 0
                    or not isinstance(card.get("id"), str) or not isinstance(card.get("key"), str) or not card["key"]
                    or type(card.get("upgrade_level")) is not int or card["upgrade_level"] < 0 for card in cards):
                raise RuntimeError("Incomplete actual choice fingerprints")
            if len({card["index"] for card in cards}) != len(cards):
                raise RuntimeError("Duplicate actual choice index")
            visible = state.get("cards", [])
            if (len(visible) != len(cards) or
                    {card["index"]: card["id"].split(".")[-1] for card in visible}
                    != {card["index"]: card["id"] for card in cards}):
                raise RuntimeError("Choice surface changed before fingerprint verification")
            tokens = plan.get("Cards")
            if not isinstance(tokens, list):
                raise RuntimeError("Solver choice has no explicit token list")
            if setup_capture is not None:
                if plan.get("SourceId") == "GAMBLING_CHIP":
                    from gambling_setup import verify as verify_gambling_setup
                    verify_gambling_setup(self, state, plan, meta, setup_capture)
                else:
                    self.verify_toasty_setup_metadata(state, plan, meta, setup_capture)
            knowledge = plan.get("Effect") == "ApplyKnowledgeCurse"
            seeker = meta.get("seeker_choice") is not None or (
                str(plan.get("ContextId", "")).startswith("seeker:")
                and state.get("choice_audit", {}).get("parent", {}).get("card_id") == "SEEKER_STRIKE")
            if knowledge:
                selected = self.knowledge_choice_indices(state, plan, meta)
            elif seeker:
                selected = self.seeker_choice_indices(state, plan, meta)
            else:
                selected = self.card_choice_indices(plan, cards)
            if len(set(selected)) != len(selected):
                raise RuntimeError("Solver selected the same card instance twice")
            if state["decision"] == "card_select":
                minimum, maximum = state.get("min_select"), state.get("max_select")
                if type(minimum) is not int or type(maximum) is not int or not minimum <= len(selected) <= maximum:
                    raise RuntimeError("Solver choice violates actual selection bounds")
                state = self.checked(cmd="action", action="select_cards", args={"indices": ",".join(map(str, selected))})
            elif len(selected) == 1:
                state = self.checked(cmd="action", action="select_card_reward", args={"card_index": selected[0]})
            elif not selected and state.get("can_skip") is True:
                state = self.checked(cmd="action", action="skip_card_reward")
            else:
                raise RuntimeError("Unsupported solver reward choice: " + json.dumps(plan))
            if setup_choices is not None:
                setup_choices.append({"plan": copy.deepcopy(plan), "actual_choice_metadata": copy.deepcopy(meta),
                    "actual_request": copy.deepcopy(self.last_action_request)})
            if knowledge and self.solve_calls:
                self.solve_calls[-1].setdefault("replay", []).append({
                    "kind": "knowledge_demon_effect_choice", "plan": copy.deepcopy(plan),
                    "actual_choice_metadata": copy.deepcopy(meta), "selected_indices": selected,
                    "identity_basis": "original_pending_ChooseCurse_source_counter_and_unique_effect_id"})
            if seeker:
                proof = self.seeker_choice_proof(plan, meta, state, selected, self.last_action_request)
                if self.solve_calls:
                    self.solve_calls[-1].setdefault("replay", []).append(proof)
        if state.get("decision") != "combat_play" and not (
                allow_pending and state.get("decision") in CHOICE_DECISIONS and combat_in_progress(state)):
            require_macro_boundary(state)
        return state

    @staticmethod
    def hologram_manual_repeat(action):
        return (action.get("Kind") == "PlayCard" and action.get("CardId") == "HOLOGRAM"
            and type(action.get("ReplayCount")) is int and 0 <= action["ReplayCount"] <= 64
            and len(choice_plans(action)) >= 1)

    @staticmethod
    def legacy_hologram_manual_repeat(action):
        return (action.get("Kind") == "PlayCard" and action.get("CardId") == "HOLOGRAM"
                and type(action.get("ReplayCount")) is int and action["ReplayCount"] == 1
                and action.get("CardEnchantmentId") == "GLAM" and len(choice_plans(action)) == 2)

    def resolve_hologram_continuation(self, before, pending, action):
        """Execute the original manual choice, then verify its original repeat."""
        events = pending.get("choice_audit", {}).get("original_returns", [])
        if events and "hologram_play_count" in events[0]:
            from hologram_series import resolve
            return resolve(self, before, pending, action, manual=True)
        plans = choice_plans(action)
        root_request = copy.deepcopy(self.last_action_request)
        root_audit = pending.get("choice_audit", {})
        root_parent = root_audit.get("parent", {})
        if (not self.legacy_hologram_manual_repeat(action) or action.get("Choice") != plans[0]
                or action.get("NestedChoices") != [plans[1]] or action.get("TurnStartChoices")
                or type(action.get("NestedChoicesBeforePrimary")) is not int
                or action["NestedChoicesBeforePrimary"] != 0 or action.get("EndsPlayerTurn") is not False
                or pending.get("decision") != "card_select" or not combat_in_progress(pending)
                or root_audit.get("schema_version") != "combat-choice-return-v2" or root_audit.get("closed") is not True
                or type(root_audit.get("action_id")) is not int or root_audit["action_id"] < 1
                or root_parent.get("action") != "play_card" or root_parent.get("card_id") != "HOLOGRAM"
                or root_parent.get("card_key") != action.get("CardStateKey")
                or not isinstance(action.get("CardStateKey"), str) or not action["CardStateKey"]
                or type(root_parent.get("card_index")) is not int or root_parent["card_index"] < 0
                or root_request != {"cmd": "action", "action": "play_card", "args": {"card_index": root_parent["card_index"]}}
                or type(action.get("Turn")) is not int or action["Turn"] != before.get("player_turn")
                or root_parent.get("player_turn") != action["Turn"]
                or root_parent.get("combat_id") != self.setup_state_identity(before)["combat_id"]
                or root_parent.get("combat_active_before") is not True):
            raise RuntimeError("Hologram continuation lacks its actual original play")
        for plan in plans:
            if (not isinstance(plan, dict) or any(plan.get(k) != v for k, v in {
                    "Effect": "MoveToHand", "SourcePile": "Discard", "SourceId": "",
                    "ContextId": "", "Timing": "Action"}.items())
                    or not isinstance(plan.get("Cards"), list) or len(plan["Cards"]) != 1):
                raise RuntimeError("Hologram continuation has an unsupported original choice plan")
        choices = []
        state = self.resolve(pending, [plans[0]], setup_choices=choices, allow_pending=True)
        if state.get("decision") == "card_select" and combat_in_progress(state):
            # More than one remaining option is still a real manual decision.
            return self.resolve(state, [plans[1]])
        audit = state.get("choice_audit", {})
        continuation = audit.get("hologram_continuation", {})
        parent = audit.get("parent", {})
        returns = audit.get("original_returns")
        original_returns = root_audit.get("original_returns")
        if (state.get("decision") != "combat_play" or not combat_in_progress(state)
                or self.setup_state_identity(before) != self.setup_state_identity(state)
                or state.get("player_turn") != action["Turn"]
                or audit.get("schema_version") != "combat-choice-return-v2" or audit.get("closed") is not True
                or audit.get("coverage") != root_audit.get("coverage")
                or type(audit.get("action_id")) is not int or audit["action_id"] != root_audit["action_id"] + 1
                or audit.get("events") != [] or parent.get("action") != "select_cards"
                or parent.get("card_id") is not None or parent.get("card_key") is not None
                or parent.get("card_index") != -1 or parent.get("combat_active_before") is not True
                or any(parent.get(k) != root_parent.get(k) for k in ("player_id", "combat_id", "player_turn"))
                or not isinstance(returns, list) or len(returns) != 1
                or not isinstance(original_returns, list) or len(original_returns) != 1
                or len(choices) != 1 or self.last_action_request != choices[0]["actual_request"]
                or self.last_action_request.get("action") != "select_cards"):
            raise RuntimeError("Hologram automatic repeat changed its original selection owner")
        first = original_returns[0]
        counter = continuation.get("selector_invocation_at_resume")
        if (continuation.get("schema_version") != "hologram-pending-task-continuation-v1"
                or continuation.get("origin_action_id") != root_audit["action_id"]
                or continuation.get("origin_parent") != root_parent
                or any(continuation.get(k) is not True for k in (
                    "original_task_pending_at_resume", "selector_task_identity_matches", "source_is_original_card_object",
                    "original_task_completed_successfully", "selector_task_completed_successfully",
                    "original_and_selector_return_same_card_objects"))
                or type(continuation.get("original_source_count_at_entry")) is not int
                or continuation["original_source_count_at_entry"] != 2
                or type(continuation.get("original_task_returned_count")) is not int
                or continuation["original_task_returned_count"] != 1
                or type(counter) is not int or counter < 1
                or type(continuation.get("selector_invocation_at_end")) is not int
                or continuation["selector_invocation_at_end"] != counter
                or continuation.get("selector_pending_at_end") is not False
                or first.get("source_id") != "HOLOGRAM" or first.get("effect_callsite") != "Hologram.OnPlay"
                or first.get("source_is_actual_parent_object") is not True
                or first.get("verified") is not False or first.get("original_task_completed_successfully") is not False
                or first.get("selector_pending_after") is not True
                or type(first.get("selector_invocations_before")) is not int
                or first["selector_invocations_before"] + 1 != counter
                or first.get("selector_invocations_after") != counter
                or first.get("raw_source_count_at_entry") != 2
                or len(choices[0]["actual_choice_metadata"]["cards"]) != 2):
            raise RuntimeError("Hologram original pending task was not authenticated")
        event = returns[0]
        expected = {"schema_version": "original-choice-return-v1", "invocation_index": 0,
            "action_id": audit["action_id"], "source_method": "CardSelectCmd.FromCombatPile",
            "effect_callsite": "Hologram.OnPlay", "effect": "MoveToHand", "source_id": "HOLOGRAM",
            "source_pile": "Discard", "source_is_actual_parent_object": True,
            "player_id": root_parent["player_id"], "player_turn": action["Turn"],
            "is_over_or_ending_at_entry": False, "combat_active_at_entry": True,
            "min_select": 1, "max_select": 1, "require_manual_confirmation": False,
            "filter_is_null": False, "filter_reexecuted_by_observer": False,
            "raw_source_count_at_entry": 1, "raw_source_count_at_return": 1,
            "selector_invocations_before": counter, "selector_invocations_after": counter,
            "selector_pending_before": False, "selector_pending_after": False,
            "verified": True, "original_task_completed_successfully": True,
            "combat_active_at_return": True, "is_over_or_ending_at_return": False,
            "original_returned_collection": "List<CardModel>", "returned_count": 1,
            "returned_objects_match_original_source": True,
            "candidate_basis": "original_implementation_and_completed_return_without_selector"}
        if any(type(event.get(k)) is not type(v) or event.get(k) != v for k, v in expected.items()):
            raise RuntimeError("Hologram repeat lacks a complete original automatic return")
        def token(value):
            if (not isinstance(value, dict) or any(not isinstance(value.get(k), str) or not value[k]
                    for k in ("CardId", "StateKey")) or any(type(value.get(k)) is not int or value[k] < 0
                    for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
                raise RuntimeError("Hologram repeat lacks a complete card fingerprint")
            return {k: value[k] for k in ("CardId", "StateKey", "UpgradeLevel", "SourceOccurrence", "OptionOccurrence")}
        returned = event.get("returned_cards")
        if (not isinstance(returned, list) or len(returned) != 1
                or token(returned[0]) != token(plans[1]["Cards"][0])
                or returned[0]["SourceOccurrence"] != 0 or returned[0]["OptionOccurrence"] != 0):
            raise RuntimeError("Hologram automatic card differs from its remaining solver plan")
        meta = self.checked(cmd="choice_meta")
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none" or meta.get("cards") != []
                or meta.get("completion_audit") != audit or not self.solve_calls):
            raise RuntimeError("Hologram continuation evidence is stale or still pending")
        self.solve_calls[-1].setdefault("replay", []).append({
            "kind": "original_choice_continuation_completed", "plan": copy.deepcopy(plans[1]),
            "primary_plan": copy.deepcopy(plans[0]), "actual_root_audit": copy.deepcopy(root_audit),
            "manual_choice": copy.deepcopy(choices[0]), "actual_choice_audit": copy.deepcopy(audit),
            "selected_cards": copy.deepcopy(returned), "manual_selection_request_sent": True,
            "automatic_selection_request_sent": False})
        return state

    @staticmethod
    def scavenge_manual_repeat(action):
        return (action.get("Kind") == "PlayCard" and action.get("CardId") == "SCAVENGE"
                and type(action.get("ReplayCount")) is int and action["ReplayCount"] == 1
                and action.get("CardEnchantmentId") == "GLAM" and len(choice_plans(action)) == 2)

    def resolve_scavenge_continuation(self, before, pending, action):
        """Execute the original manual choice, then verify its original repeat."""
        plans = choice_plans(action)
        root_request = copy.deepcopy(self.last_action_request)
        root_audit = pending.get("choice_audit", {})
        root_parent = root_audit.get("parent", {})
        if (not self.scavenge_manual_repeat(action) or action.get("Choice") != plans[0]
                or action.get("NestedChoices") != [plans[1]] or action.get("TurnStartChoices")
                or type(action.get("NestedChoicesBeforePrimary")) is not int
                or action["NestedChoicesBeforePrimary"] != 0 or action.get("EndsPlayerTurn") is not False
                or pending.get("decision") != "card_select" or not combat_in_progress(pending)
                or root_audit.get("schema_version") != "combat-choice-return-v2" or root_audit.get("closed") is not True
                or type(root_audit.get("action_id")) is not int or root_audit["action_id"] < 1
                or root_parent.get("action") != "play_card" or root_parent.get("card_id") != "SCAVENGE"
                or root_parent.get("card_key") != action.get("CardStateKey")
                or not isinstance(action.get("CardStateKey"), str) or not action["CardStateKey"]
                or type(root_parent.get("card_index")) is not int or root_parent["card_index"] < 0
                or root_request != {"cmd": "action", "action": "play_card", "args": {"card_index": root_parent["card_index"]}}
                or type(action.get("Turn")) is not int or action["Turn"] != before.get("player_turn")
                or root_parent.get("player_turn") != action["Turn"]
                or root_parent.get("combat_id") != self.setup_state_identity(before)["combat_id"]
                or root_parent.get("combat_active_before") is not True):
            raise RuntimeError("Scavenge continuation lacks its actual original play")
        for plan in plans:
            if (not isinstance(plan, dict) or any(plan.get(k) != v for k, v in {
                    "Effect": "Exhaust", "SourcePile": "Hand", "SourceId": "",
                    "ContextId": "", "Timing": "Action"}.items())
                    or not isinstance(plan.get("Cards"), list) or len(plan["Cards"]) != 1):
                raise RuntimeError("Scavenge continuation has an unsupported original choice plan")
        choices = []
        state = self.resolve(pending, [plans[0]], setup_choices=choices, allow_pending=True)
        if state.get("decision") == "card_select" and combat_in_progress(state):
            # More than one remaining option is still a real manual decision.
            return self.resolve(state, [plans[1]])
        audit = state.get("choice_audit", {})
        continuation = audit.get("scavenge_continuation", {})
        parent = audit.get("parent", {})
        returns = audit.get("original_returns")
        original_returns = root_audit.get("original_returns")
        if (state.get("decision") != "combat_play" or not combat_in_progress(state)
                or self.setup_state_identity(before) != self.setup_state_identity(state)
                or state.get("player_turn") != action["Turn"]
                or audit.get("schema_version") != "combat-choice-return-v2" or audit.get("closed") is not True
                or audit.get("coverage") != root_audit.get("coverage")
                or type(audit.get("action_id")) is not int or audit["action_id"] != root_audit["action_id"] + 1
                or audit.get("events") != [] or parent.get("action") != "select_cards"
                or parent.get("card_id") is not None or parent.get("card_key") is not None
                or parent.get("card_index") != -1 or parent.get("combat_active_before") is not True
                or any(parent.get(k) != root_parent.get(k) for k in ("player_id", "combat_id", "player_turn"))
                or not isinstance(returns, list) or len(returns) != 1
                or not isinstance(original_returns, list) or len(original_returns) != 1
                or len(choices) != 1 or self.last_action_request != choices[0]["actual_request"]
                or self.last_action_request.get("action") != "select_cards"):
            raise RuntimeError("Scavenge automatic repeat changed its original selection owner")
        first = original_returns[0]
        counter = continuation.get("selector_invocation_at_resume")
        if (continuation.get("schema_version") != "scavenge-pending-task-continuation-v1"
                or continuation.get("origin_action_id") != root_audit["action_id"]
                or continuation.get("origin_parent") != root_parent
                or any(continuation.get(k) is not True for k in (
                    "original_task_pending_at_resume", "selector_task_identity_matches", "source_is_original_card_object",
                    "original_task_completed_successfully", "selector_task_completed_successfully",
                    "original_and_selector_return_same_card_objects"))
                or type(continuation.get("original_source_count_at_entry")) is not int
                or continuation["original_source_count_at_entry"] != 2
                or type(continuation.get("original_task_returned_count")) is not int
                or continuation["original_task_returned_count"] != 1
                or type(counter) is not int or counter < 1
                or type(continuation.get("selector_invocation_at_end")) is not int
                or continuation["selector_invocation_at_end"] != counter
                or continuation.get("selector_pending_at_end") is not False
                or first.get("source_id") != "SCAVENGE" or first.get("effect_callsite") != "Scavenge.OnPlay"
                or first.get("source_method") != "CardSelectCmd.FromHand"
                or first.get("source_pile") != "Hand" or first.get("effect") != "Exhaust"
                or first.get("filter_is_null") is not True
                or first.get("filter_reexecuted_by_observer") is not False
                or first.get("require_manual_confirmation") is not False
                or first.get("source_is_actual_parent_object") is not True
                or first.get("verified") is not False or first.get("original_task_completed_successfully") is not False
                or first.get("selector_pending_after") is not True
                or type(first.get("selector_invocations_before")) is not int
                or first["selector_invocations_before"] + 1 != counter
                or first.get("selector_invocations_after") != counter
                or first.get("raw_source_count_at_entry") != 2
                or len(choices[0]["actual_choice_metadata"]["cards"]) != 2):
            raise RuntimeError("Scavenge original pending task was not authenticated")
        event = returns[0]
        expected = {"schema_version": "original-choice-return-v1", "invocation_index": 0,
            "action_id": audit["action_id"], "source_method": "CardSelectCmd.FromHand",
            "effect_callsite": "Scavenge.OnPlay", "effect": "Exhaust", "source_id": "SCAVENGE",
            "source_pile": "Hand", "source_is_actual_parent_object": True,
            "player_id": root_parent["player_id"], "player_turn": action["Turn"],
            "is_over_or_ending_at_entry": False, "combat_active_at_entry": True,
            "min_select": 1, "max_select": 1, "require_manual_confirmation": False,
            "filter_is_null": True, "filter_reexecuted_by_observer": False,
            "raw_source_count_at_entry": 1, "raw_source_count_at_return": 1,
            "selector_invocations_before": counter, "selector_invocations_after": counter,
            "selector_pending_before": False, "selector_pending_after": False,
            "verified": True, "original_task_completed_successfully": True,
            "combat_active_at_return": True, "is_over_or_ending_at_return": False,
            "original_returned_collection": "List<CardModel>", "returned_count": 1,
            "returned_objects_match_original_source": True,
            "candidate_basis": "original_implementation_and_completed_return_without_selector"}
        if any(type(event.get(k)) is not type(v) or event.get(k) != v for k, v in expected.items()):
            raise RuntimeError("Scavenge repeat lacks a complete original automatic return")
        def token(value):
            if (not isinstance(value, dict) or any(not isinstance(value.get(k), str) or not value[k]
                    for k in ("CardId", "StateKey")) or any(type(value.get(k)) is not int or value[k] < 0
                    for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
                raise RuntimeError("Scavenge repeat lacks a complete card fingerprint")
            return {k: value[k] for k in ("CardId", "StateKey", "UpgradeLevel", "SourceOccurrence", "OptionOccurrence")}
        returned = event.get("returned_cards")
        if (not isinstance(returned, list) or len(returned) != 1
                or token(returned[0]) != token(plans[1]["Cards"][0])
                or returned[0]["SourceOccurrence"] != 0 or returned[0]["OptionOccurrence"] != 0):
            raise RuntimeError("Scavenge automatic card differs from its remaining solver plan")
        meta = self.checked(cmd="choice_meta")
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none" or meta.get("cards") != []
                or meta.get("completion_audit") != audit or not self.solve_calls):
            raise RuntimeError("Scavenge continuation evidence is stale or still pending")
        self.solve_calls[-1].setdefault("replay", []).append({
            "kind": "original_choice_continuation_completed", "plan": copy.deepcopy(plans[1]),
            "primary_plan": copy.deepcopy(plans[0]), "actual_root_audit": copy.deepcopy(root_audit),
            "manual_choice": copy.deepcopy(choices[0]), "actual_choice_audit": copy.deepcopy(audit),
            "selected_cards": copy.deepcopy(returned), "manual_selection_request_sent": True,
            "automatic_selection_request_sent": False})
        return state

    @staticmethod
    def hand_trick_manual_repeat(action):
        return (action.get("Kind") == "PlayCard" and action.get("CardId") == "HAND_TRICK"
                and type(action.get("ReplayCount")) is int and action["ReplayCount"] == 0
                and len(choice_plans(action)) == 2)

    @staticmethod
    def hand_trick_continuation_envelope(state, audit):
        """Authenticate the observed task envelope without projecting gameplay away."""
        c = audit.get("hand_trick_continuation", {})
        true_fields = {"original_task_pending_at_resume", "selector_task_identity_matches",
            "source_is_original_card_object", "original_branch_context_verified",
            "original_play_task_pending_at_resume", "original_play_task_completed_successfully",
            "original_task_completed_successfully", "selector_task_completed_successfully",
            "original_and_selector_return_same_card_objects"}
        integers = {"origin_action_id", "original_source_count_at_entry", "selector_invocation_at_resume",
            "original_play_action_id", "selector_invocation_at_end", "original_task_returned_count"}
        keys = true_fields | integers | {"schema_version", "origin_parent", "original_play_card_id",
            "original_play_target_combat_id", "original_play_state_at_end", "original_play_cancelled", "selector_pending_at_end"}
        if (not isinstance(c, dict) or set(c) != keys
                or c.get("schema_version") != "hand-trick-pending-task-continuation-v1"
                or any(c[k] is not True for k in true_fields) or any(type(c[k]) is not int for k in integers)
                or c["original_play_cancelled"] is not False or c["selector_pending_at_end"] is not False
                or c["original_play_target_combat_id"] is not None or c["original_play_state_at_end"] != "Finished"
                or c["original_play_card_id"] != "HAND_TRICK" or c["origin_action_id"] < 1
                or c["original_play_action_id"] < 1 or c["original_source_count_at_entry"] < 2
                or c["original_task_returned_count"] != 1 or c["selector_invocation_at_resume"] < 1
                or c["selector_invocation_at_end"] != c["selector_invocation_at_resume"]):
            raise RuntimeError("HandTrick continuation lacks its complete original task envelope")
        origin, parent = c["origin_parent"], audit.get("parent", {})
        if (not isinstance(origin, dict) or not isinstance(parent, dict)
                or origin.get("action") != "play_card" or origin.get("card_id") != "HAND_TRICK"
                or not isinstance(origin.get("card_key"), str) or not origin["card_key"].startswith("HAND_TRICK+")
                or type(origin.get("card_index")) is not int or origin["card_index"] < 0
                or parent.get("action") != "select_cards" or parent.get("card_id") is not None
                or parent.get("card_key") is not None or type(parent.get("card_index")) is not int or parent["card_index"] != -1
                or audit.get("schema_version") != "combat-choice-return-v2" or audit.get("closed") is not True
                or type(audit.get("action_id")) is not int or audit["action_id"] != c["origin_action_id"] + 1
                or any(origin.get(k) != parent.get(k) for k in ("player_id", "player_turn", "combat_id"))
                or not isinstance(parent.get("player_id"), str) or not parent["player_id"]
                or any(type(parent.get(k)) is not int or parent[k] < 1 for k in ("player_turn", "combat_id"))
                or any(p.get("combat_active_before") is not True or p.get("potion_id") is not None
                    or any(type(p.get(k)) is not int or p[k] != -1 for k in ("potion_index", "potion_slot")) for p in (origin,parent))
                or state.get("decision") != "combat_play" or not combat_in_progress(state)
                or parent["player_turn"] != state.get("player_turn")
                or parent["combat_id"] != state.get("player", {}).get("combat_metrics", {}).get("combat_id")):
            raise RuntimeError("HandTrick continuation has the wrong parent or live combat")
        return c

    def resolve_hand_trick_continuation(self, before, pending, action):
        """Execute the original manual choice, then verify its original repeat."""
        plans = choice_plans(action)
        root_request = copy.deepcopy(self.last_action_request)
        root_audit = pending.get("choice_audit", {})
        root_parent = root_audit.get("parent", {})
        if (not self.hand_trick_manual_repeat(action) or action.get("Choice") != plans[0]
                or action.get("NestedChoices") != [plans[1]] or action.get("TurnStartChoices")
                or type(action.get("NestedChoicesBeforePrimary")) is not int
                or action["NestedChoicesBeforePrimary"] != 0 or action.get("EndsPlayerTurn") is not False
                or pending.get("decision") != "card_select" or not combat_in_progress(pending)
                or root_audit.get("schema_version") != "combat-choice-return-v2" or root_audit.get("closed") is not True
                or type(root_audit.get("action_id")) is not int or root_audit["action_id"] < 1
                or root_parent.get("action") != "play_card" or root_parent.get("card_id") != "HAND_TRICK"
                or root_parent.get("card_key") != action.get("CardStateKey")
                or not isinstance(action.get("CardStateKey"), str) or not action["CardStateKey"]
                or type(root_parent.get("card_index")) is not int or root_parent["card_index"] < 0
                or root_request != {"cmd": "action", "action": "play_card", "args": {"card_index": root_parent["card_index"]}}
                or type(action.get("Turn")) is not int or action["Turn"] != before.get("player_turn")
                or root_parent.get("player_turn") != action["Turn"]
                or root_parent.get("combat_id") != self.setup_state_identity(before)["combat_id"]
                or root_parent.get("combat_active_before") is not True):
            raise RuntimeError("HandTrick continuation lacks its actual original play")
        for plan in plans:
            if (not isinstance(plan, dict) or any(plan.get(k) != v for k, v in {
                    "Effect": "ApplySly", "SourcePile": "Hand", "SourceId": "",
                    "ContextId": "", "Timing": "Action"}.items())
                    or not isinstance(plan.get("Cards"), list) or len(plan["Cards"]) != 1):
                raise RuntimeError("HandTrick continuation has an unsupported original choice plan")
        choices = []
        state = self.resolve(pending, [plans[0]], setup_choices=choices, allow_pending=True)
        if state.get("decision") == "card_select" and combat_in_progress(state):
            # More than one remaining option is still a real manual decision.
            return self.resolve(state, [plans[1]])
        audit = state.get("choice_audit", {})
        continuation = audit.get("hand_trick_continuation", {})
        parent = audit.get("parent", {})
        returns = audit.get("original_returns")
        original_returns = root_audit.get("original_returns")
        if (state.get("decision") != "combat_play" or not combat_in_progress(state)
                or self.setup_state_identity(before) != self.setup_state_identity(state)
                or state.get("player_turn") != action["Turn"]
                or audit.get("schema_version") != "combat-choice-return-v2" or audit.get("closed") is not True
                or audit.get("coverage") != root_audit.get("coverage")
                or type(audit.get("action_id")) is not int or audit["action_id"] != root_audit["action_id"] + 1
                or audit.get("events") != [] or parent.get("action") != "select_cards"
                or parent.get("card_id") is not None or parent.get("card_key") is not None
                or parent.get("card_index") != -1 or parent.get("combat_active_before") is not True
                or any(parent.get(k) != root_parent.get(k) for k in ("player_id", "combat_id", "player_turn"))
                or not isinstance(returns, list) or len(returns) != 1
                or not isinstance(original_returns, list) or len(original_returns) != 1
                or len(choices) != 1 or self.last_action_request != choices[0]["actual_request"]
                or self.last_action_request.get("action") != "select_cards"):
            raise RuntimeError("HandTrick automatic repeat changed its original selection owner")
        first = original_returns[0]
        counter = continuation.get("selector_invocation_at_resume")
        if (continuation.get("schema_version") != "hand-trick-pending-task-continuation-v1"
                or continuation.get("origin_action_id") != root_audit["action_id"]
                or continuation.get("origin_parent") != root_parent
                or any(continuation.get(k) is not True for k in (
                    "original_task_pending_at_resume", "selector_task_identity_matches", "source_is_original_card_object",
                    "original_task_completed_successfully", "selector_task_completed_successfully",
                    "original_and_selector_return_same_card_objects"))
                or type(continuation.get("original_source_count_at_entry")) is not int
                or continuation["original_source_count_at_entry"] < 2
                or type(continuation.get("original_task_returned_count")) is not int
                or continuation["original_task_returned_count"] != 1
                or type(counter) is not int or counter < 1
                or type(continuation.get("selector_invocation_at_end")) is not int
                or continuation["selector_invocation_at_end"] != counter
                or continuation.get("selector_pending_at_end") is not False
                or first.get("source_id") != "HAND_TRICK" or first.get("effect_callsite") != "HandTrick.OnPlay"
                or first.get("source_method") != "CardSelectCmd.FromHand"
                or first.get("source_pile") != "Hand" or first.get("effect") != "ApplySly"
                or first.get("filter_is_null") is not False
                or first.get("filter_reexecuted_by_observer") is not False
                or first.get("require_manual_confirmation") is not False
                or first.get("source_is_actual_parent_object") is not True
                or first.get("verified") is not False or first.get("original_task_completed_successfully") is not False
                or first.get("selector_pending_after") is not True
                or type(first.get("selector_invocations_before")) is not int
                or first["selector_invocations_before"] + 1 != counter
                or first.get("selector_invocations_after") != counter
                or first.get("raw_source_count_at_entry") != continuation["original_source_count_at_entry"]
                or len(choices[0]["actual_choice_metadata"]["cards"]) != 2):
            raise RuntimeError("HandTrick original pending task was not authenticated")
        self.hand_trick_continuation_envelope(state, audit)
        original_play = pending.get("play_action", {})
        if (original_play.get("schema_version") != "original-play-action-v1"
                or original_play.get("outcome") != "awaiting_selection"
                or original_play.get("card_id") != "HAND_TRICK"
                or original_play.get("state") != "Executing" or original_play.get("target_combat_id") is not None
                or original_play.get("cancellation_observed") is not False or original_play.get("on_play_entered") is not True
                or type(original_play.get("action_id")) is not int
                or original_play["action_id"] != continuation["original_play_action_id"]):
            raise RuntimeError("HandTrick continuation belongs to a different original PlayCardAction")
        event = returns[0]
        expected = {"schema_version": "original-choice-return-v1", "invocation_index": 0,
            "action_id": audit["action_id"], "source_method": "CardSelectCmd.FromHand",
            "effect_callsite": "HandTrick.OnPlay", "effect": "ApplySly", "source_id": "HAND_TRICK",
            "source_pile": "Hand", "source_is_actual_parent_object": True,
            "player_id": root_parent["player_id"], "player_turn": action["Turn"],
            "is_over_or_ending_at_entry": False, "combat_active_at_entry": True,
            "min_select": 1, "max_select": 1, "require_manual_confirmation": False,
            "filter_is_null": False, "filter_reexecuted_by_observer": False,
            "raw_source_count_at_entry": continuation["original_source_count_at_entry"], "raw_source_count_at_return": continuation["original_source_count_at_entry"],
            "selector_invocations_before": counter, "selector_invocations_after": counter,
            "selector_pending_before": False, "selector_pending_after": False,
            "verified": True, "original_task_completed_successfully": True,
            "combat_active_at_return": True, "is_over_or_ending_at_return": False,
            "original_returned_collection": "List<CardModel>", "returned_count": 1,
            "returned_objects_match_original_source": True,
            "candidate_basis": "original_implementation_and_completed_return_without_selector"}
        if any(type(event.get(k)) is not type(v) or event.get(k) != v for k, v in expected.items()):
            raise RuntimeError("HandTrick repeat lacks a complete original automatic return")
        def token(value):
            if (not isinstance(value, dict) or any(not isinstance(value.get(k), str) or not value[k]
                    for k in ("CardId", "StateKey")) or any(type(value.get(k)) is not int or value[k] < 0
                    for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
                raise RuntimeError("HandTrick repeat lacks a complete card fingerprint")
            return {k: value[k] for k in ("CardId", "StateKey", "UpgradeLevel", "SourceOccurrence", "OptionOccurrence")}
        returned = event.get("returned_cards")
        if (not isinstance(returned, list) or len(returned) != 1
                or token(returned[0]) != token(plans[1]["Cards"][0])
                or returned[0]["OptionOccurrence"] != 0):
            raise RuntimeError("HandTrick automatic card differs from its remaining solver plan")
        meta = self.checked(cmd="choice_meta")
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none" or meta.get("cards") != []
                or meta.get("completion_audit") != audit or not self.solve_calls):
            raise RuntimeError("HandTrick continuation evidence is stale or still pending")
        self.solve_calls[-1].setdefault("replay", []).append({
            "kind": "original_choice_continuation_completed", "plan": copy.deepcopy(plans[1]),
            "primary_plan": copy.deepcopy(plans[0]), "actual_root_audit": copy.deepcopy(root_audit),
            "manual_choice": copy.deepcopy(choices[0]), "actual_choice_audit": copy.deepcopy(audit),
            "selected_cards": copy.deepcopy(returned), "manual_selection_request_sent": True,
            "automatic_selection_request_sent": False})
        return state

    @staticmethod
    def secret_technique_manual_repeat(action):
        return (action.get("Kind") == "PlayCard" and action.get("CardId") == "SECRET_TECHNIQUE"
                and type(action.get("ReplayCount")) is int and action["ReplayCount"] == 0
                and len(choice_plans(action)) == 2)

    @staticmethod
    def secret_technique_continuation_envelope(state, audit):
        """Authenticate the observed task envelope without projecting gameplay away."""
        c = audit.get("secret_technique_continuation", {})
        true_fields = {"original_task_pending_at_resume", "selector_task_identity_matches",
            "source_is_original_card_object", "original_branch_context_verified",
            "original_play_task_pending_at_resume", "original_play_task_completed_successfully",
            "original_task_completed_successfully", "selector_task_completed_successfully",
            "original_and_selector_return_same_card_objects"}
        integers = {"origin_action_id", "original_source_count_at_entry", "selector_invocation_at_resume",
            "original_play_action_id", "selector_invocation_at_end", "original_task_returned_count"}
        keys = true_fields | integers | {"schema_version", "origin_parent", "original_play_card_id",
            "original_play_target_combat_id", "original_play_state_at_end", "original_play_cancelled", "selector_pending_at_end"}
        if (not isinstance(c, dict) or set(c) != keys
                or c.get("schema_version") != "secret-technique-pending-task-continuation-v1"
                or any(c[k] is not True for k in true_fields) or any(type(c[k]) is not int for k in integers)
                or c["original_play_cancelled"] is not False or c["selector_pending_at_end"] is not False
                or c["original_play_target_combat_id"] is not None or c["original_play_state_at_end"] != "Finished"
                or c["original_play_card_id"] != "SECRET_TECHNIQUE" or c["origin_action_id"] < 1
                or c["original_play_action_id"] < 1 or c["original_source_count_at_entry"] < 2
                or c["original_task_returned_count"] != 1 or c["selector_invocation_at_resume"] < 1
                or c["selector_invocation_at_end"] != c["selector_invocation_at_resume"]):
            raise RuntimeError("SecretTechnique continuation lacks its complete original task envelope")
        origin, parent = c["origin_parent"], audit.get("parent", {})
        if (not isinstance(origin, dict) or not isinstance(parent, dict)
                or origin.get("action") != "play_card" or origin.get("card_id") != "SECRET_TECHNIQUE"
                or not isinstance(origin.get("card_key"), str) or not origin["card_key"].startswith("SECRET_TECHNIQUE+")
                or type(origin.get("card_index")) is not int or origin["card_index"] < 0
                or parent.get("action") != "select_cards" or parent.get("card_id") is not None
                or parent.get("card_key") is not None or type(parent.get("card_index")) is not int or parent["card_index"] != -1
                or audit.get("schema_version") != "combat-choice-return-v2" or audit.get("closed") is not True
                or type(audit.get("action_id")) is not int or audit["action_id"] != c["origin_action_id"] + 1
                or any(origin.get(k) != parent.get(k) for k in ("player_id", "player_turn", "combat_id"))
                or not isinstance(parent.get("player_id"), str) or not parent["player_id"]
                or any(type(parent.get(k)) is not int or parent[k] < 1 for k in ("player_turn", "combat_id"))
                or any(p.get("combat_active_before") is not True or p.get("potion_id") is not None
                    or any(type(p.get(k)) is not int or p[k] != -1 for k in ("potion_index", "potion_slot")) for p in (origin,parent))
                or state.get("decision") != "combat_play" or not combat_in_progress(state)
                or parent["player_turn"] != state.get("player_turn")
                or parent["combat_id"] != state.get("player", {}).get("combat_metrics", {}).get("combat_id")):
            raise RuntimeError("SecretTechnique continuation has the wrong parent or live combat")
        return c

    def resolve_secret_technique_continuation(self, before, pending, action):
        """Execute the original manual choice, then verify its original repeat."""
        plans = choice_plans(action)
        root_request = copy.deepcopy(self.last_action_request)
        root_audit = pending.get("choice_audit", {})
        root_parent = root_audit.get("parent", {})
        if (not self.secret_technique_manual_repeat(action) or action.get("Choice") != plans[0]
                or action.get("NestedChoices") != [plans[1]] or action.get("TurnStartChoices")
                or type(action.get("NestedChoicesBeforePrimary")) is not int
                or action["NestedChoicesBeforePrimary"] != 0 or action.get("EndsPlayerTurn") is not False
                or pending.get("decision") != "card_select" or not combat_in_progress(pending)
                or root_audit.get("schema_version") != "combat-choice-return-v2" or root_audit.get("closed") is not True
                or type(root_audit.get("action_id")) is not int or root_audit["action_id"] < 1
                or root_parent.get("action") != "play_card" or root_parent.get("card_id") != "SECRET_TECHNIQUE"
                or root_parent.get("card_key") != action.get("CardStateKey")
                or not isinstance(action.get("CardStateKey"), str) or not action["CardStateKey"]
                or type(root_parent.get("card_index")) is not int or root_parent["card_index"] < 0
                or root_request != {"cmd": "action", "action": "play_card", "args": {"card_index": root_parent["card_index"]}}
                or type(action.get("Turn")) is not int or action["Turn"] != before.get("player_turn")
                or root_parent.get("player_turn") != action["Turn"]
                or root_parent.get("combat_id") != self.setup_state_identity(before)["combat_id"]
                or root_parent.get("combat_active_before") is not True):
            raise RuntimeError("SecretTechnique continuation lacks its actual original play")
        for plan in plans:
            if (not isinstance(plan, dict) or any(plan.get(k) != v for k, v in {
                    "Effect": "MoveToHand", "SourcePile": "Draw", "SourceId": "",
                    "ContextId": "", "Timing": "Action"}.items())
                    or not isinstance(plan.get("Cards"), list) or len(plan["Cards"]) != 1):
                raise RuntimeError("SecretTechnique continuation has an unsupported original choice plan")
        choices = []
        state = self.resolve(pending, [plans[0]], setup_choices=choices, allow_pending=True)
        if state.get("decision") == "card_select" and combat_in_progress(state):
            # More than one remaining option is still a real manual decision.
            return self.resolve(state, [plans[1]])
        audit = state.get("choice_audit", {})
        continuation = audit.get("secret_technique_continuation", {})
        parent = audit.get("parent", {})
        returns = audit.get("original_returns")
        original_returns = root_audit.get("original_returns")
        if (state.get("decision") != "combat_play" or not combat_in_progress(state)
                or self.setup_state_identity(before) != self.setup_state_identity(state)
                or state.get("player_turn") != action["Turn"]
                or audit.get("schema_version") != "combat-choice-return-v2" or audit.get("closed") is not True
                or audit.get("coverage") != root_audit.get("coverage")
                or type(audit.get("action_id")) is not int or audit["action_id"] != root_audit["action_id"] + 1
                or audit.get("events") != [] or parent.get("action") != "select_cards"
                or parent.get("card_id") is not None or parent.get("card_key") is not None
                or parent.get("card_index") != -1 or parent.get("combat_active_before") is not True
                or any(parent.get(k) != root_parent.get(k) for k in ("player_id", "combat_id", "player_turn"))
                or not isinstance(returns, list) or len(returns) != 1
                or not isinstance(original_returns, list) or len(original_returns) != 1
                or len(choices) != 1 or self.last_action_request != choices[0]["actual_request"]
                or self.last_action_request.get("action") != "select_cards"):
            raise RuntimeError("SecretTechnique automatic repeat changed its original selection owner")
        first = original_returns[0]
        counter = continuation.get("selector_invocation_at_resume")
        if (continuation.get("schema_version") != "secret-technique-pending-task-continuation-v1"
                or continuation.get("origin_action_id") != root_audit["action_id"]
                or continuation.get("origin_parent") != root_parent
                or any(continuation.get(k) is not True for k in (
                    "original_task_pending_at_resume", "selector_task_identity_matches", "source_is_original_card_object",
                    "original_task_completed_successfully", "selector_task_completed_successfully",
                    "original_and_selector_return_same_card_objects"))
                or type(continuation.get("original_source_count_at_entry")) is not int
                or continuation["original_source_count_at_entry"] < 2
                or type(continuation.get("original_task_returned_count")) is not int
                or continuation["original_task_returned_count"] != 1
                or type(counter) is not int or counter < 1
                or type(continuation.get("selector_invocation_at_end")) is not int
                or continuation["selector_invocation_at_end"] != counter
                or continuation.get("selector_pending_at_end") is not False
                or first.get("source_id") != "SECRET_TECHNIQUE" or first.get("effect_callsite") != "SecretTechnique.OnPlay"
                or first.get("source_method") != "CardSelectCmd.FromCombatPile"
                or first.get("source_pile") != "Draw" or first.get("effect") != "MoveToHand"
                or first.get("filter_is_null") is not False
                or first.get("filter_reexecuted_by_observer") is not False
                or first.get("require_manual_confirmation") is not False
                or first.get("source_is_actual_parent_object") is not True
                or first.get("verified") is not False or first.get("original_task_completed_successfully") is not False
                or first.get("selector_pending_after") is not True
                or type(first.get("selector_invocations_before")) is not int
                or first["selector_invocations_before"] + 1 != counter
                or first.get("selector_invocations_after") != counter
                or first.get("raw_source_count_at_entry") != continuation["original_source_count_at_entry"]
                or len(choices[0]["actual_choice_metadata"]["cards"]) != 2):
            raise RuntimeError("SecretTechnique original pending task was not authenticated")
        self.secret_technique_continuation_envelope(state, audit)
        original_play = pending.get("play_action", {})
        if (original_play.get("schema_version") != "original-play-action-v1"
                or original_play.get("outcome") != "awaiting_selection"
                or original_play.get("card_id") != "SECRET_TECHNIQUE"
                or original_play.get("state") != "Executing" or original_play.get("target_combat_id") is not None
                or original_play.get("cancellation_observed") is not False or original_play.get("on_play_entered") is not True
                or type(original_play.get("action_id")) is not int
                or original_play["action_id"] != continuation["original_play_action_id"]):
            raise RuntimeError("SecretTechnique continuation belongs to a different original PlayCardAction")
        event = returns[0]
        expected = {"schema_version": "original-choice-return-v1", "invocation_index": 0,
            "action_id": audit["action_id"], "source_method": "CardSelectCmd.FromCombatPile",
            "effect_callsite": "SecretTechnique.OnPlay", "effect": "MoveToHand", "source_id": "SECRET_TECHNIQUE",
            "source_pile": "Draw", "source_is_actual_parent_object": True,
            "player_id": root_parent["player_id"], "player_turn": action["Turn"],
            "is_over_or_ending_at_entry": False, "combat_active_at_entry": True,
            "min_select": 1, "max_select": 1, "require_manual_confirmation": False,
            "filter_is_null": False, "filter_reexecuted_by_observer": False,
            "raw_source_count_at_entry": continuation["original_source_count_at_entry"] - 1, "raw_source_count_at_return": continuation["original_source_count_at_entry"] - 1,
            "selector_invocations_before": counter, "selector_invocations_after": counter,
            "selector_pending_before": False, "selector_pending_after": False,
            "verified": True, "original_task_completed_successfully": True,
            "combat_active_at_return": True, "is_over_or_ending_at_return": False,
            "original_returned_collection": "List<CardModel>", "returned_count": 1,
            "returned_objects_match_original_source": True,
            "candidate_basis": "original_implementation_and_completed_return_without_selector"}
        if any(type(event.get(k)) is not type(v) or event.get(k) != v for k, v in expected.items()):
            raise RuntimeError("SecretTechnique repeat lacks a complete original automatic return")
        def token(value):
            if (not isinstance(value, dict) or any(not isinstance(value.get(k), str) or not value[k]
                    for k in ("CardId", "StateKey")) or any(type(value.get(k)) is not int or value[k] < 0
                    for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
                raise RuntimeError("SecretTechnique repeat lacks a complete card fingerprint")
            return {k: value[k] for k in ("CardId", "StateKey", "UpgradeLevel", "SourceOccurrence", "OptionOccurrence")}
        returned = event.get("returned_cards")
        if (not isinstance(returned, list) or len(returned) != 1
                or token(returned[0]) != token(plans[1]["Cards"][0])
                or returned[0]["OptionOccurrence"] != 0):
            raise RuntimeError("SecretTechnique automatic card differs from its remaining solver plan")
        meta = self.checked(cmd="choice_meta")
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none" or meta.get("cards") != []
                or meta.get("completion_audit") != audit or not self.solve_calls):
            raise RuntimeError("SecretTechnique continuation evidence is stale or still pending")
        self.solve_calls[-1].setdefault("replay", []).append({
            "kind": "original_choice_continuation_completed", "plan": copy.deepcopy(plans[1]),
            "primary_plan": copy.deepcopy(plans[0]), "actual_root_audit": copy.deepcopy(root_audit),
            "manual_choice": copy.deepcopy(choices[0]), "actual_choice_audit": copy.deepcopy(audit),
            "selected_cards": copy.deepcopy(returned), "manual_selection_request_sent": True,
            "automatic_selection_request_sent": False})
        return state

    @staticmethod
    def neows_manual_repeat(action):
        # ReplayCount fingerprints the card; Echo Form and other original hooks
        # can repeat OnPlay without changing that field. Dispatch from the actual
        # solver choice list, then authenticate original tasks in the resolver.
        return (action.get("Kind") == "PlayCard" and action.get("CardId") == "NEOWS_FURY"
                and type(action.get("ReplayCount")) is int and 0 <= action["ReplayCount"] <= 64
                and 2 <= len(choice_plans(action)) <= 65)

    @staticmethod
    def neows_ending_envelope(state, audit):
        """Authenticate only the observed ending envelope, not a solver choice."""
        c = audit.get("neows_continuation", {})
        true_fields = {"original_task_pending_at_resume", "selector_task_identity_matches",
            "source_is_original_card_object", "original_branch_context_verified",
            "original_play_task_pending_at_resume", "original_play_task_completed_successfully",
            "original_task_completed_successfully", "selector_task_completed_successfully",
            "original_and_selector_return_same_card_objects"}
        integers = {"origin_action_id", "original_source_count_at_entry", "selector_invocation_at_resume",
            "original_play_action_id", "original_play_target_combat_id", "selector_invocation_at_end",
            "original_task_returned_count"}
        keys = true_fields | integers | {"schema_version", "origin_parent", "original_play_card_id",
            "original_play_state_at_end", "original_play_cancelled", "selector_pending_at_end"}
        if (not isinstance(c, dict) or set(c) != keys
                or c.get("schema_version") != "neows-pending-task-continuation-v1"
                or any(c[k] is not True for k in true_fields)
                or any(type(c[k]) is not int for k in integers)
                or c["original_play_cancelled"] is not False or c["selector_pending_at_end"] is not False
                or c["original_play_state_at_end"] != "Finished" or c["original_play_card_id"] != "NEOWS_FURY"
                or c["origin_action_id"] < 1 or c["original_play_action_id"] < 1
                or c["original_source_count_at_entry"] < 1 or c["original_task_returned_count"] < 0
                or c["original_task_returned_count"] > c["original_source_count_at_entry"]
                or c["selector_invocation_at_resume"] < 1
                or c["selector_invocation_at_end"] != c["selector_invocation_at_resume"]
                or type(audit.get("action_id")) is not int or audit["action_id"] != c["origin_action_id"] + 1
                or audit.get("closed") is not True or audit.get("schema_version") != "combat-choice-return-v2"
                or audit.get("events") != [] or combat_in_progress(state)
                or state.get("decision") not in {"card_reward", "map_select", "game_over"}):
            raise RuntimeError("Neows continuation lacks completed original tasks and combat ending")
        origin, parent = c["origin_parent"], audit.get("parent", {})
        parent_keys = {"action", "card_index", "card_id", "card_key", "player_id", "combat_id", "player_turn",
            "combat_active_before", "potion_index", "potion_slot", "potion_id"}
        if (not isinstance(origin, dict) or set(origin) != parent_keys or set(parent) != parent_keys
                or origin["action"] != "play_card" or origin["card_id"] != "NEOWS_FURY"
                or not isinstance(origin["card_key"], str) or not origin["card_key"].startswith("NEOWS_FURY+")
                or type(origin["card_index"]) is not int or origin["card_index"] < 0
                or parent["action"] != "select_cards" or parent["card_id"] is not None
                or parent["card_key"] is not None or type(parent["card_index"]) is not int or parent["card_index"] != -1
                or any(origin[k] != parent[k] for k in ("player_id", "combat_id", "player_turn"))):
            raise RuntimeError("Neows continuation lost its original play and selection parent")
        for entry in (origin, parent):
            if (entry["combat_active_before"] is not True or not isinstance(entry["player_id"], str) or not entry["player_id"]
                    or any(type(entry[k]) is not int or entry[k] < 1 for k in ("combat_id", "player_turn"))
                    or any(type(entry[k]) is not int or entry[k] != -1 for k in ("potion_index", "potion_slot"))
                    or entry["potion_id"] is not None):
                raise RuntimeError("Neows continuation has malformed original parent identity")
        if parent["combat_id"] != CombatExecutor.setup_state_identity(state)["combat_id"]:
            raise RuntimeError("Neows ending crossed its original combat")
        returns = audit.get("original_returns")
        if not isinstance(returns, list) or len(returns) != 1:
            raise RuntimeError("Neows ending needs one actual original repeated return")
        event = returns[0]
        expected = {"schema_version": "original-choice-return-v1", "invocation_index": 0,
            "action_id": audit["action_id"], "source_method": "CardSelectCmd.FromCombatPile",
            "effect_callsite": "NeowsFury.OnPlay", "effect": "MoveToHand", "source_id": "NEOWS_FURY",
            "source_pile": "Discard", "source_is_actual_parent_object": True,
            "player_id": parent["player_id"], "player_turn": parent["player_turn"],
            "is_over_or_ending_at_entry": True, "combat_active_at_entry": True,
            "min_select": 0, "require_manual_confirmation": True, "filter_is_null": False,
            "filter_reexecuted_by_observer": False, "selector_invocations_before": c["selector_invocation_at_resume"],
            "selector_pending_before": False, "verified": True, "original_task_completed_successfully": True,
            "selector_invocations_after": c["selector_invocation_at_end"], "selector_pending_after": False,
            "combat_active_at_return": True, "is_over_or_ending_at_return": True, "returned_cards": [],
            "original_returned_collection": "CardModel[]", "returned_count": 0,
            "returned_objects_match_original_source": True,
            "candidate_basis": "original_implementation_and_completed_return_without_selector",
            "neows_original_play_action_matches": True, "neows_original_play_action_id": c["original_play_action_id"]}
        if (not isinstance(event, dict) or set(event) != set(expected) | {"max_select", "raw_source_count_at_entry", "raw_source_count_at_return"}
                or any(type(event.get(k)) is not type(v) or event[k] != v for k, v in expected.items())
                or type(event["max_select"]) is not int or event["max_select"] < 1
                or any(type(event[k]) is not int or event[k] < 0 for k in ("raw_source_count_at_entry", "raw_source_count_at_return"))
                or event["raw_source_count_at_entry"] != event["raw_source_count_at_return"]):
            raise RuntimeError("Neows repeat lacks its authenticated original combat-ending empty return")
        return c, event

    def resolve_neows_continuation(self, before, pending, action):
        plans = choice_plans(action)
        root_request = copy.deepcopy(self.last_action_request)
        root_audit, play = pending.get("choice_audit", {}), pending.get("play_action", {})
        parent = root_audit.get("parent", {})
        if (not self.neows_manual_repeat(action) or action.get("Choice") != plans[0]
                or action.get("NestedChoices") != plans[1:]
                or action.get("TurnStartChoices") or type(action.get("NestedChoicesBeforePrimary")) is not int
                or action["NestedChoicesBeforePrimary"] != 0 or action.get("EndsPlayerTurn") is not False
                or action.get("CardEnchantmentId") != "" or not isinstance(action.get("CardStateKey"), str)
                or f"|replay={action['ReplayCount']}|" not in action["CardStateKey"]
                or pending.get("decision") != "card_select" or not combat_in_progress(pending)
                or root_audit.get("schema_version") != "combat-choice-return-v2" or root_audit.get("closed") is not True
                or parent.get("action") != "play_card" or parent.get("card_id") != "NEOWS_FURY"
                or parent.get("card_key") != action["CardStateKey"]
                or type(parent.get("card_index")) is not int or parent["card_index"] < 0
                or root_request.get("cmd") != "action" or root_request.get("action") != "play_card"
                or root_request.get("args", {}).get("card_index") != parent["card_index"]
                or set(root_request.get("args", {})) != {"card_index", "target_index"}
                or type(action.get("Turn")) is not int or action["Turn"] != before.get("player_turn")
                or parent.get("player_turn") != action["Turn"]
                or parent.get("combat_id") != self.setup_state_identity(before)["combat_id"]
                or parent.get("combat_active_before") is not True
                or play.get("schema_version") != "original-play-action-v1" or play.get("outcome") != "awaiting_selection"
                or play.get("card_id") != "NEOWS_FURY" or play.get("target_combat_id") != action.get("TargetCombatId")
                or play.get("on_play_entered") is not True or play.get("cancellation_observed") is not False):
            raise RuntimeError("Neows continuation lacks its actual original repeated play")
        variables = re.search(r"\|vars=([^|]*)\|", action["CardStateKey"])
        limits = re.findall(r"(?:^|;)Cards=([1-9][0-9]*)(?=;|$)", variables[1]) if variables else []
        if len(limits) != 1:
            raise RuntimeError("Neows original card selection limit is missing")
        limit = int(limits[0])
        for plan in plans:
            if (not isinstance(plan, dict) or any(plan.get(k) != v for k, v in {
                    "Effect": "MoveToHand", "SourcePile": "Discard", "SourceId": "", "ContextId": "", "Timing": "Action"}.items())
                    or not isinstance(plan.get("Cards"), list) or len(plan["Cards"]) > limit):
                raise RuntimeError("Neows continuation has unsupported original choices")
            for token in plan["Cards"]:
                if (not isinstance(token, dict) or any(not isinstance(token.get(k), str) or not token[k] for k in ("CardId", "StateKey"))
                        or any(type(token.get(k)) is not int or token[k] < 0 for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
                    raise RuntimeError("Neows choice lacks the complete original token")
        choices = []
        state = self.resolve(pending, [plans[0]], setup_choices=choices, allow_pending=True)
        if state.get("decision") == "card_select" and combat_in_progress(state):
            return self.resolve(state, plans[1:])
        audit = state.get("choice_audit", {})
        if state.get("decision") == "combat_play" and audit.get("neows_full_hand_diagnostic") is not None:
            from neows_full_hand_completion import complete
            return complete(self, before, state, action, root_audit, play, choices)
        c, event = self.neows_ending_envelope(state, audit)
        original = root_audit.get("original_returns")
        if (self.setup_state_identity(before) != self.setup_state_identity(state)
                or c["origin_action_id"] != root_audit.get("action_id") or c["origin_parent"] != parent
                or c["original_play_action_id"] != play.get("action_id")
                or c["original_play_target_combat_id"] != action.get("TargetCombatId")
                or audit.get("coverage") != root_audit.get("coverage")
                or not isinstance(original, list) or len(original) != 1 or len(choices) != 1
                or self.last_action_request != choices[0]["actual_request"]
                or self.last_action_request.get("action") != "select_cards"
                or c["original_task_returned_count"] != len(plans[0]["Cards"])
                or c["original_source_count_at_entry"] != len(choices[0]["actual_choice_metadata"]["cards"])
                or event["max_select"] > limit):
            raise RuntimeError("Neows ended action differs from its original solver or selection")
        first = original[0]
        expected = {"source_id": "NEOWS_FURY", "effect_callsite": "NeowsFury.OnPlay", "effect": "MoveToHand",
            "source_method": "CardSelectCmd.FromCombatPile", "source_pile": "Discard", "source_is_actual_parent_object": True,
            "verified": False, "original_task_completed_successfully": False, "filter_is_null": False,
            "filter_reexecuted_by_observer": False, "require_manual_confirmation": True,
            "min_select": 0, "selector_pending_before": False, "selector_pending_after": True,
            "selector_invocations_before": c["selector_invocation_at_resume"] - 1,
            "selector_invocations_after": c["selector_invocation_at_resume"],
            "raw_source_count_at_entry": c["original_source_count_at_entry"],
            "action_id": root_audit["action_id"], "invocation_index": 0, "player_id": parent["player_id"],
            "player_turn": action["Turn"], "is_over_or_ending_at_entry": False, "is_over_or_ending_at_return": False}
        if (any(type(first.get(k)) is not type(v) or first.get(k) != v for k, v in expected.items())
                or type(first.get("max_select")) is not int or not 1 <= first["max_select"] <= limit):
            raise RuntimeError("Neows original pending return was not authenticated")
        meta = self.checked(cmd="choice_meta")
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none" or meta.get("cards") != []
                or meta.get("completion_audit") != audit or not self.solve_calls):
            raise RuntimeError("Neows ending proof is stale or still has a selection")
        self.solve_calls[-1].setdefault("replay", []).append({
            "kind": "original_choice_continuation_ended_combat", "plan": copy.deepcopy(plans[1]),
            "remaining_plans_not_executed": copy.deepcopy(plans[1:]), "primary_plan": copy.deepcopy(plans[0]),
            "actual_root_audit": copy.deepcopy(root_audit), "actual_root_play_action": copy.deepcopy(play),
            "manual_choice": copy.deepcopy(choices[0]), "actual_choice_audit": copy.deepcopy(audit),
            "selected_cards_for_remaining_plans": [], "remaining_selection_request_sent": False,
            "remaining_battle_plan_stopped": True, "reason": "original_repeated_action_ended_combat"})
        return state

    @staticmethod
    def setup_state_identity(state):
        context = state.get("context", {})
        metrics = state.get("player", {}).get("combat_metrics", {})
        return {"combat_id": metrics.get("combat_id"), "act": context.get("act"),
            "floor": context.get("floor"), "encounter_id": context.get("encounter_id"),
            "player_name": state.get("player", {}).get("name")}

    @staticmethod
    def verify_setup_origin(origin, *, phase):
        if (not isinstance(origin, dict) or origin.get("schema_version") != "turn-setup-origin-v1"
                or origin.get("capture_method") != "CombatManager.SetupPlayerTurn.prefix"
                or type(origin.get("capture_id")) is not int or origin["capture_id"] < 1
                or type(origin.get("captured_turn")) is not int or origin["captured_turn"] < 1
                or origin.get("captured_phase") != "Start" or origin.get("current_side") != "Player"
                or origin.get("live_same_combat") is not True or origin.get("live_phase") != phase
                or type(origin.get("live_player_turn")) is not int
                or origin["live_player_turn"] != origin["captured_turn"]
                or not isinstance(origin.get("player_id"), str) or not origin["player_id"]):
            raise RuntimeError("Unverified original turn-setup capture or live phase")

    @classmethod
    def verify_toasty_setup_metadata(cls, state, plan, meta, origin):
        cls.verify_setup_origin(origin, phase="Start")
        cls.verify_setup_origin(meta.get("setup_origin"), phase="Start")
        audit = meta.get("setup_choice")
        if (meta["setup_origin"] != origin or not isinstance(audit, dict)
                or audit.get("schema_version") != "toasty-mittens-setup-choice-v1"
                or audit.get("source_method") != "CardSelectCmd.FromHand"
                or audit.get("source_id") != "TOASTY_MITTENS"
                or audit.get("source_is_current_live_relic") is not True
                or audit.get("original_task_pending") is not True or audit.get("filter_is_null") is not True
                or type(audit.get("capture_id")) is not int or audit["capture_id"] != origin["capture_id"]
                or audit.get("player_id") != origin["player_id"]
                or type(audit.get("player_turn")) is not int or audit["player_turn"] != origin["captured_turn"]
                or any(plan.get(p) != audit.get(a) for p, a in (("Effect", "effect"), ("SourcePile", "source_pile"),
                    ("Timing", "timing"), ("SourceId", "source_id"), ("ContextId", "context_id")))
                or any(type(value) is not int or value != 1 for value in
                       (state.get("min_select"), state.get("max_select"), audit.get("min_select"), audit.get("max_select")))):
            raise RuntimeError("Toasty setup choice is not bound to its original live FromHand source")

    def resolve_setup_for_continuation(self, before, result):
        """Keep one authenticated Toasty setup's original plan; unknown sources replan.

        The returned proof remains pending until the first original action really
        executes. Existing hand/potion/target checks still govern every action.
        """
        plans = result.get("turn_setup_choices") or []
        from gambling_setup import known as gambling_known, resolve as resolve_gambling_setup
        if gambling_known(plans):
            return resolve_gambling_setup(self, before, result)
        known = (len(plans) == 1 and isinstance(plans[0], dict)
            and all(plans[0].get(k) == v for k, v in {"Effect": "Exhaust", "SourcePile": "Hand",
                "Timing": "PlayerTurnStart", "SourceId": "TOASTY_MITTENS", "ContextId": ""}.items())
            and isinstance(plans[0].get("Cards"), list) and len(plans[0]["Cards"]) in (0, 1))
        if not known:
            if self.solve_calls:
                self.solve_calls[-1]["setup_plan_reuse"] = {"schema_version": "setup-plan-reuse-v1", "reused": False, "reason": "unsupported_setup_source_or_shape"}
            return self.resolve(before, plans), None
        origin = result.get("setup_origin")
        self.verify_setup_origin(origin, phase="Start")
        actions = result.get("actions")
        identity = self.setup_state_identity(before)
        if (before.get("decision") != "card_select" or not combat_in_progress(before)
                or type(identity["combat_id"]) is not int or identity["combat_id"] < 1
                or any(identity[k] is None for k in ("act", "floor", "encounter_id", "player_name"))
                or not isinstance(actions, list) or not actions
                or type(result.get("summary", {}).get("StartTurnNumber")) is not int
                or result["summary"]["StartTurnNumber"] != origin["captured_turn"]
                or type(actions[0].get("Turn")) is not int or actions[0]["Turn"] != origin["captured_turn"]
                or not self.solve_calls or self.solve_calls[-1]["request"].get("include_turn_setup") is not True
                or self.solve_calls[-1]["response"] != result):
            raise RuntimeError("Setup continuation has no matching current solve, combat, or original action plan")
        choices = []
        after = self.resolve(before, plans, setup_capture=origin, setup_choices=choices)
        ending = not combat_in_progress(after)
        if (self.setup_state_identity(after) != identity or not ending and (
                after.get("decision") != "combat_play" or type(after.get("player_turn")) is not int
                or after["player_turn"] != origin["captured_turn"])):
            raise RuntimeError("Original setup effects did not finish in the same active player turn")
        audit = after.get("choice_audit", {})
        parent = audit.get("parent", {})
        if (audit.get("closed") is not True or parent.get("action") != "select_cards"
                or parent.get("player_id") != origin["player_id"] or parent.get("combat_id") != identity["combat_id"]
                or parent.get("player_turn") != origin["captured_turn"] or parent.get("combat_active_before") is not True):
            raise RuntimeError("Completed setup is not bound to the actual selection action")
        meta = self.checked(cmd="choice_meta")
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none" or meta.get("cards") != []
                or meta.get("setup_choice") is not None or meta.get("completion_audit") != audit):
            raise RuntimeError("Original setup task is still pending or its completion audit changed")
        phase = "None" if ending else "Play"
        self.verify_setup_origin(meta.get("setup_origin"), phase=phase)
        if meta["setup_origin"] != {**origin, "live_phase": phase}:
            raise RuntimeError("Setup capture changed before the original plan could continue")
        if ending:
            require_macro_boundary(after)
            completion = meta.get("setup_completion")
            token = plans[0]["Cards"][0]
            fields = ("CardId", "UpgradeLevel", "StateKey", "SourceOccurrence", "OptionOccurrence")
            if (len(choices) != 1 or not isinstance(completion, dict)
                    or any(k not in token for k in fields)
                    or type(token.get("SourceOccurrence")) is not int or token["SourceOccurrence"] < 0
                    or token["SourceOccurrence"] != token["OptionOccurrence"]
                    or type(audit.get("action_id")) is not int or audit["action_id"] < 1
                    or type(completion.get("selector_invocations_before")) is not int
                    or completion["selector_invocations_before"] < 1):
                raise RuntimeError("Ending setup lacks original task and selected object evidence")
            cards = choices[0]["actual_choice_metadata"]["cards"]
            indices = self.card_choice_indices(plans[0], cards)
            expected = {
                "schema_version": "toasty-setup-ending-v1", "capture_id": origin["capture_id"],
                "action_id": audit["action_id"], "combat_id": identity["combat_id"],
                "player_id": origin["player_id"], "player_turn": origin["captured_turn"],
                "source_id": "TOASTY_MITTENS", "source_method": "CardSelectCmd.FromHand",
                "source_is_current_live_relic": True, "original_task_pending_at_resume": True,
                "original_task_completed_successfully": True, "selector_task_completed_successfully": True,
                "selector_task_identity_matches": True, "returned_card_matches_selected_original_object": True,
                "selector_invocations_before": completion["selector_invocations_before"],
                "selector_invocations_after": completion["selector_invocations_before"],
                "selector_pending_after": False, "raw_hand_count_at_resume": len(cards), "returned_count": 1,
                "selected_cards": [{k: token[k] for k in fields}], "combat_ending": True,
                "combat_active": False, "live_phase": "None"}
            if (len(cards) < 2 or choices[0]["actual_request"] != {
                    "cmd": "action", "action": "select_cards", "args": {"indices": str(indices[0])}}
                    or json.dumps(completion, sort_keys=True) != json.dumps(expected, sort_keys=True)):
                raise RuntimeError("Ending setup completion differs from its original capture, task or exact selected card")
            return after, {"kind": "turn_setup_ended_combat", "setup_origin": copy.deepcopy(origin),
                "turn_setup_choices": copy.deepcopy(plans), "actual_choices": choices,
                "post_setup_metadata": copy.deepcopy(meta), "combat_identity": identity,
                "selected_cards": copy.deepcopy(expected["selected_cards"]),
                "remaining_battle_plan_stopped": True, "first_action_submitted": False,
                "identity_basis": "original_Toasty_FromHand_and_selector_completed_with_same_selected_object"}
        return after, {"kind": "turn_setup_plan_continued", "setup_origin": copy.deepcopy(origin),
            "turn_setup_choices": copy.deepcopy(plans), "actual_choices": choices,
            "post_setup_metadata": copy.deepcopy(meta), "combat_identity": identity,
            "identity_basis": "original_live_Toasty_FromHand_capture_and_exact_tokens"}

    @staticmethod
    def card_choice_indices(plan, cards):
        selected = []
        for token in plan["Cards"]:
            if (not isinstance(token, dict) or not isinstance(token.get("CardId"), str)
                    or type(token.get("UpgradeLevel")) is not int or token["UpgradeLevel"] < 0
                    or type(token.get("OptionOccurrence")) is not int or token["OptionOccurrence"] < 0
                    or not isinstance(token.get("StateKey"), str) or not token["StateKey"]):
                raise RuntimeError("Incomplete solver choice token identity")
            # Original DLL ToTokens counts OptionOccurrence by CardId +
            # integer UpgradeLevel (HasStableTokenIdentity), NOT StateKey.
            # Select that physical occurrence first, then verify its state.
            matches = [c for c in cards if c["id"] == token["CardId"]
                       and c["upgrade_level"] == token["UpgradeLevel"]]
            occurrence = token["OptionOccurrence"]
            if occurrence >= len(matches) or matches[occurrence]["key"] != token["StateKey"]:
                raise RuntimeError("Choice token mismatch: " + json.dumps({"plan": plan, "cards": cards}))
            selected.append(matches[occurrence]["index"])
        return selected

    @staticmethod
    def seeker_choice_indices(state, plan, meta):
        from seeker_continuation import source_parent
        data = meta.get("seeker_choice")
        audit = state.get("choice_audit", {})
        parent = source_parent(audit)
        if (not isinstance(data, dict) or audit.get("closed") is not True
                or meta.get("completion_audit") != audit or state.get("decision") != "card_select"
                or not combat_in_progress(state) or parent.get("action") != "play_card"
                or parent.get("card_id") != "SEEKER_STRIKE" or parent.get("combat_active_before") is not True
                or parent.get("combat_id") != CombatExecutor.setup_state_identity(state)["combat_id"]
                or "player_turn" in state and parent.get("player_turn") != state["player_turn"]
                or any(type(v) is not int or v < 1 for v in (audit.get("action_id"), parent.get("combat_id"), parent.get("player_turn")))
                or not isinstance(parent.get("player_id"), str) or not parent["player_id"]
                or not isinstance(parent.get("card_key"), str) or not parent["card_key"]
                or any(plan.get(k) != v for k, v in {"Effect": "MoveToHand", "SourcePile": "Draw", "SourceId": "", "Timing": "Action"}.items())
                or not isinstance(plan.get("Cards"), list) or len(plan["Cards"]) != 1):
            raise RuntimeError("Seeker choice has no matching original pending source action")
        numeric = ("selector_invocations_before", "selector_invocations_after", "rng_counter", "selection_count")
        if any(type(data.get(k)) is not int or data[k] < (1 if k == "selection_count" else 0) for k in numeric):
            raise RuntimeError("Seeker original counters are missing or invalid")
        raw, sample, cards = data.get("source_cards"), data.get("sample_cards"), meta.get("cards")
        variables = re.findall(r"\|vars=([^|]*)\|", parent["card_key"])
        counts = re.findall(r"(?:^|;)Cards=([1-9][0-9]*)(?=;|$)", variables[0]) if len(variables) == 1 else []
        if (len(counts) != 1 or int(counts[0]) != data["selection_count"]
                or not isinstance(raw, list) or len(raw) < 2 or not isinstance(sample, list)
                or len(sample) != min(data["selection_count"], len(raw)) or not isinstance(cards, list)
                or len(sample) != len(cards) or len(sample) < 2
                or any(type(v) is not int or v != 1 for v in (state.get("min_select"), state.get("max_select")))):
            raise RuntimeError("Seeker original sample count differs from its source and actual choice")
        base_fields = {"CardId", "UpgradeLevel", "StateKey", "SourceOccurrence", "source_index"}
        for index, card in enumerate(raw):
            if (not isinstance(card, dict) or set(card) != base_fields or card.get("source_index") != index
                    or type(card.get("source_index")) is not int
                    or not isinstance(card.get("CardId"), str) or not card["CardId"]
                    or not isinstance(card.get("StateKey"), str) or not card["StateKey"]
                    or type(card.get("UpgradeLevel")) is not int or card["UpgradeLevel"] < 0
                    or type(card.get("SourceOccurrence")) is not int
                    or card["SourceOccurrence"] != sum(c["CardId"] == card["CardId"] and c["UpgradeLevel"] == card["UpgradeLevel"] for c in raw[:index])):
                raise RuntimeError("Seeker original source identity or occurrence is invalid")
        seen_source, seen_ui = set(), set()
        for index, card in enumerate(sample):
            if (not isinstance(card, dict) or set(card) != base_fields | {"OptionOccurrence", "option_index", "ui_index"}
                    or any(type(card.get(k)) is not int or card[k] < 0 for k in ("source_index", "option_index", "ui_index", "OptionOccurrence", "SourceOccurrence", "UpgradeLevel"))
                    or card["source_index"] >= len(raw) or card["source_index"] in seen_source
                    or card["ui_index"] >= len(cards) or card["ui_index"] in seen_ui or card["option_index"] != index
                    or {k: card[k] for k in base_fields} != raw[card["source_index"]]
                    or card["OptionOccurrence"] != sum(c["CardId"] == card["CardId"] and c["UpgradeLevel"] == card["UpgradeLevel"] for c in sample[:index])):
                raise RuntimeError("Seeker sampled object mapping is incomplete or duplicated")
            ui = cards[card["ui_index"]]
            if (type(ui.get("index")) is not int or type(ui.get("upgrade_level")) is not int
                    or ui.get("index") != card["ui_index"] or ui.get("id") != card["CardId"]
                    or ui.get("upgrade_level") != card["UpgradeLevel"] or ui.get("key") != card["StateKey"]):
                raise RuntimeError("Seeker original sampled object differs from the live option")
            seen_source.add(card["source_index"]); seen_ui.add(card["ui_index"])
        context = f"seeker:{data['rng_counter']}:" + ','.join(f"{c['CardId']}+{c['UpgradeLevel']}" for c in sample)
        expected = {
            "schema_version": "seeker-option-order-v1", "action_id": audit["action_id"],
            "source_method": "SeekerStrike.OnPlay.Enumerable.Take", "selection_method": "CardSelectCmd.FromCombatPile",
            "source_id": "SEEKER_STRIKE", "source_card_key": parent["card_key"], "source_pile": "Draw",
            "player_id": parent["player_id"], "combat_id": parent["combat_id"], "player_turn": parent["player_turn"],
            "source_is_original_card_object": True, "original_take_result_is_filter_capture": True,
            "original_task_pending": True, "selector_task_pending": True, "selector_task_identity_matches": True,
            "selector_invocations_before": data["selector_invocations_before"],
            "selector_invocations_after": data["selector_invocations_before"] + 1,
            "rng_counter": data["rng_counter"], "selection_count": int(counts[0]),
            "filter_invoked_by_observer": False, "original_sample_order_preserved": True,
            "ui_options_same_original_objects": True, "min_select": 1, "max_select": 1,
            "context_id": context, "source_cards": raw, "sample_cards": sample}
        if (plan.get("ContextId") != context
                or json.dumps(data, sort_keys=True) != json.dumps(expected, sort_keys=True)):
            raise RuntimeError("Seeker context or original pending provenance differs from its solver plan")
        token = plan["Cards"][0]
        fields = ("CardId", "UpgradeLevel", "StateKey", "SourceOccurrence", "OptionOccurrence")
        if (not isinstance(token, dict) or any(k not in token for k in fields)
                or any(type(token[k]) is not int or token[k] < 0 for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
            raise RuntimeError("Seeker solver token lacks both original occurrence identities")
        matches = [c for c in sample if all(c[k] == token[k] for k in fields)]
        if len(matches) != 1:
            raise RuntimeError("Seeker solver token does not identify one original sampled card object")
        return [matches[0]["ui_index"]]

    @staticmethod
    def seeker_choice_proof(plan, meta, after, indices, request):
        origin = meta["seeker_choice"]
        audit = after.get("choice_audit", {})
        parent = audit.get("parent", {})
        if (request != {"cmd": "action", "action": "select_cards", "args": {"indices": str(indices[0])}}
                or audit.get("closed") is not True or type(audit.get("action_id")) is not int
                or audit["action_id"] != origin["action_id"] + 1 or parent.get("action") != "select_cards"
                or any(type(parent.get(k)) is not type(origin[k]) or parent.get(k) != origin[k] for k in ("player_id", "combat_id", "player_turn"))
                or parent.get("combat_active_before") is not True):
            raise RuntimeError("Seeker mapped choice did not complete its actual selection action")
        return {"kind": "seeker_option_choice", "plan": copy.deepcopy(plan),
            "actual_choice_metadata": copy.deepcopy(meta), "selected_indices": list(indices),
            "actual_selection_request": copy.deepcopy(request), "actual_selection_audit": copy.deepcopy(audit),
            "identity_basis": "original_Seeker_sample_and_source_occurrences_mapped_by_same_object_to_sorted_UI"}

    def resolve_seeker_continuation(self, before, pending, action):
        from seeker_continuation import resolve
        return resolve(self, before, pending, action)

    @staticmethod
    def knowledge_choice_indices(state, plan, meta):
        audit, cards = meta.get("knowledge_choice"), meta["cards"]
        if (state["decision"] != "card_select" or not isinstance(audit, dict)
                or audit.get("schema_version") != "knowledge-demon-choice-v1"
                or audit.get("source_method") != "KnowledgeDemon.ChooseCurse"
                or audit.get("original_task_pending") is not True
                or audit.get("source_is_current_live_enemy") is not True
                or type(audit.get("source_combat_id")) is not int or audit["source_combat_id"] < 0
                or type(audit.get("curse_counter")) is not int or not 0 <= audit["curse_counter"] < 3
                or audit.get("source_id") != f"KNOWLEDGE_DEMON:{audit['source_combat_id']}:{audit['curse_counter']}"
                or not isinstance(audit.get("target_player_id"), str) or not audit["target_player_id"]
                or audit.get("effect") != "ApplyKnowledgeCurse" or audit.get("source_pile") != "None"
                or audit.get("timing") != "EnemyTurn" or audit.get("context_id") != ""
                or any(plan.get(field) != audit[key] for field, key in (
                    ("Effect", "effect"), ("SourcePile", "source_pile"), ("Timing", "timing"),
                    ("SourceId", "source_id"), ("ContextId", "context_id")))
                or len(cards) != 2 or len({c["id"] for c in cards}) != 2
                or any(c["upgrade_level"] != 0 for c in cards)
                or audit.get("engine_option_ids") != [c["id"] for c in cards]
                or audit.get("option_keys") != [c["key"] for c in cards]
                or len(plan["Cards"]) != 1):
            raise RuntimeError("Knowledge Demon choice lacks matching original effect identity")
        token = plan["Cards"][0]
        if (not isinstance(token, dict) or token.get("StateKey") != ""
                or any(type(token.get(k)) is not int or token[k] != 0
                       for k in ("UpgradeLevel", "OptionOccurrence", "SourceOccurrence"))):
            raise RuntimeError("Invalid Knowledge Demon effect token contract")
        matches = [c for c in cards if c["id"] == token.get("CardId")]
        if len(matches) != 1:
            raise RuntimeError("Knowledge Demon planned effect is not a unique current option")
        return [matches[0]["index"]]

    def resolve_ending_choice(self, before, state, action):
        return self._resolve_original_choice_return(before, state, action, empty_source=False)

    def resolve_stampede_automatic_return(self, before, state, action):
        """Bind turn-end choices to the original power hook and its completed child tasks."""
        audit = state.get("choice_audit", {})
        returns = audit.get("original_returns") if isinstance(audit, dict) else None
        if not returns:
            return False
        plans = choice_plans(action)
        if (action.get("Kind") != "EndTurn" or not plans or action.get("Choice") is not None
                or action.get("NestedChoices") or action.get("TurnStartChoices") != plans
                or type(action.get("ReplayCount", 0)) is not int or action.get("ReplayCount", 0) != 0
                or type(action.get("NestedChoicesBeforePrimary", 0)) is not int
                or action.get("NestedChoicesBeforePrimary", 0) != 0
                or not isinstance(returns, list) or len(returns) != len(plans)):
            raise RuntimeError("Stampede return does not cover the original EndTurn choice sequence")
        turn = action.get("Turn")
        combat_id = before.get("player", {}).get("combat_metrics", {}).get("combat_id")
        parent = audit.get("parent", {})
        action_id = audit.get("action_id")
        powers = [p for p in before.get("player_powers", []) if p.get("name") == "Stampede"]
        if (type(turn) is not int or turn < 1 or before.get("player_turn") != turn
                or state.get("player_turn") != turn + 1
                or any(s.get("decision") != "combat_play" or not combat_in_progress(s) for s in (before, state))
                or type(combat_id) is not int or combat_id < 1
                or state.get("player", {}).get("combat_metrics", {}).get("combat_id") != combat_id
                or self.setup_state_identity(before) != self.setup_state_identity(state)
                or audit.get("schema_version") != "combat-choice-return-v2" or audit.get("closed") is not True
                or audit.get("coverage") != "FromCombatPile.IsEnding_or_NeowsFury.empty_source.synchronous_empty_return_only"
                or audit.get("events") != [] or type(action_id) is not int or action_id < 1
                or not isinstance(parent, dict) or parent.get("action") != "end_turn"
                or parent.get("card_id") is not None or parent.get("card_key") is not None
                or parent.get("potion_id") is not None
                or any(type(parent.get(k)) is not int or parent[k] != -1 for k in ("card_index", "potion_index", "potion_slot"))
                or type(parent.get("combat_id")) is not int or parent["combat_id"] != combat_id
                or type(parent.get("player_turn")) is not int or parent["player_turn"] != turn
                or parent.get("combat_active_before") is not True
                or not isinstance(parent.get("player_id"), str) or not parent["player_id"]
                or self.last_action_request != {"cmd": "action", "action": "end_turn"}
                or len(powers) != 1 or type(powers[0].get("amount")) is not int or powers[0]["amount"] < 1):
            raise RuntimeError("Stampede return lacks its actual parent power, combat and next-turn identity")
        def token(t):
            if (not isinstance(t, dict) or any(not isinstance(t.get(k), str) or not t[k] for k in ("CardId", "StateKey"))
                    or any(type(t.get(k)) is not int or t[k] < 0 for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
                raise RuntimeError("Stampede return lacks complete original token identity")
            return {k: t[k] for k in ("CardId", "UpgradeLevel", "StateKey", "SourceOccurrence", "OptionOccurrence")}
        previous_child, selector_count, total_children = -1, None, None
        for index, (plan, event) in enumerate(zip(plans, returns)):
            if (not isinstance(plan, dict) or tuple(plan.get(k) for k in ("Effect", "SourcePile", "SourceId", "ContextId", "Timing"))
                    != ("Discard", "Hand", "STAMPEDE_POWER", "", "PlayerTurnEnd")
                    or not isinstance(plan.get("Cards"), list) or len(plan["Cards"]) not in (0, 1)
                    or not isinstance(event, dict)):
                raise RuntimeError("Unsupported Stampede original child selection")
            planned = [token(t) for t in plan["Cards"]]
            true_fields = ("verified", "original_task_completed_successfully", "returned_objects_match_original_source",
                "filter_is_null", "combat_active_at_entry", "combat_active_at_return",
                "nested_power_hook_source_is_original_object", "nested_auto_play_source_is_original_object",
                "nested_auto_play_task_completed_successfully", "nested_power_hook_task_completed_successfully")
            false_fields = ("source_is_actual_parent_object", "require_manual_confirmation", "filter_reexecuted_by_observer",
                "selector_pending_before", "selector_pending_after", "is_over_or_ending_at_entry", "is_over_or_ending_at_return")
            expected = {"schema_version": "original-choice-return-v1", "effect_callsite": "DaggerThrow.OnPlay",
                "source_method": "CardSelectCmd.FromHand", "effect": "Discard", "source_pile": "Hand", "source_id": "DAGGER_THROW",
                "player_id": parent["player_id"], "nested_parent_power_id": "STAMPEDE_POWER",
                "nested_power_hook_callsite": "StampedePower.AfterAutoPostPlayPhaseEntered",
                "nested_auto_play_callsite": "StampedePower.AfterAutoPostPlayPhaseEntered.CardCmd.AutoPlay",
                "nested_relation": "STAMPEDE_POWER_original_AutoPlay_DAGGER_THROW_original_OnPlay_hand_return",
                "player_phase_at_entry": "AutoPostPlay", "player_phase_after_action": "Play",
                "original_returned_collection": "List<CardModel>",
                "candidate_basis": "original_implementation_and_completed_return_without_selector"}
            integers = {"invocation_index": index, "action_id": action_id, "player_turn": turn,
                "player_turn_after_action": turn + 1, "min_select": 1, "max_select": 1,
                "nested_power_hook_total_calls": 1, "nested_parent_power_amount": powers[0]["amount"],
                "returned_count": len(planned), "raw_source_count_at_entry": len(planned), "raw_source_count_at_return": len(planned)}
            if (any(event.get(k) is not True for k in true_fields) or any(event.get(k) is not False for k in false_fields)
                    or any(event.get(k) != v for k, v in expected.items())
                    or any(type(event.get(k)) is not int or event[k] != v for k, v in integers.items())
                    or any(type(event.get(k)) is not int or event[k] < 0 for k in
                        ("selector_invocations_before", "selector_invocations_after", "nested_auto_play_index", "nested_auto_play_total_calls"))
                    or event["selector_invocations_before"] != event["selector_invocations_after"]
                    or selector_count is not None and event["selector_invocations_before"] != selector_count
                    or not previous_child < event["nested_auto_play_index"] < event["nested_auto_play_total_calls"] <= powers[0]["amount"]
                    or total_children is not None and event["nested_auto_play_total_calls"] != total_children
                    or any(not isinstance(event.get(k), str) or not event[k].startswith("DAGGER_THROW+")
                        for k in ("nested_source_card_key", "nested_auto_play_source_key_at_entry"))
                    or not isinstance(event.get("returned_cards"), list)
                    or [token(t) for t in event["returned_cards"]] != planned
                    or any(t["SourceOccurrence"] != 0 or t["OptionOccurrence"] != 0 for t in planned)):
                raise RuntimeError("Stampede original hook, child task or mandatory returned card does not match")
            previous_child = event["nested_auto_play_index"]
            selector_count = event["selector_invocations_after"]
            total_children = event["nested_auto_play_total_calls"]
        meta = self.checked(cmd="choice_meta")
        setup = meta.get("setup_origin", {})
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none" or meta.get("cards") != []
                or meta.get("completion_audit") != audit or not isinstance(setup, dict)
                or setup.get("schema_version") != "turn-setup-origin-v1"
                or setup.get("capture_method") != "CombatManager.SetupPlayerTurn.prefix"
                or type(setup.get("capture_id")) is not int or setup["capture_id"] < 1
                or setup.get("player_id") != parent["player_id"] or setup.get("live_same_combat") is not True
                or setup.get("captured_phase") != "Start" or setup.get("live_phase") != "Play"
                or setup.get("current_side") != "Player"
                or any(type(setup.get(k)) is not int or setup[k] != turn + 1 for k in ("captured_turn", "live_player_turn"))):
            raise RuntimeError("Stampede metadata is stale or lacks the actual next-turn setup")
        if not self.solve_calls:
            raise RuntimeError("No original solve owns this Stampede return")
        proof = {"kind": "original_choice_return_completed", "reason": "engine_automatic_mandatory_selection",
            "plan": copy.deepcopy(plans[0]), "actual_choice_audit": copy.deepcopy(audit),
            "selected_cards": copy.deepcopy(returns[0]["returned_cards"]), "selection_request_sent": False,
            "remaining_battle_plan_stopped": False, "actual_next_turn_setup": copy.deepcopy(setup),
            "nested_effect_binding": "actual_Stampede_power_hook_and_AutoPlay_tasks_with_original_DaggerThrow_return"}
        if len(plans) > 1:
            proof["nested_plans"] = copy.deepcopy(plans[1:])
        self.solve_calls[-1].setdefault("replay", []).append(proof)
        return True

    def resolve_turn_end_toasty_ending(self, before, state, action):
        """Stop an unexecuted setup choice only on original completed ending tasks."""
        plans = choice_plans(action)
        if (combat_in_progress(state) or action.get("Kind") != "EndTurn" or len(plans) != 1
                or plans[0].get("SourceId") != "TOASTY_MITTENS"):
            return False
        plan = plans[0]
        def require(ok, message):
            if not ok: raise RuntimeError("Toasty ending: " + message)
        require(action.get("Choice") is None and not action.get("NestedChoices")
            and action.get("TurnStartChoices") == plans
            and all(type(action.get(k, 0)) is int and action.get(k, 0) == 0
                for k in ("ReplayCount", "NestedChoicesBeforePrimary"))
            and tuple(plan.get(k) for k in ("Effect", "SourcePile", "SourceId", "ContextId", "Timing"))
                == ("Exhaust", "Hand", "TOASTY_MITTENS", "", "PlayerTurnStart")
            and isinstance(plan.get("Cards"), list) and len(plan["Cards"]) == 1,
            "unsupported original EndTurn choice plan")
        token = plan["Cards"][0]
        require(isinstance(token, dict)
            and all(isinstance(token.get(k), str) and token[k] for k in ("CardId", "StateKey"))
            and all(type(token.get(k)) is int and token[k] >= 0
                for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence")), "incomplete planned token")
        turn = action.get("Turn")
        require(type(turn) is int and turn > 0 and before.get("player_turn") == turn
            and before.get("decision") == "combat_play" and combat_in_progress(before)
            and state.get("context", {}).get("combat_in_progress") is False
            and self.setup_state_identity(before) == self.setup_state_identity(state)
            and self.last_action_request == {"cmd": "action", "action": "end_turn"}, "wrong combat or parent request")
        require_macro_boundary(state)
        audit = state.get("choice_audit", {})
        parent = audit.get("parent", {})
        combat_id = before.get("player", {}).get("combat_metrics", {}).get("combat_id")
        action_id = audit.get("action_id")
        require(audit.get("schema_version") == "combat-choice-return-v2" and audit.get("closed") is True
            and audit.get("events") == [] and audit.get("original_returns") == []
            and type(action_id) is int and action_id > 0 and type(combat_id) is int and combat_id > 0
            and parent.get("action") == "end_turn" and parent.get("combat_active_before") is True
            and type(parent.get("combat_id")) is int and parent["combat_id"] == combat_id
            and type(parent.get("player_turn")) is int and parent["player_turn"] == turn
            and isinstance(parent.get("player_id"), str) and bool(parent["player_id"])
            and all(parent.get(k) is None for k in ("card_id", "card_key", "potion_id"))
            and all(type(parent.get(k)) is int and parent[k] == -1
                for k in ("card_index", "potion_index", "potion_slot")), "invalid original action audit")
        meta = self.checked(cmd="choice_meta")
        origin = meta.get("turn_end_origin", {})
        setup = meta.get("setup_origin", {})
        require(meta.get("type") == "choice_meta" and meta.get("selection") == "none"
            and meta.get("cards") == [] and meta.get("completion_audit") == audit
            and origin.get("schema_version") == "original-end-turn-tasks-v1"
            and origin.get("closed") is True and type(origin.get("action_id")) is int
            and origin["action_id"] == action_id and origin.get("parent") == parent
            and origin.get("setup_origin") == setup, "missing or stale original task capture")
        capture = origin.get("setup_capture_before")
        require(type(capture) is int and capture > 0 and setup.get("schema_version") == "turn-setup-origin-v1"
            and setup.get("capture_method") == "CombatManager.SetupPlayerTurn.prefix"
            and type(setup.get("capture_id")) is int and setup["capture_id"] == capture + 1
            and setup.get("player_id") == parent["player_id"] and setup.get("live_same_combat") is True
            and setup.get("captured_phase") == "Start" and setup.get("live_phase") == "None"
            and setup.get("current_side") == "Player"
            and all(type(setup.get(k)) is int and setup[k] == turn + 1
                for k in ("captured_turn", "live_player_turn")), "setup did not advance exactly once")
        count = origin.get("before_action", {}).get("selector_invocations")
        require(type(count) is int and count >= 0, "missing original selector counter")
        def snapshot(s, number, phase, active, ending):
            require(isinstance(s, dict) and s.get("same_original_combat") is True
                and type(s.get("player_turn")) is int and s["player_turn"] == number
                and s.get("player_phase") == phase and s.get("combat_active") is active
                and s.get("combat_ending") is ending and s.get("selector_pending") is False
                and type(s.get("selector_invocations")) is int and s["selector_invocations"] == count,
                "task phase, combat or selector changed unexpectedly")
        snapshot(origin.get("before_action"), turn, "Play", True, False)
        snapshot(origin.get("after_action"), turn + 1, "None", False, True)
        calls = origin.get("calls")
        # Loop is one possible cause of combat ending during setup, not a
        # prerequisite for the original Toasty task to return an empty result.
        names = ["CombatManager.SetupPlayerTurn", "ToastyMittens.AfterPlayerTurnStart",
            "ToastyMittens.CardSelectCmd.FromHand"]
        actual_names = [c.get("kind") for c in calls if isinstance(c, dict)] if isinstance(calls, list) else []
        if actual_names == [names[0], "LoopPower.AfterPlayerTurnStart", *names[1:]]:
            names.insert(1, "LoopPower.AfterPlayerTurnStart")
        require(isinstance(calls, list) and len(calls) == len(names) and actual_names == names,
            "unexpected original hook sequence")
        for i, (call, name) in enumerate(zip(calls, names)):
            require(isinstance(call, dict) and call.get("kind") == name
                and type(call.get("index")) is int and call["index"] == i
                and type(call.get("setup_capture_id")) is int and call["setup_capture_id"] == capture + 1
                and call.get("original_task_completed_successfully") is True
                and call.get("original_task_status") == "RanToCompletion"
                and (i == 0 or call.get("source_is_original_player_object") is True),
                "original task or source identity not proven")
            snapshot(call.get("entry"), turn + 1, "Start", True, name.startswith("ToastyMittens."))
            snapshot(call.get("at_method_return"), turn + 1, "Start", True, True)
        hand = calls[-1]
        require(hand.get("filter_is_null") is True and hand.get("require_manual_confirmation") is False
            and all(type(hand.get(k)) is int and hand[k] == 1 for k in ("min_select", "max_select"))
            and type(hand.get("raw_hand_count")) is int and hand["raw_hand_count"] >= 0
            and hand.get("original_returned_collection") == "CardModel[]"
            and type(hand.get("returned_count")) is int and hand["returned_count"] == 0
            and hand.get("returned_card_keys") == [], "original ending FromHand did not return empty")
        require(bool(self.solve_calls), "no original solve owns this boundary")
        self.solve_calls[-1].setdefault("replay", []).append({
            "kind": "end_turn_setup_choice_not_executed", "reason": "original_setup_tasks_completed_with_combat_ending",
            "plan": copy.deepcopy(plan), "actual_choice_audit": copy.deepcopy(audit),
            "actual_turn_end_origin": copy.deepcopy(origin), "selected_cards": [],
            "selection_request_sent": False, "remaining_battle_plan_stopped": True})
        return True

    def resolve_original_automatic_choice(self, before, state, action):
        """Accept only observed original eager returns; never send a selection."""
        if state.get("decision") in {"card_select", "card_reward"} and combat_in_progress(state):
            return False
        if action.get("Kind") == "EndTurn":
            return (self.resolve_turn_end_toasty_ending(before, state, action)
                    or self.resolve_stampede_automatic_return(before, state, action))
        if action.get("Kind") == "PlayCard" and action.get("CardId") == "UPROAR" and not combat_in_progress(state):
            return self.resolve_ending_choice(before, state, action)
        audit = state.get("choice_audit", {})
        returns = audit.get("original_returns") if isinstance(audit, dict) else None
        if not returns:
            return False
        if action.get("Kind") == "PlayCard" and action.get("CardId") == "HOLOGRAM" and "hologram_play_count" in returns[0]:
            from hologram_series import resolve
            resolve(self, before, state, action, manual=False)
            return True
        plans = choice_plans(action)
        scavenge_replay = (
            action.get("Kind") == "PlayCard" and action.get("CardId") == "SCAVENGE"
            and type(action.get("ReplayCount")) is int and action["ReplayCount"] == 1
            and action.get("CardEnchantmentId") == "GLAM"
            and len(plans) == 2 and isinstance(plans[0], dict)
            and isinstance(plans[0].get("Cards"), list) and len(plans[0]["Cards"]) in (0, 1)
            and action.get("NestedChoices") == [dict(plans[0], Cards=[])]
            and plans[1] == dict(plans[0], Cards=[]))
        uproar_empty = (action.get("Kind") == "PlayCard" and action.get("CardId") == "UPROAR"
            and action.get("Choice") is None and len(plans) == 1
            and action.get("NestedChoices") == plans
            and plans[0] == {"Effect": "MoveToHand", "SourcePile": "Discard", "Cards": [],
                             "SourceId": "UPROAR", "ContextId": "", "Timing": "Action"}
            and type(action.get("ReplayCount", 0)) is int and action.get("ReplayCount", 0) == 0)
        uproar_heirloom = (action.get("Kind") == "PlayCard" and action.get("CardId") == "UPROAR"
            and action.get("Choice") is None and len(plans) == 1 and action.get("NestedChoices") == plans
            and tuple(plans[0].get(k) for k in ("Effect", "SourcePile", "SourceId", "ContextId", "Timing"))
                == ("Duplicate", "Hand", "UPROAR", "", "Action")
            and isinstance(plans[0].get("Cards"), list) and len(plans[0]["Cards"]) == 1
            and type(action.get("ReplayCount")) is int and action["ReplayCount"] == 0)
        catastrophe_heirloom = (action.get("Kind") == "PlayCard" and action.get("CardId") == "CATASTROPHE"
            and action.get("Choice") is None and len(plans) == 1 and action.get("NestedChoices") == plans
            and tuple(plans[0].get(k) for k in ("Effect", "SourcePile", "SourceId", "ContextId", "Timing"))
                == ("Duplicate", "Hand", "CATASTROPHE", "", "Action")
            and isinstance(plans[0].get("Cards"), list) and len(plans[0]["Cards"]) == 1
            and type(action.get("ReplayCount")) is int and action["ReplayCount"] == 0)
        catastrophe_hologram = (not catastrophe_heirloom and action.get("Kind") == "PlayCard" and action.get("CardId") == "CATASTROPHE"
            and action.get("Choice") is None and len(plans) == 1 and action.get("NestedChoices") == plans
            and type(action.get("ReplayCount", 0)) is int and action.get("ReplayCount", 0) == 0)
        if (len(plans) != (2 if scavenge_replay else 1)
                or action.get("Choice") != plans[0] and not (uproar_empty or catastrophe_hologram or uproar_heirloom or catastrophe_heirloom)
                or action.get("NestedChoices") and not (scavenge_replay or uproar_empty or catastrophe_hologram or uproar_heirloom or catastrophe_heirloom)
                or action.get("TurnStartChoices") or type(action.get("NestedChoicesBeforePrimary", 0)) is not int
                or action.get("NestedChoicesBeforePrimary", 0) != (1 if uproar_empty or catastrophe_hologram or uproar_heirloom or catastrophe_heirloom else 0)
                or action.get("EndsPlayerTurn", False) is not False):
            raise RuntimeError("Original return has unsupported nested action shape")
        plan = plans[0]
        cards = plan.get("Cards")
        seeker_singleton = action.get("Kind") == "PlayCard" and action.get("CardId") == "SEEKER_STRIKE"
        if (plan.get("Timing") != "Action" or not seeker_singleton and plan.get("ContextId") != "" or not isinstance(cards, list)):
            raise RuntimeError("Original return has unsupported choice timing or context")
        def token(t):
            if (not isinstance(t, dict) or any(not isinstance(t.get(k), str) or not t[k] for k in ("CardId", "StateKey"))
                    or any(type(t.get(k)) is not int or t[k] < 0 for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
                raise RuntimeError("Original return lacks complete solver token identity")
            return {k: t[k] for k in ("CardId", "UpgradeLevel", "StateKey", "SourceOccurrence", "OptionOccurrence")}
        planned = [token(c) for c in cards]
        if seeker_singleton:
            context = plan.get("ContextId")
            if (len(planned) != 1 or not isinstance(context, str)
                    or not re.fullmatch(r"seeker:(0|[1-9][0-9]*):[A-Z][A-Z0-9_]*\+(0|[1-9][0-9]*)", context)
                    or context.split(":", 2)[2] != f"{planned[0]['CardId']}+{planned[0]['UpgradeLevel']}"):
                raise RuntimeError("Seeker singleton context does not identify its original returned card")
        source = action.get("CardId") if action.get("Kind") == "PlayCard" else action.get("PotionId")
        contracts = {
            ("PlayCard", "HEADBUTT"): ("MoveToDrawTop", "Discard", "", "Headbutt.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "WISH"): ("MoveToHand", "Draw", "", "Wish.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "DREDGE"): ("MoveToHand", "Discard", "", "Dredge.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "COSMIC_INDIFFERENCE"): ("MoveToDrawTop", "Discard", "", "CosmicIndifference.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "HOLOGRAM"): ("MoveToHand", "Discard", "", "Hologram.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "GRAVEBLAST"): ("MoveToHand", "Discard", "", "Graveblast.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "UPROAR"): ("MoveToHand", "Discard", "UPROAR", "NeowsFury.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "CATASTROPHE"): ("MoveToHand", "Discard", "CATASTROPHE", "Hologram.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "SEEKER_STRIKE"): ("MoveToHand", "Draw", "", "SeekerStrike.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "SECRET_WEAPON"): ("MoveToHand", "Draw", "", "SecretWeapon.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "SECRET_TECHNIQUE"): ("MoveToHand", "Draw", "", "SecretTechnique.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "PURITY"): ("Exhaust", "Hand", "", "Purity.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "SCAVENGE"): ("Exhaust", "Hand", "", "Scavenge.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "BRAND"): ("Exhaust", "Hand", "", "Brand.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "DAGGER_THROW"): ("Discard", "Hand", "", "DaggerThrow.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "HIDDEN_DAGGERS"): ("Discard", "Hand", "", "HiddenDaggers.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "PREPARED"): ("Discard", "Hand", "", "Prepared.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "SCULPTING_STRIKE"): ("ApplyEthereal", "Hand", "", "SculptingStrike.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "PHOTON_CUT"): ("MoveToDrawTop", "Hand", "", "PhotonCut.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "THINKING_AHEAD"): ("MoveToDrawTop", "Hand", "", "ThinkingAhead.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "NIGHTMARE"): ("Nightmare", "Hand", "", "Nightmare.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "HAND_TRICK"): ("ApplySly", "Hand", "", "HandTrick.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "CHARGE"): ("Transform", "Draw", "", "Charge.OnPlay", "CardSelectCmd.FromCombatPile"),
            ("PlayCard", "BEGONE"): ("Transform", "Hand", "", "Begone.OnPlay", "CardSelectCmd.FromHand"),
            ("PlayCard", "HEIRLOOM_HAMMER"): ("Duplicate", "Hand", "", "HeirloomHammer.OnPlay", "CardSelectCmd.FromHand"),
            ("UsePotion", "LIQUID_MEMORIES"): ("MoveToHandFreeThisTurn", "Discard", "LIQUID_MEMORIES", "LiquidMemories.OnUse", "CardSelectCmd.FromCombatPile"),
            ("UsePotion", "TOUCH_OF_INSANITY"): ("SetFreeThisCombat", "Hand", "TOUCH_OF_INSANITY", "TouchOfInsanity.OnUse", "CardSelectCmd.FromHand"),
        }
        contract = contracts.get((action.get("Kind"), source))
        if uproar_heirloom or catastrophe_heirloom:
            contract = ("Duplicate", "Hand", source, "HeirloomHammer.OnPlay", "CardSelectCmd.FromHand")
        if contract is None or tuple(plan.get(k) for k in ("Effect", "SourcePile", "SourceId")) != contract[:3]:
            raise RuntimeError("Original return source/effect is not verified")
        ending = source in {"BRAND", "DAGGER_THROW", "PHOTON_CUT", "HEIRLOOM_HAMMER", "SCULPTING_STRIKE"} and not combat_in_progress(state)
        empty_source = source in {"SCAVENGE", "BRAND", "GRAVEBLAST", "UPROAR", "PURITY", "BEGONE", "HIDDEN_DAGGERS", "PREPARED", "CHARGE", "DAGGER_THROW", "PHOTON_CUT", "THINKING_AHEAD", "NIGHTMARE", "WISH", "DREDGE"} and not planned
        empty_filtered = source in {"HAND_TRICK", "HEIRLOOM_HAMMER", "SCULPTING_STRIKE", "SECRET_WEAPON", "SECRET_TECHNIQUE", "TOUCH_OF_INSANITY"} and not planned
        catastrophe_limit = None
        if source == "CATASTROPHE":
            variables = re.search(r"\|vars=([^|]*)\|", action.get("CardStateKey", ""))
            limits = re.findall(r"(?:^|;)Cards=([1-9][0-9]*)(?=;|$)", variables[1]) if variables else []
            if not (catastrophe_hologram or catastrophe_heirloom) or len(limits) != 1:
                raise RuntimeError("Catastrophe requires its original nested action and auto-play count")
            catastrophe_limit = int(limits[0])
        mandatory_many = source in {"HIDDEN_DAGGERS", "PREPARED", "CHARGE", "DREDGE"}
        mandatory_limit = None
        if mandatory_many:
            variables = re.search(r"\|vars=([^|]*)\|", action.get("CardStateKey", ""))
            limits = re.findall(r"(?:^|;)Cards=([1-9][0-9]*)(?=;|$)", variables[1]) if variables else []
            if len(limits) != 1 or not len(planned) <= int(limits[0]):
                raise RuntimeError("Mandatory choice plan lacks its original card count")
            mandatory_limit = int(limits[0])
            if source == "DREDGE":
                hand = before.get("hand")
                if not isinstance(hand, list) or not 1 <= len(hand) <= 10:
                    raise RuntimeError("Dredge lacks its original pre-play hand capacity")
                mandatory_limit = min(mandatory_limit, 11 - len(hand))
                if len(planned) > mandatory_limit:
                    raise RuntimeError("Dredge planned return exceeds its original free hand capacity")
        purity_empty = source == "PURITY" and not planned
        purity_cards = re.search(r"\|vars=Cards=([1-9][0-9]*)(?:,|\|)", action.get("CardStateKey", "")) if purity_empty else None
        if source == "PURITY" and (not purity_empty or purity_cards is None):
            raise RuntimeError("Purity requires its original empty hand and card-count fingerprint")
        replay = action.get("ReplayCount", 0)
        hand_trick_empty_repeat = (source == "HAND_TRICK" and type(replay) is int and replay == 0
            and isinstance(returns, list) and len(returns) == 2
            and any(p.get("name") == "Echo Form" and type(p.get("amount")) is int and p["amount"] == 1
                for p in before.get("player_powers", [])))
        if hand_trick_empty_repeat:
            play = state.get("play_action", {})
            expected_play = {"schema_version":"original-play-action-v1", "outcome":"completed", "card_id":"HAND_TRICK",
                "target_combat_id":None, "state":"Finished", "completion_task_status":"RanToCompletion",
                "cancellation_observed":False, "on_play_entered":True}
            if (not isinstance(play, dict) or any(type(play.get(k)) is not type(v) or play[k] != v for k,v in expected_play.items())
                    or type(play.get("action_id")) is not int or play["action_id"] < 1
                    or any(not isinstance(e, dict) for e in returns)
                    or returns[1].get("returned_cards") != []
                    or any(e.get(k) != returns[0].get("raw_source_count_at_entry") for e in returns
                        for k in ("raw_source_count_at_entry", "raw_source_count_at_return"))):
                raise RuntimeError("HandTrick additional empty effect lacks its original completed play")
        if (type(replay) is not int or replay not in (0, 1)
                or replay and not (scavenge_replay or source == "HOLOGRAM" and action.get("CardEnchantmentId") == "GLAM")
                or not isinstance(returns, list) or len(returns) != 1 + replay + int(hand_trick_empty_repeat)
                or (len(planned) not in (0, 1) if source in {"SCAVENGE", "BRAND", "HAND_TRICK", "HEIRLOOM_HAMMER", "GRAVEBLAST", "UPROAR", "PURITY", "BEGONE", "SCULPTING_STRIKE", "SECRET_WEAPON", "SECRET_TECHNIQUE", "DAGGER_THROW", "PHOTON_CUT", "THINKING_AHEAD", "NIGHTMARE", "TOUCH_OF_INSANITY", "WISH"} else not mandatory_many and len(planned) != 1)):
            raise RuntimeError("Original return does not cover every planned invocation")
        if ending:
            if combat_in_progress(state):
                raise RuntimeError("This card return is only verified for original combat ending")
            require_macro_boundary(state)
        elif (state.get("decision") != "combat_play" or not combat_in_progress(state)
                or self.setup_state_identity(before) != self.setup_state_identity(state)
                or state.get("player_turn") != before.get("player_turn")):
            raise RuntimeError("Automatic return changed the live combat or turn")
        parent = audit.get("parent", {})
        action_id = audit.get("action_id")
        combat_id = before.get("player", {}).get("combat_metrics", {}).get("combat_id")
        if (audit.get("schema_version") != "combat-choice-return-v2" or audit.get("closed") is not True
                or audit.get("coverage") != "FromCombatPile.IsEnding_or_NeowsFury.empty_source.synchronous_empty_return_only"
                or type(action_id) is not int or action_id < 1 or audit.get("events") != []
                or not isinstance(parent, dict) or not combat_in_progress(before)
                or type(combat_id) is not int or combat_id < 1 or type(parent.get("combat_id")) is not int
                or parent.get("combat_id") != combat_id
                or state.get("player", {}).get("combat_metrics", {}).get("combat_id") != combat_id
                or parent.get("combat_active_before") is not True
                or type(parent.get("player_turn")) is not int or parent["player_turn"] != action.get("Turn")
                or parent["player_turn"] != before.get("player_turn")
                or not isinstance(parent.get("player_id"), str) or not parent["player_id"]
                or not isinstance(self.last_action_request, dict)):
            raise RuntimeError("Original return parent combat or action identity mismatch")
        request = self.last_action_request
        if request.get("cmd") != "action":
            raise RuntimeError("Original return requires an actual action request")
        args = request.get("args", {})
        if action["Kind"] == "PlayCard":
            valid_parent = (request.get("action") == parent.get("action") == "play_card"
                and parent.get("card_id") == source and bool(action.get("CardStateKey"))
                and parent.get("card_key") == action["CardStateKey"]
                and type(parent.get("card_index")) is int and parent["card_index"] >= 0
                and parent["card_index"] == args.get("card_index"))
        else:
            valid_parent = (request.get("action") == parent.get("action") == "use_potion"
                and parent.get("potion_id") == source
                and type(parent.get("potion_slot")) is int and parent["potion_slot"] >= 0
                and parent["potion_slot"] == action.get("PotionSlot")
                and type(parent.get("potion_index")) is int and parent["potion_index"] >= 0
                and parent["potion_index"] == args.get("potion_index"))
        if not valid_parent:
            raise RuntimeError("Original return is not bound to its actual card or potion")
        previous_counter = None
        for index, event in enumerate(returns):
            if not isinstance(event, dict):
                raise RuntimeError("Malformed original return event")
            if source == "DREDGE":
                expected_dredge = {"dredge_hand_count_at_entry": len(before["hand"]) - 1,
                    "dredge_cards_at_entry": int(limits[0]), "dredge_hand_capacity": 10,
                    "raw_source_count_at_entry": before.get("discard_pile_count")}
                if (any(type(event.get(k)) is not int or type(v) is not int or event[k] != v
                        for k, v in expected_dredge.items())
                        or event["raw_source_count_at_entry"] > mandatory_limit):
                    raise RuntimeError("Dredge original return count or hand-capacity evidence differs")
            counter = event.get("selector_invocations_before")
            returned = event.get("returned_cards")
            if (event.get("schema_version") != "original-choice-return-v1" or event.get("verified") is not True
                    or type(event.get("invocation_index")) is not int or event["invocation_index"] != index
                    or type(event.get("action_id")) is not int or event.get("action_id") != action_id or event.get("source_id") != ("NEOWS_FURY" if uproar_empty else "HOLOGRAM" if catastrophe_hologram else "HEIRLOOM_HAMMER" if uproar_heirloom or catastrophe_heirloom else source)
                    or event.get("effect_callsite") != contract[3] or event.get("source_method") != contract[4]
                    or event.get("effect") != contract[0] or event.get("source_pile") != contract[1]
                    or event.get("source_is_actual_parent_object") is not (not (uproar_empty or catastrophe_hologram or uproar_heirloom or catastrophe_heirloom))
                    or event.get("player_id") != parent["player_id"] or type(event.get("player_turn")) is not int
                    or event.get("player_turn") != action["Turn"]
                    or event.get("original_task_completed_successfully") is not True
                    or event.get("returned_objects_match_original_source") is not True
                    or event.get("filter_reexecuted_by_observer") is not False
                    or event.get("candidate_basis") != "original_implementation_and_completed_return_without_selector"
                    or type(counter) is not int or counter < 0
                    or type(event.get("selector_invocations_after")) is not int or event["selector_invocations_after"] != counter
                    or previous_counter is not None and previous_counter != counter
                    or event.get("selector_pending_before") is not False or event.get("selector_pending_after") is not False
                    or (type(event.get("min_select")) is not int or event["min_select"] != 0
                        or type(event.get("max_select")) is not int or event["max_select"] <= 0
                        if uproar_empty or purity_empty else any(type(event.get(k)) is not int or event[k] != (mandatory_limit if mandatory_many else 1)
                                                 for k in ("min_select", "max_select")))
                    or event.get("require_manual_confirmation") is not (uproar_empty or purity_empty)
                    or any(type(event.get(k)) is not int or event[k] < 0 for k in ("raw_source_count_at_entry", "raw_source_count_at_return"))
                    or event.get("is_over_or_ending_at_entry") is not ending
                    or event.get("is_over_or_ending_at_return") is not ending
                    or not isinstance(returned, list) or type(event.get("returned_count")) is not int
                    or event["returned_count"] != len(returned)):
                raise RuntimeError("Original synchronous return evidence is incomplete")
            if purity_empty and event["max_select"] != int(purity_cards.group(1)):
                raise RuntimeError("Purity selection maximum differs from original card fingerprint")
            if uproar_empty and (event.get("nested_parent_card_id") != "UPROAR"
                    or event.get("nested_relation") != "UPROAR_action_NEOWS_FURY_original_OnPlay_empty_discard"
                    or event.get("nested_source_owner_matches_parent") is not True
                    or not isinstance(event.get("nested_source_card_key"), str)
                    or not event["nested_source_card_key"].startswith("NEOWS_FURY+")
                    or not empty_source):
                raise RuntimeError("Uproar nested empty return lacks its original NeowsFury callsite binding")
            if catastrophe_hologram and (event.get("nested_parent_card_id") != "CATASTROPHE"
                    or event.get("nested_relation") != "CATASTROPHE_original_AutoPlay_HOLOGRAM_original_OnPlay_singleton_discard"
                    or event.get("nested_source_owner_matches_parent") is not True
                    or any(not isinstance(event.get(k), str) or not event[k].startswith("HOLOGRAM+")
                           for k in ("nested_source_card_key", "nested_auto_play_source_key_at_entry"))
                    or event.get("nested_auto_play_callsite") != "Catastrophe.OnPlay.CardCmd.AutoPlay"
                    or event.get("nested_auto_play_source_is_original_object") is not True
                    or event.get("nested_auto_play_task_completed_successfully") is not True
                    or type(event.get("nested_auto_play_index")) is not int
                    or type(event.get("nested_auto_play_total_calls")) is not int
                    or not 0 <= event["nested_auto_play_index"] < event["nested_auto_play_total_calls"] <= catastrophe_limit):
                raise RuntimeError("Catastrophe nested return lacks its actual original AutoPlay child task binding")
            if uproar_heirloom:
                expected_nested = {
                    "nested_parent_card_id": "UPROAR",
                    "nested_relation": "UPROAR_original_AutoPlay_HEIRLOOM_HAMMER_original_OnPlay_hand_return",
                    "nested_source_owner_matches_parent": True,
                    "nested_auto_play_callsite": "Uproar.OnPlay.CardCmd.AutoPlay",
                    "nested_auto_play_source_is_original_object": True,
                    "nested_auto_play_task_completed_successfully": True,
                    "nested_auto_play_index": 0, "nested_auto_play_total_calls": 1,
                }
                if (any(type(event.get(k)) is not type(v) or event[k] != v for k,v in expected_nested.items())
                        or any(not isinstance(event.get(k), str) or not re.match(r"^HEIRLOOM_HAMMER\+[0-9]+\|",event[k])
                            for k in ("nested_source_card_key", "nested_auto_play_source_key_at_entry"))
                        or event["nested_source_card_key"] != event["nested_auto_play_source_key_at_entry"]
                        or event["raw_source_count_at_entry"] != event["raw_source_count_at_return"]
                        or event["raw_source_count_at_entry"] < 1):
                    raise RuntimeError("Uproar duplicate lacks its exact original Heirloom AutoPlay return")
            if catastrophe_heirloom:
                expected_nested = {
                    "nested_parent_card_id": "CATASTROPHE",
                    "nested_relation": "CATASTROPHE_original_AutoPlay_HEIRLOOM_HAMMER_original_OnPlay_hand_return",
                    "nested_source_owner_matches_parent": True,
                    "nested_auto_play_callsite": "Catastrophe.OnPlay.CardCmd.AutoPlay",
                    "nested_auto_play_source_is_original_object": True,
                    "nested_auto_play_task_completed_successfully": True,
                }
                if (any(type(event.get(k)) is not type(v) or event[k] != v for k,v in expected_nested.items())
                        or any(not isinstance(event.get(k),str) or not re.match(r"^HEIRLOOM_HAMMER\+[0-9]+\|",event[k])
                            for k in ("nested_source_card_key","nested_auto_play_source_key_at_entry"))
                        or event["nested_source_card_key"] != event["nested_auto_play_source_key_at_entry"]
                        or type(event.get("nested_auto_play_index")) is not int
                        or type(event.get("nested_auto_play_total_calls")) is not int
                        or not 0 <= event["nested_auto_play_index"] < event["nested_auto_play_total_calls"] <= catastrophe_limit
                        or event["raw_source_count_at_entry"] != event["raw_source_count_at_return"]
                        or event["raw_source_count_at_entry"] < 1):
                    raise RuntimeError("Catastrophe duplicate lacks its exact original Heirloom AutoPlay return")
            previous_counter = counter
            if not ending and (event.get("combat_active_at_entry") is not True or event.get("combat_active_at_return") is not True):
                raise RuntimeError("Automatic return did not occur during active combat")
            if ending or empty_source or empty_filtered or index > 0:
                if (returned != [] or event.get("original_returned_collection") != ("List<CardModel>" if source in {"SCAVENGE", "HAND_TRICK", "PURITY", "BEGONE", "HIDDEN_DAGGERS", "PREPARED", "TOUCH_OF_INSANITY"} or source in {"BRAND", "HEIRLOOM_HAMMER", "SCULPTING_STRIKE", "DAGGER_THROW", "PHOTON_CUT", "THINKING_AHEAD", "NIGHTMARE"} and not ending else "CardModel[]")
                        or not ending and not empty_filtered and not (hand_trick_empty_repeat and index == 1) and any(event[k] != 0 for k in ("raw_source_count_at_entry", "raw_source_count_at_return"))):
                    raise RuntimeError("Original empty return is not verified")
            elif ([token(c) for c in returned] != planned or len(returned) != (len(planned) if mandatory_many else 1)
                    or returned[0]["OptionOccurrence"] != 0
                    or event.get("original_returned_collection") != "List<CardModel>"
                    or source in {"HOLOGRAM", "SCAVENGE", "BRAND", "SEEKER_STRIKE", "LIQUID_MEMORIES", "HEADBUTT", "COSMIC_INDIFFERENCE", "GRAVEBLAST", "CATASTROPHE", "BEGONE", "DAGGER_THROW", "PHOTON_CUT", "THINKING_AHEAD", "NIGHTMARE", "WISH"} and not catastrophe_heirloom and any(event[k] != 1 for k in ("raw_source_count_at_entry", "raw_source_count_at_return"))):
                raise RuntimeError("Original automatically returned card does not match solver fingerprint")
            if source in {"SECRET_WEAPON", "SECRET_TECHNIQUE", "TOUCH_OF_INSANITY"} and (event["raw_source_count_at_entry"] != event["raw_source_count_at_return"]
                    or event["raw_source_count_at_entry"] < len(planned)):
                raise RuntimeError("Original filtered return has inconsistent source counts")
            if mandatory_many and any(event[k] != len(planned) for k in ("raw_source_count_at_entry", "raw_source_count_at_return")):
                raise RuntimeError("Original mandatory choice did not return its complete source selection")
            if event.get("filter_is_null") is not (source in {"SCAVENGE", "BRAND", "DAGGER_THROW", "PHOTON_CUT", "THINKING_AHEAD", "NIGHTMARE", "PURITY", "BEGONE", "HIDDEN_DAGGERS", "PREPARED"}):
                raise RuntimeError("Original return filter contract differs")
        meta = self.checked(cmd="choice_meta")
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none" or meta.get("cards") != []
                or meta.get("completion_audit") != audit):
            raise RuntimeError("Original return audit is stale or a choice remains pending")
        if not self.solve_calls:
            raise RuntimeError("No original solve owns this return proof")
        self.solve_calls[-1].setdefault("replay", []).append({
            "kind": "original_choice_return_completed",
            "reason": "engine_combat_ending" if ending else "engine_empty_source" if empty_source else "engine_empty_filtered_selection" if empty_filtered else "engine_automatic_mandatory_selection",
            "plan": copy.deepcopy(plan), "actual_choice_audit": copy.deepcopy(audit),
            "selected_cards": copy.deepcopy(returns[0]["returned_cards"]),
            "selection_request_sent": False, "remaining_battle_plan_stopped": ending})
        if uproar_empty:
            self.solve_calls[-1]["replay"][-1]["nested_effect_binding"] = "actual_NeowsFury_callsite_within_original_Uproar_action"
        if catastrophe_hologram:
            self.solve_calls[-1]["replay"][-1]["nested_effect_binding"] = "actual_Catastrophe_AutoPlay_task_with_original_Hologram_child_return"
        if uproar_heirloom:
            self.solve_calls[-1]["replay"][-1]["nested_effect_binding"] = "actual_Uproar_AutoPlay_task_with_original_HeirloomHammer_child_return"
        if catastrophe_heirloom:
            self.solve_calls[-1]["replay"][-1]["nested_effect_binding"] = "actual_Catastrophe_AutoPlay_task_with_original_HeirloomHammer_child_return"
        if scavenge_replay:
            self.solve_calls[-1]["replay"][-1]["nested_plans"] = copy.deepcopy(plans[1:])
        if hand_trick_empty_repeat:
            self.solve_calls[-1]["replay"][-1]["additional_original_empty_returns"] = copy.deepcopy(returns[1:])
            self.solve_calls[-1]["replay"][-1]["actual_original_play_completion"] = copy.deepcopy(state["play_action"])
        if seeker_singleton:
            self.solve_calls[-1]["replay"][-1]["context_validation"] = "original_singleton_token_identity_not_rng_counter"
        return True

    def resolve_empty_source_choice(self, before, state, action):
        return self._resolve_original_choice_return(before, state, action, empty_source=True)

    def _resolve_original_choice_return(self, before, state, action, *, empty_source):
        """Verify one observed original return; never invent or submit a choice.

        Empty-source completion is limited to an empty Neow's Fury plan during
        active combat. Ending completion separately stops the remaining plan.
        """
        plans = choice_plans(action)
        uproar_ending = not empty_source and action.get("CardId") == "UPROAR"
        uproar_headbutt_ending = (uproar_ending and len(plans) == 1
            and plans[0].get("Effect") == "MoveToDrawTop" and plans[0].get("SourcePile") == "Discard")
        uproar_neows_ending = uproar_ending and not uproar_headbutt_ending and len(plans) == 1 and plans[0].get("SourcePile") == "Discard"
        uproar_seeker_ending = uproar_ending and not (uproar_neows_ending or uproar_headbutt_ending)
        seeker_ending = not empty_source and (action.get("CardId") == "SEEKER_STRIKE" or uproar_seeker_ending)
        if uproar_ending and (action.get("EndsPlayerTurn", False) is not False
                or type(action.get("NestedChoicesBeforePrimary")) is not int
                or action["NestedChoicesBeforePrimary"] != 1):
            return False
        headbutt_ending = not empty_source and (action.get("CardId") == "HEADBUTT" or uproar_headbutt_ending)
        if (combat_in_progress(state) != empty_source or action.get("Kind") != "PlayCard"
                or action.get("CardId") not in ({"SEEKER_STRIKE", "NEOWS_FURY", "HEADBUTT", "GRAVEBLAST", "UPROAR"} if not empty_source else {"NEOWS_FURY"})
                or len(plans) != 1
                or (action.get("Choice") is not None or action.get("NestedChoices") != plans if uproar_ending
                    else action.get("Choice") != plans[0] or action.get("NestedChoices"))
                or action.get("TurnStartChoices") or type(action.get("ReplayCount", 0)) is not int
                or action.get("ReplayCount", 0) != 0):
            return False
        plan = plans[0]
        if (plan.get("Effect") != ("MoveToDrawTop" if headbutt_ending else "MoveToHand")
                or plan.get("SourcePile") != ("Draw" if seeker_ending else "Discard")
                or plan.get("Timing") != "Action" or plan.get("SourceId") != ("UPROAR" if uproar_ending else "")
                or not isinstance(plan.get("Cards"), list)):
            return False
        if seeker_ending:
            # This is only the original solver's context syntax. The engine
            # ended combat before selection; no sampled candidate or RNG match
            # is claimed and the planned token is never executed.
            context = plan.get("ContextId")
            if (not isinstance(context, str) or not re.fullmatch(
                    r"seeker:(0|[1-9][0-9]*):[A-Z][A-Z0-9_]*\+(0|[1-9][0-9]*)(,[A-Z][A-Z0-9_]*\+(0|[1-9][0-9]*)){0,2}", context)
                    or len(plan["Cards"]) != 1
                    or type(action.get("NestedChoicesBeforePrimary", 0)) is not int
                    or action.get("NestedChoicesBeforePrimary", 0) != (1 if uproar_seeker_ending else 0)):
                return False
        elif plan.get("ContextId") != "":
            return False
        if (headbutt_ending or action.get("CardId") == "GRAVEBLAST") and (len(plan["Cards"]) != 1
                or type(action.get("NestedChoicesBeforePrimary", 0)) is not int
                or action.get("NestedChoicesBeforePrimary", 0) != int(uproar_headbutt_ending)
                or any(type(t.get("SourceOccurrence")) is not int or t["SourceOccurrence"] < 0
                       for t in plan["Cards"] if isinstance(t, dict))):
            return False
        if empty_source and (plan["Cards"] != [] or state.get("decision") != "combat_play"
                or type(action.get("NestedChoicesBeforePrimary", 0)) is not int
                or action.get("NestedChoicesBeforePrimary", 0) != 0
                or action.get("EndsPlayerTurn", False) is not False
                or state.get("player_turn") != before.get("player_turn")
                or type(state.get("discard_pile_count")) is not int or state["discard_pile_count"] != 0):
            return False
        for token in plan["Cards"]:
            if (not isinstance(token, dict) or not isinstance(token.get("CardId"), str) or not token["CardId"]
                    or not isinstance(token.get("StateKey"), str) or not token["StateKey"]
                    or type(token.get("UpgradeLevel")) is not int or token["UpgradeLevel"] < 0
                    or type(token.get("OptionOccurrence")) is not int or token["OptionOccurrence"] < 0):
                return False
            if uproar_neows_ending and (type(token.get("SourceOccurrence")) is not int or token["SourceOccurrence"] < 0):
                return False
        if seeker_ending:
            token = plan["Cards"][0]
            if (type(token.get("SourceOccurrence")) is not int or token["SourceOccurrence"] < 0
                    or f"{token['CardId']}+{token['UpgradeLevel']}" not in plan["ContextId"].split(":", 2)[2].split(",")):
                return False
        audit = state.get("choice_audit")
        if not isinstance(audit, dict):
            return False
        meta = self.checked(cmd="choice_meta")
        if (meta.get("type") != "choice_meta" or meta.get("selection") != "none"
                or meta.get("cards") != [] or meta.get("completion_audit") != audit):
            raise RuntimeError("Ending choice audit is stale or a selector is still pending")
        parent, events = audit.get("parent"), audit.get("events")
        action_id = audit.get("action_id")
        contract = (audit.get("schema_version"), audit.get("coverage"))
        v1 = ("combat-choice-return-v1", "FromCombatPile.IsEnding.synchronous_empty_return_only")
        v2 = ("combat-choice-return-v2", "FromCombatPile.IsEnding_or_NeowsFury.empty_source.synchronous_empty_return_only")
        if (contract not in ({v2} if empty_source else {v1, v2})
                or type(action_id) is not int or action_id < 1 or audit.get("closed") is not True
                or not isinstance(parent, dict) or not isinstance(events, list) or len(events) != 1):
            raise RuntimeError("Incomplete ending choice audit")
        before_id = before.get("player", {}).get("combat_metrics", {}).get("combat_id")
        after_id = state.get("player", {}).get("combat_metrics", {}).get("combat_id")
        if (type(before_id) is not int or before_id < 1 or after_id != before_id
                or type(parent.get("combat_id")) is not int or parent["combat_id"] != before_id
                or parent.get("combat_active_before") is not True or not combat_in_progress(before)
                or parent.get("action") != "play_card" or parent.get("card_id") != action["CardId"]
                or not action.get("CardStateKey") or parent.get("card_key") != action["CardStateKey"]
                or type(parent.get("player_turn")) is not int or parent["player_turn"] != action.get("Turn")
                or parent["player_turn"] != before.get("player_turn")
                or not isinstance(self.last_action_request, dict)
                or self.last_action_request.get("action") != "play_card"
                or type(parent.get("card_index")) is not int
                or parent["card_index"] != self.last_action_request.get("args", {}).get("card_index")
                or not isinstance(parent.get("player_id"), str) or not parent["player_id"]):
            raise RuntimeError("Ending choice audit parent action or combat mismatch")
        event = events[0]
        if (not isinstance(event, dict) or type(event.get("event_index")) is not int or event["event_index"] != 0
                or type(event.get("action_id")) is not int or event["action_id"] != action_id
                or event.get("source_method") != "CardSelectCmd.FromCombatPile"
                or event.get("source_pile") != plan["SourcePile"]
                or event.get("player_id") != parent["player_id"]
                or event.get("reason") != ("empty_source_pile" if empty_source else "combat_ending")
                or event.get("is_ending_at_entry") is not (not empty_source)
                or event.get("original_task_completed_successfully") is not True
                or event.get("original_returned_empty_array") is not True
                or event.get("selection_executed") is not False or event.get("selected_cards") != []
                or type(event.get("selector_invocations_before")) is not int or event["selector_invocations_before"] < 0
                or type(event.get("selector_invocations_after")) is not int
                or event["selector_invocations_after"] != event["selector_invocations_before"]):
            raise RuntimeError("Ending choice return does not prove an unexecuted selection")
        if uproar_ending:
            returns = audit.get("original_returns")
            if not isinstance(returns, list) or len(returns) != 1:
                raise RuntimeError("Uproar ending lacks its actual nested source return")
            original = returns[0]
            source_id = "HEADBUTT" if uproar_headbutt_ending else "NEOWS_FURY" if uproar_neows_ending else "SEEKER_STRIKE"
            callsite = "Headbutt.OnPlay" if uproar_headbutt_ending else "NeowsFury.OnPlay" if uproar_neows_ending else "SeekerStrike.OnPlay"
            relation = ("UPROAR_original_AutoPlay_HEADBUTT_original_OnPlay_combat_ending" if uproar_headbutt_ending
                else f"UPROAR_action_{source_id}_original_OnPlay_combat_ending")
            if (not isinstance(original, dict) or original.get("schema_version") != "original-choice-return-v1"
                    or original.get("verified") is not True or type(original.get("invocation_index")) is not int
                    or original["invocation_index"] != 0 or type(original.get("action_id")) is not int
                    or original["action_id"] != action_id or original.get("source_id") != source_id
                    or original.get("effect_callsite") != callsite
                    or original.get("source_method") != "CardSelectCmd.FromCombatPile"
                    or original.get("source_pile") != plan["SourcePile"] or original.get("effect") != plan["Effect"]
                    or original.get("source_is_actual_parent_object") is not False
                    or original.get("nested_parent_card_id") != "UPROAR"
                    or original.get("nested_source_owner_matches_parent") is not True
                    or original.get("nested_relation") != relation
                    or not isinstance(original.get("nested_source_card_key"), str)
                    or not original["nested_source_card_key"].startswith(source_id + "+")
                    or original.get("player_id") != parent["player_id"]
                    or type(original.get("player_turn")) is not int or original["player_turn"] != parent["player_turn"]
                    or original.get("is_over_or_ending_at_entry") is not True
                    or original.get("is_over_or_ending_at_return") is not True
                    or original.get("original_task_completed_successfully") is not True
                    or original.get("returned_objects_match_original_source") is not True
                    or original.get("original_returned_collection") != "CardModel[]"
                    or original.get("returned_cards") != [] or type(original.get("returned_count")) is not int
                    or original["returned_count"] != 0 or original.get("filter_reexecuted_by_observer") is not False
                    or original.get("filter_is_null") is not False
                    or original.get("candidate_basis") != "original_implementation_and_completed_return_without_selector"
                    or any(type(original.get(k)) is not int for k in ("min_select", "max_select"))
                    or original["min_select"] != (0 if uproar_neows_ending else 1)
                    or (original["max_select"] <= 0 if uproar_neows_ending else original["max_select"] != 1)
                    or original.get("require_manual_confirmation") is not uproar_neows_ending
                    or any(type(original.get(k)) is not int or original[k] < 0 for k in ("raw_source_count_at_entry", "raw_source_count_at_return"))
                    or any(type(original.get(k)) is not int or original[k] != event["selector_invocations_before"]
                           for k in ("selector_invocations_before", "selector_invocations_after"))
                    or original.get("selector_pending_before") is not False or original.get("selector_pending_after") is not False):
                raise RuntimeError("Uproar ending nested source/task evidence differs")
            if uproar_headbutt_ending:
                expected = {"nested_auto_play_callsite":"Uproar.OnPlay.CardCmd.AutoPlay",
                    "nested_auto_play_index":0,"nested_auto_play_total_calls":1,
                    "nested_auto_play_source_is_original_object":True,
                    "nested_auto_play_task_completed_successfully":True}
                play = state.get("play_action",{})
                if (any(type(original.get(k)) is not type(value) or original[k] != value for k,value in expected.items())
                        or not isinstance(original.get("nested_auto_play_source_key_at_entry"),str)
                        or not re.match(r"^HEADBUTT\+[0-9]+\|",original["nested_auto_play_source_key_at_entry"])
                        or any(type(original.get(k)) is not bool for k in
                            ("nested_auto_play_combat_active_at_entry","nested_auto_play_combat_ending_at_entry"))
                        or not (original["nested_auto_play_combat_active_at_entry"] or original["nested_auto_play_combat_ending_at_entry"])
                        or play.get("schema_version") != "original-play-action-v1" or play.get("card_id") != "UPROAR"
                        or play.get("target_combat_id") != action.get("TargetCombatId")
                        or type(play.get("action_id")) is not int or play["action_id"] < 0
                        or play.get("outcome") != "completed" or play.get("state") != "Finished"
                        or play.get("completion_task_status") != "RanToCompletion" or play.get("on_play_entered") is not True
                        or play.get("cancellation_observed") is not False):
                    raise RuntimeError("Uproar Headbutt original AutoPlay task is not completely bound")
            if uproar_neows_ending:
                # Bind the original dynamic card limit; the ending engine did
                # not execute any of the solver's planned retrievals.
                variables = re.search(r"\|vars=([^|]*)\|", original["nested_source_card_key"])
                limits = re.findall(r"(?:^|;)Cards=([1-9][0-9]*)(?=;|$)", variables[1]) if variables else []
                if len(limits) != 1 or not len(plan["Cards"]) <= original["max_select"] <= int(limits[0]):
                    raise RuntimeError("Uproar NeowsFury ending selection limit differs from original source")
        if empty_source and (event.get("combat_active_at_entry") is not True
                or event.get("combat_active_at_return") is not True
                or any(type(event.get(k)) is not int or event[k] != 0
                       for k in ("source_pile_count_at_entry", "source_pile_count_at_return", "min_select"))
                or type(event.get("max_select")) is not int or event["max_select"] <= 0
                or event.get("require_manual_confirmation") is not True
                or event.get("selector_is_headless") is not True
                or event.get("selector_pending_before") is not False
                or event.get("selector_pending_after") is not False):
            raise RuntimeError("Empty source choice return lacks original active-combat empty-pile proof")
        evidence = {"kind": "planned_empty_choice_completed" if empty_source else "planned_choice_not_executed",
            "reason": "engine_empty_source_pile" if empty_source else "engine_combat_ending_short_circuit",
            "plan": copy.deepcopy(plan), "actual_choice_audit": copy.deepcopy(audit),
            "selected_cards": [], "remaining_battle_plan_stopped": not empty_source}
        if seeker_ending:
            evidence["context_validation"] = "solver_syntax_only_not_engine_selection"
        if uproar_seeker_ending:
            evidence["nested_effect_binding"] = "actual_SeekerStrike_callsite_within_original_Uproar_action"
        if uproar_neows_ending:
            evidence["nested_effect_binding"] = "actual_NeowsFury_callsite_within_original_Uproar_action"
        if uproar_headbutt_ending:
            evidence["nested_effect_binding"] = "actual_Uproar_AutoPlay_task_with_original_Headbutt_ending_return"
            evidence["actual_original_play_completion"] = copy.deepcopy(state["play_action"])
        if not self.solve_calls:
            raise RuntimeError("No solver call to bind ending choice replay evidence")
        self.solve_calls[-1].setdefault("replay", []).append(evidence)
        return True

    @staticmethod
    def unplayable_card_proof(state, action, meta, action_index):
        """Replan on the original CanPlay predicate, without submitting a play."""
        if action.get("Kind") != "PlayCard": return None
        snapshot = meta.get("playability_preflight")
        if snapshot is None:
            # Historical traces predate this observer. A visible rejected card
            # still cannot justify submitting an action without fresh metadata.
            matches = [c for c in meta.get("hand", []) if c.get("key") == action.get("CardStateKey")]
            occurrence = action.get("CardStateOccurrence", 0)
            if type(occurrence) is int and 0 <= occurrence < len(matches):
                index = matches[occurrence].get("index")
                if any(c.get("index") == index and c.get("can_play") is False for c in state.get("hand", [])):
                    raise RuntimeError("Missing original playability preflight for an unplayable card")
            return None
        def require(ok, message):
            if not ok: raise RuntimeError("Playability preflight: " + message)
        combat_id = state.get("player", {}).get("combat_metrics", {}).get("combat_id")
        turn = state.get("player_turn")
        require(isinstance(snapshot, dict) and snapshot.get("schema_version") == "original-card-playability-preflight-v1"
            and snapshot.get("source_method") == "CardModel.CanPlay"
            and meta.get("type") == "combat_meta" and state.get("decision") == "combat_play"
            and combat_in_progress(state) and snapshot.get("combat_active") is True
            and type(combat_id) is int and combat_id > 0 and type(snapshot.get("combat_id")) is int
            and snapshot["combat_id"] == combat_id and type(turn) is int and turn > 0
            and type(snapshot.get("player_turn")) is int and snapshot["player_turn"] == turn
            and type(action.get("Turn")) is int and action["Turn"] == turn
            and snapshot.get("player_phase") == "Play" and isinstance(snapshot.get("player_id"), str)
            and bool(snapshot["player_id"]), "missing or stale original combat/player identity")
        for key in ("energy", "stars"):
            require(type(snapshot.get(key)) is int and snapshot[key] >= 0, "invalid original resource value")
            if key in state: require(type(state[key]) is int and state[key] == snapshot[key], "resource snapshot differs from state")
        rows, hand = snapshot.get("cards"), meta.get("hand")
        visible = state.get("hand")
        require(isinstance(rows, list) and isinstance(hand, list) and isinstance(visible, list)
            and len(rows) == len(hand) == len(visible), "hand snapshot differs from actual hand")
        for i, (row, card, shown) in enumerate(zip(rows, hand, visible)):
            require(all(isinstance(o, dict) for o in (row, card, shown))
                and all(type(o.get("index")) is int and o["index"] == i for o in (row, card, shown))
                and isinstance(row.get("key"), str) and bool(row["key"]) and row["key"] == card.get("key")
                and isinstance(row.get("id"), str) and bool(row["id"]) and shown.get("id") == "CARD." + row["id"]
                and row.get("source_is_original_hand_card") is True
                and row.get("fingerprint_unchanged_after_query") is True
                and type(row.get("upgrade_level")) is int and row["upgrade_level"] >= 0
                and type(row.get("original_can_play")) is bool and type(shown.get("can_play")) is bool
                and isinstance(row.get("original_reason"), str) and bool(row["original_reason"])
                and type(row.get("energy_cost")) is int and row["energy_cost"] >= 0
                and type(shown.get("cost")) is int and shown["cost"] == row["energy_cost"]
                and type(row.get("costs_x")) is bool and type(row.get("star_cost")) is int,
                "malformed original hand predicate or fingerprint")
        occurrence = action.get("CardStateOccurrence", 0)
        matches = [r for r in rows if r["key"] == action.get("CardStateKey")]
        require(type(occurrence) is int and 0 <= occurrence < len(matches), "planned card identity absent")
        row = matches[occurrence]
        require(row["id"] == action.get("CardId") and row["upgrade_level"] == action.get("CardUpgradeLevel"),
            "planned card does not match original predicate source")
        if row["original_can_play"]:
            require(row["original_reason"] == "None", "successful predicate has a rejection reason")
            return None
        require(visible[row["index"]]["can_play"] is False and row["original_reason"] != "None",
            "original rejected predicate differs from visible card")
        if row["original_reason"] == "EnergyCostTooHigh":
            require(row["costs_x"] is False and row["energy_cost"] > snapshot["energy"],
                "energy rejection contradicts original cost/resources")
        return {"schema_version":"original-card-playability-replan-v1",
            "reason":"planned_card_rejected_by_original_pre_action_CanPlay",
            "action_index":action_index,"action":copy.deepcopy(action),"state":copy.deepcopy(state),
            "combat_meta":copy.deepcopy(meta),"action_submitted":False,
            "selected_hand_index":row["index"],"original_rejection_reason":row["original_reason"]}

    @staticmethod
    def missing_target_proof(state, action, meta, action_index):
        enemies = meta.get("enemies")
        target = action.get("TargetCombatId")
        if (meta.get("type") != "combat_meta" or type(target) is not int or target < 0
                or not isinstance(enemies, list) or any(not isinstance(e, dict)
                    or type(e.get("combat_id")) is not int or e["combat_id"] < 0
                    or type(e.get("index")) is not int or e["index"] < 0 for e in enemies)
                or len({e["combat_id"] for e in enemies}) != len(enemies)
                or len({e["index"] for e in enemies}) != len(enemies)):
            raise RuntimeError("Invalid or duplicate target combat identity metadata")
        if any(e["combat_id"] == target for e in enemies):
            return None
        return {"schema_version": "missing-combat-target-replan-v1",
            "reason": "planned_target_absent_from_actual_combat_meta",
            "action_index": action_index, "action": copy.deepcopy(action),
            "state": copy.deepcopy(state), "combat_meta": copy.deepcopy(meta),
            "action_submitted": False}

    @staticmethod
    def missing_hologram_choice_proof(state, action, meta, action_index):
        """Replan before submission if the recorded retrieval is absent now.

        This is a pre-action availability check, not a simulation of OnPlay,
        a substituted selection, or proof about the future choice surface.
        """
        plan = action.get("Choice")
        if (action.get("Kind") != "PlayCard" or action.get("CardId") != "HOLOGRAM"
                or not isinstance(plan, dict) or plan.get("Effect") != "MoveToHand"
                or plan.get("SourcePile") != "Discard" or plan.get("SourceId") != ""
                or plan.get("ContextId") != "" or plan.get("Timing") != "Action"
                or not isinstance(plan.get("Cards"), list) or len(plan["Cards"]) != 1):
            return None
        token = plan["Cards"][0]
        if (not isinstance(token, dict) or any(not isinstance(token.get(k), str) or not token[k]
                for k in ("CardId", "StateKey")) or any(type(token.get(k)) is not int or token[k] < 0
                for k in ("UpgradeLevel", "SourceOccurrence", "OptionOccurrence"))):
            raise RuntimeError("Invalid Hologram preflight token")
        snapshot = meta.get("discard_preflight")
        combat_id = state.get("player", {}).get("combat_metrics", {}).get("combat_id")
        if (not isinstance(snapshot, dict) or snapshot.get("schema_version") != "original-discard-preflight-v1"
                or snapshot.get("pile") != "Discard" or snapshot.get("combat_active") is not True
                or state.get("decision") != "combat_play" or not combat_in_progress(state)
                or type(combat_id) is not int or combat_id < 1
                or type(snapshot.get("combat_id")) is not int or snapshot["combat_id"] != combat_id
                or type(snapshot.get("player_turn")) is not int or snapshot["player_turn"] != state.get("player_turn")
                or snapshot["player_turn"] != action.get("Turn")
                or not isinstance(snapshot.get("player_id"), str) or not snapshot["player_id"]
                or not isinstance(snapshot.get("cards"), list)):
            raise RuntimeError("Missing or stale original discard preflight")
        cards = snapshot["cards"]
        if any(not isinstance(c, dict) or type(c.get("index")) is not int or c["index"] != i
                or type(c.get("upgrade_level")) is not int or c["upgrade_level"] < 0
                or any(not isinstance(c.get(k), str) or not c[k] for k in ("id", "key"))
                for i, c in enumerate(cards)):
            raise RuntimeError("Malformed original discard preflight cards")
        matches = [c for c in cards if c["id"] == token["CardId"] and c["upgrade_level"] == token["UpgradeLevel"]]
        occurrence = token["SourceOccurrence"]
        if occurrence < len(matches) and matches[occurrence]["key"] == token["StateKey"]:
            return None
        return {"schema_version": "hologram-discard-preflight-replan-v1",
            "reason": "planned_retrieval_absent_from_actual_pre_action_discard",
            "action_index": action_index, "action": copy.deepcopy(action),
            "state": copy.deepcopy(state), "combat_meta": copy.deepcopy(meta),
            "action_submitted": False, "post_effect_choice_availability_claimed": False}

    def advance(self, state):
        self.solve_calls = []
        self.last_state = copy.deepcopy(state)
        self.last_error = None
        retained_result, setup_proof = None, None
        if state.get("decision") == "card_select" and combat_in_progress(state):
            result = self.solve(state, self.config["setup_budget_ms"], setup=True)
            state, setup_proof = self.resolve_setup_for_continuation(state, result)
            if setup_proof is not None:
                if setup_proof["kind"] == "turn_setup_ended_combat":
                    self.solve_calls[-1].setdefault("replay", []).append(setup_proof)
                    self.solve_calls[-1]["setup_plan_reuse"] = {"schema_version": "setup-plan-reuse-v1",
                        "reused": False, "reason": "original_setup_ended_combat"}
                    setup_proof = None
                else:
                    retained_result = result
        if state.get("decision") != "combat_play":
            require_macro_boundary(state)
        used = 0
        replans = 0
        while state.get("decision") == "combat_play":
            if not combat_in_progress(state):
                raise RuntimeError("combat_play returned outside active combat")
            if replans >= self.config["max_replans"]:
                raise RuntimeError("Too many combat replans")
            if retained_result is not None:
                result, retained_result = retained_result, None
            else:
                result = self.solve(state, self.config["first_budget_ms" if replans == 0 else "replan_budget_ms"], used)
                setup_proof = None
            if not result.get("actions"):
                raise RuntimeError("Solver returned no actions")
            before_replay = json.dumps(state, sort_keys=True)
            setup_first_action_mismatch = False
            target_missing = False
            for action_index, action in enumerate(result["actions"]):
                if state.get("decision") != "combat_play":
                    break
                # Solver actions use PlayerCombatState.TurnNumber. The global
                # CombatState.RoundNumber need not advance on an extra turn.
                player_turn = state.get("player_turn")
                if type(player_turn) is not int or player_turn < 1:
                    raise RuntimeError("Missing actual player_turn for solver replay")
                if type(action.get("Turn")) is not int or action["Turn"] != player_turn:
                    raise RuntimeError(f"Solver replay player turn mismatch: planned={action.get('Turn')}, actual={player_turn}")
                kind = action["Kind"]
                before_action = copy.deepcopy(state)
                if kind == "EndTurn":
                    state = self.checked(cmd="action", action="end_turn")
                elif kind in ("PlayCard", "UsePotion"):
                    meta = self.checked(cmd="combat_meta")
                    args = {}
                    if kind == "PlayCard":
                        matches = [c for c in meta["hand"] if c["key"] == action["CardStateKey"]]
                        occurrence = action.get("CardStateOccurrence", 0)
                        if type(occurrence) is not int or occurrence < 0 or not action["CardStateKey"]:
                            raise RuntimeError("Invalid solver hand-card identity")
                        if occurrence >= len(matches):
                            if setup_proof is not None:
                                self.solve_calls[-1]["setup_plan_reuse"] = {"schema_version": "setup-plan-reuse-v1", "reused": False, "reason": "first_action_fingerprint_changed"}
                                setup_proof = None
                                setup_first_action_mismatch = True
                            break  # Ask the solver again from actual state.
                        args["card_index"] = matches[occurrence]["index"]
                        method = "play_card"
                    else:
                        matches = [p for p in meta["potions"] if p["slot"] == action["PotionSlot"] and p["id"] == action["PotionId"]]
                        if len(matches) != 1:
                            raise RuntimeError("Potion identity mismatch")
                        args["potion_index"] = matches[0]["index"]
                        method = "use_potion"
                    proof = self.unplayable_card_proof(state, action, meta, action_index)
                    if proof is None:
                        proof = self.missing_hologram_choice_proof(state, action, meta, action_index)
                    if proof is not None:
                        self.solve_calls[-1]["plan_invalidation"] = proof
                        target_missing = True
                        break  # Ask the original solver from current state before playing.
                    if action["TargetIndex"] >= 0:
                        proof = self.missing_target_proof(state, action, meta, action_index)
                        if proof is not None:
                            self.solve_calls[-1]["plan_invalidation"] = proof
                            target_missing = True
                            break  # Original solver must choose from the actual state.
                        matches = [e for e in meta["enemies"] if e["combat_id"] == action["TargetCombatId"]]
                        if len(matches) != 1:
                            raise RuntimeError("Target combat ID mismatch")
                        args["target_index"] = matches[0]["index"]
                    state = self.checked(cmd="action", action=method, args=args)
                    used += int(kind == "UsePotion")
                else:
                    raise RuntimeError("Unknown solver action: " + kind)
                if setup_proof is not None:
                    setup_proof.update(first_action=copy.deepcopy(action),
                        actual_first_request=copy.deepcopy(self.last_action_request))
                    self.solve_calls[-1].setdefault("replay", []).append(setup_proof)
                    self.solve_calls[-1]["setup_plan_reuse"] = {"schema_version": "setup-plan-reuse-v1", "reused": True, "reason": "original_setup_and_first_action_verified"}
                    setup_proof = None
                if choice_plans(action):
                    if (action.get("Kind") == "UsePotion" and action.get("PotionId") == "DISTILLED_CHAOS"
                            and state.get("decision") == "combat_play" and combat_in_progress(state)):
                        from distilled_chaos_replan import proof as distilled_replan_proof
                        completion = self.checked(cmd="choice_meta")
                        self.solve_calls[-1]["plan_invalidation"] = distilled_replan_proof(
                            before_action, state, action, completion, action_index, self.last_action_request)
                        self.publish(state)
                        break  # Preserve used-potion count and replan from this actual state.
                    from neows_empty_series import resolve as resolve_empty_neows_series
                    if not (resolve_empty_neows_series(self, before_action, state, action)
                            or self.resolve_original_automatic_choice(before_action, state, action)
                            or self.resolve_ending_choice(before_action, state, action)
                            or self.resolve_empty_source_choice(before_action, state, action)):
                        state = (self.resolve_seeker_continuation(before_action, state, action)
                                 if action.get("CardId") == "SEEKER_STRIKE" and len(choice_plans(action)) > 1 else
                                 self.resolve_hologram_continuation(before_action, state, action)
                                 if self.hologram_manual_repeat(action) else
                                 self.resolve_scavenge_continuation(before_action, state, action)
                                 if self.scavenge_manual_repeat(action) else
                                 self.resolve_hand_trick_continuation(before_action, state, action)
                                 if self.hand_trick_manual_repeat(action) else self.resolve_secret_technique_continuation(before_action, state, action)
                                 if self.secret_technique_manual_repeat(action) else self.resolve_neows_continuation(before_action, state, action)
                                 if self.neows_manual_repeat(action) else self.resolve(state, choice_plans(action)))
                elif (state.get("decision") == "card_select" and combat_in_progress(state) and kind == "EndTurn"
                        and state.get("choice_audit", {}).get("closed") is True
                        and state.get("choice_audit", {}).get("parent", {}).get("action") == "end_turn"):
                    # An actual new setup can outlive the solver's predicted
                    # terminal state. Authenticate its original tasks, then let
                    # a fresh original setup solve own every selection/action.
                    from unpredicted_setup import proof as unpredicted_setup_proof
                    meta = self.checked(cmd="choice_meta")
                    self.solve_calls[-1]["plan_invalidation"] = unpredicted_setup_proof(
                        before_action, state, action, meta, action_index)
                    if replans + 1 >= self.config["max_replans"]:
                        raise RuntimeError("Too many combat replans")
                    result = self.solve(state, self.config["setup_budget_ms"], used, setup=True)
                    plans = result.get("turn_setup_choices") or []
                    if len(plans) != 1 or result.get("setup_origin") != meta["setup_origin"]:
                        raise RuntimeError("Fresh solve does not own the actual unpredicted setup")
                    self.verify_toasty_setup_metadata(state, plans[0], meta, result["setup_origin"])
                    state, setup_proof = self.resolve_setup_for_continuation(state, result)
                    if setup_proof is None:
                        raise RuntimeError("Unpredicted setup did not produce an original continuation proof")
                    if setup_proof["kind"] == "turn_setup_ended_combat":
                        self.solve_calls[-1].setdefault("replay", []).append(setup_proof)
                        self.solve_calls[-1]["setup_plan_reuse"] = {"schema_version": "setup-plan-reuse-v1",
                            "reused": False, "reason": "original_setup_ended_combat"}
                        setup_proof = None
                    else:
                        retained_result = result
                    self.publish(state)
                    break
                elif state.get("decision") != "combat_play":
                    require_macro_boundary(state)
                self.publish(state)
            if (state.get("decision") == "combat_play" and json.dumps(state, sort_keys=True) == before_replay
                    and not setup_first_action_mismatch and not target_missing):
                raise RuntimeError("Solver replay made no progress")
            replans += 1
        require_macro_boundary(state)
        return state
