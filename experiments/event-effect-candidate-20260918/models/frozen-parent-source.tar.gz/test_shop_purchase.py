"""Actual merchant transaction regression; artificial fixtures are not training data."""
import json
import unittest
import uuid

from probe import Bridge, ROOT


class ShopPurchaseTests(unittest.TestCase):
    def test_successful_potion_sale_clears_stock_without_false_error_or_double_charge(self):
        label = "shop-purchase-fixture-" + uuid.uuid4().hex[:12]
        bridge = Bridge(label)
        requests = []

        def send(**request):
            requests.append(request)
            return bridge.send(**request)

        try:
            send(cmd="start_run", character="Defect", ascension=10, seed="merchant-potion-clear-model")
            send(cmd="set_player", gold=500, potions=[])
            before = send(cmd="enter_room", type="shop")
            self.assertEqual(before.get("decision"), "shop", before)
            entry = next(p for p in before["potions"] if p["can_purchase"])
            after = send(cmd="action", action="buy_potion", args={"potion_index": entry["index"]})
            self.assertEqual(after.get("decision"), "shop", after)
            self.assertEqual(after["player"]["gold"], before["player"]["gold"] - entry["cost"])
            self.assertEqual([p["id"] for p in after["player"]["potions"]], [entry["id"]])
            stock = next(p for p in after["potions"] if p["index"] == entry["index"])
            self.assertFalse(stock["can_purchase"])
            duplicate = send(cmd="action", action="buy_potion", args={"potion_index": entry["index"]})
            self.assertEqual(duplicate.get("type"), "error")
            self.assertIn("already purchased", duplicate["message"].lower())
            final = send(cmd="set_player")  # Existing fixture API, no fields changed.
            self.assertEqual(final["player"]["gold"], after["player"]["gold"])
            self.assertEqual(final["player"]["potions"], after["player"]["potions"])
        finally:
            (ROOT / "outputs" / (label + ".json")).write_text(json.dumps({
                "provenance": "artificial merchant fixture; not training data",
                "requests": requests, "responses": bridge.rows}, ensure_ascii=False, indent=2), encoding="utf-8")
            bridge.close()


if __name__ == "__main__":
    unittest.main()
