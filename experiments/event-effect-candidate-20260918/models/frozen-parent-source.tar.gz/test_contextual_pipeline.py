"""Temporary synthetic files exercise the whole pipeline, never natural outcomes."""
import copy
from contextlib import ExitStack
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

STAGE = Path(__file__).resolve().parent
sys.path.insert(0, str(STAGE.parents[2]))
sys.path.insert(0, str(STAGE))
import train_contextual_run as trainer
import sample_runs
import evaluate_contextual_run as evaluator
import reconcile_contextual_generation as generation_reconciler
import archive_contextual_training as archiver
import reconcile_contextual_evaluation as evaluation_reconciler
from run_metadata import file_evidence
from test_initial_policy import state


class ContextualPipelineTests(unittest.TestCase):
    def test_complete_allocation_archive_evaluation_and_raw_reconciliation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            protocol_path = root / 'training' / 'protocol.json'
            protocol = trainer.prepare(protocol_path, name='synthetic-context-pipeline',
                                       generations=1, seeds_per_generation=2)
            initial = state()
            initial['context'].update(act=1, floor=2, integrity_recovery_used=False)
            terminal = copy.deepcopy(initial)
            terminal.update(decision='game_over', victory=False)
            terminal['player']['hp'] = 0

            class FakeBridge:
                def send(self, **request):
                    return copy.deepcopy(initial if request['cmd'] == 'start_run' else terminal)
                def close(self):
                    pass

            original_metadata = sample_runs.metadata
            def staged_metadata(*args, **kwargs):
                meta = original_metadata(*args, **kwargs)
                for name in trainer.STAGED_SOURCES:
                    meta['versions']['sources'][name] = file_evidence(STAGE / name)
                return meta

            with ExitStack() as stack:
                for module in (trainer, sample_runs, evaluator, generation_reconciler, evaluation_reconciler):
                    stack.enter_context(patch.object(module, 'ROOT', root))
                stack.enter_context(patch.object(sample_runs, 'metadata', side_effect=staged_metadata))
                bridge = stack.enter_context(patch.object(sample_runs, 'Bridge', side_effect=lambda *a, **k: FakeBridge()))
                stack.enter_context(patch('builtins.print'))
                trainer.run(protocol_path)
                self.assertEqual(bridge.call_count, 34)
                folder = protocol_path.parent / 'generation-00'
                check = generation_reconciler.reconcile(protocol_path, 0, folder / 'RECONCILIATION.json')
                self.assertTrue(check['passed'])
                self.assertEqual(check['actual_games'], 34)
                self.assertEqual(check['elite_indices'], [0, 1, 2, 3, 4])
                archive = archiver.archive(protocol_path)
                self.assertTrue(archive['archive_readback_verified'])
                self.assertTrue(archive['training_complete'])
                with self.assertRaises(ValueError): archiver.archive(protocol_path)

                eval_path = root / 'evaluation' / 'protocol.json'
                evaluation = evaluator.prepare(protocol_path, eval_path)
                summary = json.loads((folder / 'summary.json').read_text())
                self.assertEqual(evaluation['models']['trained'], summary['best_candidate_artifact'])
                self.assertEqual(evaluation['seeds'], protocol['reserved_evaluation_seeds'])
                self.assertEqual(len(evaluation['order']), 60)
                self.assertFalse(set(evaluation['seeds']) & set(sum(protocol['training_seeds'], [])))
                evaluator.run(eval_path)
                self.assertEqual(bridge.call_count, 94)
                result = evaluation_reconciler.reconcile(eval_path, eval_path.parent / 'RECONCILIATION.json')
                self.assertTrue(result['passed'])
                self.assertEqual(result['actual_games'], 60)
                self.assertEqual(result['distinct_seeds'], 30)
                self.assertEqual(result['paired_first_boss_results'], {'neither': 30})
                self.assertFalse(result['universal_success_proven'])
                for arm in ('trained', 'zero'):
                    self.assertEqual(result['arms'][arm]['first_boss_successes'], 0)
                    self.assertEqual(result['arms'][arm]['outcomes'], {'defeat': 30})
                with self.assertRaises(FileExistsError): evaluator.run(eval_path)

                # A changed real return invalidates reconciliation; it is never repaired or relabelled.
                audit_path = eval_path.parent / (evaluation['name'] + '-trained-000-audit.json')
                row = json.loads(audit_path.read_text()); row['goal_success'] = True
                audit_path.write_text(json.dumps(row))
                with self.assertRaises(ValueError):
                    evaluation_reconciler.reconcile(eval_path, eval_path.parent / 'must-not-exist.json')
                self.assertFalse((eval_path.parent / 'must-not-exist.json').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
