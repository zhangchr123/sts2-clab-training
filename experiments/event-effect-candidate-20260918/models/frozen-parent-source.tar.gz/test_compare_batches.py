"""Synthetic temporary evidence only; no games or natural training samples."""
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from combat_executor import DEFAULT_CONFIG
from compare_batches import BEHAVIOR_SOURCES, compare_batches, load_protocol, wilson95
from decision_data import DecisionJournal, enumerate_candidates


def write(path, value):
    path.write_text(json.dumps(value), encoding="utf-8")


class CompareBatchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def run_fixture(self, name, seed, backend, outcome, *, config=None, recovered=False,
                    engine_hash="a" * 64, policy_change=False, fake_second=False):
        directory = self.root / name
        directory.mkdir()
        config = copy.deepcopy(config or DEFAULT_CONFIG)
        config["solver_backend"] = backend
        provenance = {"origin": "natural", "kind": "rules", "id": "synthetic-policy", "version": "1",
                      "llm_involved": False, "random_seed": seed, "epsilon": .1}
        evidence = {"sha256": "a" * 64, "bytes": 100}
        versions = {k: dict(evidence) for k in ("engine", "solver", "cli", "bridge")}
        versions["engine"]["sha256"] = engine_hash
        versions["sources"] = {name: dict(evidence) for name in BEHAVIOR_SOURCES}
        metadata = {"run_id": name, "seed": seed, "character": "Defect", "ascension": 10,
                    "mode": "standard", "versions": versions, "solver_requested_config": config,
                    "provenance": provenance, "branch_restore_enabled": False, "llm_used_for_combat": False,
                    "sampling": {"epsilon": .1, "max_seconds": 600, "max_decisions": 500,
                                 "hidden_audit_features_used": False, "selection_budget": 256}}
        write(directory / "manifest.json", metadata)
        context = {"ascension": 10, "act": 1, "room_type": "Map", "combat_in_progress": False,
                   "integrity_recovery_used": False, "is_second_boss": False, "encounter_id": None}
        initial = {"type": "decision", "decision": "map_select", "context": context,
                   "player": {"hp": 20}, "choices": [{"col": 0, "row": 1, "type": "Monster"}]}
        chosen = enumerate_candidates(initial)["candidates"][0]["request"]
        terminal = {"type": "decision", "decision": "game_over", "victory": outcome == "victory",
                    "player": {"hp": 10 if outcome == "victory" else 0},
                    "context": {**context, "act": 3 if outcome == "victory" else 2,
                                "room_type": "Boss", "is_second_boss": outcome == "victory", "encounter_id": "BOSS_B"}}
        combat = {"type": "decision", "decision": "combat_play", "player": {"hp": 20},
                  "context": {**terminal["context"], "combat_in_progress": True,
                              "is_second_boss": outcome == "victory" and not fake_second}}
        solve_request = {"cmd": "solve", "solver_backend": backend, "budget_ms": config["first_budget_ms"],
                         **{key: copy.deepcopy(config[key]) for key in ("potion_policy", "growth_budgets",
                            "act_boss_hp_strategy", "final_boss_hp_strategy", "search_profile")},
                         "hp_lost_so_far": 0, "potions_used_so_far": 0, "include_turn_setup": False}
        profile = {**config["search_profile"], "soft_time_budget_ms": solve_request["budget_ms"]}
        stage = {"index": 0, "search_profile": profile, "expanded_nodes": 10, "elapsed_ms": 100,
                 "effective_potion_policy": "Smart", "policy_snapshot": {}, "battle_damage_snapshot": {},
                 "minimum_potion_uses": 0, "maximum_potion_uses": None, "status": "completed", "error": None}
        settings = {"solver_backend": backend, "search_profile_verified": True, "search_profile": profile,
                    "configured_search_profile": profile, "max_degree_of_parallelism": 1,
                    "potion_policy": config["potion_policy"], "potions": [], "growth_budgets": config["growth_budgets"],
                    "search_stages": [stage], "search_stage_audit": {"verified": True, "hook_verified": True,
                        "top_level_outcome": "solver_result", "started_stage_count": 1, "finished_stage_count": 1,
                        "failed_stage_count": 0, "observed_expanded_nodes": 10, "reported_total_expanded_nodes": 10,
                        "total_nodes_reconciled": True}}
        response = {"type": "solver_result", "elapsed_ms": 150, "settings": settings, "summary": {"TotalExpandedNodes": 10}}
        calls = []
        if recovered:
            calls.append({"request": copy.deepcopy(solve_request), "response": {"type": "error", "error": "OperationCanceledException"}, "seconds": .5})
        calls.append({"request": solve_request, "response": response, "seconds": .25})
        error = {"kind": outcome, "traceback": "synthetic failure"} if outcome in {"timeout", "environment_error"} else None
        final_state = terminal if error is None else {"type": "error", "error": "synthetic failure"}
        with DecisionJournal(directory, metadata) as journal:
            policy = {**provenance, "choice_count": 3}
            if policy_change:
                policy.update(kind="llm", llm_involved=True)
            token = journal.begin(initial, chosen, policy=policy)
            journal.complete(token, final_state, solver_calls=calls, environment_error=error)
            finished = journal.finalize(final_state, termination="engine_terminal" if error is None else outcome,
                             environment_error=error, terminal_evidence={"second_boss_entered": outcome == "victory",
                                "second_boss_victory": outcome == "victory", "trace_reference": str(directory / "trace.jsonl")})
        trace = [{"request": {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": seed}, "response": initial},
                 {"request": chosen, "response": combat}, *calls,
                 {"request": {"cmd": "action", "action": "end_turn"}, "response": final_state}]
        (directory / "trace.jsonl").write_text("\n".join(json.dumps(row) for row in trace) + "\n", encoding="utf-8")
        write(directory / "state.json", final_state)
        report = {"run_id": name, "seed": seed, "outcome": finished["outcome"], "seconds": 2., "solver_calls": len(calls), "error": error}
        write(directory / "report.json", report)
        return report

    def batch(self, name, backend, outcomes, **kwargs):
        directory = self.root / name
        directory.mkdir()
        reports = [self.run_fixture(f"{name}-{index}", f"seed-{index}", backend, outcome, **kwargs)
                   for index, outcome in enumerate(outcomes)]
        write(directory / "reports.json", reports)
        write(directory / "summary.json", {"runs": len(reports), "reports": reports})
        return directory

    def compare(self, a, b):
        return compare_batches(a, b, left_backend="beam", right_backend="coordinator")

    def protocol(self, left_config, right_config, *, seeds=None, created=None):
        path = self.root / "protocol.json"
        write(path, {"schema_version": "paired-solver-config-v1",
            "created_utc": created or datetime.now(timezone.utc).isoformat(),
            "seeds": seeds or ["seed-0"], "arms": {
                "left": {"batch": "a", "solver_config": left_config},
                "right": {"batch": "b", "solver_config": right_config}},
            "conditions": {"character": "Defect", "ascension": 10, "epsilon": .1,
                           "max_seconds": 600, "max_decisions": 500, "selection_budget": 256}})
        return path

    def protocol_configs(self):
        left = copy.deepcopy(DEFAULT_CONFIG)
        left["solver_backend"] = "coordinator"
        right = copy.deepcopy(left)
        right.update(first_budget_ms=10000, replan_budget_ms=10000)
        right["search_profile"].update(beam_width=60, max_expanded_nodes=24000,
            max_card_branches_per_node=32, max_pile_choice_branches_per_action=18,
            max_hand_choice_branches_per_action=24)
        return left, right

    def mutate_manifest(self, run_id, mutate):
        directory = self.root / run_id
        value = json.loads((directory / "manifest.json").read_text())
        mutate(value)
        write(directory / "manifest.json", value)
        rows = [json.loads(line) for line in (directory / "decisions.jsonl").read_text().splitlines()]
        rows[0]["metadata"].update(value)
        (directory / "decisions.jsonl").write_text("\n".join(json.dumps(row) for row in rows) + "\n", encoding="utf-8")

    def test_failures_stay_in_denominator_and_discordant_counts(self):
        a = self.batch("a", "beam", ["victory", "defeat", "timeout", "environment_error"])
        b = self.batch("b", "coordinator", ["defeat", "victory", "defeat", "environment_error"])
        result = self.compare(a, b)
        self.assertTrue(result["comparable"], result["errors"])
        left, right = result["left"]["summary"], result["right"]["summary"]
        self.assertEqual((left["runs_in_denominator"], left["end_to_end_win_rate"]), (4, .25))
        self.assertEqual(left["environment_error_or_timeout_rate"], .5)
        self.assertEqual((left["natural_defeats"], right["natural_defeats"]), (1, 2))
        self.assertEqual(result["paired"]["left_wins_right_does_not"], 1)
        self.assertEqual(result["paired"]["right_wins_left_does_not"], 1)
        self.assertEqual(result["paired"]["win_rate_difference_right_minus_left"], 0)
        self.assertEqual(left["act_reach"]["3"]["rate"], .25)
        self.assertEqual((left["total_run_seconds"], left["solver_calls"], left["solver_request_seconds"]), (8., 4, 1.))

    def test_wilson_zero_success_and_no_zero_cost_per_win(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["timeout"])
        result = self.compare(a, b)
        self.assertTrue(result["comparable"], result["errors"])
        self.assertIsNone(result["left"]["summary"]["seconds_per_verified_victory"])
        self.assertEqual(result["left"]["summary"]["seconds_per_victory_unavailable_reason"], "no_verified_victories")
        self.assertAlmostEqual(wilson95(0, 10)[1], .2775327998628892)
        self.assertIsNone(wilson95(0, 0))

    def test_recovered_solver_errors_are_separate_from_true_defeat(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["defeat"], recovered=True)
        result = self.compare(a, b)
        self.assertTrue(result["comparable"], result["errors"])
        summary = result["right"]["summary"]
        self.assertEqual(summary["natural_defeats"], 1)
        self.assertEqual(summary["environment_errors"], 0)
        self.assertEqual(summary["solver_error_calls"], 1)
        self.assertEqual(summary["recovered_solver_error_calls"], 1)
        self.assertEqual(summary["non_training_eligible_runs"], 1)
        self.assertEqual(summary["solver_request_seconds"], .75)
        self.assertIsNone(summary["reported_search_seconds"])
        self.assertEqual(summary["missing_search_elapsed_count"], 1)

    def test_missing_seed_is_not_silently_paired_subset(self):
        a = self.batch("a", "beam", ["defeat", "environment_error"])
        b = self.batch("b", "coordinator", ["victory"])
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertIsNone(result["paired"])
        self.assertEqual(result["missing_paired_seeds"]["right"], ["seed-1"])
        self.assertEqual(result["left"]["summary"]["runs_in_denominator"], 2)
        self.assertEqual(len(result["per_seed"]), 2)

    def test_version_difference_prevents_comparison(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["defeat"], engine_hash="b" * 64)
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("beyond" in error for error in result["errors"]))

    def test_budget_difference_is_not_backend_only(self):
        a = self.batch("a", "beam", ["defeat"])
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["first_budget_ms"] = 5000
        b = self.batch("b", "coordinator", ["defeat"], config=config)
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertIsNone(result["paired"])

    def test_mixed_arm_backend_rejected_without_removing_run(self):
        a = self.batch("a", "beam", ["defeat", "defeat"])
        b = self.batch("b", "coordinator", ["defeat", "defeat"])
        path = self.root / "b-1" / "manifest.json"
        value = json.loads(path.read_text()); value["solver_requested_config"]["solver_backend"] = "beam"
        write(path, value)
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertEqual(result["right"]["summary"]["runs_in_denominator"], 2)
        self.assertTrue(any("Mixed or undeclared" in error for error in result["errors"]))

    def test_changed_or_llm_decision_policy_prevents_comparison(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["victory"], policy_change=True)
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertEqual(result["right"]["summary"]["verified_a10_victories"], 0)

    def test_boolean_claim_is_not_second_boss_trace_evidence(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["victory"], fake_second=True)
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertEqual(result["right"]["summary"]["verified_a10_victories"], 0)
        self.assertTrue(any("second-boss" in error for error in result["errors"]))

    def test_duplicate_seed_is_explicit_and_denominator_is_not_deduplicated(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["defeat"])
        reports = json.loads((a / "reports.json").read_text()) * 2
        write(a / "reports.json", reports); write(a / "summary.json", {"runs": 2, "reports": reports})
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertEqual(result["left"]["summary"]["runs_in_denominator"], 2)
        self.assertTrue(any("Duplicate seed" in error for error in result["errors"]))

    def test_signed_paired_difference_uses_full_seed_denominator(self):
        a = self.batch("a", "beam", ["defeat", "timeout"])
        b = self.batch("b", "coordinator", ["victory", "timeout"])
        result = self.compare(a, b)
        self.assertTrue(result["comparable"], result["errors"])
        self.assertEqual(result["paired"]["win_rate_difference_right_minus_left"], .5)
        self.assertEqual(result["paired"]["right_wins_left_does_not"], 1)
        self.assertEqual(result["paired"]["neither_wins"], 1)

    def test_only_behavior_source_hashes_are_frozen(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["defeat"])
        self.mutate_manifest("b-0", lambda m: m["versions"]["sources"].update({
            "compare_batches.py": {"sha256": "b" * 64, "bytes": 42}}))
        self.assertTrue(self.compare(a, b)["comparable"])
        self.mutate_manifest("b-0", lambda m: m["versions"]["sources"]["selection_policy.py"].update(sha256="b" * 64))
        self.assertFalse(self.compare(a, b)["comparable"])

    def test_actual_request_cannot_silently_use_a_wider_profile(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["defeat"])
        path = self.root / "b-0" / "trace.jsonl"
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        next(row for row in rows if row["request"]["cmd"] == "solve")["request"]["search_profile"]["beam_width"] = 999
        path.write_text("\n".join(json.dumps(row) for row in rows) + "\n")
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("frozen manifest" in error for error in result["errors"]))

    def test_protocol_allows_same_backend_declared_profile_and_time_difference(self):
        left, right = self.protocol_configs()
        protocol = self.protocol(left, right, seeds=["seed-0", "seed-1"])
        expected_hash = hashlib.sha256(protocol.read_bytes()).hexdigest()
        a = self.batch("a", "coordinator", ["defeat", "environment_error"], config=left)
        b = self.batch("b", "coordinator", ["victory", "timeout"], config=right)
        result = compare_batches(a, b, protocol=protocol)
        self.assertTrue(result["comparable"], result["errors"])
        self.assertTrue(result["predeclaration_chronology_verified"])
        self.assertEqual(result["protocol"]["sha256"], expected_hash)
        changes = {item["field"] for item in result["declared_solver_config_differences"]}
        self.assertIn("solver_config.first_budget_ms", changes)
        self.assertIn("solver_config.search_profile.beam_width", changes)
        self.assertNotIn("solver_config.solver_backend", changes)
        self.assertEqual(result["paired"]["win_rate_difference_right_minus_left"], .5)
        self.assertEqual(result["right"]["summary"]["runs_in_denominator"], 2)
        self.assertEqual(result["right"]["summary"]["timeouts"], 1)

    def test_protocol_rejects_undeclared_config_even_when_manifest_and_trace_agree(self):
        left, right = self.protocol_configs()
        protocol = self.protocol(left, right)
        right["growth_budgets"]["GeneticAlgorithm"] = 8
        a = self.batch("a", "coordinator", ["defeat"], config=left)
        b = self.batch("b", "coordinator", ["defeat"], config=right)
        result = compare_batches(a, b, protocol=protocol)
        self.assertFalse(result["comparable"])
        self.assertIsNone(result["paired"])
        self.assertTrue(any("Solver config differs from predeclared" in error for error in result["errors"]))

    def test_protocol_common_conditions_are_not_inferred_from_matching_arms(self):
        left, right = self.protocol_configs()
        protocol = self.protocol(left, right)
        value = json.loads(protocol.read_text())
        value["conditions"]["selection_budget"] = 999
        write(protocol, value)
        a = self.batch("a", "coordinator", ["defeat"], config=left)
        b = self.batch("b", "coordinator", ["defeat"], config=right)
        result = compare_batches(a, b, protocol=protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("Common conditions differ" in error for error in result["errors"]))

    def test_protocol_after_first_run_is_not_predeclared(self):
        left, right = self.protocol_configs()
        a = self.batch("a", "coordinator", ["defeat"], config=left)
        protocol = self.protocol(left, right)
        b = self.batch("b", "coordinator", ["defeat"], config=right)
        result = compare_batches(a, b, protocol=protocol)
        self.assertFalse(result["comparable"])
        self.assertFalse(result["predeclaration_chronology_verified"])
        self.assertTrue(any("precede every journal run_start" in error for error in result["errors"]))

    def test_protocol_missing_timestamp_cannot_claim_chronology(self):
        left, right = self.protocol_configs()
        protocol = self.protocol(left, right)
        a = self.batch("a", "coordinator", ["defeat"], config=left)
        b = self.batch("b", "coordinator", ["defeat"], config=right)
        path = self.root / "b-0" / "decisions.jsonl"
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        del rows[0]["recorded_at_unix"]
        path.write_text("\n".join(json.dumps(row) for row in rows) + "\n")
        result = compare_batches(a, b, protocol=protocol)
        self.assertFalse(result["comparable"])
        self.assertFalse(result["predeclaration_chronology_verified"])
        self.assertTrue(any("recorded_at_unix" in error for error in result["errors"]))

    def test_protocol_missing_seed_in_both_arms_remains_in_planned_denominator(self):
        left, right = self.protocol_configs()
        protocol = self.protocol(left, right, seeds=["seed-0", "seed-1"])
        a = self.batch("a", "coordinator", ["defeat"], config=left)
        b = self.batch("b", "coordinator", ["victory"], config=right)
        result = compare_batches(a, b, protocol=protocol)
        self.assertFalse(result["comparable"])
        for arm in ("left", "right"):
            self.assertEqual(result[arm]["summary"]["runs_in_denominator"], 2)
            self.assertEqual(result[arm]["summary"]["missing_runs"], 1)
        self.assertEqual(result["right"]["summary"]["end_to_end_win_rate"], .5)
        self.assertEqual(result["per_seed"][-1]["right"]["category"], "missing_run")

    def test_protocol_partial_config_is_rejected_instead_of_using_current_defaults(self):
        left, right = self.protocol_configs()
        del right["retry_budget_ms"]
        protocol = self.protocol(left, right)
        with self.assertRaisesRegex(ValueError, "full supported solver_config"):
            load_protocol(protocol)

    def test_execution_plan_pre_run_hash_is_checked_when_present(self):
        left, right = self.protocol_configs()
        protocol = self.protocol(left, right)
        plan_path = self.root / "execution-plan.json"
        plan = {"created_utc": datetime.now(timezone.utc).isoformat(), "protocol": {
            "sha256": hashlib.sha256(protocol.read_bytes()).hexdigest(), "bytes": protocol.stat().st_size}}
        write(plan_path, plan)
        a = self.batch("a", "coordinator", ["defeat"], config=left)
        b = self.batch("b", "coordinator", ["defeat"], config=right)
        result = compare_batches(a, b, protocol=protocol)
        self.assertTrue(result["comparable"], result["errors"])
        self.assertTrue(result["execution_plan"]["pre_run_protocol_hash_verified"])
        invalid = copy.deepcopy(plan)
        invalid["protocol"]["sha256"] = "f" * 64
        write(plan_path, invalid)
        result = compare_batches(a, b, protocol=protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("Execution plan protocol hash" in error for error in result["errors"]))
        plan["created_utc"] = datetime.now(timezone.utc).isoformat()
        write(plan_path, plan)
        result = compare_batches(a, b, protocol=protocol)
        self.assertFalse(result["comparable"])
        self.assertFalse(result["execution_plan"]["pre_run_protocol_hash_verified"])
        self.assertTrue(any("before every run_start" in error for error in result["errors"]))

    def test_modern_behavior_sources_required_and_old_absence_stays_compatible(self):
        a = self.batch("a", "beam", ["defeat"])
        b = self.batch("b", "coordinator", ["defeat"])
        for name in ("a-0", "b-0"):
            self.mutate_manifest(name, lambda m: [m["versions"]["sources"].pop(k)
                for k in ("selection_context.py", "mechanism_facts.py")])
        self.assertTrue(self.compare(a, b)["comparable"])
        for name in ("a-0", "b-0"):
            self.mutate_manifest(name, lambda m: m["provenance"].update(version="initial-stat-mechanism-v3"))
        result = self.compare(a, b)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("Modern v3 policy is missing behavior source" in error for error in result["errors"]))


if __name__ == "__main__":
    unittest.main()
