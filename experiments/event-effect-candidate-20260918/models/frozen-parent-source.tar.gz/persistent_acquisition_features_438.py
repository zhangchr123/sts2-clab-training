"""438 public residual features, adding observed ancient identity and nominal effects."""
import math
from reference_archetype_features import (PARAMETERS as ORIGINAL_PARAMETERS,CONTRACT as ORIGINAL_CONTRACT,
    PRIOR,PRIOR_PATH,PRIOR_EVIDENCE,features as original_features,_acquired_cards)
from persistent_power_features import PARAMETERS as POWER_PARAMETERS,FACTS,ENGINE_SHA,features as card_features
from decision_data import DataContractError

from ancient_reward_features import PARAMETERS as ANCIENT_PARAMETERS, CONTRACT as ANCIENT_CONTRACT, features as ancient_features
EXTRA_PARAMETERS=(*POWER_PARAMETERS,*ANCIENT_PARAMETERS)
PARAMETERS=(*ORIGINAL_PARAMETERS,*EXTRA_PARAMETERS)
CONTRACT=dict(version='persistent-ancient-reward-features-v1',original_parameters=321,extra_parameters=len(EXTRA_PARAMETERS),ancient_contract=ANCIENT_CONTRACT,
    original_contract=ORIGINAL_CONTRACT,engine_sha256=ENGINE_SHA,facts=FACTS,
    scope='public_acquisitions_and_starting_ancient_options',multi_card='sum_each_selected_occurrence',
    nominal_counters_not_guaranteed_effects=True,strategic_weights_not_prescribed=True)


def extra_features(state,row,candidate):
    result=dict.fromkeys(EXTRA_PARAMETERS,0.)
    for card in _acquired_cards(row,candidate):
        try:values=card_features(card)
        except ValueError as exc:raise DataContractError(str(exc)) from exc
        for name in POWER_PARAMETERS:result[name]+=values[name]
    result.update(ancient_features(state,row,candidate))
    return result


def features(state,row,candidate,route_input=None):
    original=original_features(state,row,candidate,route_input)
    if tuple(original)!=ORIGINAL_PARAMETERS:raise DataContractError('Original 321-feature order changed')
    return {**original,**extra_features(state,row,candidate)}


def zero_extend(parameters):
    if set(parameters)!=set(ORIGINAL_PARAMETERS) or any(type(x) not in (float,int)
            or not math.isfinite(x) or abs(x)>4 for x in parameters.values()):
        raise DataContractError('Invalid original 321-parameter vector')
    return {**{name:parameters[name] for name in ORIGINAL_PARAMETERS},**dict.fromkeys(EXTRA_PARAMETERS,0.)}
