"""Synthetic registered-prefix comparison contracts; no games, fit or test returns."""
import copy
from pathlib import Path
import unittest

import test_compare_policy_batches as comparison_fixtures
import test_prefix_health_policy as prefix_fixtures
from compare_batches import policy_identity
from compare_policy_batches import (POLICY_SOURCES, PREFIX_POLICY_SOURCES, compare_policy_batches,
                                    load_policy_protocol, required_policy_sources, validate_prefix_registration)
from run_metadata import file_evidence
from selection_policy import SelectionPolicy


class PrefixPolicyComparisonTests(unittest.TestCase):
    def setUp(self):
        self.comparison = comparison_fixtures.ComparePolicyBatchTests(methodName="run")
        self.comparison.setUp()
        self.addCleanup(self.comparison.doCleanups)
        self.prefix = prefix_fixtures.PrefixHealthPolicyTests(methodName="run")
        self.prefix.setUp()
        self.addCleanup(self.prefix.doCleanups)
        self.prefix.fixture()
        self.comparison.declare()
        self.root, self.document, self.protocol = self.comparison.root, self.comparison.document, self.comparison.protocol
        self.config = self.comparison.config
        collection = self.prefix.protocol_path
        from prefix_interventions import read_json
        source = read_json(collection)
        runtime = {name: {"path": str(self.root / (name + ".dll")), "sha256": "a" * 64, "bytes": 100}
                   for name in ("engine", "solver", "ritsu")}
        source["frozen_sources"] = list(runtime.values())
        source["unavailable_gates"] = [{"seed": "excluded-source-root", "reason": "synthetic unavailable gate"}]
        source["gates"] = []
        for split in ("train", "validation", "test"):
            source["gates"].append({**copy.deepcopy(self.prefix.gate), "seed": split + "-source-root",
                "gate_id": split + "-gate", "source_runtime": copy.deepcopy(runtime),
                "source_solver_config": copy.deepcopy(self.config)})
        self.prefix.write(collection, source)
        self.prefix.model_data.update(source_protocol=file_evidence(collection), runtime_and_collection_sources=source["frozen_sources"],
            split_seeds={split: [split + "-source-root"] for split in ("train", "validation", "test")},
            complete_split_seeds={split: [split + "-source-root"] for split in ("train", "validation", "test")})
        self.prefix.register()
        # Construction checks registration; it neither fits nor chooses/scores
        # a prospective state. The source fixture remains explicitly synthetic.
        from prefix_health_policy import PrefixHealthPolicy
        policy = SelectionPolicy(PrefixHealthPolicy(self.prefix.model_path,
            protocol_path=collection, solver_config=self.config, seed="declaration-only"), max_evaluations=256)
        arm = self.document["arms"]["right"]
        arm["policy_identity"] = policy_identity(policy.provenance)
        arm["sampling"]["model_path"] = str(self.prefix.model_path)
        arm["model_artifacts"] = [{**file_evidence(self.prefix.model_path),
            "sampling_field": "model_path", "policy_hash_field": "version"}]
        arm["registered_prefix_sources"] = {"model": file_evidence(self.prefix.model_path),
            "protocol": file_evidence(collection), "fit_receipt": file_evidence(self.prefix.receipt_path),
            "training_audit": file_evidence(self.prefix.audit_path)}
        self.comparison.write = comparison_fixtures.write
        comparison_fixtures.write(self.protocol, self.document)

    def declare(self):
        comparison_fixtures.write(self.protocol, self.document)
        return load_policy_protocol(self.protocol)

    def batches(self):
        paths = self.comparison.batches()
        root = Path(__file__).resolve().parent
        for batch in ("a", "b"):
            for index in range(2):
                def update(metadata):
                    metadata["versions"]["sources"].update({name: file_evidence(root / name)
                        for name in required_policy_sources(self.document)})
                    metadata["versions"].update({name: {"sha256": "a" * 64, "bytes": 100}
                                                for name in ("godot", "ritsu")})
                self.comparison.rewrite_run(f"{batch}-{index}", update)
        return paths

    def test_registered_prefix_identity_and_common_union_are_verified(self):
        loaded = self.declare()
        registration = loaded["prefix_registrations"]["right"]
        self.assertTrue(registration["verified"])
        self.assertEqual(set(registration["registered_sources"]), {"model", "protocol", "fit_receipt", "training_audit"})
        self.assertEqual(registration["source_root_seeds"],
                         ["excluded-source-root", "test-source-root", "train-source-root", "validation-source-root"])
        self.assertEqual(required_policy_sources(self.document), tuple(dict.fromkeys((*POLICY_SOURCES, *PREFIX_POLICY_SOURCES))))
        a, b = self.batches()
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertTrue(result["comparable"], result["errors"])
        self.assertTrue(result["right"]["prefix_model_registration"]["verified"])
        self.assertEqual(result["paired"]["verified_a10_victory"]["pairs"], 2)
        self.assertFalse(result["right"]["prefix_model_registration"]["A10_victory_model"])

    def test_every_source_split_and_unavailable_root_is_forbidden_for_prospective_reuse(self):
        for seed in ("train-source-root", "validation-source-root", "test-source-root", "excluded-source-root"):
            with self.subTest(seed=seed):
                with self.assertRaisesRegex(ValueError, "reuses"):
                    validate_prefix_registration(self.document["arms"]["right"], [seed], self.document["conditions"])

    def test_missing_or_wrong_registered_source_identity_is_rejected(self):
        arm = self.document["arms"]["right"]
        for mutate in (lambda a: a.pop("registered_prefix_sources"),
                       lambda a: a["registered_prefix_sources"].pop("training_audit"),
                       lambda a: a["registered_prefix_sources"]["fit_receipt"].update(sha256="b" * 64),
                       lambda a: a["policy_identity"]["source_protocol"].update(sha256="b" * 64),
                       lambda a: a["sampling"].update(model_path="not-registered.json")):
            with self.subTest(mutate=mutate):
                changed = copy.deepcopy(arm)
                mutate(changed)
                with self.assertRaises(ValueError):
                    validate_prefix_registration(changed, ["new-root"], self.document["conditions"])

    def test_wrong_scope_target_or_search_budget_cannot_relabel_prefix_model(self):
        arm = self.document["arms"]["right"]
        for mutate in (lambda a: a["policy_identity"].update(target_semantics="act1_survival_probability"),
                       lambda a: a["policy_identity"]["model_scope"].update(uses_per_run=2),
                       lambda a: a["policy_identity"].update(A10_victory_model=True),
                       lambda a: a["sampling"].update(selection_budget=128)):
            with self.subTest(mutate=mutate):
                changed = copy.deepcopy(arm)
                mutate(changed)
                with self.assertRaises(ValueError):
                    validate_prefix_registration(changed, ["new-root"], self.document["conditions"])

    def test_source_union_is_required_in_rules_arm_too(self):
        a, b = self.batches()
        self.comparison.rewrite_run("a-0", lambda m: m["versions"]["sources"].pop("prefix_health_policy.py"))
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("source" in e.lower() for e in result["errors"]))

    def test_identically_wrong_live_feature_hashes_are_not_accepted_as_common(self):
        a, b = self.batches()
        for batch in ("a", "b"):
            for index in range(2):
                self.comparison.rewrite_run(f"{batch}-{index}", lambda m:
                    m["versions"]["sources"]["initial_policy.py"].update(sha256="b" * 64))
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("registered paired model" in e for e in result["errors"]))

    def test_identically_changed_original_solver_or_missing_godot_is_rejected(self):
        a, b = self.batches()
        for batch in ("a", "b"):
            for index in range(2):
                self.comparison.rewrite_run(f"{batch}-{index}", lambda m: m["versions"]["solver"].update(sha256="b" * 64))
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("registered paired-prefix collection" in e for e in result["errors"]))

    def test_missing_godot_and_ritsu_cannot_be_hidden_by_both_arms(self):
        a, b = self.batches()
        for batch in ("a", "b"):
            for index in range(2):
                self.comparison.rewrite_run(f"{batch}-{index}", lambda m:
                    [m["versions"].pop(name) for name in ("godot", "ritsu")])
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertTrue(any("Godot" in e for e in result["errors"]))
        self.assertTrue(any("Ritsu" in e for e in result["errors"]))

    def test_full_planned_denominator_retains_missing_seed_and_environment_failure(self):
        self.document["seeds"].append("missing-new-root")
        self.declare()
        a, b = self.batches()
        result = compare_policy_batches(a, b, protocol=self.protocol)
        self.assertFalse(result["comparable"])
        self.assertIsNone(result["paired"])
        for arm in ("left", "right"):
            self.assertEqual(result[arm]["summary"]["runs_in_denominator"], 3)
            self.assertEqual(result[arm]["summary"]["missing_runs"], 1)
        self.assertEqual(result["left"]["summary"]["timeouts"], 1)
        self.assertEqual(len(result["per_seed"]), 3)


if __name__ == "__main__":
    unittest.main()
