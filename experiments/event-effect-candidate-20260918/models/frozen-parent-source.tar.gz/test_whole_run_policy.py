"""Synthetic fixtures only; these tests never contribute rollout outcomes."""
import copy
import json
from pathlib import Path
import random
import tempfile
import unittest
from unittest.mock import patch

import sample_runs
import train_whole_run
from audit_batch import _Audit
from decision_data import DataContractError, read_decisions
from initial_policy import InitialPolicy
from selection_policy import SelectionPolicy, validate_selection_evidence
from test_initial_policy import state
from test_selection_policy import selection_state
from whole_run_audit import validate_whole_run_choices
from whole_run_policy import PARAMETERS, WholeRunPolicy, make_artifact


class WholeRunTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = json.loads((sample_runs.ROOT / 'configs/defect-v3-base.json').read_text())
        self.path = self.root / 'parameters.json'
        self.write()

    def write(self, **parameters):
        self.artifact = make_artifact(dict(dict.fromkeys(PARAMETERS, 0.), **parameters), self.config,
                                      training={'synthetic_test_only': True})
        self.path.write_text(json.dumps(self.artifact), encoding='utf-8')

    def policy(self, epsilon=.31):
        return sample_runs.build_policy('fixture', self.config, epsilon=epsilon,
                                       model_path=self.path, selection_budget=8)

    def test_zero_scores_and_rng_equal_v3_across_acts_and_implicit_space(self):
        actual = self.policy()
        expected = SelectionPolicy(InitialPolicy(random_seed='fixture', epsilon=.31), max_evaluations=8)
        for act in (1, 2, 3):
            for current, purpose in ((state(), None), (selection_state(n=9, minimum=0, maximum=9), 'remove')):
                current['context'].update(act=act, ascension=10, combat_in_progress=False)
                rng = actual.base.rng.getstate()
                actual.score(current, selection_purpose=purpose)
                self.assertEqual(actual.base.rng.getstate(), rng)
                a = actual.choose(current, selection_purpose=purpose)
                b = expected.choose(current, selection_purpose=purpose)
                self.assertEqual(a['request'], b['request'])
                self.assertEqual(a['exploration'], b['exploration'])
                self.assertEqual([r['score'] for r in a['scoring']['scores']],
                                 [r['score'] for r in b['scoring']['scores']])
                self.assertEqual(actual.base.rng.getstate(), expected.base.rng.getstate())

    def test_acquire_parameter_changes_only_actual_acquisition_score(self):
        self.write(card_acquire=-2.)
        current = state(); current['context']['act'] = 2
        result = self.policy().score(current)
        for row in result['scores']:
            delta = 0 if row['is_skip'] else -2.
            self.assertAlmostEqual(row['score'] - row['rule_score'], delta)
            self.assertEqual(row['learned_residual'], delta)
        current.update(decision='card_select', min_select=1, max_select=1)
        self.assertTrue(all(r['learned_residual'] == 0 for r in self.policy().score(current)['scores']))

    def test_invalid_parameters_config_and_live_artifact_drift_rejected(self):
        for value in (float('nan'), 4.01, True):
            self.write(card_acquire=value)
            with self.assertRaises(DataContractError):
                self.policy()
        self.write()
        with self.assertRaises(DataContractError):
            WholeRunPolicy(self.path, solver_config={}, seed='fixture')
        policy = self.policy()
        self.write(card_acquire=1.)
        current = state(); current['context']['act'] = 1
        with self.assertRaises(DataContractError):
            policy.score(current)

    def test_explicit_combinations_do_not_revalidate_full_space_per_score(self):
        self.write(card_acquire=1.)
        current = selection_state(n=7, minimum=3, maximum=3)
        current['context'].update(ascension=10, act=2)
        policy = self.policy()
        with patch('decision_data.materialize_candidate', side_effect=AssertionError('Quadratic explicit revalidation')):
            packet = policy.base.score(current, selection_purpose='remove')
        self.assertEqual(len(packet['scores']), 210)
        self.assertTrue(all(r['learned_residual'] == 0 for r in packet['scores']))

    def test_sampler_raw_audit_reconstruction_and_score_tamper(self):
        initial = state(); initial['context'].update(act=1, floor=2, integrity_recovery_used=False)
        terminal = copy.deepcopy(initial)
        terminal.update(decision='game_over', victory=False)
        terminal['player']['hp'] = 0

        class FakeBridge:
            def send(self, **request):
                return copy.deepcopy(initial if request['cmd'] == 'start_run' else terminal)
            def close(self):
                pass

        with patch.object(sample_runs, 'ROOT', self.root), patch.object(sample_runs, 'Bridge', return_value=FakeBridge()):
            report = sample_runs.run_one('fixture', 'fixture', settings=self.config, epsilon=0.,
                                         model_path=self.path, selection_budget=8)
        audit = _Audit(self.root / 'outputs' / 'synthetic-audit')
        records, _ = audit.run(report)
        self.assertEqual(audit.issues, [])
        destination = self.root / 'deep' / 'generation-00'
        destination.mkdir(parents=True)
        with patch.object(train_whole_run, 'ROOT', self.root):
            result = train_whole_run.audit_training_run(report, destination, seed='fixture')
        self.assertTrue(result['audit_passed'])
        self.assertFalse(result['goal_success_for_search'])
        policies = {r['decision_id']: r for r in map(json.loads,
            (self.root / 'outputs/fixture/policy.jsonl').read_text().splitlines())}
        policies[records[0]['decision_id']]['scoring']['scores'][0]['score'] += 1
        with self.assertRaises(DataContractError):
            validate_whole_run_choices(records, policies)

    def test_cem_population_elite_success_priority_and_complete_denominator(self):
        center, std = dict.fromkeys(PARAMETERS, 0.), dict.fromkeys(PARAMETERS, .7)
        vectors = train_whole_run.population(center, std, random.Random('fixture'))
        self.assertEqual(len(vectors), 9)
        for i in (1, 3, 5, 7):
            for k in PARAMETERS:
                self.assertEqual(vectors[i][k], -vectors[i+1][k])
                self.assertLessEqual(abs(vectors[i][k]), 4.)
        scores = [{'goal_successes': int(i == 8), 'mean_fitness': i / -10} for i in range(9)]
        updated, deviations, elites = train_whole_run.update_distribution(vectors, scores, center, std)
        self.assertEqual(elites, [8, 0, 1])
        self.assertNotEqual(updated, center)
        self.assertTrue(all(v >= .15 for v in deviations.values()))
        with self.assertRaises(ValueError):
            train_whole_run.update_distribution(vectors, scores[:-1], center, std)

    def test_prepared_train_and_evaluation_seeds_are_disjoint_and_complete(self):
        path = self.root / 'protocol' / 'protocol.json'
        protocol = train_whole_run.prepare(path, name='fixture-protocol')
        training = sum(protocol['training_seeds'], [])
        evaluation = protocol['reserved_evaluation_seeds']
        self.assertEqual(len(set(training + evaluation)), 48)
        self.assertEqual(protocol['planned_training_games'], 162)
        self.assertFalse(protocol['llm_gameplay_choices'])
        self.assertFalse(protocol['goal_complete_from_finite_training_games'])


if __name__ == '__main__':
    unittest.main()
