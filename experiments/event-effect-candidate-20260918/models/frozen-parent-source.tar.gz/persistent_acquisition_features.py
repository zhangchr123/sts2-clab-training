"""471 public features: the frozen 438 plus 33 functional-role descriptors."""
from persistent_acquisition_features_438 import (
    PARAMETERS as OLD_PARAMETERS, CONTRACT as OLD_CONTRACT, PRIOR, PRIOR_PATH,
    PRIOR_EVIDENCE, features as old_features, zero_extend as old_zero_extend)
from functional_role_features import PARAMETERS as ROLE_PARAMETERS, extra_features as role_features
from decision_data import DataContractError

PARAMETERS = (*OLD_PARAMETERS, *ROLE_PARAMETERS)
CONTRACT = dict(version='persistent-functional-role-features-v1', original_parameters=438,
    extra_parameters=33, original_contract=OLD_CONTRACT,
    role_features='public pre-choice role gaps, energy support, repeat utility and rarity proxies',
    limitations=['partial role coverage', 'no relic energy', 'no calibrated future reward probability',
                 'no guaranteed high-cost bootstrap', 'no actual combat draw order'])

def features(state, row, candidate, route_input=None):
    old = old_features(state, row, candidate, route_input)
    if tuple(old) != OLD_PARAMETERS: raise DataContractError('Original 438-feature order changed')
    return {**old, **role_features(state, row, candidate)}

def zero_extend(parameters):
    return {**old_zero_extend(parameters), **dict.fromkeys(ROLE_PARAMETERS, 0.)}
