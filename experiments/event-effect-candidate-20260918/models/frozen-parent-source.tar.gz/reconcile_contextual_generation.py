"""Reconcile a finished CEM generation from original traces and recorded allocation.

Read-only for every training source. Writes a new receipt, never changes results.
"""
import argparse
import math
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from boss_progress import observed_progress
from prefix_interventions import read_json, read_lines, require, unchanged
from run_metadata import file_evidence
from train_contextual_run import ROOT, METHOD, VERSION, WARM_VERSION, write_new
from contextual_policy import PARAMETERS


def reconcile(protocol_path, generation, output):
    protocol_path = Path(protocol_path).resolve()
    protocol = read_json(protocol_path)
    require(protocol['schema_version'] in {VERSION, WARM_VERSION} and protocol['method'] == METHOD, 'Unsupported optimizer')
    folder = protocol_path.parent / f'generation-{generation:02d}'
    summary = read_json(folder / 'summary.json')
    allocation = read_json(folder / 'allocation.json')
    seeds = protocol['training_seeds'][generation]
    require(summary['generation'] == generation and allocation['seeds'] == seeds, 'Generation/seed mismatch')
    require(unchanged(protocol['frozen_sources'] + allocation['artifacts'] + [summary['source_allocation']]),
            'Frozen input or allocation changed')
    order = [(r['candidate'], r['seed']) for r in allocation['order']]
    require(len(order) == len(set(order)) == 17 * len(seeds)
        and set(order) == {(c, s) for c in range(17) for s in seeds}, 'Incomplete population allocation')
    evaluations, audited_sources = [], []
    for candidate in range(17):
        artifact = allocation['artifacts'][candidate]
        require(read_json(artifact['path'])['parameters'] == allocation['vectors'][candidate], 'Candidate parameter drift')
        returns, wins, errors, acts = [], 0, 0, []
        for index, seed in enumerate(seeds):
            label = f"{protocol['name']}-g{generation:02d}-c{candidate:02d}-s{index:02d}"
            receipt_path = folder / (label + '-audit.json')
            receipt = read_json(receipt_path)
            report = receipt['report']
            run = ROOT / 'outputs' / label
            manifest = read_json(run / 'manifest.json')
            require(receipt['audit_passed'] is True and not receipt['issues'], 'Failed raw run audit')
            require(unchanged(receipt['actual_source_evidence']), 'Audited raw source changed')
            require(report == read_json(run / 'report.json') and report['seed'] == seed
                and manifest['seed'] == seed and manifest['provenance']['policy_source'] == artifact,
                'Run/report/candidate mismatch')
            observed = observed_progress(read_lines(run / 'trace.jsonl'), natural=True, expected_seed=seed)
            require(observed == receipt['goal'], 'Actual first-boss/progress evidence mismatch')
            good = report['outcome'] in {'defeat', 'victory'} and not observed['errors']
            fitness = observed['shaped_progress_not_win_probability'] if good else -1.
            success = good and observed['natural_goal_success']
            require(fitness == receipt['fitness'] and success == receipt['goal_success_for_search'], 'Training return mismatch')
            returns.append(fitness); wins += success
            errors += report['outcome'] not in {'defeat', 'victory'}
            acts.append(observed['max_act_observed'])
            audited_sources.append(file_evidence(receipt_path))
        evaluations.append({'candidate': candidate, 'planned_games': len(seeds), 'actual_games': len(returns),
            'goal_successes': wins, 'mean_fitness': sum(returns) / len(seeds), 'environment_errors_or_timeouts': errors})
    require(evaluations == summary['evaluations'], 'Generation aggregate differs from all actual runs')
    elites = sorted(range(17), key=lambda c: (-evaluations[c]['goal_successes'], -evaluations[c]['mean_fitness'], c))[:5]
    require(elites == summary['elite_indices'] and summary['best_candidate_artifact'] == allocation['artifacts'][elites[0]],
            'Selected elites/candidate differ from predeclared ranking')
    updated, deviations = {}, {}
    for key in PARAMETERS:
        values = [allocation['vectors'][c][key] for c in elites]
        mean = sum(values) / 5
        variance = sum((v - mean) ** 2 for v in values) / 5
        updated[key] = .5 * allocation['center_before'][key] + .5 * mean
        deviations[key] = max(.15, .5 * allocation['std_before'][key] + .5 * math.sqrt(variance))
    require(updated == summary['center_after'] and deviations == summary['std_after'], 'Incorrect learned distribution')
    following = protocol_path.parent / f'generation-{generation+1:02d}' / 'allocation.json'
    if following.exists():
        next_allocation = read_json(following)
        require(next_allocation['center_before'] == updated and next_allocation['std_before'] == deviations
            and next_allocation['vectors'][0] == updated, 'Next generation did not use learned parameters')
    result = {'passed': True, 'generation': generation, 'actual_games': len(audited_sources),
        'source_protocol': file_evidence(protocol_path), 'source_summary': file_evidence(folder / 'summary.json'),
        'run_audit_sources': audited_sources, 'evaluations_recomputed_from_original_traces': evaluations,
        'elite_indices': elites, 'distribution_recomputed': True,
        'next_generation_uses_updated_distribution': following.exists(),
        'learned_center_changed': updated != allocation['center_before'],
        'independent_evaluation_or_goal_completion_claimed': False,
        'reconciler_source': file_evidence(Path(__file__).resolve())}
    write_new(output, result)
    return result


if __name__ == '__main__':
    import json
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--protocol', required=True, type=Path)
    p.add_argument('--generation', required=True, type=int)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    r = reconcile(args.protocol, args.generation, args.output)
    print(json.dumps({k: r[k] for k in ('passed', 'generation', 'actual_games', 'elite_indices',
        'learned_center_changed', 'next_generation_uses_updated_distribution')}))
