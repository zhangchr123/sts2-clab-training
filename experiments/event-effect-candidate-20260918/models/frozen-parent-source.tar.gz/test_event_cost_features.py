"""Exact event-variable attribution, escalation, and unknown-effect boundaries."""
import unittest
import circulation_capability_features as t
import event_cost_features as e
from decision_data import DataContractError


class EventCostTests(unittest.TestCase):
    def values(self,key,variables,hp=5,maximum=80):
        request={'action':'choose_option','args':{'option_index':0}}
        return e.extra_features({'decision':'event_choice','player':{'hp':hp,'max_hp':maximum}},
            {'request':request},{'request':request,'evidence':{'text_key':key,'vars':variables}})

    def test_shared_option_variables_are_not_all_charged(self):
        variables={'HpLoss':6,'Gold':52,'Curse':0}
        expensive=self.values('THIS_OR_THAT.pages.INITIAL.options.PLAIN',variables)
        alternate=self.values('THIS_OR_THAT.pages.INITIAL.options.ORNATE',variables)
        self.assertEqual(expensive['event_nominal_hp_cost_per_current_hp'],1.2)
        self.assertEqual(expensive['event_nominal_cost_reaches_current_hp'],1.)
        self.assertEqual(expensive['event_explicit_gold_gain_hundreds'],.52)
        self.assertTrue(all(v==0 for v in alternate.values()))
        variables={'SoloHp':18,'SoloGold':150,'JoinForcesGold':60}
        alternate=self.values('JUNGLE_MAZE_ADVENTURE.pages.INITIAL.options.JOIN_FORCES',variables)
        self.assertEqual(alternate['event_explicit_gold_gain_hundreds'],.6)
        self.assertEqual(alternate['event_nominal_cost_reaches_current_hp'],0.)

    def test_escalating_hold_on_keys_use_current_cost_and_stop_on_unknown(self):
        keys=['SLIPPERY_BRIDGE.pages.INITIAL.options.HOLD_ON_0']
        keys += [f'SLIPPERY_BRIDGE.pages.HOLD_ON_{i}.options.HOLD_ON_{i+1 if i<6 else "LOOP"}' for i in range(7)]
        keys += ['SLIPPERY_BRIDGE.pages.HOLD_ON_LOOP.options.HOLD_ON_LOOP']
        for key in keys:
            self.assertEqual(self.values(key,{'HpLoss':12},hp=6)['event_nominal_hp_cost_per_current_hp'],2.)
        self.assertEqual(self.values(keys[-1],{'HpLoss':3},hp=20)['event_nominal_hp_cost_per_current_hp'],.15)
        for key in ('SLIPPERY_BRIDGE.pages.HOLD_ON_6.options.HOLD_ON_7','UNKNOWN.options.DAMAGE'):
            self.assertTrue(all(v==0 for v in self.values(key,{'HpLoss':999}).values()))

    def test_invalid_numbers_rejected_and_current_hp_threshold_exact(self):
        key='THIS_OR_THAT.pages.INITIAL.options.PLAIN'
        for bad in (None,True,-1,float('nan'),float('inf')):
            with self.subTest(value=bad),self.assertRaises(DataContractError):self.values(key,{'HpLoss':bad,'Gold':52})
        for hp in (0,True,None,-1):
            with self.assertRaises(DataContractError):self.values(key,{'HpLoss':6,'Gold':52},hp=hp)
        self.assertEqual(self.values(key,{'HpLoss':6,'Gold':52},hp=6)['event_nominal_cost_reaches_current_hp'],1.)
        self.assertEqual(self.values(key,{'HpLoss':6,'Gold':52},hp=7)['event_nominal_cost_reaches_current_hp'],0.)
        weights={k:(i%11-5)/3 for i,k in enumerate(t.PARAMETERS)}
        extended=e.zero_extend(weights)
        self.assertEqual(len(extended),265)
        self.assertEqual({k:extended[k] for k in t.PARAMETERS},weights)


if __name__=='__main__':unittest.main(verbosity=2)
