"""Synthetic contracts for the frozen descriptive public-reference feature layer."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from audit_batch import _Audit
from decision_data import DataContractError, enumerate_candidates
from initial_policy import InitialPolicy
from public_route_learning import PARAMETERS as OLD_PARAMETERS
import public_route_policy as old_policy
import reference_archetype_features as features
import reference_archetype_policy as policy
from run_metadata import file_evidence
import sample_runs
from test_initial_policy import card, state


def reward(card_id, deck_ids):
    current = state([card(card_id)])
    current["context"]["act"] = 2
    current["player"]["deck"] = [card(identity) for identity in deck_ids]
    current["player"]["deck_size"] = len(deck_ids)
    return current


def extracted(current, index=0):
    packet = InitialPolicy().score(current)
    row = packet["scores"][index]
    candidate = next(item for item in enumerate_candidates(current)["candidates"]
                     if item["candidate_id"] == row["candidate_id"])
    return features.extra_features(current, row, candidate)


class ReferenceArchetypeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=policy.ROOT / "outputs")
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.config = json.loads((policy.ROOT / "configs/defect-v3-base.json").read_text(encoding="utf-8"))

    def model(self, weights=None, name="model.json"):
        path = self.folder / name
        path.write_text(json.dumps(policy.make_artifact(
            weights or dict.fromkeys(policy.PARAMETERS, 0.), self.config,
            training={"synthetic_contract_only": True})), encoding="utf-8")
        return path, sample_runs.build_policy("reference-contract", self.config, ascension=10,
            epsilon=0., model_path=path)

    def test_schema_extends_all_311_parameters_with_ten_bounded_descriptors(self):
        self.assertEqual(tuple(policy.PARAMETERS[:311]), tuple(OLD_PARAMETERS))
        self.assertEqual(len(policy.PARAMETERS), len(set(policy.PARAMETERS)))
        self.assertEqual(len(policy.PARAMETERS), 321)
        extended = features.zero_extend(dict.fromkeys(OLD_PARAMETERS, 0.25))
        self.assertEqual([extended[name] for name in features.EXTRA_PARAMETERS], [0.] * 10)
        with self.assertRaises(DataContractError):
            features.zero_extend({})

    def test_prior_binds_all_6389_references_90_cores_and_six_archetypes(self):
        prior = features.PRIOR
        self.assertEqual(prior["reference_runs"], 6389)
        self.assertEqual(len(prior["pairs"]), 90)
        self.assertEqual(tuple(prior["archetypes"]), features.ARCHETYPE_KEYS)
        self.assertEqual(file_evidence(prior["source_analysis"]["path"]), prior["source_analysis"])
        self.assertEqual(file_evidence(prior["source_accounting"]["path"]), prior["source_accounting"])
        self.assertEqual(prior["limitations"], ["winner_only_selection_bias",
            "cross_version_pooling_is_descriptive_only", "not_independently_replayed"])

    def test_single_card_prevalence_and_logged_pick_fraction_are_exact(self):
        values = extracted(reward("TURBO", ["ZAP", "DEFEND_DEFECT"]))
        row = features.PRIOR["cards"]["TURBO"]
        self.assertAlmostEqual(values["reference_card_prevalence"], row["prevalence"])
        self.assertAlmostEqual(values["reference_logged_pick_fraction"], row["logged_pick_fraction"])
        self.assertEqual(values["reference_pair_prevalence"], 0.)

    def test_missing_offer_fraction_and_unknown_card_emit_zero_without_invention(self):
        missing = extracted(reward("CLUMSY", ["ZAP"]))
        self.assertGreater(missing["reference_card_prevalence"], 0.)
        self.assertEqual(missing["reference_logged_pick_fraction"], 0.)
        unknown = extracted(reward("TOTALLY_UNKNOWN_REFERENCE_CARD", ["ZAP"]))
        self.assertTrue(all(value == 0. for value in unknown.values()))

    def test_pair_features_require_an_observed_partner_in_current_public_deck(self):
        absent = extracted(reward("BOOST_AWAY", ["ZAP", "DEFEND_DEFECT"]))
        present = extracted(reward("BOOST_AWAY", ["ROCKET_PUNCH", "ZAP"]))
        pair = next(row for row in features.PRIOR["pairs"]
                    if row["cards"] == ["BOOST_AWAY", "ROCKET_PUNCH"])
        self.assertEqual(absent["reference_pair_prevalence"], 0.)
        self.assertAlmostEqual(present["reference_pair_prevalence"], pair["prevalence"])
        self.assertAlmostEqual(present["reference_pair_lift_excess"], pair["lift"] - 1.)

    def test_two_marker_archetype_completes_and_duplicate_does_not_add_distinct_marker(self):
        frost = extracted(reward("GLACIER", ["COOLHEADED", "ZAP"]))
        duplicate = extracted(reward("COOLHEADED", ["COOLHEADED", "ZAP"]))
        self.assertEqual(frost["reference_archetype_frost_defense_affinity"], 1.)
        self.assertEqual(duplicate["reference_archetype_frost_defense_affinity"], 0.)

    def test_three_marker_archetype_affinity_is_half_then_complete(self):
        half = extracted(reward("TURBO", ["HOLOGRAM", "ZAP"]))
        complete = extracted(reward("TURBO", ["HOLOGRAM", "SKIM", "ZAP"]))
        key = "reference_archetype_draw_energy_recycle_affinity"
        self.assertEqual(half[key], .5)
        self.assertEqual(complete[key], 1.)

    def test_skip_and_nonacquisition_are_all_zero(self):
        current = reward("TURBO", ["HOLOGRAM", "ZAP"])
        packet = InitialPolicy().score(current)
        row = next(item for item in packet["scores"] if item["is_skip"])
        candidate = next(item for item in enumerate_candidates(current)["candidates"]
                         if item["candidate_id"] == row["candidate_id"])
        self.assertTrue(all(value == 0. for value in features.extra_features(current, row, candidate).values()))

    def test_zero_extension_preserves_old_scores_choice_and_rng_position(self):
        old_path = self.folder / "old.json"
        old_weights = dict.fromkeys(OLD_PARAMETERS, 0.)
        old_path.write_text(json.dumps(old_policy.make_artifact(old_weights, self.config,
            training={"synthetic_contract_only": True})), encoding="utf-8")
        new_path, new = self.model(features.zero_extend(old_weights), "new.json")
        old = sample_runs.build_policy("same-seed", self.config, ascension=10, epsilon=0., model_path=old_path)
        current = state([card("TURBO"), card("GLACIER", block=6, cost=2)])
        current["context"]["act"] = 2
        left, right = old.choose(copy.deepcopy(current)), new.choose(copy.deepcopy(current))
        self.assertEqual(left["request"], right["request"])
        self.assertEqual(left["policy_provenance"]["choice_count"], right["policy_provenance"]["choice_count"])
        fields = lambda result: [(row["request"], row["rule_score"], row["learned_residual"], row["score"])
                                 for row in result["scoring"]["scores"]]
        self.assertEqual(fields(left), fields(right))
        self.assertEqual(new_path, new.base.path)

    def test_reference_weight_changes_only_declared_residual(self):
        weights = dict.fromkeys(policy.PARAMETERS, 0.)
        weights["reference_card_prevalence"] = 1.
        _, model = self.model(weights)
        current = reward("TURBO", ["ZAP", "DEFEND_DEFECT"])
        row = next(item for item in model.score(current)["scores"] if not item["is_skip"])
        self.assertAlmostEqual(row["learned_residual"], features.PRIOR["cards"]["TURBO"]["prevalence"])
        self.assertEqual(row["rule_score"] + row["learned_residual"]
                         - row["deck_discipline"]["penalty"], row["score"])

    def test_artifact_and_live_source_tampering_are_rejected(self):
        path, model = self.model()
        damaged = json.loads(path.read_text(encoding="utf-8"))
        damaged["reference_contract"]["reference_runs"] = 1
        bad = self.folder / "bad.json"
        bad.write_text(json.dumps(damaged), encoding="utf-8")
        with self.assertRaises(DataContractError):
            sample_runs.build_policy("bad", self.config, ascension=10, epsilon=0., model_path=bad)
        current = reward("TURBO", ["ZAP"])
        with patch.object(policy, "feature_sources", return_value={}):
            with self.assertRaises(DataContractError):
                model.score(current)

    def test_user_deck_cap_and_latched_bing_bong_exception_remain_active(self):
        weights = dict.fromkeys(policy.PARAMETERS, 4.)
        _, model = self.model(weights)
        current = reward("TURBO", ["DEFEND_DEFECT"] * 36)
        self.assertEqual(model.choose(current)["request"]["action"], "skip_card_reward")
        current["player"]["relics"] = [{"id": "RELIC.BING_BONG"}]
        model.choose(current)
        current["player"]["relics"] = []
        self.assertTrue(all(not row["deck_discipline"]["hard_blocked"]
                            for row in model.score(current)["scores"]))

    def test_sampler_and_full_auditor_reconstruct_new_policy(self):
        current = reward("TURBO", ["HOLOGRAM", "ZAP"])
        final = copy.deepcopy(current)
        final.update(decision="game_over", victory=False)
        final["player"]["hp"] = 0
        requests = []

        class FixtureBridge:
            def send(self, **request):
                requests.append(copy.deepcopy(request))
                return copy.deepcopy(current if request["cmd"] == "start_run" else final)
            def close(self):
                pass

        path, _ = self.model()
        with patch.object(sample_runs, "ROOT", self.folder), patch.object(
                sample_runs, "Bridge", return_value=FixtureBridge()):
            report = sample_runs.run_one("synthetic-public-reference", "reference-contract",
                settings=self.config, epsilon=0., model_path=path)
        self.assertIsNone(report["error"], report["error"])
        self.assertEqual([request["cmd"] for request in requests], ["start_run", "action"])
        out = self.folder / "outputs/synthetic-public-reference"
        audit = _Audit(out)
        audit.run(report)
        self.assertEqual(audit.issues, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
