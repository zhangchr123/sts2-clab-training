"""Synthetic proofs and explicitly artificial original-DLL Seeker fixtures.

Run SeekerOfflineTests alone without launching a game. The live class writes
isolated UUID evidence files; none of these observations are training data.
"""
import copy
import json
import unittest
import uuid

from combat_executor import CombatExecutor
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence
import test_combat_executor as fixtures


def seeker_fixture():
    before, after, action = fixtures.EndingChoiceTests().fixture()
    action.update(CardId="SEEKER_STRIKE", CardStateKey="seeker")
    action["Choice"].update(SourcePile="Draw", ContextId="seeker:47:ZAP+0,DEFEND_DEFECT+0,STRIKE_DEFECT+0",
        Cards=[fixtures.token("strike", id="STRIKE_DEFECT")])
    after["choice_audit"]["parent"].update(card_id="SEEKER_STRIKE", card_key="seeker")
    after["choice_audit"]["events"][0]["source_pile"] = "Draw"
    return before, after, action


def offline_executor(after):
    return fixtures.EndingChoiceTests().engine(after)


class SeekerOfflineTests(unittest.TestCase):
    def test_complete_original_ending_return_means_unexecuted_not_selected(self):
        before, after, action = seeker_fixture()
        executor = offline_executor(after)
        original = copy.deepcopy((before, after, action))
        self.assertTrue(executor.resolve_ending_choice(before, after, action))
        proof = executor.solve_calls[0]["replay"][0]
        self.assertEqual(proof["kind"], "planned_choice_not_executed")
        self.assertEqual(proof["selected_cards"], [])
        self.assertEqual(proof["plan"], action["Choice"])
        self.assertTrue(proof["remaining_battle_plan_stopped"])
        self.assertEqual(executor.send.requests, [{"cmd": "choice_meta"}])
        self.assertEqual((before, after, action), original)

    def test_unverified_context_effect_replay_or_other_card_cannot_relax_choice_execution(self):
        mutations = [lambda a: a.update(CardId="HOLOGRAM"),
                     lambda a: a.update(ReplayCount=1),
                     lambda a: a.update(NestedChoices=[copy.deepcopy(a["Choice"])]),
                     lambda a: a["Choice"].update(Effect="Upgrade"),
                     lambda a: a["Choice"].update(SourcePile="Discard"),
                     lambda a: a["Choice"].update(Timing="TurnStart"),
                     lambda a: a["Choice"].update(SourceId="unrelated"),
                     lambda a: a["Choice"].update(ContextId=""),
                     lambda a: a["Choice"].update(ContextId="seeker:-1:STRIKE_DEFECT+0"),
                     lambda a: a["Choice"].update(ContextId="seeker:47:STRIKE_DEFECT"),
                     lambda a: a["Choice"].update(ContextId="seeker:47:DEFEND_DEFECT+0"),
                     lambda a: a["Choice"].update(Cards=[]),
                     lambda a: a["Choice"]["Cards"][0].update(StateKey="")]
        for mutate in mutations:
            before, after, action = seeker_fixture()
            mutate(action)
            executor = offline_executor(after)
            with self.subTest(mutate=mutate):
                try:
                    accepted = executor.resolve_ending_choice(before, after, action)
                except RuntimeError:
                    accepted = False
                self.assertFalse(accepted)
                self.assertNotIn("replay", executor.solve_calls[0])
                self.assertFalse(any(r.get("cmd") == "action" for r in executor.send.requests))

    def test_terminal_state_alone_and_stale_or_mismatched_audit_never_suffice(self):
        for mutation in ("active", "missing", "no_events", "parent_card", "parent_key", "source_pile",
                         "selector_called", "not_ending", "selected", "stale_meta"):
            before, after, action = seeker_fixture()
            if mutation == "active": after["context"]["combat_in_progress"] = True
            if mutation == "missing": after.pop("choice_audit")
            if mutation == "no_events": after["choice_audit"]["events"] = []
            if mutation == "parent_card": after["choice_audit"]["parent"]["card_id"] = "NEOWS_FURY"
            if mutation == "parent_key": after["choice_audit"]["parent"]["card_key"] = "different"
            if mutation == "source_pile": after["choice_audit"]["events"][0]["source_pile"] = "Discard"
            if mutation == "selector_called": after["choice_audit"]["events"][0]["selector_invocations_after"] += 1
            if mutation == "not_ending": after["choice_audit"]["events"][0]["is_ending_at_entry"] = False
            if mutation == "selected": after["choice_audit"]["events"][0]["selected_cards"] = ["STRIKE_DEFECT"]
            executor = offline_executor(after) if "choice_audit" in after else CombatExecutor(fixtures.FakeEngine([]))
            if mutation == "stale_meta": executor.send.responses[0]["completion_audit"]["action_id"] += 1
            with self.subTest(mutation=mutation):
                try:
                    accepted = executor.resolve_ending_choice(before, after, action)
                except RuntimeError:
                    accepted = False
                self.assertFalse(accepted)
                self.assertFalse(any(call.get("replay") for call in executor.solve_calls))

    def test_offline_replay_binds_original_plan_and_action_without_claiming_random_context_was_observed(self):
        before, after, action = seeker_fixture()
        executor = offline_executor(after)
        call = {"request": {"cmd": "solve"}, "response": fixtures.solved([action])}
        executor.solve_calls = [copy.deepcopy(call)]
        self.assertTrue(executor.resolve_ending_choice(before, after, action))
        traces = [{"request": {"cmd": "start_run"}, "response": before}, copy.deepcopy(call),
            {"request": {"cmd": "combat_meta"}, "response": {"type": "combat_meta",
                "hand": [{"index": 2, "key": "seeker"}], "enemies": []}},
            {"request": executor.last_action_request, "response": after},
            {"request": {"cmd": "choice_meta"}, "response": {"type": "choice_meta", "selection": "none",
                "cards": [], "completion_audit": copy.deepcopy(after["choice_audit"])}}]
        self.assertEqual(validate_replay_evidence(executor.solve_calls, traces)["replay_count"], 1)
        executor.solve_calls[0]["replay"][0]["plan"]["ContextId"] = "seeker:48:STRIKE_DEFECT+0"
        with self.assertRaises(ValueError):
            validate_replay_evidence(executor.solve_calls, traces)


class SeekerLiveTests(unittest.TestCase):
    def setUp(self):
        self.label = "seeker-choice-" + self._testMethodName + "-" + uuid.uuid4().hex[:10]
        self.bridge = Bridge(self.label)
        self.addCleanup(self.bridge.close)
        self.trace, self.replays = [], []
        self.send(cmd="start_run", character="Defect", ascension=10, seed="seeker-ending-fixture-v1")
        self.send(cmd="set_player", deck=["SEEKER_STRIKE"] * 8, relics=[], potions=["FIRE_POTION"])
        self.state = self.send(cmd="enter_room", type="combat", encounter="SHRINKER_BEETLE_WEAK")
        self.initial_hp = self.state["enemies"][0]["hp"]
        self.assertTrue(34 <= self.initial_hp <= 43)
        self.assertEqual(self.state["draw_pile_count"], 3)
        self.player_hp = self.state["player"]["hp"]

    def tearDown(self):
        (ROOT / "outputs" / (self.label + ".json")).write_text(json.dumps({
            "provenance": "artificial original-engine fixture; excluded from training",
            "trace": self.trace, "solver_calls": self.replays}, ensure_ascii=False, indent=2), encoding="utf-8")

    def send(self, **request):
        response = self.bridge.send(**request)
        self.trace.append({"request": request, "response": response})
        self.assertNotEqual(response.get("type"), "error", response)
        return response

    def test_nonlethal_seeker_still_requires_original_pending_selection(self):
        self.state = self.send(cmd="action", action="play_card", args={"card_index": 0, "target_index": 0})
        self.assertEqual(self.state["decision"], "card_select")
        self.assertTrue(self.state["context"]["combat_in_progress"])
        self.assertEqual(self.state["min_select"], 1)
        self.assertEqual(len(self.state["cards"]), 3)
        self.assertEqual(self.state["choice_audit"]["events"], [])
        meta = self.send(cmd="choice_meta")
        self.assertEqual(meta["selection"], "card_select")
        self.assertEqual(len(meta["cards"]), 3)
        self.state = self.send(cmd="action", action="select_cards", args={"indices": "0"})
        self.assertEqual(self.state["decision"], "combat_play")
        self.assertEqual(self.state["enemies"][0]["hp"], self.initial_hp - 9)
        self.assertEqual(self.state["draw_pile_count"], 2)
        self.assertEqual(len(self.state["hand"]), 5)
        self.assertEqual(self.state["player"]["hp"], self.player_hp)

    def test_lethal_original_solver_choice_is_retained_as_unexecuted_and_replay_audits(self):
        self.state = self.send(cmd="action", action="use_potion", args={"potion_index": 0, "target_index": 0})
        self.assertEqual(self.state["enemies"][0]["hp"], self.initial_hp - 20)
        executor = CombatExecutor(self.send)
        try:
            self.state = executor.advance(self.state)
        finally:
            self.replays = executor.solve_calls
        self.assertEqual(self.state["decision"], "card_reward")
        self.assertFalse(self.state["context"]["combat_in_progress"])
        self.assertFalse(self.state["context"]["integrity_recovery_used"])
        self.assertEqual(self.state["player"]["hp"], self.player_hp)
        proofs = [p for call in self.replays for p in call.get("replay", [])]
        ending = [p for p in proofs if p["kind"] == "planned_choice_not_executed"]
        mapped = [p for p in proofs if p["kind"] == "seeker_option_choice"]
        self.assertEqual(len(ending), 1)
        self.assertEqual(len(proofs), len(mapped) + 1)
        actual_selections = [t for t in self.trace if t["request"].get("action") == "select_cards"]
        self.assertEqual(len(mapped), len(actual_selections))
        self.assertIn(len(mapped), (1, 2))
        proof = ending[0]
        self.assertEqual(proof["kind"], "planned_choice_not_executed")
        self.assertEqual(proof["actual_choice_audit"]["parent"]["card_id"], "SEEKER_STRIKE")
        self.assertEqual(proof["plan"]["SourcePile"], "Draw")
        self.assertEqual(len(proof["plan"]["Cards"]), 1)
        self.assertTrue(proof["plan"]["ContextId"].startswith("seeker:"))
        self.assertEqual(proof["selected_cards"], [])
        event = proof["actual_choice_audit"]["events"][0]
        self.assertTrue(event["original_returned_empty_array"])
        self.assertFalse(event["selection_executed"])
        self.assertEqual(event["selector_invocations_before"], event["selector_invocations_after"])
        self.assertEqual(self.trace[-1]["request"], {"cmd": "choice_meta"})
        self.assertEqual(self.trace[-2]["request"]["action"], "play_card")
        self.assertEqual(validate_replay_evidence(self.replays, self.trace)["replay_count"], len(proofs))


if __name__ == "__main__":
    unittest.main()
