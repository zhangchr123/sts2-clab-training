"""Original Seeker singleton return, plus tamper-resistant synthetic replay checks."""
import copy
import json
import unittest
import uuid
from combat_executor import CombatExecutor
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence
import test_original_return_executor as original_fixture


def synthetic():
    values = list(original_fixture.fixture('hologram_barrage'))
    before, after, action, request, meta, call, traces = values
    action['CardId'] = 'SEEKER_STRIKE'
    plan = action['Choice']; plan['SourcePile'] = 'Draw'
    token = plan['Cards'][0]
    plan['ContextId'] = f"seeker:19:{token['CardId']}+{token['UpgradeLevel']}"
    audit = after['choice_audit']; audit['parent']['card_id'] = 'SEEKER_STRIKE'
    for row in audit['original_returns']:
        row.update(source_id='SEEKER_STRIKE', source_pile='Draw', effect_callsite='SeekerStrike.OnPlay')
    meta['completion_audit'] = copy.deepcopy(audit)
    call['response']['actions'] = [copy.deepcopy(action)]
    traces[1] = copy.deepcopy(call); traces[3]['response'] = copy.deepcopy(after)
    traces[4]['response'] = copy.deepcopy(meta)
    return values


class SeekerSingletonTests(unittest.TestCase):
    def test_original_singleton_proof_binds_without_claiming_rng_counter(self):
        calls, traces = original_fixture.OriginalReturnExecutorTests().execute(synthetic())
        self.assertTrue(validate_replay_evidence(calls, traces)['verified'])
        self.assertEqual(calls[0]['replay'][0]['context_validation'], 'original_singleton_token_identity_not_rng_counter')

    def test_wrong_context_multiple_source_cards_and_missing_return_are_rejected(self):
        for mutation in ('context', 'multiple', 'missing', 'returned_key'):
            values = synthetic(); before, after, action, request, meta, call, traces = values
            if mutation == 'context': action['Choice']['ContextId'] = 'seeker:19:WRONG+0'
            elif mutation == 'multiple': after['choice_audit']['original_returns'][0]['raw_source_count_at_entry'] = 2
            elif mutation == 'missing': after['choice_audit']['original_returns'] = []
            else: after['choice_audit']['original_returns'][0]['returned_cards'][0]['StateKey'] = 'wrong'
            executor = CombatExecutor(lambda **q: meta); executor.last_action_request = request; executor.solve_calls = [call]
            try: accepted = executor.resolve_original_automatic_choice(before, after, action)
            except RuntimeError: accepted = False
            self.assertFalse(accepted, mutation)

    def test_original_engine_singleton_completes_and_replays(self):
        label = 'seeker-singleton-' + uuid.uuid4().hex[:10]
        bridge = Bridge(label); traces = []; executor = None
        def send(**request):
            response = bridge.send(**request)
            traces.append({'request': request, 'response': copy.deepcopy(response)})
            self.assertNotEqual(response.get('type'), 'error', response)
            return response
        try:
            send(cmd='start_run', character='Defect', ascension=10, seed='seeker-singleton-fixture')
            send(cmd='set_player', hp=1000, max_hp=1000, deck=['SEEKER_STRIKE']*6, relics=[], potions=[])
            state = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
            self.assertEqual(state['draw_pile_count'], 1)
            executor = CombatExecutor(send); final = executor.advance(state)
            self.assertEqual(final['decision'], 'card_reward')
            self.assertFalse(final['context']['integrity_recovery_used'])
            proofs = [p for c in executor.solve_calls for p in c.get('replay', [])
                      if p.get('context_validation') == 'original_singleton_token_identity_not_rng_counter']
            self.assertGreaterEqual(len(proofs), 1)
            self.assertEqual(len({p['actual_choice_audit']['action_id'] for p in proofs}),len(proofs))
            self.assertTrue(all(p['actual_choice_audit']['original_returns'][0]['returned_count'] == 1 for p in proofs))
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
        finally:
            bridge.close()
            (ROOT/'outputs'/(label+'.json')).write_text(json.dumps({'origin':'artificial_fixture',
                'training_eligible':False,'traces':traces,'solver_calls':executor.solve_calls if executor else []},
                ensure_ascii=False),encoding='utf-8')


if __name__ == '__main__': unittest.main()
