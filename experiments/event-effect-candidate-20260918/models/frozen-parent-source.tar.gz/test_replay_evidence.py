"""Synthetic offline trace proofs. No engine process, search, or model is run."""
import copy
import unittest

from audit_batch import audit_batch
from combat_executor import CombatExecutor
from decision_data import DataContractError, read_decisions
from replay_evidence import solver_projection, validate_replay_evidence
from selection_context import direct_action_evidence
from train_act_survival import trace_label
import test_batch_audit as audit_fixtures
import test_combat_executor as combat_fixtures
import test_decision_data as data_fixtures


def knowledge_fixture():
    pending, meta, plan = combat_fixtures.CombatExecutorTests().knowledge_fixture()
    before, after = combat_fixtures.state(), combat_fixtures.state(round=2)
    action = {"Kind": "EndTurn", "Turn": 1, "TurnStartChoices": [plan]}
    call = data_fixtures.solver_call()
    call["response"]["actions"] = [action]
    engine = combat_fixtures.FakeEngine([meta, after])
    executor = CombatExecutor(engine)
    executor.solve_calls = [copy.deepcopy(call)]
    executor.resolve(pending, [plan])
    calls = executor.solve_calls
    traces = [{"request": {"cmd": "start_run"}, "response": before}, copy.deepcopy(call),
        {"request": {"cmd": "action", "action": "end_turn"}, "response": pending},
        {"request": {"cmd": "choice_meta"}, "response": meta},
        {"request": engine.requests[-1], "response": after}]
    return calls, traces


def ending_fixture():
    fixture = combat_fixtures.EndingChoiceTests()
    before, after, action = fixture.fixture()
    executor = fixture.engine(after)
    call = data_fixtures.solver_call()
    call["response"]["actions"] = [action]
    executor.solve_calls = [copy.deepcopy(call)]
    executor.resolve_ending_choice(before, after, action)
    meta = {"type": "choice_meta", "selection": "none", "cards": [],
            "completion_audit": copy.deepcopy(after["choice_audit"])}
    traces = [{"request": {"cmd": "start_run"}, "response": before}, copy.deepcopy(call),
        {"request": {"cmd": "combat_meta"}, "response": {"type": "combat_meta",
            "hand": [{"index": 2, "key": "neow"}], "enemies": []}},
        {"request": executor.last_action_request, "response": after},
        {"request": {"cmd": "choice_meta"}, "response": meta}]
    return executor.solve_calls, traces


class ReplayEvidenceTests(unittest.TestCase):
    def test_both_original_contracts_bind_without_dropping_annotations(self):
        for fixture in (knowledge_fixture, ending_fixture):
            calls, traces = fixture()
            before = copy.deepcopy((calls, traces))
            result = validate_replay_evidence(calls, traces)
            self.assertEqual(result["replay_count"], 1)
            self.assertTrue(result["verified"])
            self.assertEqual((calls, traces), before)
            self.assertIn("replay", calls[0])
            self.assertNotIn("replay", solver_projection(calls)[0])

    def test_knowledge_source_and_option_fingerprints_cannot_be_replaced(self):
        for key, value in (("source_id", "KNOWLEDGE_DEMON:8:0"), ("curse_counter", 1),
                           ("original_task_pending", False), ("option_keys", ["tampered", "mindrot=1"])):
            calls, traces = knowledge_fixture()
            # Even if both copies of metadata agree, the original plan and
            # pure executor contract must still detect changed source identity.
            for meta in (calls[0]["replay"][0]["actual_choice_metadata"], traces[3]["response"]):
                meta["knowledge_choice"][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_replay_evidence(calls, traces)

    def test_selected_indices_and_original_solver_parent_plan_are_required(self):
        for mutation in ("recorded_indices", "actual_indices", "plan", "parent_turn", "parent_action"):
            calls, traces = knowledge_fixture()
            if mutation == "recorded_indices": calls[0]["replay"][0]["selected_indices"] = [0]
            if mutation == "actual_indices": traces[4]["request"]["args"]["indices"] = "0"
            if mutation == "plan": calls[0]["replay"][0]["plan"]["Cards"][0]["CardId"] = "DISINTEGRATION"
            if mutation == "parent_turn": traces[0]["response"]["player_turn"] = 2
            if mutation == "parent_action": traces[2]["request"]["action"] = "use_potion"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                validate_replay_evidence(calls, traces)

    def test_unknown_missing_duplicate_or_cross_solve_proof_is_rejected(self):
        for mutation in ("unknown", "missing", "duplicate", "cross_solve", "extra_field"):
            calls, traces = knowledge_fixture()
            if mutation == "unknown": calls[0]["replay"][0]["kind"] = "unchecked_selection"
            if mutation == "missing": del calls[0]["replay"]
            if mutation == "duplicate": calls[0]["replay"] *= 2
            if mutation == "extra_field": calls[0]["replay"][0]["assumed_safe"] = True
            if mutation == "cross_solve":
                new_call = copy.deepcopy(solver_projection(calls)[0])
                calls.append(new_call)
                traces.insert(3, copy.deepcopy(new_call))
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                validate_replay_evidence(calls, traces)

    def test_ending_short_circuit_must_bind_original_return_and_card_instance(self):
        for mutation in ("audit", "actual_request", "hand_key", "original_choice"):
            calls, traces = ending_fixture()
            if mutation == "audit": calls[0]["replay"][0]["actual_choice_audit"]["action_id"] = 9
            if mutation == "actual_request": traces[3]["request"]["args"]["card_index"] = 0
            if mutation == "hand_key": traces[2]["response"]["hand"][0]["key"] = "another_neow"
            if mutation == "original_choice": calls[0]["replay"][0]["plan"]["SourcePile"] = "Draw"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                validate_replay_evidence(calls, traces)

    def test_response_projection_still_rejects_changed_solver_response(self):
        calls, traces = knowledge_fixture()
        calls[0]["response"]["actions"] = []
        with self.assertRaisesRegex(ValueError, "projection differs"):
            validate_replay_evidence(calls, traces)

    def test_batch_audit_and_survival_label_accept_real_bound_annotations_and_reject_tamper(self):
        fixture = audit_fixtures.BatchAuditTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        out = fixture.run_fixture()
        read, write = audit_fixtures.read, audit_fixtures.write
        calls, combat_trace = knowledge_fixture()
        traces = read(out / "trace.jsonl", lines=True)
        chosen, final = traces[1]["request"], traces[1]["response"]
        context = {"act": 1, "ascension": 10, "integrity_recovery_used": False}
        for row in combat_trace:
            if row["response"].get("type") == "decision":
                row["response"]["context"].update(context)
        combat = combat_trace[0]["response"]
        traces[0]["request"].update(character="Defect", ascension=10)
        traces = [traces[0], {"request": chosen, "response": combat}, *combat_trace[1:],
                  {"request": {"cmd": "action", "action": "end_turn"}, "response": final}]
        write(out / "trace.jsonl", traces, lines=True)
        journal = read(out / "decisions.jsonl", lines=True)
        completed = next(r for r in journal if r["record_type"] == "decision_completed")
        completed["solver_calls"] = calls
        completed["execution"]["direct_action_result"] = direct_action_evidence(combat)
        write(out / "decisions.jsonl", journal, lines=True)
        records = read_decisions(out / "decisions.jsonl")
        report = fixture.reports[0]
        report.update(solver_calls=1, training_eligible_decisions=sum(r["training_eligible"] for r in records),
            exclusion_reasons=sorted({reason for r in records for reason in r["training_exclusion_reasons"]}))
        write(out / "report.json", report)
        write(out / "status.json", {"status": "finished", **report})
        fixture.finish_batch()
        result = audit_batch(fixture.batch)
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual(trace_label(records, traces)["target"], 0)
        completed["solver_calls"][0]["replay"][0]["selected_indices"] = [0]
        write(out / "decisions.jsonl", journal, lines=True)
        result = audit_batch(fixture.batch)
        self.assertIn("solver_replay_trace_binding", [i["check"] for i in result["issues"]])
        with self.assertRaisesRegex(DataContractError, "Replay evidence"):
            trace_label(read_decisions(out / "decisions.jsonl"), traces)


if __name__ == "__main__":
    unittest.main()
