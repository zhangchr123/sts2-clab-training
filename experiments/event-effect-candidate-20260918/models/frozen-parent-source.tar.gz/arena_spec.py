"""Pure, deliberately narrow specifications for fresh synthetic card arenas.

No process, RNG, engine, save, policy or training code is invoked. A spec is a
declared projection, never a restoration of its source state. Version 1 supports
only the four canonical level-zero Defect basics, Ascender's Bane, and no candidate acquisition.
Readback validates supplied wire evidence, not the authenticity of a transport.
"""
from __future__ import annotations

import hashlib
import json
import math
import re


VERSION = "canonical-synthetic-arena-spec-v1"
PROTOCOL_VERSION = "canonical-synthetic-arena-protocol-v1"
ENGINE_SHA256 = "14b57dbaee1b58cb919625a662831054fd714b3b75b13b7449eac0e95b98a3e4"
ENCOUNTER = "SHRINKER_BEETLE_WEAK"
MAX_CARDS = 100
_CARD_ROWS = (("STRIKE_DEFECT", 1, "Attack", (("damage", 6),), ()),
              ("DEFEND_DEFECT", 1, "Skill", (("block", 5),), ()),
              ("ZAP", 1, "Skill", (), ()), ("DUALCAST", 1, "Skill", (), ()),
              # Engine constructor uses -1; current PlayerSummary.GetResolved
              # exports 0. This is a public readback template, not EnergyCost.
              ("ASCENDERS_BANE", 0, "Curse", (), ("Eternal", "Unplayable", "Ethereal")))
SUPPORTED_CARD_IDS = tuple(row[0] for row in _CARD_ROWS)
_CARD_REQUIRED = {"id", "cost", "type", "stats", "keywords", "upgraded", "current_upgrade_level"}
_CARD_METADATA = {"name", "description", "after_upgrade", "is_upgradable", "upgrade_preview_basis",
                  "upgrade_preview_instance_modifiers_copied", "upgrade_preview_status", "upgrade_preview_error"}
_PLAYER_FIELDS = {"name", "hp", "max_hp", "gold", "block", "deck", "deck_size", "relics",
                  "potions", "potion_capacity", "potion_empty_slots", "combat_metrics"}
_PROTOCOL_FIELDS = {"schema_version", "engine_sha256", "projection", "relic_mode", "inventory_mode",
                    "arena_seed", "seed_origin", "encounter_id", "encounter_origin", "character", "ascension"}


class ArenaSpecError(ValueError):
    def __init__(self, code, path, message):
        self.code, self.path, self.message = code, path, message
        super().__init__(f"{code} at {path}: {message}")

    def to_dict(self):
        return {"status": "rejected", "code": self.code, "path": self.path, "reason": self.message,
                "training_eligible": False, "not_current_state_clone": True}


def _require(condition, code, path, message):
    if not condition:
        raise ArenaSpecError(code, path, message)


def _copy(value, path="$"):
    if value is None or type(value) in (bool, str, int):
        return value
    if type(value) is float and math.isfinite(value):
        return value
    if type(value) is list:
        return [_copy(v, f"{path}[{i}]") for i, v in enumerate(value)]
    if type(value) is dict:
        _require(all(type(k) is str for k in value), "invalid_json", path, "Object keys must be strings")
        return {k: _copy(v, path + "." + k) for k, v in value.items()}
    raise ArenaSpecError("invalid_json", path, "Only finite JSON values are accepted")


def _json(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def content_hash(value):
    return hashlib.sha256(_json(_copy(value)).encode("utf-8")).hexdigest()


def _field(obj, key, path):
    _require(type(obj) is dict and key in obj, "missing_public_field", path + "." + key, "Required field is absent")
    return obj[key]


def _integer(value, path, low=0, high=2**31 - 1):
    _require(type(value) is int and low <= value <= high, "invalid_integer", path,
             f"Expected integer in [{low}, {high}], not a boolean or coerced value")
    return value


def canonical_card(card_id):
    """A new detached public template, not an engine instance or current card."""
    _require(type(card_id) is str and card_id in SUPPORTED_CARD_IDS, "unsupported_card", "$.card_id",
             "Only the four audited bare Defect basics and Ascender's Bane are supported")
    _, cost, kind, stats, keywords = next(row for row in _CARD_ROWS if row[0] == card_id)
    return {"id": "CARD." + card_id, "cost": cost, "type": kind, "stats": dict(stats) or None,
            "keywords": list(keywords) or None, "upgraded": False, "current_upgrade_level": 0}


def _card(card, path):
    _require(type(card) is dict, "unsupported_instance", path, "Full public card evidence is required; bare source strings are insufficient")
    for key in sorted(_CARD_REQUIRED):
        _field(card, key, path)
    _require(not (set(card) & {"enchantment", "enchantment_amount", "affliction", "affliction_amount"}),
             "unsupported_instance", path, "Enchantment/affliction markers cannot be copied, even if null")
    _require(not (set(card) - _CARD_REQUIRED - _CARD_METADATA), "unsupported_instance", path,
             "Unknown instance fields have no canonical codec")
    _require(card["upgraded"] is False and type(card["current_upgrade_level"]) is int
             and card["current_upgrade_level"] == 0, "unsupported_upgrade", path,
             "The existing set_player wire only constructs level-zero cards")
    identifier = card["id"]
    _require(type(identifier) is str and identifier.startswith("CARD.")
             and identifier[5:] in SUPPORTED_CARD_IDS, "unsupported_card", path + ".id",
             "No codec for this card; growth-capable and unknown classes are not projected")
    expected = canonical_card(identifier[5:])
    _integer(card["cost"], path + ".cost")
    stats, keywords = card["stats"], card["keywords"]
    _require(stats is None or type(stats) is dict, "noncanonical_card", path + ".stats", "Expected canonical BaseValue statistics")
    _require(keywords is None or type(keywords) is list, "noncanonical_card", path + ".keywords", "Expected explicit canonical keywords")
    if stats is not None:
        for key, value in stats.items():
            _integer(value, path + ".stats." + key)
    actual = {"id": identifier, "cost": card["cost"], "type": card["type"],
              "stats": stats or None, "keywords": keywords or None, "upgraded": False, "current_upgrade_level": 0}
    _require(_json(actual) == _json(expected), "noncanonical_card", path,
             "Public cost/type/stats/keywords differ from the audited base card; modifiers are not copied")
    return expected


def _protocol(protocol):
    protocol = _copy(protocol, "$.protocol")
    _require(type(protocol) is dict, "invalid_protocol", "$.protocol", "An explicit predeclared protocol is required")
    _require(not (set(protocol) & {"energy", "max_energy"}), "unsupported_energy", "$.protocol",
             "set_player has no energy setter; this version cannot assert or copy a requested energy value")
    _require(protocol.get("projection") == "explicit_canonical_deck_hp_gold_v1"
             and protocol.get("relic_mode") == "fresh_default_relics", "projection_not_accepted", "$.protocol",
             "Explicit canonical projection and fresh-default-relics acceptance are mandatory; default/copy is rejected")
    _require(set(protocol) == _PROTOCOL_FIELDS, "invalid_protocol", "$.protocol",
             "Unknown/missing protocol fields, candidate mutation, acquisition hooks and inventory codecs are unsupported")
    required = {"schema_version": PROTOCOL_VERSION, "engine_sha256": ENGINE_SHA256,
        "inventory_mode": "empty_potions", "character": "Defect", "ascension": 10,
        "seed_origin": "predeclared_external", "encounter_origin": "predeclared_external", "encounter_id": ENCOUNTER}
    _require(all(_json(protocol[k]) == _json(v) for k, v in required.items()), "invalid_protocol", "$.protocol",
             "Only the audited engine / Defect A10 / externally declared weak-beetle protocol is supported")
    _require(type(protocol["arena_seed"]) is str and re.fullmatch(r"[A-Za-z0-9_-]{1,128}", protocol["arena_seed"]),
             "invalid_protocol", "$.protocol.arena_seed", "An explicit bounded arena seed is required")
    return protocol


def _source_player(state):
    _require(type(state) is dict and state.get("type") == "decision"
             and state.get("decision") in {"map_select", "card_reward"}, "unsupported_source", "$",
             "Only public noncombat map/card-reward decisions are accepted")
    context = _field(state, "context", "$")
    _require(type(context) is dict and context.get("combat_in_progress") is False
             and context.get("integrity_recovery_used") is False
             and type(context.get("ascension")) is int and context["ascension"] == 10,
             "unsupported_source", "$.context", "Explicit inactive clean A10 context is required")
    player = _field(state, "player", "$")
    _require(type(player) is dict, "unsupported_source", "$.player", "Public player evidence is required")
    _require(not (set(player) & {"energy", "max_energy"}), "unsupported_energy", "$.player", "Energy instance state has no setter")
    _require(set(player) <= _PLAYER_FIELDS, "unsupported_source", "$.player", "Unknown persistent player fields have no projection codec")
    _require(_field(player, "name", "$.player") == "The Defect", "unsupported_source", "$.player.name",
             "This codec uses the current CLI's explicit Defect public identity only")
    hp = _integer(_field(player, "hp", "$.player"), "$.player.hp", 1)
    maximum = _integer(_field(player, "max_hp", "$.player"), "$.player.max_hp", 1)
    _require(hp <= maximum, "invalid_integer", "$.player.hp", "HP cannot exceed maximum HP")
    gold = _integer(_field(player, "gold", "$.player"), "$.player.gold")
    _require(_field(player, "potions", "$.player") == [], "unsupported_inventory", "$.player.potions",
             "Potion IDs/compact indexes do not certify slots; only explicitly empty inventory is supported")
    capacity = _integer(_field(player, "potion_capacity", "$.player"), "$.player.potion_capacity")
    empty = _integer(_field(player, "potion_empty_slots", "$.player"), "$.player.potion_empty_slots")
    _require(capacity == empty == 2, "unsupported_inventory", "$.player.potion_capacity", "Only the audited empty A10 base capacity is supported")
    relics = _field(player, "relics", "$.player")
    _require(type(relics) is list and all(type(r) is dict for r in relics), "unsupported_source", "$.player.relics",
             "Source relics must be explicitly recorded; none will be copied")
    deck = _field(player, "deck", "$.player")
    _require(type(deck) is list and 1 <= len(deck) <= MAX_CARDS, "unsupported_deck", "$.player.deck", "Expected 1..100 fully described cards")
    _require(_integer(_field(player, "deck_size", "$.player"), "$.player.deck_size") == len(deck),
             "unsupported_deck", "$.player.deck_size", "Deck length evidence is inconsistent")
    cards = [_card(c, f"$.player.deck[{i}]") for i, c in enumerate(deck)]
    return player, {"hp": hp, "max_hp": maximum, "gold": gold, "deck": cards}


def build_spec(public_state, protocol):
    """Build a synthetic baseline or raise a structured ArenaSpecError.

    protocol has no implicit default. Source relics/history are omitted only
    under its explicit fresh-default-relics projection. No source future/seed
    chooses the arena encounter or RNG seed. Version 1 has no card mutation.
    """
    state, protocol = _copy(public_state), _protocol(protocol)
    source_player, projected = _source_player(state)
    used, omitted = [], []
    for field in ("hp", "max_hp", "gold"):
        used.append({"path": "$.player." + field, "sha256": content_hash(source_player[field])})
    for index, card in enumerate(source_player["deck"]):
        for field, value in card.items():
            path = f"$.player.deck[{index}].{field}"
            item = {"path": path, "sha256": content_hash(value)}
            if field in _CARD_REQUIRED:
                used.append(item)
            else:
                omitted.append({**item, "reason": "display_or_canonical_upgrade_preview_not_instance_copy"})
    for field, value in source_player.items():
        if field not in {"hp", "max_hp", "gold", "deck"}:
            omitted.append({"path": "$.player." + field, "sha256": content_hash(value),
                            "reason": "fresh_default_relics_no_source_hooks_or_counters" if field == "relics"
                            else "validated_or_audited_only_not_copied"})
    for field, value in state.items():
        if field != "player":
            omitted.append({"path": "$." + field, "sha256": content_hash(value),
                            "reason": "source_context_history_future_and_metadata_not_arena_input"})
    templates = [canonical_card(identifier) for identifier in SUPPORTED_CARD_IDS]
    result = {"format": VERSION, "origin": "diagnostic_fixture", "training_eligible": False,
        "natural_labels_allowed": False, "not_current_state_clone": True, "exact_restore": False,
        "protocol_predeclaration_verified": False,
        "acquisition_hooks_replayed": False, "candidate_pick_benefit_supported": False,
        "arena_context": "fresh_Act1_synthetic_environment", "protocol": protocol,
        "card_codec": {"engine_sha256": ENGINE_SHA256, "ids": list(SUPPORTED_CARD_IDS),
                       "templates_sha256": content_hash(templates), "coverage": "canonical_level_zero_basics_and_ascenders_bane_only"},
        "card_instance_identity": "fresh_array_ordinal_not_source_engine_instance",
        "projected_player": projected,
        "source_audit": {"state_sha256": content_hash(state), "projection_sha256": content_hash(projected),
            "projected_fields": sorted(used, key=lambda x: x["path"]),
            "omitted_fields": sorted(omitted, key=lambda x: x["path"])},
        "wire_requests": [
            {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": protocol["arena_seed"]},
            {"cmd": "set_player", "hp": projected["hp"], "max_hp": projected["max_hp"],
             "gold": projected["gold"], "deck": [c["id"][5:] for c in projected["deck"]]},
            {"cmd": "enter_room", "type": "combat", "encounter": ENCOUNTER}],
        "required_gates": ["fresh_start_response", "complete_set_player_readback_before_enter_room", "actual_encounter_entry"],
        "unsupported": ["source_relics_counters_hooks", "upgrades_growth_enchantment_affliction", "potion_slots_or_capacity_change",
                        "energy_setting", "source_act_floor_rng_combat_snapshot", "candidate_acquisition_or_natural_outcome_label"]}
    result["spec_sha256"] = content_hash(result)
    return result


def validate_spec(spec, public_state):
    """Rebuild the complete envelope against its original public audit input."""
    spec = _copy(spec)
    _require(type(spec) is dict and type(spec.get("protocol")) is dict, "invalid_spec", "$", "Missing canonical spec protocol")
    expected = build_spec(public_state, spec["protocol"])
    _require(_json(spec) == _json(expected), "invalid_spec", "$", "Spec, projection, commands, omitted evidence or hashes were modified")
    return expected


def _fresh_inventory(player, path):
    _require(type(player) is dict and player.get("name") == "The Defect", "readback_mismatch", path, "Missing actual Defect player")
    relics = player.get("relics")
    _require(type(relics) is list and len(relics) == 1 and type(relics[0]) is dict
             and relics[0].get("id") == "RELIC.CRACKED_CORE" and _json(relics[0].get("vars")) == '{"Lightning":1}',
             "readback_mismatch", path + ".relics", "Fresh original starting relic was not preserved")
    _require(player.get("potions") == [] and type(player.get("potion_capacity")) is int
             and type(player.get("potion_empty_slots")) is int and player["potion_capacity"] == player["potion_empty_slots"] == 2,
             "readback_mismatch", path + ".potions", "Empty fresh inventory/capacity is not verified")


def verify_readback(spec, public_state, transcript):
    """Check start+set_player before permitting entry, optionally check entry.

    Returns an evidence receipt, not commands, outcomes or an engine attestation.
    A runner must stop/destroy its worker if the two-response gate fails.
    """
    spec = validate_spec(spec, public_state)
    rows = _copy(transcript)
    _require(type(rows) is list and len(rows) in {2, 3}, "readback_mismatch", "$.transcript", "Exactly start/set and optional enter response are required")
    for index, row in enumerate(rows):
        _require(type(row) is dict and set(row) == {"request", "response"}
                 and _json(row["request"]) == _json(spec["wire_requests"][index])
                 and type(row["response"]) is dict, "readback_mismatch", f"$.transcript[{index}]", "Actual wire order/request/response mismatch")
    start, built = rows[0]["response"], rows[1]["response"]
    context = start.get("context", {})
    _require(type(context) is dict and start.get("type") == "decision"
             and start.get("decision") in {"event_choice", "map_select"} and context.get("act") == 1
             and type(context.get("act")) is int and type(context.get("ascension")) is int and context["ascension"] == 10
             and context.get("combat_in_progress") is False and context.get("integrity_recovery_used") is False,
             "readback_mismatch", "$.start", "Worker is not in the fresh inactive A1 environment")
    _fresh_inventory(start.get("player"), "$.start.player")
    _require(built.get("type") == "ok", "readback_mismatch", "$.set_player", "set_player did not succeed")

    def player_matches(player, path):
        _fresh_inventory(player, path)
        actual = {field: _integer(_field(player, field, path), path + "." + field)
                  for field in ("hp", "max_hp", "gold")}
        deck = _field(player, "deck", path)
        _require(type(deck) is list and type(player.get("deck_size")) is int and player["deck_size"] == len(deck),
                 "readback_mismatch", path + ".deck", "Deck size/count readback is absent or inconsistent")
        actual["deck"] = [_card(card, path + f".deck[{i}]") for i, card in enumerate(deck)]
        _require(_json(actual) == _json(spec["projected_player"]), "readback_mismatch", path,
                 "Exact canonical card count/order/duplicates or HP/max HP/gold did not survive set_player")

    player_matches(built.get("player"), "$.set_player.player")
    if len(rows) == 3:
        entered = rows[2]["response"]
        context = entered.get("context", {})
        _require(type(context) is dict and entered.get("type") == "decision" and entered.get("decision") == "combat_play"
                 and type(entered.get("player_turn")) is int and entered["player_turn"] == 1
                 and type(context.get("act")) is int and context["act"] == 1
                 and type(context.get("ascension")) is int and context["ascension"] == 10
                 and context.get("encounter_id") == ENCOUNTER and context.get("room_type") == "Monster"
                 and context.get("combat_in_progress") is True and context.get("is_second_boss") is False
                 and context.get("integrity_recovery_used") is False,
                 "readback_mismatch", "$.enter_room", "The actual room is not the predeclared fresh weak-beetle combat")
        player_matches(entered.get("player"), "$.enter_room.player")
    return {"format": "canonical-synthetic-arena-readback-v1", "verified": True,
        "spec_sha256": spec["spec_sha256"], "transcript_sha256": content_hash(rows),
        "ready_to_enter": len(rows) == 2, "entry_verified": len(rows) == 3,
        "validation_scope": "supplied_ordered_request_response_evidence_only",
        "transport_authenticity_verified": False, "energy_setting_verified": False,
        "origin": "diagnostic_fixture", "training_eligible": False, "not_current_state_clone": True}
