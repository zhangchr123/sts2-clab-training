import copy
import unittest

from decision_data import DataContractError, enumerate_candidates
from initial_policy import FEATURE_NAMES as BASE_NAMES, InitialPolicy, POLICY_VERSION
from interaction_features import FEATURE_NAMES, INTERACTION_NAMES, VERSION, extend_scoring_packet
from test_initial_policy import card, state


class InteractionFeatureTests(unittest.TestCase):
    def setUp(self):
        self.policy = InitialPolicy(prior_path=None)

    def extend(self, current, **kwargs):
        return extend_scoring_packet(current, self.policy.score(current, **kwargs))

    def shop(self, held=2):
        current = state()
        current.update(decision="shop", cards=[dict(card("GLACIER", block=6, cost=2),
            index=0, cost=40, can_purchase=True)],
            relics=[{"id": "RELIC.DATA_DISK", "index": 0, "cost": 50, "can_purchase": True}],
            potions=[{"id": "POTION.FIRE_POTION", "index": 0, "cost": 30, "can_purchase": True}],
            card_removal_available=True, card_removal_cost=75, can_leave=True)
        current["player"].update(potions=[{"id": "POTION.FIRE_POTION", "index": i} for i in range(held)],
                                 potion_capacity=3, potion_empty_slots=3-held)
        return current

    def test_base_features_scores_requests_coverage_and_inputs_are_unchanged(self):
        current = state([card("GLACIER", block=6, cost=2)])
        base = self.policy.score(current)
        before_state, before_packet = copy.deepcopy(current), copy.deepcopy(base)
        result = extend_scoring_packet(current, base)
        self.assertEqual(len(BASE_NAMES), 101)
        self.assertEqual(len(FEATURE_NAMES), 119)
        self.assertEqual(len(set(FEATURE_NAMES)), 119)
        self.assertEqual(current, before_state)
        self.assertEqual(base, before_packet)
        for original, extended in zip(base["scores"], result["scores"]):
            self.assertEqual({k: extended["features"][k] for k in BASE_NAMES}, original["features"])
            self.assertEqual(set(extended["features"]), set(FEATURE_NAMES))
            self.assertEqual({k: v for k, v in extended.items() if k not in
                              {"features", "interaction_missing", "interaction_evidence"}},
                             {k: v for k, v in original.items() if k != "features"})
        for key in ("candidate_count", "candidate_space_representation", "evaluated_candidates_complete",
                    "state_hash", "mechanism_facts", "policy_version", "score_semantics"):
            self.assertEqual(result[key], base[key])
        self.assertEqual(result["feature_policy_version"], VERSION)
        self.assertEqual(result["base_feature_policy_version"], POLICY_VERSION)
        self.assertFalse(result["interaction_scores_applied"])
        self.assertEqual(result["interaction_feature_source"]["mechanism_facts"], self.policy.mechanism_source)
        self.assertEqual(len(result["interaction_feature_source"]["definition_sha256"]), 64)
        result["interaction_feature_source"]["direct_frost_source_ids"].append("ZAP")
        self.assertEqual(len(self.extend(current)["interaction_feature_source"]["direct_frost_source_ids"]), 3)

    def test_health_interacts_with_both_rest_options_without_changing_legality(self):
        current = state()
        current.update(decision="rest_site", options=[{"index": 2, "option_id": "HEAL", "is_enabled": True},
                                                   {"index": 5, "option_id": "SMITH", "is_enabled": True}])
        current["player"]["hp"] = 75
        healthy = self.extend(current)
        current["player"]["hp"] = 15
        low = self.extend(current)
        self.assertEqual([r["request"] for r in healthy["scores"]], [r["request"] for r in low["scores"]])
        for i, term in enumerate(("rest_heal", "rest_smith")):
            self.assertEqual(healthy["scores"][i]["features"]["ix_health_deficit_x_" + term], 0.)
            self.assertEqual(low["scores"][i]["features"]["ix_health_deficit_x_" + term], .8)
            self.assertEqual(low["scores"][1-i]["features"]["ix_health_deficit_x_" + term], 0.)

    def test_health_interacts_only_with_visible_map_type_and_candidate_block(self):
        current = state([card("DEFEND_DEFECT", block=5, cost=1)])
        current["player"]["hp"] = 15
        result = self.extend(current)
        self.assertEqual(result["scores"][0]["features"]["ix_health_deficit_x_base_block_per_cost"], 2.)
        self.assertEqual(result["scores"][1]["features"]["ix_health_deficit_x_base_block_per_cost"], 0.)
        current.update(decision="map_select", choices=[{"col": i, "row": 7, "type": kind}
            for i, kind in enumerate(("Monster", "Elite", "RestSite", "Unknown"))])
        before = enumerate_candidates(current)
        result = self.extend(current)
        self.assertEqual(enumerate_candidates(current), before)
        for i, term in enumerate(("map_monster", "map_elite", "map_rest")):
            self.assertEqual(result["scores"][i]["features"]["ix_health_deficit_x_" + term], .8)
            self.assertEqual(result["scores"][3]["features"]["ix_health_deficit_x_" + term], 0.)

    def test_verified_frost_counts_deck_copies_not_channels_and_marks_other_sources_partial(self):
        current = state([card("DEFRAGMENT"), card("HOTFIX"), card("BIASED_COGNITION"), card("CAPACITOR")])
        current["player"]["deck"] = [card("GLACIER"), card("GLACIER"), card("COLD_SNAP"),
                                     card("COOLHEADED"), card("ZAP"), card("RAINBOW")]
        packet = self.extend(current)
        for row, term in zip(packet["scores"], ("sustained_focus", "temporary_focus", "decaying_focus", "orb_capacity")):
            self.assertEqual(row["features"]["ix_direct_frost_source_cards_x_" + term], 4.)
            self.assertEqual(row["interaction_evidence"]["public_inputs"]["direct_frost_source_cards"], 4)
            self.assertEqual(row["features"]["ix_orb_source_coverage_partial"], 1.)
            self.assertIn("tagged_orb_sources_without_verified_channel_quantity", row["interaction_missing"])
            self.assertEqual(row["interaction_evidence"]["public_inputs"]["unquantified_tagged_orb_source_ids"],
                             ["RAINBOW", "ZAP"])
        current["player"]["deck"] = [card("ZAP")]
        row = self.extend(current)["scores"][0]
        self.assertEqual(row["features"]["ix_direct_frost_source_cards_x_sustained_focus"], 0.)
        self.assertEqual(row["features"]["ix_orb_source_coverage_partial"], 1.)
        self.assertEqual(row["features"]["ix_missing_deck"], 0.)
        self.assertIn("not_no_orb_sources", packet["interaction_feature_source"]["zero_frost_count_semantics"])

    def test_public_shop_prices_include_relics_potions_and_removal_without_rewriting_base(self):
        current = self.shop()
        result = self.extend(current)
        rows = {r["request"]["action"]: r for r in result["scores"]}
        for action, expected in (("buy_card", .4), ("buy_relic", .5), ("buy_potion", .3),
                                 ("remove_card", .75), ("leave_room", 0.)):
            self.assertEqual(rows[action]["features"]["ix_public_spend_fraction_of_gold"], expected)
        self.assertEqual(rows["buy_relic"]["features"]["gold_spend"], 0.)
        self.assertEqual(rows["buy_potion"]["features"]["gold_spend"], 0.)
        current["player"]["gold"] = 200
        rich = {r["request"]["action"]: r for r in self.extend(current)["scores"]}
        self.assertEqual(rich["buy_relic"]["features"]["ix_public_spend_fraction_of_gold"], .25)
        self.assertEqual([r["request"] for r in result["scores"]],
                         [r["request"] for r in self.extend(current)["scores"]])

    def test_held_potion_count_interacts_with_discard_only_and_incomplete_inventory_is_missing(self):
        for count in (1, 2):
            for row in self.extend(self.shop(held=count))["scores"]:
                expected = count if row["request"]["action"] == "discard_potion" else 0.
                self.assertEqual(row["features"]["ix_held_potions_x_discard_potion"], expected)
        current = state()
        current["player"].update(potions=[{"id": "POTION.FIRE_POTION"}], potion_capacity=3, potion_empty_slots=3)
        row = self.extend(current)["scores"][0]
        self.assertIsNone(row["interaction_evidence"]["public_inputs"]["held_potions"])
        self.assertEqual(row["features"]["ix_missing_potion_inventory"], 1.)
        self.assertEqual(row["features"]["ix_held_potions_x_discard_potion"], 0.)

    def test_missing_raw_inputs_have_masks_not_inferred_zero_quantities(self):
        current = state([card("DEFRAGMENT")])
        current["player"] = {}
        row = self.extend(current)["scores"][0]
        for field in ("health", "deck", "gold", "potion_inventory"):
            self.assertEqual(row["features"]["ix_missing_" + field], 1.)
        self.assertEqual(row["features"]["ix_health_deficit_x_base_block_per_cost"], 0.)
        self.assertEqual(row["features"]["ix_direct_frost_source_cards_x_sustained_focus"], 0.)
        current = self.shop()
        current["relics"][0].pop("cost")
        relic = next(r for r in self.extend(current)["scores"] if r["request"]["action"] == "buy_relic")
        self.assertEqual(relic["features"]["ix_missing_spend"], 1.)
        self.assertEqual(relic["features"]["ix_public_spend_fraction_of_gold"], 0.)

    def test_malformed_public_quantities_do_not_become_verified_inputs(self):
        for changes, mask in (({"hp": True}, "health"), ({"hp": 100}, "health"),
                              ({"max_hp": 0}, "health"), ({"gold": -1}, "gold"),
                              ({"deck": [{"id": "RELIC.GLACIER"}]}, "deck"),
                              ({"potions": [{"id": "CARD.FIRE_POTION"}]}, "potion_inventory")):
            current = state()
            current["player"].update(changes)
            with self.subTest(changes=changes):
                row = self.extend(current)["scores"][0]
                self.assertEqual(row["features"]["ix_missing_" + mask], 1.)

    def test_huge_implicit_subset_retains_exact_space_and_partial_evaluation(self):
        current = state([card("GLACIER", block=6) for _ in range(15)])
        current.update(decision="card_select", min_select=0, max_select=15)
        requests = [{"cmd": "action", "action": "select_cards", "args": {"indices": indices}}
                    for indices in ("", "14,0,8")]
        base = self.policy.score_requests(current, requests, selection_purpose="acquire")
        result = extend_scoring_packet(current, base)
        self.assertEqual(result["candidate_count"], 3554627472076)
        self.assertFalse(result["evaluated_candidates_complete"])
        self.assertEqual(result["candidate_space_representation"], "ordered_selection_implicit_v1")
        self.assertEqual([r["request"] for r in result["scores"]], requests)

    def test_hidden_metadata_and_candidate_indices_are_not_features(self):
        current = state([card("GLACIER", block=6), card("DEFRAGMENT")])
        before = self.extend(current)
        current.update(seed="must-not-use", rng={"counter": 123}, future_outcome={"victory": True},
                       hidden_next_encounter="must-not-use")
        current["player"]["hidden_status"] = "must-not-use"
        current["cards"][0].update(index=18, hidden_expected_value=1e9)
        current["cards"][1]["index"] = 21
        after = self.extend(current)
        self.assertEqual([r["features"] for r in before["scores"]], [r["features"] for r in after["scores"]])
        self.assertNotEqual(before["scores"][0]["request"], after["scores"][0]["request"])

    def test_invalid_packet_binding_schema_identity_or_coverage_is_rejected(self):
        current = state()
        packet = self.policy.score(current)
        mutators = [lambda p: p.update(state_hash="forged"),
                    lambda p: p["mechanism_facts"].update(registry_sha256="forged"),
                    lambda p: p["scores"][0]["features"].update(seed=1.),
                    lambda p: p["scores"][0]["features"].update(action_select_card_reward=0.),
                    lambda p: p["scores"][0]["features"].update(base_block_per_cost=float("nan")),
                    lambda p: p["scores"][0].update(features=None),
                    lambda p: p["scores"].append(copy.deepcopy(p["scores"][0])),
                    lambda p: p["scores"].__setitem__(0, None),
                    lambda p: p.update(candidate_count=True),
                    lambda p: p.update(evaluated_candidates_complete=False),
                    lambda p: p["scores"][0]["request"]["args"].update(card_index=999)]
        for mutate in mutators:
            broken = copy.deepcopy(packet)
            mutate(broken)
            with self.subTest(mutate=mutate), self.assertRaises(DataContractError):
                extend_scoring_packet(current, broken)
        with self.assertRaises(DataContractError):
            extend_scoring_packet(current, self.extend(current))


if __name__ == "__main__":
    unittest.main()
