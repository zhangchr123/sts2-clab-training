"""Fail-closed audit tests; all synthetic data below are labeled test fixtures."""
import copy
import unittest

from branch_audit import compare_snapshots, differences, fingerprint


def synthetic_observation():
    rng = {"seed": "123", "expected_streams": ["Shuffle"], "streams": {
        "Shuffle": {"initialized": True, "counter": 3, "state": ["0123456789abcdef"] * 4}}}
    return {"type": "branch_audit", "schema_version": 1, "capture_kind": "read_only_observation",
            "engine": {"game_mvid": "synthetic-game", "cli_mvid": "synthetic-cli"}, "capture_stable": True,
            "coverage": {"rng_complete": True, "relic_counters_complete": True,
                         "full_state_complete": False, "quiescence_verified": False, "restore_supported": False},
            "payload": {"run": {"seed": "synthetic-unit-test-only"},
                        "players": [{"index": 0, "character": "CHARACTER.DEFECT", "deck": [{"id": "STRIKE_DEFECT", "index": 0}]}],
                        "rng": {"run": rng, "players": [{"index": 0, "rng": copy.deepcopy(rng)}]},
                        "relics": [{"player_index": 0, "entries": [{"index": 0, "id": "RELIC.NUNCHAKU", "runtime_fields": {"Nunchaku._attacksPlayed": 3}}]}],
                        "missing_rng_fields": [], "missing_relic_fields": []}}


class BranchAuditTests(unittest.TestCase):
    def compare(self, left, right, **kwargs):
        return compare_snapshots(left, right, scope="observed-state", **kwargs)

    def test_equal_observations_never_certify_restore(self):
        state = synthetic_observation()
        result = self.compare(state, copy.deepcopy(state), comparison_kind="same_seed_action_replay")
        self.assertTrue(result["passed"])
        self.assertFalse(result["exact_branch_verified"])
        self.assertFalse(result["restore_authorized"])
        self.assertFalse(compare_snapshots(state, state)["passed"])
        self.assertFalse(self.compare(state, state, comparison_kind="branch_restore")["passed"])

    def test_seed_and_counter_match_do_not_hide_changed_rng_word(self):
        first = synthetic_observation()
        other = copy.deepcopy(first)
        other["payload"]["rng"]["players"][0]["rng"]["streams"]["Shuffle"]["state"][3] = "ffffffffffffffff"
        result = self.compare(first, other)
        self.assertFalse(result["passed"])
        self.assertIn("/state/3", result["differences"][0]["path"])

    def test_relic_count_and_deck_order_are_not_normalized_away(self):
        first = synthetic_observation()
        for modify in (
            lambda x: x["payload"]["relics"][0]["entries"][0]["runtime_fields"].update({"Nunchaku._attacksPlayed": 4}),
            lambda x: x["payload"]["players"][0]["deck"].append({"id": "ZAP", "index": 1}),
            lambda x: x["engine"].update({"game_mvid": "different-engine"}),
        ):
            with self.subTest(modify=modify):
                other = copy.deepcopy(first)
                modify(other)
                self.assertFalse(self.compare(first, other)["passed"])

    def test_missing_coverage_cannot_pass_even_when_both_sides_equal(self):
        for mutation in (
            lambda x: x["coverage"].update({"rng_complete": False}),
            lambda x: x["payload"].update({"missing_relic_fields": ["PenNib._attackToDouble"]}),
            lambda x: x["payload"]["rng"]["run"]["streams"].clear(),
            lambda x: x["payload"]["rng"]["run"]["streams"]["Shuffle"].pop("state"),
            lambda x: x["payload"]["rng"]["run"].update({"expected_streams": []}),
            lambda x: x.update({"capture_stable": False}),
            lambda x: x["payload"].pop("players"),
            lambda x: x.update({"engine": {}}),
        ):
            state = synthetic_observation()
            mutation(state)
            with self.subTest(state=state):
                result = self.compare(state, state)
                self.assertTrue(result["observed_match"])
                self.assertFalse(result["coverage_valid"])
                self.assertFalse(result["passed"])

    def test_forged_complete_coverage_does_not_enable_restore(self):
        state = synthetic_observation()
        state["coverage"].update({"full_state_complete": True, "quiescence_verified": True, "restore_supported": True})
        self.assertFalse(compare_snapshots(state, state)["passed"])

    def test_null_missing_bool_and_order_remain_distinct(self):
        self.assertTrue(differences({}, {"x": None}))
        self.assertTrue(differences({"x": 1}, {"x": True}))
        self.assertTrue(differences(["a", "b"], ["b", "a"]))
        self.assertNotEqual(fingerprint(["a", "b"]), fingerprint(["b", "a"]))
        self.assertEqual(fingerprint({"a": 1, "b": 2}), fingerprint({"b": 2, "a": 1}))

    def test_invalid_api_response_is_a_failed_check(self):
        for value in (None, [], {"type": "error", "message": "unsupported"}):
            result = self.compare(value, value)
            self.assertFalse(result["passed"])
            self.assertFalse(result["coverage_valid"])


if __name__ == "__main__":
    unittest.main()
