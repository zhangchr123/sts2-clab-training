"""Original whole plans and actual engine series, never natural training samples."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from inspection.trial_cosmetic_projection import project_trial_number
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers


class HologramSeriesTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def test_base_and_enchanted_replay_counts_remain_distinct(self):
        from hologram_series import checked_card_replay
        for base in (0,2):
            for used in (False,True):
                key=f'HOLOGRAM+0|replay={base}|GLAM:1:0:{used}|'
                action={'CardStateKey':key,'CardEnchantmentId':'GLAM','ReplayCount':base+int(not used)}
                checked_card_replay(action)
                with self.assertRaises(RuntimeError):
                    checked_card_replay(dict(action,ReplayCount=action['ReplayCount']+1))
                with self.assertRaises(RuntimeError):
                    checked_card_replay(dict(action,CardEnchantmentId=''))
                with self.assertRaises(RuntimeError):
                    checked_card_replay(dict(action,CardStateKey=key.replace(str(used),'Unknown')))
            checked_card_replay({'CardStateKey':f'HOLOGRAM+0|replay={base}|-|',
                'CardEnchantmentId':'','ReplayCount':base})

    def original_case(self, suffix, expected_prefix, expected_count):
        root = Path('D:/sts2-training/staging/seeker-manual-repeat-return/sts2-solver-bridge')
        batch = 'defect-identity-warm-cem-20260915a'; name = batch + '-generation-03-' + suffix
        run = root / 'outputs' / name
        audit = read_json(root / 'outputs' / batch / 'generation-03' / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and not audit['issues'] and unchanged(audit['actual_source_evidence']))
        self.assertEqual(audit['outcome'], 'environment_error')
        rows = read_lines(run / 'trace.jsonl')
        gate = max(i for i,r in enumerate(rows) if r['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'hologram-series-full-' + suffix + '-' + uuid.uuid4().hex[:10]
        bridge,traces,send = self.worker(label)
        passed,matched,executor = False,0,None
        differences = []
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve','combat_meta','choice_meta'}: continue
                before = send(row['request'])
                a,ad = project_trial_number(checked_public(before)); b,bd = project_trial_number(checked_public(row['response']))
                self.assertEqual(a,b)
                if ad or bd: differences.append({'prefix':matched,'actual':ad,'original':bd})
                matched += 1
            self.assertEqual(matched,expected_prefix)
            executor = CombatExecutor(send,read_json(run/'manifest.json')['solver_requested_config'])
            actual_solve,supplied = executor.solve,False
            def recorded(state,budget,used=0,setup=False):
                nonlocal supplied
                if supplied: return actual_solve(state,budget,used,setup)
                self.assertEqual(state,before);self.assertFalse(setup);supplied=True
                call=copy.deepcopy(original);traces.append(copy.deepcopy(call));executor.solve_calls.append(call)
                return call['response']
            executor.solve=recorded
            final=executor.advance(before)
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
            self.assertEqual(executor.solve_calls[0]['response'],original['response'])
            proofs=[p for p in executor.solve_calls[0].get('replay',[]) if p.get('series_schema')=='hologram-original-indexed-series-v1']
            self.assertTrue(proofs)
            target=next(p for p in proofs if p['original_play_count']==expected_count)
            self.assertEqual(target['manual_selection_requests_sent'],0 if suffix=='10-003' else 2)
            self.assertFalse(target['automatic_selection_request_sent'])
            for field,value in [('hologram_play_count',99),('hologram_play_index',99),
                ('hologram_original_series_verified',False),('hologram_original_play_action_id',-1),
                ('original_task_completed_successfully',False),('returned_objects_match_original_source',False),
                ('filter_reexecuted_by_observer',True),('raw_source_count_at_entry',-1)]:
                def corrupt(obj):
                    if isinstance(obj,dict):
                        for k in obj:
                            if k==field: obj[k]=value
                            else: corrupt(obj[k])
                    elif isinstance(obj,list):
                        for x in obj:corrupt(x)
                bad_calls,bad_traces=copy.deepcopy(executor.solve_calls),copy.deepcopy(traces)
                corrupt(bad_calls);corrupt(bad_traces)
                with self.subTest(field=field),self.assertRaises((ValueError,RuntimeError)):
                    validate_replay_evidence(bad_calls,bad_traces)
            bad=copy.deepcopy(executor.solve_calls)
            bad[0]['replay'].remove(target)
            with self.assertRaises(ValueError):validate_replay_evidence(bad,traces)
            if suffix == '1-018':
                for field,value in [('previous_action_id',0),('pending_play_index',99),('original_play_count',99),
                    ('selected_original_option_index',999),('selector_task_identity_matches',False),
                    ('original_and_selector_return_same_card_objects',False),('original_play_cancelled',True),
                    ('original_play_action_id',-1),('source_is_original_card_object',False)]:
                    bad_calls,bad_traces=copy.deepcopy(executor.solve_calls),copy.deepcopy(traces)
                    corrupt(bad_calls);corrupt(bad_traces)
                    with self.subTest(field=field),self.assertRaises((ValueError,RuntimeError)):
                        validate_replay_evidence(bad_calls,bad_traces)
                bad_calls,bad_traces=copy.deepcopy(executor.solve_calls),copy.deepcopy(traces)
                bad_calls[0]['replay'].remove(target)
                query=next(i for i,r in enumerate(bad_traces) if r['request']=={'cmd':'choice_meta'}
                    and r['response'].get('completion_audit')==target['actual_choice_audit'])
                del bad_traces[query]
                with self.assertRaises(ValueError):validate_replay_evidence(bad_calls,bad_traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']));passed=True
        finally:
            self.save(label,traces,passed=passed,origin='recorded_full_original_solver_envelope_diagnostic',
                original_failed_run=name,original_sources=audit['actual_source_evidence'],
                public_prefix_responses_verified=matched,first_solve_is_recorded_full_original_envelope_not_new_search=True,
                hidden_state_or_rng_equality_claimed=False,all_public_fields_identical_claimed=False,
                diagnostic_only_Trial_display_number_projection=differences,
                solver_calls=executor.solve_calls if executor else [])
            bridge.close()

    def test_original_echo_form_singleton_and_empty(self): self.original_case('10-003',723,2)
    def test_original_three_plays_two_manual_and_final_singleton(self): self.original_case('1-018',561,3)

    def test_base_and_upgraded_empty_singleton_and_manual_boundaries(self):
        for upgraded in (False,True):
            for n in range(4):
                with self.subTest(upgraded=upgraded,discard=n):self.boundary(n,upgraded)

    def boundary(self,n,upgraded):
        label=f'hologram-series-boundary-n{n}-u{int(upgraded)}-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);passed=False;action=None;executor=None
        try:
            send(cmd='start_run',character='Defect',ascension=10,seed='hologram-original-series-boundaries')
            send(cmd='set_player',hp=1000,max_hp=1000,relics=[],deck=['HOLOGRAM']+['DEFLECT']*n,
                potions=['BLESSING_OF_THE_FORGE'] if upgraded else [])
            before=send(cmd='enter_room',type='combat',encounter='SHRINKER_BEETLE_WEAK')
            if upgraded:before=send(cmd='action',action='use_potion',args={'potion_index':0})
            meta=send(cmd='combat_meta')
            defend=next((c for c in before['hand'] if c['id']=='CARD.DEFLECT'),None)
            key=next((c['key'] for c in meta['hand'] if defend and c['index']==defend['index']),None)
            for _ in range(n):
                card=next(c for c in before['hand'] if c['id']=='CARD.DEFLECT')
                before=send(cmd='action',action='play_card',args={'card_index':card['index']})
            self.assertEqual(before['discard_pile_count'],n)
            actor=next(c for c in before['hand'] if c['id']=='CARD.HOLOGRAM')
            meta=send(cmd='combat_meta');actor_key=next(c['key'] for c in meta['hand'] if c['index']==actor['index'])
            cards=[] if n==0 else [{'CardId':'DEFLECT','UpgradeLevel':int(upgraded),'StateKey':key,
                'SourceOccurrence':0,'OptionOccurrence':0}]
            action={'Kind':'PlayCard','CardId':'HOLOGRAM','CardStateKey':actor_key,'CardStateOccurrence':0,
                'CardUpgradeLevel':int(upgraded),'ReplayCount':0,'CardEnchantmentId':'','TargetIndex':-1,
                'TargetCombatId':None,'Turn':before['player_turn'],'EndsPlayerTurn':False,'NestedChoicesBeforePrimary':0,
                'Choice':{'Effect':'MoveToHand','SourcePile':'Discard','SourceId':'','ContextId':'','Timing':'Action','Cards':cards}}
            request={'cmd':'action','action':'play_card','args':{'card_index':actor['index']}}
            after=send(request);executor=CombatExecutor(send);executor.last_action_request=request
            executor.solve_calls=[{'constructed_boundary_plan_not_solver_output':True}]
            if n>=2:after=executor.resolve_hologram_continuation(before,after,action)
            else:self.assertTrue(executor.resolve_original_automatic_choice(before,after,action))
            proof=executor.solve_calls[0]['replay'][0]
            self.assertEqual(proof['manual_selection_requests_sent'],int(n>=2))
            self.assertEqual(proof['original_play_count'],1)
            self.assertFalse(proof['automatic_selection_request_sent'])
            self.assertEqual(after['decision'],'combat_play')
            self.assertEqual(len(after['hand']),int(n>0))
            self.assertEqual(after['discard_pile_count'],n-int(n>0)+int(upgraded))
            passed=True
        finally:
            self.save(label,traces,passed=passed,origin='synthetic_original_hologram_series_boundary',
                constructed_plan_is_not_solver_output=True,synthetic_plan=action,upgraded=upgraded,discard=n,
                hidden_state_or_rng_equality_claimed=False,solver_calls=executor.solve_calls if executor else [])
            bridge.close()


if __name__ == '__main__': unittest.main(verbosity=2)
