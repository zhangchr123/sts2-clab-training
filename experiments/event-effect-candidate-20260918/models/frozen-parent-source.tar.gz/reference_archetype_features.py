"""Descriptive Defect reference features from frozen public A10 victory histories.

The reference set is winner-only and cross-version.  These features expose
card prevalence, logged pick fraction, frequent pair completion and marker
affinity; they are not win probabilities or causal card values.
"""
import json
import math
from collections.abc import Mapping
from pathlib import Path

from decision_data import DataContractError
from initial_policy import card_id
from public_route_learning import PARAMETERS as ORIGINAL_PARAMETERS, features as original_features
from run_metadata import file_evidence

ROOT = Path(__file__).resolve().parent
PRIOR_PATH = ROOT / "defect_public_reference_prior.json"
ARCHETYPE_KEYS = ("frost_defense", "draw_energy_recycle", "zero_cost_physical",
                  "focus_orbs", "power_synergy", "dark_orbs")
EXTRA_PARAMETERS = ("reference_card_prevalence", "reference_logged_pick_fraction",
                    "reference_pair_prevalence", "reference_pair_lift_excess",
                    *("reference_archetype_" + key + "_affinity" for key in ARCHETYPE_KEYS))
PARAMETERS = (*ORIGINAL_PARAMETERS, *EXTRA_PARAMETERS)
CONTRACT = {
    "version": "defect-public-reference-features-v1",
    "original_parameters": 311,
    "reference_parameters": 10,
    "reference_runs": 6389,
    "frequent_pair_minimum_runs": 500,
    "winner_only_descriptive": True,
    "cross_version_descriptive": True,
    "pair_context": "predecision_public_deck_only",
    "multi_card_context": "each_public_selected_card_against_same_predecision_deck",
    "unknown_cards_are_zero": True,
}


def require(ok, message):
    if not ok:
        raise DataContractError(message)


def _load_prior():
    try:
        value = json.loads(PRIOR_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise DataContractError("Invalid frozen public reference prior") from exc
    required = {"format", "character", "ascension", "reference_runs", "versions", "cards", "pairs",
                "archetypes", "source_analysis", "source_accounting", "limitations"}
    require(isinstance(value, dict) and set(value) == required, "Reference prior schema differs")
    require(value["format"] == "defect-public-reference-prior-v1" and value["character"] == "Defect"
            and value["ascension"] == 10 and value["reference_runs"] == CONTRACT["reference_runs"],
            "Reference prior scope differs")
    require(value["limitations"] == ["winner_only_selection_bias",
            "cross_version_pooling_is_descriptive_only", "not_independently_replayed"],
            "Reference limitations must remain explicit")
    require(isinstance(value["cards"], dict) and value["cards"], "Reference cards missing")
    for cid, row in value["cards"].items():
        require(isinstance(cid, str) and cid == cid.upper() and cid,
                "Reference card id is not normalized")
        require(set(row) == {"runs_present", "prevalence", "logged_offers", "logged_picks",
                            "logged_pick_fraction"}, "Reference card schema differs")
        pick_fraction = row["logged_pick_fraction"]
        require(type(row["runs_present"]) is int and row["runs_present"] >= 0
                and type(row["logged_offers"]) is int and row["logged_offers"] >= 0
                and type(row["logged_picks"]) is int and 0 <= row["logged_picks"] <= row["logged_offers"]
                and type(row["prevalence"]) in (int, float) and math.isfinite(row["prevalence"])
                and 0 <= row["prevalence"] <= 1
                and ((type(pick_fraction) in (int, float) and math.isfinite(pick_fraction)
                      and 0 <= pick_fraction <= 1 and row["logged_offers"] > 0)
                     or pick_fraction is None and row["logged_offers"] == row["logged_picks"] == 0),
                "Invalid reference card statistics")
    require(isinstance(value["pairs"], list) and len(value["pairs"]) == 90,
            "Expected all 90 data-derived frequent cores")
    seen = set()
    for row in value["pairs"]:
        require(set(row) == {"cards", "runs_present", "prevalence", "lift"}
                and isinstance(row["cards"], list) and len(row["cards"]) == 2,
                "Reference pair schema differs")
        pair = tuple(row["cards"])
        require(pair == tuple(sorted(pair)) and pair not in seen
                and all(isinstance(cid, str) and cid == cid.upper() and cid for cid in pair),
                "Reference pair identity differs")
        seen.add(pair)
        require(type(row["runs_present"]) is int and row["runs_present"] >= 500
                and type(row["prevalence"]) in (int, float) and 0 <= row["prevalence"] <= 1
                and type(row["lift"]) in (int, float) and math.isfinite(row["lift"]) and row["lift"] >= 1,
                "Invalid frequent pair statistics")
    require(isinstance(value["archetypes"], dict) and tuple(value["archetypes"]) == ARCHETYPE_KEYS,
            "Reference archetype order or identity differs")
    for row in value["archetypes"].values():
        require(set(row) == {"minimum_distinct_markers", "markers", "runs_matching", "prevalence"}
                and type(row["minimum_distinct_markers"]) is int and row["minimum_distinct_markers"] >= 2
                and isinstance(row["markers"], list) and len(row["markers"]) >= row["minimum_distinct_markers"]
                and len(row["markers"]) == len(set(row["markers"])), "Reference archetype schema differs")
    return value


PRIOR = _load_prior()
PRIOR_EVIDENCE = file_evidence(PRIOR_PATH)
PAIR_INDEX = {}
for _row in PRIOR["pairs"]:
    _a, _b = _row["cards"]
    PAIR_INDEX.setdefault(_a, {})[_b] = _row
    PAIR_INDEX.setdefault(_b, {})[_a] = _row


def _valid_card(value):
    require(isinstance(value, Mapping) and isinstance(value.get("id"), str) and value["id"],
            "Reference features require identified public cards")
    return value


def _acquired_cards(row, candidate):
    require(row["request"] == candidate["request"], "Reference row/candidate mismatch")
    action = row["request"]["action"]
    if action in {"select_card_reward", "buy_card"}:
        return [_valid_card(candidate["evidence"])]
    if action == "select_bundle" or (action == "select_cards"
            and row["features"].get("selection_acquire") == 1.):
        cards = candidate["evidence"].get("cards")
        require(isinstance(cards, list), "Reference acquisition cards must be a list")
        return [_valid_card(card) for card in cards]
    return []


def extra_features(state, row, candidate):
    result = dict.fromkeys(EXTRA_PARAMETERS, 0.)
    cards = _acquired_cards(row, candidate)
    if not cards:
        return result
    player = state.get("player", {})
    deck = player.get("deck")
    require(isinstance(deck, list) and deck, "Reference features require a nonempty public deck")
    exported = player.get("deck_size")
    require(exported is None or type(exported) is int and exported == len(deck),
            "Reference public deck size differs")
    deck_ids = {card_id(_valid_card(card)) for card in deck}
    for card in cards:
        cid = card_id(card)
        statistics = PRIOR["cards"].get(cid)
        if statistics is not None:
            result["reference_card_prevalence"] += statistics["prevalence"]
            if statistics["logged_pick_fraction"] is not None:
                result["reference_logged_pick_fraction"] += statistics["logged_pick_fraction"]
        matching = [pair for partner, pair in PAIR_INDEX.get(cid, {}).items() if partner in deck_ids]
        if matching:
            result["reference_pair_prevalence"] += max(pair["prevalence"] for pair in matching)
            result["reference_pair_lift_excess"] += min(1., max(pair["lift"] - 1. for pair in matching))
        for key, definition in PRIOR["archetypes"].items():
            markers = set(definition["markers"])
            if cid not in markers or cid in deck_ids:
                continue
            present = len(markers & deck_ids)
            result["reference_archetype_" + key + "_affinity"] += min(
                1., present / (definition["minimum_distinct_markers"] - 1))
    return result


def features(state, row, candidate, route_input=None):
    original = original_features(state, row, candidate, route_input)
    require(tuple(original) == ORIGINAL_PARAMETERS, "Original 311-feature schema differs")
    return {**original, **extra_features(state, row, candidate)}


def zero_extend(parameters):
    require(set(parameters) == set(ORIGINAL_PARAMETERS)
            and all(type(value) in (int, float) and math.isfinite(value) and abs(value) <= 4
                    for value in parameters.values()), "Invalid original 311-parameter vector")
    return {**{name: parameters[name] for name in ORIGINAL_PARAMETERS},
            **dict.fromkeys(EXTRA_PARAMETERS, 0.)}
