"""Bind original Seeker manual/repeat/automatic returns without supplying choices."""
import copy
import json
import re


def require(ok, message):
    if not ok:
        raise RuntimeError('Seeker continuation: ' + message)


def same(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def checked_envelope(state, audit):
    """Validate a known observer envelope for public projection, not replay fidelity."""
    parent = source_parent(audit)
    data = audit['seeker_continuation']
    previous = data['pending_choice']
    true_fields = {'original_task_pending_at_resume', 'selector_task_identity_matches',
        'source_is_original_card_object', 'original_task_completed_successfully',
        'selector_task_completed_successfully', 'original_and_selector_return_same_card_objects',
        'original_branch_context_verified', 'original_play_task_pending_at_resume'}
    integers = {'origin_action_id', 'previous_action_id', 'selector_invocation_at_end',
        'original_task_returned_count', 'returned_sample_index', 'original_play_action_id'}
    other = {'schema_version', 'origin_parent', 'pending_choice', 'selector_pending_at_end',
        'original_play_card_id', 'original_play_target_combat_id', 'original_play_task_completed_successfully',
        'original_play_state_at_end', 'original_play_cancelled'}
    pending = state.get('decision') == 'card_select'
    require(set(data) == true_fields | integers | other
        and data['schema_version'] == 'seeker-pending-task-continuation-v1'
        and all(data[k] is True for k in true_fields)
        and all(type(data[k]) is int and data[k] >= 0 for k in integers)
        and data['original_play_action_id'] > 0 and data['original_task_returned_count'] == 1
        and type(previous.get('selector_invocations_after')) is int
        and data['selector_invocation_at_end'] == previous['selector_invocations_after'] + int(pending)
        and data['selector_pending_at_end'] is pending and data['original_play_cancelled'] is False
        and data['original_play_task_completed_successfully'] is (not pending)
        and data['original_play_state_at_end'] == ('Executing' if pending else 'Finished')
        and data['original_play_card_id'] == 'SEEKER_STRIKE'
        and type(data['original_play_target_combat_id']) is int and data['original_play_target_combat_id'] >= 0
        and isinstance(previous.get('sample_cards'), list)
        and data['returned_sample_index'] < len(previous['sample_cards'])
        and previous.get('schema_version') == 'seeker-option-order-v1'
        and state.get('player', {}).get('combat_metrics', {}).get('combat_id') == parent['combat_id']
        and ('player_turn' not in state or state['player_turn'] == parent['player_turn']),
        'unknown or incomplete observer envelope')


def source_parent(audit):
    parent = audit.get('parent', {})
    if parent.get('action') == 'play_card':
        return parent
    data = audit.get('seeker_continuation')
    require(isinstance(data, dict), 'selection lost its original source')
    origin = data.get('origin_parent', {})
    previous = data.get('pending_choice', {})
    parent_keys = {'action', 'card_index', 'card_id', 'card_key', 'player_id', 'combat_id', 'player_turn',
        'combat_active_before', 'potion_index', 'potion_slot', 'potion_id'}
    require(isinstance(origin, dict) and isinstance(previous, dict) and set(parent) == set(origin) == parent_keys,
        'unknown parent envelope')
    require(audit.get('closed') is True and type(audit.get('action_id')) is int
        and type(data.get('origin_action_id')) is int and data['origin_action_id'] > 0
        and type(data.get('previous_action_id')) is int
        and data['origin_action_id'] <= data['previous_action_id'] == audit['action_id'] - 1
        and origin.get('action') == 'play_card' and origin.get('card_id') == 'SEEKER_STRIKE'
        and isinstance(origin.get('card_key'), str) and origin['card_key'].startswith('SEEKER_STRIKE+')
        and type(origin.get('card_index')) is int and origin['card_index'] >= 0
        and parent.get('action') == 'select_cards' and parent.get('card_id') is None
        and parent.get('card_key') is None and parent.get('potion_id') is None
        and all(type(parent.get(k)) is int and parent[k] == -1 for k in ('card_index', 'potion_index', 'potion_slot'))
        and parent.get('combat_active_before') is origin.get('combat_active_before') is True
        and all(same(parent.get(k), origin.get(k)) for k in ('player_id', 'combat_id', 'player_turn'))
        and previous.get('action_id') == data['previous_action_id']
        and previous.get('source_card_key') == origin['card_key']
        and all(same(previous.get(k), origin.get(k)) for k in ('player_id', 'combat_id', 'player_turn')),
        'original action/selection identity differs')
    return origin


def verify_resume(meta, after, indices, root, root_play):
    audit = after.get('choice_audit', {})
    data = audit.get('seeker_continuation')
    require(isinstance(data, dict), 'original tasks were not observed at resume')
    parent = source_parent(audit)
    previous_audit = meta.get('completion_audit', {})
    previous = meta.get('seeker_choice', {})
    prior = previous_audit.get('seeker_continuation')
    origin_id = prior.get('origin_action_id') if prior else previous_audit.get('action_id')
    origin_parent = prior.get('origin_parent') if prior else previous_audit.get('parent')
    require(same(root.get('parent'), parent) and root.get('action_id') == origin_id,
        'continuation belongs to another original play')
    selected = [c for c in previous.get('sample_cards', []) if c.get('ui_index') in indices]
    require(len(indices) == len(selected) == 1, 'selected original sampled object is missing')
    pending = after.get('decision') == 'card_select'
    counter = previous.get('selector_invocations_after')
    require(type(counter) is int and counter >= 1, 'selector counter is missing')
    expected = {
        'schema_version': 'seeker-pending-task-continuation-v1',
        'origin_action_id': origin_id, 'origin_parent': origin_parent,
        'previous_action_id': previous_audit.get('action_id'), 'pending_choice': previous,
        'original_task_pending_at_resume': True, 'selector_task_identity_matches': True,
        'source_is_original_card_object': True, 'original_task_completed_successfully': True,
        'selector_task_completed_successfully': True, 'selector_invocation_at_end': counter + int(pending),
        'selector_pending_at_end': pending, 'original_task_returned_count': 1,
        'original_and_selector_return_same_card_objects': True,
        'returned_sample_index': selected[0]['option_index'],
        'original_branch_context_verified': True,
        'original_play_action_id': root_play['action_id'], 'original_play_card_id': 'SEEKER_STRIKE',
        'original_play_target_combat_id': root_play['target_combat_id'],
        'original_play_task_pending_at_resume': True,
        'original_play_task_completed_successfully': not pending,
        'original_play_state_at_end': 'Executing' if pending else 'Finished',
        'original_play_cancelled': False,
    }
    require(same(data, expected), 'original task result, sample, counter or provenance differs')


def resolve(executor, before, pending, action):
    from combat_executor import choice_plans, combat_in_progress
    plans = choice_plans(action)
    root = copy.deepcopy(pending.get('choice_audit', {}))
    root_play = copy.deepcopy(pending.get('play_action', {}))
    parent = root.get('parent', {})
    request = copy.deepcopy(executor.last_action_request)
    require(action.get('Kind') == 'PlayCard' and action.get('CardId') == 'SEEKER_STRIKE'
        and len(plans) > 1 and action.get('Choice') == plans[0]
        and action.get('NestedChoices') == plans[1:] and not action.get('TurnStartChoices')
        and type(action.get('NestedChoicesBeforePrimary')) is int and action['NestedChoicesBeforePrimary'] == 0
        and action.get('EndsPlayerTurn') is False
        and pending.get('decision') == 'card_select' and combat_in_progress(pending)
        and before.get('decision') == 'combat_play' and combat_in_progress(before)
        and executor.setup_state_identity(before) == executor.setup_state_identity(pending)
        and parent.get('action') == 'play_card' and parent.get('card_id') == 'SEEKER_STRIKE'
        and parent.get('card_key') == action.get('CardStateKey')
        and root.get('closed') is True and root.get('events') == [] and root.get('original_returns') == []
        and type(root.get('action_id')) is int and root['action_id'] > 0
        and type(action.get('Turn')) is int and action['Turn'] == before.get('player_turn') == parent.get('player_turn')
        and parent.get('combat_id') == executor.setup_state_identity(before)['combat_id']
        and isinstance(request, dict) and request.get('cmd') == 'action' and request.get('action') == 'play_card'
        and request.get('args', {}).get('card_index') == parent.get('card_index'),
        'sequence is not bound to its original solver action')
    require(all(same(root_play.get(k), v) for k, v in {
        'schema_version': 'original-play-action-v1', 'outcome': 'awaiting_selection', 'card_id': 'SEEKER_STRIKE',
        'state': 'Executing', 'completion_task_status': 'WaitingForActivation', 'cancellation_observed': False,
        'on_play_entered': True}.items()) and type(root_play.get('action_id')) is int and root_play['action_id'] > 0
        and root_play.get('target_combat_id') == action.get('TargetCombatId'),
        'original play task is not the pending solver action')
    state = pending
    automatic_verified = False
    for index, plan in enumerate(plans):
        if state.get('decision') == 'card_select':
            capture = []
            state = executor.resolve(state, [plan], setup_choices=capture, allow_pending=True)
            require(len(capture) == 1, 'manual selection capture is incomplete')
            manual = capture[0]
            indices = [int(i) for i in manual['actual_request']['args']['indices'].split(',')]
            verify_resume(manual['actual_choice_metadata'], state, indices, root, root_play)
            require(state.get('choice_audit', {}).get('events') == [], 'uncovered original choice event')
            if not combat_in_progress(state):
                verify_manual_terminal(executor, before, state, action, plans, index, root, request, root_play, manual)
                return state
            if state.get('decision') == 'card_select':
                require(state['choice_audit'].get('original_returns') == [],
                    'automatic return occurred between planned manual selections')
        else:
            require(index == len(plans) - 1, 'automatic return cannot skip planned selections')
            verify_singleton(executor, before, state, action, plan, root, request, root_play)
            automatic_verified = True
    require(automatic_verified or state.get('choice_audit', {}).get('original_returns') == [],
        'original automatic return has no corresponding solver plan')
    require(state.get('decision') == 'combat_play' and combat_in_progress(state)
        and state.get('player_turn') == before.get('player_turn')
        and executor.setup_state_identity(state) == executor.setup_state_identity(before),
        'sequence did not reach its original combat boundary')
    return state


def verify_singleton(executor, before, state, action, plan, root, root_request, root_play):
    from combat_executor import combat_in_progress
    audit = state.get('choice_audit', {})
    parent = source_parent(audit)
    data = audit.get('seeker_continuation', {})
    require(same(parent, root['parent']) and data.get('origin_action_id') == root['action_id']
        and state.get('decision') == 'combat_play' and combat_in_progress(state)
        and state.get('player_turn') == before.get('player_turn')
        and executor.setup_state_identity(state) == executor.setup_state_identity(before)
        and audit.get('closed') is True and audit.get('events') == []
        and audit.get('schema_version') == 'combat-choice-return-v2'
        and audit.get('coverage') == 'FromCombatPile.IsEnding_or_NeowsFury.empty_source.synchronous_empty_return_only'
        and data.get('selector_pending_at_end') is False,
        'automatic return lost the original combat identity')
    cards = plan.get('Cards')
    require(isinstance(cards, list) and len(cards) == 1
        and all(plan.get(k) == v for k, v in {'Effect': 'MoveToHand', 'SourcePile': 'Draw', 'SourceId': '', 'Timing': 'Action'}.items()),
        'unsupported automatic selection plan')
    token = cards[0]
    fields = ('CardId', 'UpgradeLevel', 'StateKey', 'SourceOccurrence', 'OptionOccurrence')
    require(isinstance(token, dict) and all(isinstance(token.get(k), str) and token[k] for k in ('CardId', 'StateKey'))
        and all(type(token.get(k)) is int and token[k] == 0 for k in ('SourceOccurrence', 'OptionOccurrence'))
        and type(token.get('UpgradeLevel')) is int and token['UpgradeLevel'] >= 0,
        'singleton token is incomplete')
    context = plan.get('ContextId')
    require(isinstance(context, str) and re.fullmatch(r'seeker:(0|[1-9][0-9]*):[A-Z][A-Z0-9_]*\+(0|[1-9][0-9]*)', context)
        and context.split(':', 2)[2] == f"{token['CardId']}+{token['UpgradeLevel']}", 'singleton context differs')
    returns = audit.get('original_returns')
    require(isinstance(returns, list) and len(returns) == 1, 'missing original singleton return')
    counter = data.get('selector_invocation_at_end')
    expected = {
        'schema_version': 'original-choice-return-v1', 'invocation_index': 0, 'action_id': audit['action_id'],
        'source_method': 'CardSelectCmd.FromCombatPile', 'effect_callsite': 'SeekerStrike.OnPlay',
        'effect': 'MoveToHand', 'source_id': 'SEEKER_STRIKE', 'source_pile': 'Draw',
        'source_is_actual_parent_object': True, 'player_id': parent['player_id'], 'player_turn': parent['player_turn'],
        'is_over_or_ending_at_entry': False, 'combat_active_at_entry': True,
        'min_select': 1, 'max_select': 1, 'require_manual_confirmation': False,
        'filter_is_null': False, 'filter_reexecuted_by_observer': False, 'raw_source_count_at_entry': 1,
        'selector_invocations_before': counter, 'selector_pending_before': False, 'verified': True,
        'original_task_completed_successfully': True, 'selector_invocations_after': counter,
        'selector_pending_after': False, 'combat_active_at_return': True, 'is_over_or_ending_at_return': False,
        'returned_cards': [{k: token[k] for k in fields}], 'original_returned_collection': 'List<CardModel>',
        'returned_count': 1, 'returned_objects_match_original_source': True, 'raw_source_count_at_return': 1,
        'candidate_basis': 'original_implementation_and_completed_return_without_selector',
    }
    require(same(returns, [expected]), 'automatic result differs from the original solver token')
    require(data.get('original_play_task_completed_successfully') is True
        and data.get('original_play_state_at_end') == 'Finished' and data.get('original_play_cancelled') is False
        and data.get('original_play_action_id') == root_play['action_id']
        and data.get('original_play_target_combat_id') == root_play['target_combat_id'],
        'original repeated play task did not finish')
    meta = executor.checked(cmd='choice_meta')
    require(meta.get('type') == 'choice_meta' and meta.get('selection') == 'none' and meta.get('cards') == []
        and same(meta.get('completion_audit'), audit) and meta.get('seeker_choice') is None,
        'automatic return metadata differs from actual action')
    proof = {'kind': 'seeker_automatic_continuation_completed', 'plan': copy.deepcopy(plan),
        'original_action': copy.deepcopy(action), 'actual_parent_request': copy.deepcopy(root_request),
        'actual_origin_audit': copy.deepcopy(root), 'actual_choice_metadata': copy.deepcopy(meta),
        'actual_origin_play_action': copy.deepcopy(root_play),
        'context_validation': 'original_singleton_token_identity_not_rng_counter'}
    if executor.solve_calls:
        executor.solve_calls[-1].setdefault('replay', []).append(proof)


def verify_manual_terminal(executor, before, state, action, plans, index, root, request, root_play, manual):
    """Bind an actual completed play after a manual return, never a predicted win."""
    from combat_executor import combat_in_progress
    audit = state.get('choice_audit', {})
    checked_envelope(state, audit)
    parent = source_parent(audit)
    data = audit['seeker_continuation']
    identity = executor.setup_state_identity(before)
    after_identity = executor.setup_state_identity(state)
    context = state.get('context', {})
    require(state.get('type') == 'decision' and state.get('decision') in {'map_select', 'card_reward', 'game_over'}
        and combat_in_progress(state) is False and context.get('integrity_recovery_used') is False
        and all(value is not None for value in identity.values())
        and type(identity['combat_id']) is int and identity['combat_id'] > 0
        and all(same(after_identity[k], identity[k]) for k in ('combat_id', 'act', 'floor', 'player_name'))
        and (after_identity['encounter_id'] == identity['encounter_id']
             or after_identity['encounter_id'] is None and state['decision'] in {'map_select', 'game_over'})
        and type(state.get('player', {}).get('hp')) is int and state['player']['hp'] >= 0
        and ('player_turn' not in state or state['player_turn'] == before.get('player_turn')),
        'manual completion did not reach the same actual combat endpoint')
    require(same(parent, root['parent']) and data['origin_action_id'] == root['action_id']
        and audit.get('schema_version') == root.get('schema_version') == 'combat-choice-return-v2'
        and audit.get('coverage') == root.get('coverage')
        and audit.get('closed') is True and audit.get('events') == [] and audit.get('original_returns') == []
        and data['original_play_action_id'] == root_play['action_id']
        and data['original_play_target_combat_id'] == action['TargetCombatId'] == root_play['target_combat_id']
        and data['original_play_task_completed_successfully'] is True
        and data['original_play_state_at_end'] == 'Finished' and data['original_play_cancelled'] is False
        and data['selector_pending_at_end'] is False
        and executor.last_action_request == manual['actual_request']
        and manual['actual_request'].get('action') == 'select_cards'
        and bool(executor.solve_calls), 'manual terminal task or original parent differs')
    meta = executor.checked(cmd='choice_meta')
    require(meta.get('type') == 'choice_meta' and meta.get('selection') == 'none' and meta.get('cards') == []
        and same(meta.get('completion_audit'), audit) and meta.get('seeker_choice') is None,
        'manual terminal selector is still pending or completion changed')
    executor.solve_calls[-1].setdefault('replay', []).append({
        'kind': 'seeker_manual_continuation_ended_combat', 'plan': copy.deepcopy(plans[index]),
        'remaining_plans_not_executed': copy.deepcopy(plans[index + 1:]),
        'original_action': copy.deepcopy(action), 'actual_parent_request': copy.deepcopy(request),
        'actual_origin_audit': copy.deepcopy(root), 'actual_origin_play_action': copy.deepcopy(root_play),
        'actual_choice_metadata': copy.deepcopy(meta), 'actual_manual_selection': copy.deepcopy(manual),
        'combat_identity_before': identity, 'combat_identity_after': after_identity,
        'remaining_battle_plan_stopped': True, 'outcome_basis': 'actual_original_play_task_and_terminal_response'})
