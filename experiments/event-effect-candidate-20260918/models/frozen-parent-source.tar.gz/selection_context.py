"""Bind a macro selection purpose to its immediate, observed source action."""
import copy

from decision_data import DataContractError, state_hash
from mechanism_facts import ENGINE_SHA256

VERSION = "sts2.selection_context.v1"
FEATURE_VERSION = "initial-stat-mechanism-v5"
LEGACY_FEATURE_VERSIONS = {"initial-stat-mechanism-v1", "initial-stat-mechanism-v2"}
EXACT_SELECTION_PURPOSES = {
    "OROBAS.pages.INITIAL.options.SEA_GLASS": ("acquire", "SEA_GLASS", "Deck"),
    "NEOW.pages.INITIAL.options.LEAD_PAPERWEIGHT": ("acquire", "LEAD_PAPERWEIGHT", "Deck"),
    "NEOW.pages.INITIAL.options.PRECISE_SCISSORS": ("remove", "PRECISE_SCISSORS", "None"),
    "AMALGAMATOR.pages.INITIAL.options.COMBINE_STRIKES": ("remove", "AMALGAMATOR", "None"),
    "AMALGAMATOR.pages.INITIAL.options.COMBINE_DEFENDS": ("remove", "AMALGAMATOR", "None"),
    "NEOW.pages.INITIAL.options.POMANDER": ("upgrade", "POMANDER", "Deck"),
    "AROMA_OF_CHAOS.pages.INITIAL.options.MAINTAIN_CONTROL": ("upgrade", "AROMA_OF_CHAOS", "Deck"),
    "SAPPHIRE_SEED.pages.INITIAL.options.EAT": ("upgrade", "SAPPHIRE_SEED", "Deck"),
    "NEOW.pages.INITIAL.options.NEW_LEAF": ("transform", "NEW_LEAF", "Deck"),
    "AROMA_OF_CHAOS.pages.INITIAL.options.LET_GO": ("transform", "AROMA_OF_CHAOS", "Deck"),
    "MORPHIC_GROVE.pages.INITIAL.options.GROUP": ("transform", "MORPHIC_GROVE", "Deck"),
    "WHISPERING_HOLLOW.pages.INITIAL.options.HUG": ("transform", "WHISPERING_HOLLOW", "Deck"),
    "WOOD_CARVINGS.pages.INITIAL.options.BIRD": ("transform", "WOOD_CARVINGS", "Deck"),
}
REGISTRY_HASH = state_hash({"version": VERSION, "engine_sha256": ENGINE_SHA256,
    "exact": EXACT_SELECTION_PURPOSES, "special": ["merchant_remove_card", "SMITH"],
    "fallback": "unverified_unique_english_effect_keyword_v1"})


def selection_context(candidate):
    evidence = candidate.get("evidence", {})
    action, key = candidate["request"]["action"], evidence.get("text_key")
    if action == "choose_option" and key in EXACT_SELECTION_PURPOSES:
        purpose, source, destination = EXACT_SELECTION_PURPOSES[key]
        context = {"purpose": purpose, "source_model": source, "source_option_key": key,
                   "destination": destination, "basis": "verified_exact_option_registry_v1"}
    elif action == "remove_card":
        context = {"purpose": "remove", "basis": "merchant_remove_card_action"}
    elif action == "choose_option" and evidence.get("option_id") == "SMITH":
        context = {"purpose": "upgrade", "source_option_key": "SMITH", "basis": "rest_option_id"}
    elif action == "choose_option":
        text = " ".join(str(evidence.get(k, "")) for k in ("id", "option_id", "name", "title", "description")).lower()
        matches = [purpose for purpose, words in {
            "upgrade": ("upgrade", "smith"), "remove": ("remove a card", "remove 2 cards"),
            "transform": ("transform",), "enchant": ("enchant",),
        }.items() if any(word in text for word in words)]
        if len(matches) != 1:
            return None
        context = {"purpose": matches[0], "basis": "unverified_text_heuristic"}
    else:
        return None
    return {**context, "version": VERSION, "registry_sha256": REGISTRY_HASH,
            "engine_sha256": ENGINE_SHA256, "phase": "immediate_pending_card_selection"}


def direct_action_evidence(state):
    if state is None:
        return None
    return {"state_hash": state_hash(state), "type": state.get("type"), "decision": state.get("decision"),
            "combat_in_progress": state.get("context", {}).get("combat_in_progress")}


def _pending(info):
    return (isinstance(info, dict) and info.get("type") == "decision" and info.get("decision") == "card_select"
            and info.get("combat_in_progress") is False)


def bind_selection_context(candidate, decision_id, source_state, direct_state, advanced_state, *, captured_direct=None):
    context = selection_context(candidate)
    direct = captured_direct if captured_direct is not None else direct_action_evidence(direct_state)
    if context is None or not _pending(direct) or direct["state_hash"] != state_hash(advanced_state):
        return None
    return {**context, "source_decision_id": decision_id, "source_candidate_id": candidate["candidate_id"],
            "source_state_hash": state_hash(source_state), "source_returned_state_hash": direct["state_hash"]}


def validate_interaction_scoring(state, scoring):
    """Recompute the known public transform; never validate learned scores here.

    The caller still audits the original 101 features and model/provenance. This
    verifies the 119 schema, actual-state/legal-request binding, live verified
    mechanism source, exact transform definition and all 18 derived features.
    """
    from initial_policy import FEATURE_NAMES as BASE_NAMES
    from interaction_features import FEATURE_NAMES, VERSION as TRANSFORM_VERSION, extend_scoring_packet

    def require(value, message):
        if not value:
            raise DataContractError(message)

    require(isinstance(scoring, dict)
            and scoring.get("feature_policy_version") == TRANSFORM_VERSION
            and scoring.get("base_feature_policy_version") == FEATURE_VERSION
            and scoring.get("feature_names") == list(FEATURE_NAMES),
            "Unsupported or incomplete interaction feature schema")
    rows = scoring.get("scores")
    require(isinstance(rows, list) and bool(rows), "Interaction packet has no evaluated candidates")
    require(all(isinstance(row, dict) and isinstance(row.get("features"), dict)
                and set(row["features"]) == set(FEATURE_NAMES) for row in rows),
            "Interaction row feature schema differs from the known 119 features")
    base = copy.deepcopy(scoring)
    base["feature_policy_version"] = FEATURE_VERSION
    for row in base["scores"]:
        row["features"] = {name: row["features"][name] for name in BASE_NAMES}
    rebuilt = extend_scoring_packet(state, base)
    require(state_hash(scoring.get("interaction_feature_source"))
            == state_hash(rebuilt["interaction_feature_source"]),
            "Interaction transform definition or verified mechanism source differs")
    require(scoring.get("interaction_semantics") == rebuilt["interaction_semantics"],
            "Interaction feature semantics differ")
    for row, original, expected in zip(rows, base["scores"], rebuilt["scores"]):
        for key in ("features", "interaction_missing", "interaction_evidence"):
            require(state_hash(row.get(key)) == state_hash(expected[key]),
                    "Interaction public feature evidence differs: " + key)
        if "base_features_sha256" in row:
            require(row["base_features_sha256"] == state_hash(original["features"]),
                    "Interaction base feature hash differs")
    return {"valid": True, "feature_policy_version": TRANSFORM_VERSION,
            "definition_sha256": rebuilt["interaction_feature_source"]["definition_sha256"]}


def validate_prefix_policy_sequence(records, policies):
    """Recompute registered prefix-policy choices in actual whole-run order.

    The first-reward scope is stateful, so a packet alone cannot prove it.
    Replaying the pure policy also checks raw public features, candidate-minus-
    skip inputs, actual predictions, rule fallback, RNG and implicit choices.
    No original game, historical observation or model fit is executed.
    """
    from pathlib import Path
    from prefix_health_policy import PrefixHealthPolicy, VERSION as PREFIX_POLICY
    from selection_policy import SelectionPolicy
    from train_prefix_ranker import VERSION as PREFIX_MODEL

    def require(value, message):
        if not value:
            raise DataContractError(message)

    grouped = {}
    for record in records:
        grouped.setdefault(record["run_id"], []).append(record)
    checked = []
    for run_id, sequence in grouped.items():
        def marked(record):
            picked = policies[record["decision_id"]]
            packet = picked["scoring"]
            return (record["metadata"].get("provenance", {}).get("id") == PREFIX_POLICY
                    or picked.get("policy_provenance", {}).get("id") == PREFIX_POLICY
                    or packet.get("policy_id") == PREFIX_POLICY
                    or packet.get("effective_scorer") == PREFIX_MODEL
                    or "model_input_representation" in packet
                    or any("model_features" in row for row in packet.get("scores", [])))
        if not any(marked(record) for record in sequence):
            continue
        manifest = sequence[0]["metadata"]
        provenance = manifest.get("provenance", {})
        require(provenance.get("kind") == "model" and provenance.get("id") == PREFIX_POLICY,
                "Paired-prefix evidence cannot be relabeled as another policy format")
        sampling = manifest.get("sampling", {})
        root = Path(__file__).resolve().parent
        model_path = Path(sampling["model_path"])
        protocol_path = Path(provenance["source_protocol"]["path"])
        model_path = model_path if model_path.is_absolute() else root / model_path
        protocol_path = protocol_path if protocol_path.is_absolute() else root / protocol_path
        base = PrefixHealthPolicy(model_path, protocol_path=protocol_path,
            solver_config=manifest["solver_requested_config"], epsilon=sampling["epsilon"],
            seed=manifest["seed"], character=manifest["character"], ascension=manifest["ascension"],
            mode=manifest["mode"])
        replay = SelectionPolicy(base, max_evaluations=sampling.get("selection_budget", 256))
        require(state_hash(provenance) == state_hash(replay.provenance),
                "Prefix manifest does not describe the registered policy and selection method")
        prior = None
        for position, record in enumerate(sequence):
            picked = policies[record["decision_id"]]
            require(state_hash(record["metadata"]) == state_hash(manifest), "Prefix run metadata changed")
            require(prior is None or (prior.get("environment_error") is None
                    and state_hash(prior["next_state"]) == state_hash(record["state"])),
                    "Prefix scope needs the complete ordered macro chain with no choices after failure")
            context = picked.get("selection_context")
            purpose = context.get("purpose") if isinstance(context, dict) else None
            expected = replay.choose(record["state"], candidates=record["candidate_set"],
                                     selection_purpose=purpose)
            require(type(picked.get("policy_provenance", {}).get("choice_count")) is int
                    and picked["policy_provenance"]["choice_count"] == position,
                    "Prefix scope requires every choice from run position zero")
            require(set(picked) == set(expected) | {"decision_id", "selection_context"}
                    and state_hash({key: picked[key] for key in expected}) == state_hash(expected),
                    "Prefix policy scope, features, predictions, fallback or RNG differ from sequential recomputation")
            require(state_hash(record["chosen"]["request"]) == state_hash(expected["request"])
                    and record["chosen"]["candidate_id"] == expected["candidate_id"]
                    and state_hash(record["policy_provenance"]) == state_hash(expected["policy_provenance"]),
                    "Prefix policy chosen action/provenance differs from the actual journal")
            checked.append(record["decision_id"])
            prior = record
    return {"valid": True, "validated_decision_ids": checked}


def validate_selection_contexts(records, policies):
    """Strict v3/known interaction origin chain; old v1/v2 remain readable."""
    from interaction_features import VERSION as TRANSFORM_VERSION

    validate_prefix_policy_sequence(records, policies)
    from whole_run_audit import validate_whole_run_choices
    validate_whole_run_choices(records, policies)
    previous = {}
    for record in records:
        policy = policies[record["decision_id"]]
        scoring = policy["scoring"]
        version = scoring.get("feature_policy_version", scoring.get("policy_version"))
        prior = previous.get(record["run_id"])
        previous[record["run_id"]] = record
        if version == TRANSFORM_VERSION:
            validate_interaction_scoring(record["state"], scoring)
        elif version in LEGACY_FEATURE_VERSIONS:
            if "base_feature_policy_version" in scoring or "interaction_feature_source" in scoring:
                raise DataContractError("Legacy version cannot bypass interaction context validation")
            continue
        elif version != FEATURE_VERSION:
            raise DataContractError("Unsupported scoring feature version for selection context validation")
        elif "base_feature_policy_version" in scoring or "interaction_feature_source" in scoring:
            raise DataContractError("Base v3 version cannot relabel an interaction scoring packet")
        execution = record.get("execution", {})
        if "selection_context" not in policy or "selection_context" not in execution or "direct_action_result" not in execution:
            raise DataContractError("V3 selection context/direct action evidence is missing")
        context = policy["selection_context"]
        if state_hash(context) != state_hash(execution["selection_context"]):
            raise DataContractError("Policy and journal selection contexts disagree")
        purpose = context.get("purpose") if isinstance(context, dict) else None
        if (scoring.get("selection_purpose") != purpose or execution.get("selection_purpose") != purpose
                or (context is not None and not isinstance(context, dict))):
            raise DataContractError("Selection purpose disagrees with its context")
        direct = execution["direct_action_result"]
        if direct is None and record.get("environment_error") is None:
            raise DataContractError("Successful V3 action lacks its direct return evidence")
        if direct is not None and (not isinstance(direct, dict)
                or set(direct) != {"state_hash", "type", "decision", "combat_in_progress"}
                or not isinstance(direct["state_hash"], str) or len(direct["state_hash"]) != 64
                or any(c not in "0123456789abcdef" for c in direct["state_hash"])
                or (direct["combat_in_progress"] is not None and type(direct["combat_in_progress"]) is not bool)):
            raise DataContractError("Malformed direct action return evidence")
        expected = None
        if prior is not None and prior.get("environment_error") is None:
            prior_direct = prior.get("execution", {}).get("direct_action_result")
            if (_pending(prior_direct) and prior_direct["state_hash"] == state_hash(record["state"])
                    and state_hash(prior["next_state"]) == state_hash(record["state"])):
                expected = bind_selection_context(prior["chosen"], prior["decision_id"], prior["state"],
                                                  record["state"], record["state"])
        if state_hash(context) != state_hash(expected):
            raise DataContractError("Selection context is not bound to the immediately preceding real action")
        if context is not None:
            engine = record["metadata"]["versions"]["engine"]
            if not isinstance(engine, dict) or engine.get("sha256") != ENGINE_SHA256:
                raise DataContractError("Selection purpose registry engine hash differs from the recorded engine")
    return True
