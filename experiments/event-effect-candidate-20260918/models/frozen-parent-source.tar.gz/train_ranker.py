"""Small CPU ridge ranker: explicit weak-prior distillation or observed-policy returns.

No neural-network dependency; the JSON artifact is a shared linear candidate scorer.
Prior mode learns heuristic scores, never game success. Outcome mode only consumes
clean natural non-LLM trajectories, chosen actions and true terminal returns. It
does not assign counterfactual outcomes or label the chosen action as optimal.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import random

from decision_data import DataContractError, materialize_candidate, read_decisions, split_by_seed, state_hash
from initial_policy import FEATURE_NAMES, POLICY_VERSION, InitialPolicy
from run_metadata import atomic_json, file_evidence
from selection_context import validate_selection_contexts


VERSION = "linear-candidate-ridge-v1"


def validate_mechanism_facts(value):
    """Validate stored evidence without substituting today's registry for history."""
    fields = {"version", "engine_sha256", "registry_sha256", "coverage"}
    if (not isinstance(value, dict) or set(value) != fields
            or any(not isinstance(value[key], str) or not value[key] for key in fields)):
        raise DataContractError("Missing or invalid mechanism facts source evidence")
    for key in ("engine_sha256", "registry_sha256"):
        if len(value[key]) != 64 or any(c not in "0123456789abcdef" for c in value[key]):
            raise DataContractError("Invalid mechanism facts SHA256: " + key)
    return copy.deepcopy(value)


def feature_facts_for(records, scores):
    """All splits must use one nonmissing feature version and facts registry."""
    frozen = None
    for record in records:
        policy = scores.get(record["decision_id"])
        if not isinstance(policy, dict) or not isinstance(policy.get("scoring"), dict):
            raise DataContractError("Missing auditable scoring row")
        scoring = policy["scoring"]
        if scoring.get("feature_policy_version", scoring.get("policy_version")) != POLICY_VERSION:
            raise DataContractError("Scoring feature policy version mismatch; historical rows are read-only")
        facts = validate_mechanism_facts(scoring.get("mechanism_facts"))
        if (policy.get("policy_provenance", {}).get("mechanism_facts") != facts
                or record.get("policy_provenance", {}).get("mechanism_facts") != facts):
            raise DataContractError("Scoring mechanism facts differ from policy provenance")
        if frozen is not None and frozen != facts:
            raise DataContractError("Feature mechanism facts must be fixed across all data splits")
        frozen = facts
    return frozen


def vector(features, names):
    if set(features) != set(names) or any(type(features[name]) not in (int, float) for name in names):
        raise DataContractError("Feature schema mismatch")
    values = [float(features[name]) for name in names]
    if not all(math.isfinite(x) for x in values):
        raise DataContractError("Nonfinite model feature")
    return values


def validate_model(model):
    # Numerical validation remains available for historical artifacts. Only
    # SmallValuePolicy grants permission to use one with live feature extraction.
    names = model.get("feature_names")
    if not isinstance(names, list) or not names or len(set(names)) != len(names):
        raise DataContractError("Invalid model feature schema")
    for key in ("means", "scales", "weights", "feature_min", "feature_max"):
        values = model.get(key)
        expected = len(names) + int(key == "weights")
        if not isinstance(values, list) or len(values) != expected or not all(type(v) in (int, float) and math.isfinite(v) for v in values):
            raise DataContractError("Invalid model dimensions or values: " + key)
    if any(scale <= 0 for scale in model["scales"]):
        raise DataContractError("Model scales must be positive")


def linear_solve(matrix, target):
    """Pivoted elimination for a small positive regularized normal equation."""
    rows = [list(row) + [value] for row, value in zip(matrix, target)]
    size = len(rows)
    for col in range(size):
        pivot = max(range(col, size), key=lambda row: abs(rows[row][col]))
        rows[col], rows[pivot] = rows[pivot], rows[col]
        scale = rows[col][col]
        if abs(scale) < 1e-12:
            raise ValueError("Singular fit")
        rows[col] = [x / scale for x in rows[col]]
        for row in range(size):
            if row == col:
                continue
            factor = rows[row][col]
            if factor:
                rows[row] = [a - factor * b for a, b in zip(rows[row], rows[col])]
    return [row[-1] for row in rows]


def fit(examples, names, regularization=1.0):
    if not examples:
        raise ValueError("No training examples")
    if not math.isfinite(regularization) or regularization <= 0:
        raise ValueError("Regularization must be finite and positive")
    for row in examples:
        if type(row["target"]) not in (int, float) or not math.isfinite(row["target"]):
            raise DataContractError("Nonfinite training target")
        weight = row.get("weight", 1.0)
        if type(weight) not in (int, float) or not math.isfinite(weight) or weight <= 0:
            raise DataContractError("Invalid training weight")
    inputs = [vector(row["features"], names) for row in examples]
    means = [sum(column) / len(inputs) for column in zip(*inputs)]
    scales = [max(1.0, math.sqrt(sum((x[j] - means[j]) ** 2 for x in inputs) / len(inputs)))
              for j in range(len(names))]
    size = len(names) + 1
    matrix = [[0.0] * size for _ in range(size)]
    target = [0.0] * size
    for example, values in zip(examples, inputs):
        x = [1.0] + [(a - b) / c for a, b, c in zip(values, means, scales)]
        weight = example.get("weight", 1.0)
        for i in range(size):
            target[i] += weight * x[i] * example["target"]
            for j in range(i, size):
                matrix[i][j] += weight * x[i] * x[j]
    for i in range(size):
        for j in range(i):
            matrix[i][j] = matrix[j][i]
        matrix[i][i] += regularization if i else 1e-8
    weights = linear_solve(matrix, target)
    return {"feature_names": list(names), "means": means, "scales": scales, "weights": weights,
        "feature_min": [min(col) for col in zip(*inputs)], "feature_max": [max(col) for col in zip(*inputs)]}


def predict(model, features):
    validate_model(model)
    x = vector(features, model["feature_names"])
    return model["weights"][0] + sum(w * (v - mean) / scale for w, v, mean, scale in
        zip(model["weights"][1:], x, model["means"], model["scales"]))


def metrics(model, examples):
    if not examples:
        return {"examples": 0, "rmse": None, "mae": None}
    errors = [predict(model, row["features"]) - row["target"] for row in examples]
    return {"examples": len(examples), "rmse": math.sqrt(sum(x*x for x in errors) / len(errors)),
            "mae": sum(abs(x) for x in errors) / len(errors)}


def load_runs(paths):
    records = []
    scores = {}
    sources = []
    for path in paths:
        path = Path(path)
        journal_path = path / "decisions.jsonl"
        policy_path = path / "policy.jsonl"
        records.extend(read_decisions(journal_path))
        sources.extend([file_evidence(journal_path), file_evidence(policy_path)])
        for line in policy_path.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            if row["decision_id"] in scores:
                raise DataContractError("Duplicate decision ID across input runs")
            scores[row["decision_id"]] = row
    if len({row["decision_id"] for row in records}) != len(records):
        raise DataContractError("Repeated input run")
    return records, scores, sources


def examples_for(records, scores, mode):
    feature_facts_for(records, scores)
    validate_selection_contexts(records, scores)
    examples = []
    # Weight each decision equally even when multi-select exposes many candidates.
    for record in records:
        policy = scores.get(record["decision_id"])
        if not policy:
            raise DataContractError("Missing auditable scoring row")
        provenance = policy["policy_provenance"]
        if (provenance != record["policy_provenance"]
                or policy["request"] != record["chosen"]["request"]
                or policy["candidate_id"] != record["chosen"]["candidate_id"]
                or policy["scoring"].get("state_hash") != state_hash(record["state"])):
            raise DataContractError("Scoring row does not match the recorded state, chosen action or policy")
        if (provenance.get("origin") != "natural"
                or "run_contains_non_natural_or_non_training_policy" in record["training_exclusion_reasons"]):
            raise DataContractError("Non-natural, LLM or human-contaminated rollouts cannot supply training labels")
        allowed = {"rules"} if mode == "prior" else {"rules", "model", "search", "exploration"}
        if provenance.get("kind") not in allowed or provenance.get("llm_involved") is not False:
            raise DataContractError("This trainer expects an auditable non-LLM policy; prior labels must come from rules")
        scored = policy["scoring"]["scores"]
        space = record["candidate_set"]
        if not isinstance(scored, list) or not scored or len({s["candidate_id"] for s in scored}) != len(scored):
            raise DataContractError("Missing or duplicate scored candidates")
        if space.get("representation") == "ordered_selection_implicit_v1":
            from selection_policy import validate_selection_evidence
            validate_selection_evidence(record["state"], space, policy)
            if (policy["scoring"].get("evaluated_candidates_complete") is not False
                    or policy["scoring"].get("candidate_count") != space["candidate_count"]):
                raise DataContractError("Implicit candidate evaluation must declare its actual coverage")
            if record["chosen"]["candidate_id"] not in {s["candidate_id"] for s in scored}:
                raise DataContractError("Chosen implicit action has no auditable score")
        else:
            expected = {c["candidate_id"] for c in space["candidates"]}
            if {s["candidate_id"] for s in scored} != expected or len(scored) != len(expected):
                raise DataContractError("Scored candidates differ from complete engine candidates")
        for row in scored:
            canonical = materialize_candidate(space, row.get("request"))
            if row["candidate_id"] != canonical["candidate_id"] or row.get("is_skip") is not canonical["is_skip"]:
                raise DataContractError("Scoring row request or identity differs from the current engine candidate")
        if policy["scoring"].get("feature_policy_version", policy["scoring"].get("policy_version")) != POLICY_VERSION:
            raise DataContractError("Scoring feature policy version mismatch")
        if mode == "outcome":
            if not record["training_eligible"]:
                continue
            scored = [s for s in scored if s["candidate_id"] == record["chosen"]["candidate_id"]]
        for row in scored:
            target = row["score"] if mode == "prior" else float(record["run_outcome"]["outcome"] == "victory")
            vector(row["features"], FEATURE_NAMES)
            if type(target) not in (int, float) or not math.isfinite(target):
                raise DataContractError("Nonfinite training target")
            examples.append({"features": row["features"], "target": target, "weight": 1 / len(scored),
                             "run_id": record["run_id"], "decision_id": record["decision_id"]})
    return examples


def train(paths, output, *, mode="prior", regularization=1.0):
    if mode not in {"prior", "outcome"} or regularization <= 0:
        raise ValueError("Invalid training mode or regularization")
    records, scores, sources = load_runs(paths)
    if not records:
        raise DataContractError("No complete decision observations")
    mechanism_facts = feature_facts_for(records, scores)
    grouped = split_by_seed(records)
    if mode == "outcome":
        eligible = [r for r in grouped["train"] if r["training_eligible"]]
        if len({r["seed"] for r in eligible}) < 10:
            raise DataContractError("Outcome fit requires at least 10 clean training seeds; collect more natural runs")
        if len({r["run_outcome"]["outcome"] for r in eligible}) < 2:
            raise DataContractError("Outcome fit requires both wins and losses")
        frozen = set()
        for record in (r for r in records if r["training_eligible"]):
            meta = record["metadata"]
            policy_identity = {k: v for k, v in record["policy_provenance"].items() if k not in {"random_seed", "choice_count"}}
            frozen.add(json.dumps({"policy": policy_identity, "solver": meta["solver_requested_config"],
                "run_conditions": {key: meta[key] for key in ("character", "ascension", "mode")},
                "runtime_versions": {key: meta["versions"].get(key)
                    for key in ("engine", "solver", "cli", "bridge", "ritsu")},
                "sampling_sources": {key: meta["versions"].get("sources", {}).get(key)
                    for key in ("initial_policy.py", "combat_executor.py", "sample_runs.py",
                                "decision_data.py", "selection_space.py", "selection_policy.py",
                                "mechanism_facts.py", "selection_context.py")}}, sort_keys=True))
        if len(frozen) != 1:
            raise DataContractError("Outcome fit cannot mix followup policies or engine/solver configurations")
    examples = {key: examples_for(rows, scores, mode) for key, rows in grouped.items()}
    prior_hashes = {scores[r["decision_id"]]["scoring"].get("prior_source", {}).get("sha256") for r in records}
    if len(prior_hashes) != 1:
        raise DataContractError("Feature prior source must be fixed across all data splits")
    model = fit(examples["train"], FEATURE_NAMES, regularization)
    implicit = [r for r in records if r["candidate_set"].get("representation") == "ordered_selection_implicit_v1"]
    model.update({"format": VERSION, "mode": mode, "feature_policy_version": POLICY_VERSION,
        "feature_prior_sha256": next(iter(prior_hashes)),
        "feature_mechanism_facts": mechanism_facts,
        "calibrated_probability": False,
        "target_semantics": "weak_heuristic_prior_score" if mode == "prior" else "observed_terminal_return_under_frozen_policy",
        "prior_weight": 1.0 if mode == "prior" else 0.0,
        "counterfactual_labels": False, "chosen_action_is_optimal_label": False,
        "regularization": regularization, "sources": sources,
        "split_runs": {key: sorted({r["run_id"] for r in rows}) for key, rows in grouped.items()},
        "validation": {key: metrics(model, examples[key]) for key in ("train", "validation")},
        "test_used_for_fit_or_tuning": False,
        "candidate_label_coverage": {
            "implicit_decisions": len(implicit),
            "implicit_legal_action_count": sum(r["candidate_set"]["candidate_count"] for r in implicit),
            "implicit_evaluated_action_count": sum(len(scores[r["decision_id"]]["scoring"]["scores"]) for r in implicit),
            "labels_for_unevaluated_actions": False,
            "prior_label_sampling": "all_explicit_actions_and_bounded_search_evaluations"},
        "training_seed_count": len({r["seed"] for r in grouped["train"]
            if r["run_id"] in {e["run_id"] for e in examples["train"]}}),
        "limitations": ["uncalibrated_relative_score", "limited_state_and_mechanism_coverage",
            "heuristic_distillation_does_not_prove_play_strength" if mode == "prior" else "on_policy_return_is_not_counterfactual_action_value"]})
    if implicit:
        model["limitations"].append("bounded_search_candidate_labels_are_non_exhaustive")
    if Path(output).exists():
        raise FileExistsError("Choose a new model output path")
    atomic_json(output, model)
    return model


class SmallValuePolicy:
    """Deployment-neutral candidate scores; no API calls and no generated rationale."""
    def __init__(self, path, *, fallback=None, epsilon=.1, seed="model-policy"):
        self.model = json.loads(Path(path).read_text(encoding="utf-8"))
        if self.model.get("format") != VERSION or self.model.get("feature_policy_version") != POLICY_VERSION:
            raise DataContractError("Model/feature version mismatch: historical artifacts are read-only and cannot supply live scores")
        if self.model.get("mode") not in {"prior", "outcome"} or "feature_prior_sha256" not in self.model:
            raise DataContractError("Model training mode or feature-prior evidence is missing")
        validate_model(self.model)
        if self.model["feature_names"] != list(FEATURE_NAMES):
            raise DataContractError("Model feature schema differs from live scoring features")
        if not 0 <= epsilon <= 1:
            raise ValueError("epsilon must be 0..1")
        self.fallback = fallback or InitialPolicy(epsilon=0, random_seed=seed)
        self.mechanism_source = validate_mechanism_facts(self.model.get("feature_mechanism_facts"))
        if self.mechanism_source != validate_mechanism_facts(self.fallback.mechanism_source):
            raise DataContractError("Model mechanism facts differ from the live feature source")
        if self.model.get("feature_prior_sha256") != self.fallback.prior.source["sha256"]:
            raise DataContractError("Model feature prior CSV hash differs from live feature source")
        self.epsilon = epsilon
        self.rng = random.Random(seed)
        self.seed = seed
        self.choice_count = 0
        self.sha256 = hashlib.sha256(Path(path).read_bytes()).hexdigest()

    @property
    def provenance(self):
        return {"origin": "natural", "kind": "model", "id": VERSION, "version": self.sha256,
                "llm_involved": False, "epsilon": self.epsilon, "random_seed": self.seed,
                "prior_sha256": self.model["feature_prior_sha256"],
                "mechanism_facts": copy.deepcopy(self.mechanism_source)}

    def score(self, state, candidates=None, *, selection_purpose=None):
        result = self.fallback.score(state, candidates, selection_purpose=selection_purpose)
        return self._model_score(result)

    def score_requests(self, state, requests, *, selection_purpose=None):
        result = self.fallback.score_requests(state, requests, selection_purpose=selection_purpose)
        return self._model_score(result)

    def _model_score(self, result):
        if (result.get("mechanism_facts") != self.mechanism_source
                or self.fallback.mechanism_source != self.mechanism_source):
            raise DataContractError("Live feature mechanism facts changed after model loading")
        for row in result["scores"]:
            row["prior_score"] = row["score"]
            row["score"] = predict(self.model, row["features"])
            values = vector(row["features"], self.model["feature_names"])
            outside = [name for name, x, lo, hi in zip(self.model["feature_names"], values,
                self.model["feature_min"], self.model["feature_max"]) if x < lo or x > hi]
            row["model_coverage"] = {"out_of_training_range": outside, "uncertainty_calibrated": False}
            row["mechanism_evidence_source"] = "feature_rules; not the model's reasoning"
        baseline = next((r["score"] for r in result["scores"] if r["is_skip"]), None)
        for row in result["scores"]:
            row["delta_from_skip"] = row["score"] - baseline if baseline is not None else None
        result["model"] = {"sha256": self.sha256, "mode": self.model["mode"], "calibrated_probability": False,
            "feature_policy_version": POLICY_VERSION, "feature_mechanism_facts": copy.deepcopy(self.mechanism_source)}
        result["score_semantics"] = "uncalibrated_relative_model_score"
        result["policy_id"] = VERSION
        result["policy_version"] = VERSION
        result["feature_policy_version"] = POLICY_VERSION
        return result

    def choose(self, state, candidates=None, *, selection_purpose=None):
        scoring = self.score(state, candidates, selection_purpose=selection_purpose)
        rows = scoring["scores"]
        best = max(row["score"] for row in rows)
        greedy = [row for row in rows if abs(row["score"] - best) <= 1e-12]
        explored = self.rng.random() < self.epsilon
        chosen = self.rng.choice(rows if explored else greedy)
        result = {"request": chosen["request"], "candidate_id": chosen["candidate_id"], "scoring": scoring,
            "policy_provenance": {**self.provenance, "choice_count": self.choice_count},
            "exploration": {"epsilon": self.epsilon, "explored": explored,
                "chosen_probability": self.epsilon / len(rows) + ((1 - self.epsilon) / len(greedy) if chosen in greedy else 0),
                "greedy_tie_count": len(greedy), "candidate_count": len(rows), "random_seed": self.seed,
                "choice_count": self.choice_count}}
        self.choice_count += 1
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", nargs="+", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--mode", choices=("prior", "outcome"), default="prior")
    parser.add_argument("--regularization", type=float, default=1.0)
    args = parser.parse_args()
    model = train(args.runs, args.output, mode=args.mode, regularization=args.regularization)
    print(json.dumps({"output": str(args.output), "mode": model["mode"],
        "parameters": len(model["weights"]), "training_seeds": model["training_seed_count"],
        "validation": model["validation"], "calibrated_probability": False}))


if __name__ == "__main__":
    main()
