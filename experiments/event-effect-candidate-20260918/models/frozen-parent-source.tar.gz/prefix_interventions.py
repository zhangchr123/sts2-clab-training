"""Actual next-combat experiments after a strictly checked same-seed action prefix.

Each arm starts a NEW original engine and replays recorded original actions.
This is not save/load, an exact state/RNG clone, or a natural win-rate sample.
All legal reward actions and a second skip control are predeclared, executed,
and retained. Only the first eligible ordinary Act1 reward is selected, without
using the source run's outcome. The suffix uses rules and original CombatSolver.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import random
import re
import time
import traceback

from combat_executor import CombatExecutor, require_macro_boundary
from decision_data import enumerate_candidates, materialize_candidate, state_hash
from initial_policy import InitialPolicy
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence
from run_metadata import atomic_json, file_evidence, metadata
from selection_context import bind_selection_context, direct_action_evidence
from selection_policy import SelectionPolicy


VERSION = "same-seed-prefix-next-combat-intervention-v1"
IGNORED_PUBLIC_FIELDS = ("choice_audit", "play_action")
SOURCES = ("prefix_interventions.py", "audit_prefix_interventions.py", "compare_batches.py", "solver_evidence.py",
           "train_prefix_ranker.py", "train_ranker.py", "interaction_features.py",
           "combat_executor.py", "replay_evidence.py", "probe.py",
           "run_metadata.py", "initial_policy.py", "decision_data.py", "mechanism_facts.py",
           "selection_space.py", "selection_policy.py", "selection_context.py")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def parse_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key")
            result[key] = value
        return result
    def bad_constant(value):
        raise ValueError("Nonfinite JSON number: " + value)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=bad_constant)


def read_json(path):
    return parse_json(Path(path).read_text(encoding="utf-8-sig"))


def read_lines(path):
    # Journals are immutable local artifacts; reject non-JSON/blank records.
    return [parse_json(line)
        for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def public_state(state):
    require(isinstance(state, dict), "Missing public response")
    if "play_action" in state:
        receipt = state["play_action"]
        require(isinstance(receipt, dict) and set(receipt) == {"schema_version", "outcome", "action_id",
                "card_id", "target_combat_id", "state", "completion_task_status", "cancellation_observed",
                "on_play_entered"} and receipt.get("schema_version") == "original-play-action-v1",
                "Unknown play-action observer envelope")
        require(receipt["outcome"] in {"completed", "awaiting_selection"}
                and receipt["cancellation_observed"] is False and receipt["on_play_entered"] is True,
                "Play-action observer does not show an entered uncanceled original play")
        if receipt["outcome"] == "completed":
            require(receipt["state"] == "Finished" and receipt["completion_task_status"] == "RanToCompletion",
                    "Original play lacks completion evidence")
    return {key: copy.deepcopy(value) for key, value in state.items() if key not in IGNORED_PUBLIC_FIELDS}


def eligible_gate(state):
    if not isinstance(state, dict):
        return False
    ctx = state.get("context") or {}
    return (state.get("type") == "decision" and state.get("decision") == "card_reward"
        and ctx.get("act") == 1 and ctx.get("ascension") == 10
        and type(ctx.get("floor")) is int and 2 <= ctx["floor"] <= 8
        and ctx.get("room_type") == "Monster" and ctx.get("combat_in_progress") is False
        and ctx.get("integrity_recovery_used") is False)


def select_gate(traces, seed):
    expected_start = {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": seed}
    require(bool(traces) and traces[0].get("request") == expected_start, "Wrong natural source start")
    for index, row in enumerate(traces):
        req, res = row.get("request", {}), row.get("response")
        cmd = req.get("cmd")
        require(cmd in {"start_run", "action", "solve", "combat_meta", "choice_meta"}
                and (cmd != "start_run" or index == 0), "Unsupported prefix command")
        require(isinstance(res, dict) and not row.get("transport_error") and res.get("type") != "error",
                "Source failed before an eligible gate")
        require(res.get("context", {}).get("integrity_recovery_used") is not True, "Source engine recovered")
        if eligible_gate(res):
            require(cmd == "action", "Reward must be an actual action response")
            candidates = enumerate_candidates(res)
            require(candidates.get("complete") and candidates.get("representation") == "explicit_v1",
                    "Gate needs complete explicit candidates")
            rows = candidates["candidates"]
            require(2 <= len(rows) <= 6 and sum(bool(r["is_skip"]) for r in rows) == 1,
                    "Gate needs cards and one real skip")
            require(all(r["request"].get("action") in {"select_card_reward", "skip_card_reward"}
                        for r in rows), "Unexpected reward actions")
            return {"trace_index": index, "state": copy.deepcopy(res),
                    "public_state_hash": state_hash(public_state(res)), "candidates": copy.deepcopy(rows)}
    raise ValueError("No eligible first ordinary Act1 reward")


def unchanged(evidence):
    return all(isinstance(value, dict) and file_evidence(value["path"]) == value for value in evidence)


def prepare(batch, output, *, max_gates=30):
    """Freeze source selection and ALL branch allocations before any new outcome."""
    batch, output = Path(batch).resolve(), Path(output).resolve()
    require(not output.exists(), "Use a fresh protocol output")
    require(type(max_gates) is int and 1 <= max_gates <= 100, "Invalid gate count")
    audit_path = batch / "DATA_AUDIT.json"
    audit = read_json(audit_path)
    require(audit.get("passed") is True, "Source batch needs its completed full audit")
    audited = {str(Path(e["path"]).resolve()): e for e in audit["source_evidence"]}
    reports_path = batch / "reports.json"
    reports = read_json(reports_path)
    require(unchanged([audited[str(reports_path)]]), "Source reports drifted after audit")
    selected, excluded, all_sources = [], [], [file_evidence(audit_path), file_evidence(reports_path)]
    # Run-id ordering is predeclared and does not rank successes, decks, or reward strength.
    for report in sorted(reports, key=lambda row: row["run_id"])[:max_gates]:
        directory = batch.parent / report["run_id"]
        sources = {name: file_evidence(directory / name) for name in ("manifest.json", "trace.jsonl")}
        for evidence in sources.values():
            require(evidence and evidence == audited.get(str(Path(evidence["path"]).resolve())),
                    "Source file is absent from the successful audit or changed")
        all_sources.extend(sources.values())
        manifest = read_json(directory / "manifest.json")
        provenance = manifest.get("provenance", {})
        require(manifest.get("character") == "Defect" and manifest.get("ascension") == 10
                and manifest.get("mode") == "standard" and manifest.get("branch_restore_enabled") is False
                and manifest.get("llm_used_for_combat") is False
                and provenance.get("origin") == "natural" and provenance.get("kind") == "rules"
                and provenance.get("llm_involved") is False, "Source must be natural non-LLM Defect A10 rules")
        require(manifest["seed"] == report["seed"], "Source seed mismatch")
        try:
            gate = select_gate(read_lines(directory / "trace.jsonl"), manifest["seed"])
        except ValueError as exc:
            excluded.append({"run_id": report["run_id"], "seed": manifest["seed"], "reason": str(exc)})
            continue
        gate.update(source_run_id=report["run_id"], seed=manifest["seed"], sources=sources)
        gate["gate_id"] = state_hash({"seed": gate["seed"], "source_trace": sources["trace.jsonl"]["sha256"],
                                       "trace_index": gate["trace_index"]})[:20]
        arms = [{"arm_id": f"candidate-{i}", "candidate_id": c["candidate_id"], "request": c["request"],
                 "is_duplicate_control": False} for i, c in enumerate(gate["candidates"])]
        skip = next(c for c in gate["candidates"] if c["is_skip"])
        arms.append({"arm_id": "skip-replicate", "candidate_id": skip["candidate_id"],
                     "request": skip["request"], "is_duplicate_control": True})
        random.Random(gate["gate_id"] + VERSION).shuffle(arms)
        gate["arms"] = arms
        gate["source_solver_config"] = manifest["solver_requested_config"]
        gate["source_runtime"] = {k: manifest["versions"][k] for k in ("engine", "solver", "ritsu")}
        selected.append(gate)
    require(bool(selected), "No source gates passed; no worker started")
    policy = SelectionPolicy(InitialPolicy(epsilon=.1, random_seed="protocol", origin="prefix_intervention"),
                             max_evaluations=256)
    versions = metadata("prefix-interventions", "protocol", 10, {}, policy.provenance)["versions"]
    frozen = [versions[k] for k in ("engine", "solver", "ritsu", "bridge", "cli", "godot")]
    frozen += [file_evidence(ROOT / name) for name in SOURCES] + [file_evidence(policy.base.prior.source["path"])]
    require(unchanged(frozen + all_sources), "Source/runtime changed during declaration")
    for gate in selected:
        require(all(gate["source_runtime"][key]["sha256"] == versions[key]["sha256"]
                    for key in gate["source_runtime"]), "Engine/solver changed since source action plans")
    from train_prefix_ranker import LEARNER
    protocol = {"schema_version": VERSION, "character": "Defect", "ascension": 10,
        "provenance": "same_seed_action_prefix_intervention", "natural_training_eligible": False,
        "prospective_A10_win_rate_sample": False, "llm_involved": False, "branch_restore_enabled": False,
        "full_state_equality_verified": False, "rng_equality_verified": False,
        "ignored_public_fields": list(IGNORED_PUBLIC_FIELDS), "frozen_sources": frozen,
        "historical_sources": all_sources, "selection": "run_id order; first ordinary Act1 reward floors2..8",
        "requested_source_count": min(max_gates, len(reports)), "gates": selected, "unavailable_gates": excluded,
        "horizon": "first_actual_next_combat_end_under_frozen_rule_suffix",
        "suffix": {"epsilon": .1, "selection_budget": 256,
                   "random_seed": "<source_seed>:prefix-next-combat-v1",
                   "rng_semantics": "fresh identical macro stream per arm; not historical policy RNG continuation"},
        "limits": {"max_seconds_per_arm": 300, "max_suffix_decisions": 60},
        "labels": {"actual_hp_and_hp_event_counts_only": True, "A10_victory_label": False,
                   "source_final_outcome_used": False, "missing_outcome_imputed": False},
        "order": "one worker; deterministic shuffled candidate arms plus duplicate skip per gate",
        "planned_learner": copy.deepcopy(LEARNER)}
    output.parent.mkdir(parents=True, exist_ok=True)
    validate_protocol(protocol)
    atomic_json(output, protocol)
    return protocol


def validate_protocol(protocol):
    from train_prefix_ranker import LEARNER
    require(protocol.get("planned_learner") == LEARNER, "Unknown or undeclared downstream learner")
    require(protocol.get("schema_version") == VERSION and protocol.get("character") == "Defect"
            and type(protocol.get("ascension")) is int and protocol["ascension"] == 10,
            "Wrong intervention protocol scope")
    require(protocol.get("provenance") == "same_seed_action_prefix_intervention"
            and all(protocol.get(k) is False for k in ("natural_training_eligible", "llm_involved",
                "prospective_A10_win_rate_sample", "branch_restore_enabled",
                "full_state_equality_verified", "rng_equality_verified")), "Invalid intervention provenance")
    require(protocol.get("ignored_public_fields") == list(IGNORED_PUBLIC_FIELDS), "Unexpected comparison exclusions")
    require(protocol.get("horizon") == "first_actual_next_combat_end_under_frozen_rule_suffix"
            and protocol.get("limits") == {"max_seconds_per_arm": 300, "max_suffix_decisions": 60}
            and protocol.get("suffix", {}).get("epsilon") == .1
            and protocol["suffix"].get("selection_budget") == 256, "Undeclared horizon, limits or policy")
    frozen = protocol.get("frozen_sources", [])
    require(len(frozen) == len(SOURCES) + 7 and len({e["path"] for e in frozen}) == len(frozen),
            "Incomplete or duplicate runtime source set")
    require({Path(e["path"]).name for e in frozen}.issuperset(SOURCES), "Missing actual execution sources")
    gates = protocol.get("gates", [])
    require(bool(gates) and len({g["gate_id"] for g in gates}) == len(gates)
            and len({g["seed"] for g in gates}) == len(gates), "Missing or duplicate root seed gate")
    historical = protocol.get("historical_sources", [])
    audits = [read_json(e["path"]) for e in historical if Path(e["path"]).name == "DATA_AUDIT.json"]
    require(bool(audits) and all(a.get("passed") is True for a in audits), "Missing successful historical full audit")
    audited_files = [e for a in audits for e in a["source_evidence"]]
    for gate in gates:
        require(all(e in historical and e in audited_files for e in gate["sources"].values()),
                "Gate sources were not frozen by the historical audit")
        manifest = read_json(gate["sources"]["manifest.json"]["path"])
        require(manifest["seed"] == gate["seed"] and manifest["run_id"] == gate["source_run_id"]
                and manifest["solver_requested_config"] == gate["source_solver_config"]
                and {k: manifest["versions"][k] for k in ("engine", "solver", "ritsu")} == gate["source_runtime"],
                "Gate source runtime/configuration differs from its frozen original manifest")
        require(eligible_gate(gate["state"]) and state_hash(public_state(gate["state"])) == gate["public_state_hash"],
                "Bad gate state")
        actual = enumerate_candidates(gate["state"])
        require(actual.get("complete") and actual.get("candidates") == gate["candidates"], "Stale gate candidates")
        rows, arms = gate["candidates"], gate["arms"]
        regular = [a for a in arms if a.get("is_duplicate_control") is False]
        controls = [a for a in arms if a.get("is_duplicate_control") is True]
        require(len(regular) == len(rows) and len(controls) == 1 and len(arms) == len(rows) + 1
                and len({a["arm_id"] for a in arms}) == len(arms), "Every candidate and one skip replicate are required")
        require({(a["candidate_id"], state_hash(a["request"])) for a in regular}
                == {(c["candidate_id"], state_hash(c["request"])) for c in rows}, "Candidate arm substitution")
        skip = next(c for c in rows if c["is_skip"])
        require(controls[0]["candidate_id"] == skip["candidate_id"] and controls[0]["request"] == skip["request"],
                "Duplicate control must be actual skip")
    return protocol


def run_arm(protocol, gate, arm, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    label = output.name
    require(re.fullmatch(r"[A-Za-z0-9_-]+", label), "Invalid isolated worker label")
    evidence = protocol["frozen_sources"] + protocol["historical_sources"]
    require(unchanged(evidence), "Frozen input drift before worker")
    prefix = read_lines(gate["sources"]["trace.jsonl"]["path"])[:gate["trace_index"] + 1]
    expected_gate = select_gate(prefix, gate["seed"])
    require(all(state_hash(expected_gate[k]) == state_hash(gate[k]) for k in expected_gate), "Gate declaration drift")
    require(arm in gate["arms"], "Arm was not predeclared")
    info = {"schema_version": VERSION, "gate_id": gate["gate_id"], "seed": gate["seed"], "arm": arm,
            "provenance": protocol["provenance"], "natural_training_eligible": False,
            "full_state_equality_verified": False, "rng_equality_verified": False,
            "status": "starting", "observed_label": None}
    atomic_json(output / "declaration.json", {"protocol_sha256": state_hash(protocol), "gate": gate, "arm": arm})
    bridge, state = None, None
    started = time.monotonic()
    trace_rows, solve_calls, prefix_checks, macro_count = [], [], 0, 0
    battle_started, battle_start, suffix_start_index = False, None, None
    failure_evidence = None
    policy = SelectionPolicy(InitialPolicy(epsilon=protocol["suffix"]["epsilon"],
        random_seed=gate["seed"] + ":prefix-next-combat-v1", origin="prefix_intervention"), max_evaluations=256)
    try:
        bridge = Bridge(label)
        with (output / "trace.jsonl").open("x", encoding="utf-8") as trace, \
                (output / "policy.jsonl").open("x", encoding="utf-8") as policy_log:
            phase, historical_index = "historical_prefix", None
            def send(**request):
                nonlocal state, battle_started, battle_start, failure_evidence
                if time.monotonic() - started > protocol["limits"]["max_seconds_per_arm"]:
                    failure_evidence = {"kind": "deadline_before_send", "elapsed": time.monotonic() - started,
                                        "request_not_sent": copy.deepcopy(request), "trace_count": len(trace_rows)}
                    raise TimeoutError("Declared arm deadline")
                row = {"phase": phase, "historical_trace_index": historical_index,
                       "request": copy.deepcopy(request), "response_received": False}
                begin = time.monotonic()
                try:
                    row["response"] = bridge.send(**request)
                    row["response_received"] = True
                except Exception as exc:
                    row.update(response=None, transport_error=repr(exc))
                    raise
                finally:
                    row["seconds"] = time.monotonic() - begin
                    trace_rows.append(row)
                    trace.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                    trace.flush()
                result = row["response"]
                require(isinstance(result, dict), "Malformed engine response")
                # Preserve original bounded solver-cancellation retry and its call log.
                # Actual game actions still fail immediately and are never retried here.
                require(result.get("type") != "error" or request.get("cmd") == "solve",
                        "Actual engine error: " + str(result))
                if result.get("type") == "decision":
                    require(result.get("context", {}).get("integrity_recovery_used") is False,
                            "Missing original no-recovery evidence")
                    state = copy.deepcopy(result)
                    if phase != "historical_prefix" and result.get("context", {}).get("combat_in_progress") is True:
                        if not battle_started:
                            battle_start = copy.deepcopy(result)
                        battle_started = True
                return result
            for historical_index, row in enumerate(prefix):
                if row["request"]["cmd"] in {"solve", "combat_meta", "choice_meta"}:
                    continue
                actual = send(**row["request"])
                if state_hash(public_state(actual)) != state_hash(public_state(row["response"])):
                    failure_evidence = {"kind": "public_prefix_mismatch", "historical_trace_index": historical_index,
                                        "actual_trace_index": len(trace_rows) - 1}
                    raise ValueError("Public prefix mismatch at source trace index " + str(historical_index))
                prefix_checks += 1
            require(eligible_gate(state) and state_hash(public_state(state)) == gate["public_state_hash"],
                    "Actual gate mismatch")
            require(unchanged(evidence), "Frozen inputs drifted during prefix")
            phase, historical_index = "intervention_suffix", None
            suffix_start_index = len(trace_rows)
            require(materialize_candidate(enumerate_candidates(state), arm["request"])["candidate_id"]
                    == arm["candidate_id"], "Arm is not actually legal")
            atomic_json(output / "gate-state.json", state)
            executor = CombatExecutor(send, gate["source_solver_config"])
            purpose_context = None
            while True:
                if macro_count >= protocol["limits"]["max_suffix_decisions"]:
                    failure_evidence = {"kind": "macro_limit_before_choice", "completed_choices": macro_count,
                                        "trace_count": len(trace_rows)}
                    raise TimeoutError("Suffix macro limit")
                require(unchanged(protocol["frozen_sources"]), "Runtime drift before suffix action")
                before = copy.deepcopy(state)
                require_macro_boundary(before)
                candidates = enumerate_candidates(before)
                require(candidates.get("complete"), "Incomplete suffix candidate set")
                purpose = purpose_context["purpose"] if purpose_context else None
                picked = ({"request": copy.deepcopy(arm["request"]), "origin": "predeclared_intervention"}
                    if macro_count == 0 else policy.choose(before, candidates=candidates, selection_purpose=purpose))
                chosen = materialize_candidate(candidates, picked["request"])
                token = f"{label}:{macro_count:04d}"
                policy_log.write(json.dumps({"decision_id": token, "state": before,
                    "candidate_set": candidates, "selection_context": purpose_context, "picked": picked},
                    ensure_ascii=False, allow_nan=False) + "\n")
                policy_log.flush()
                direct = copy.deepcopy(send(**picked["request"]))
                try:
                    state = executor.advance(direct)
                finally:
                    solve_calls.extend(copy.deepcopy(executor.solve_calls))
                macro_count += 1
                purpose_context = bind_selection_context(chosen, token, before, direct, state,
                                                         captured_direct=direct_action_evidence(direct))
                if battle_started and state.get("context", {}).get("combat_in_progress") is False:
                    require_macro_boundary(state)
                    player = state.get("player", {})
                    require(type(player.get("hp")) is int and type(player.get("max_hp")) is int,
                            "Missing actual boundary HP")
                    require(state.get("decision") != "game_over" or state.get("victory") is False,
                            "Unexpected Act1 next-combat victory terminal")
                    validate_replay_evidence(solve_calls, trace_rows[suffix_start_index:])
                    info["observed_label"] = {"horizon": protocol["horizon"], "hp": player["hp"],
                        "max_hp": player["max_hp"], "gate_hp": gate["state"]["player"]["hp"],
                        "combat_metrics": copy.deepcopy(player.get("combat_metrics")),
                        "actual_death": state.get("decision") == "game_over" and state.get("victory") is False,
                        "boundary_state_hash": state_hash(state), "battle_start_state_hash": state_hash(battle_start),
                        "battle_start_context": copy.deepcopy(battle_start.get("context")),
                        "context": copy.deepcopy(state.get("context")),
                        "potions_used": sum(r["request"].get("action") == "use_potion"
                                            for r in trace_rows[suffix_start_index:])}
                    info["status"] = "observed_next_combat_boundary"
                    break
                if state.get("decision") == "game_over":
                    info["status"] = "terminal_before_next_combat"
                    break
    except Exception as exc:
        if failure_evidence is None and trace_rows:
            last = trace_rows[-1]
            if last.get("response_received") is False and last.get("transport_error"):
                failure_evidence = {"kind": "transport_error", "actual_trace_index": len(trace_rows) - 1}
            elif isinstance(last.get("response"), dict) and last["response"].get("type") == "error":
                failure_evidence = {"kind": "engine_error", "actual_trace_index": len(trace_rows) - 1}
        if failure_evidence is None:
            failure_evidence = {"kind": "execution_guard_rejection", "trace_count": len(trace_rows),
                                "offline_failure_reason_not_yet_verified": True}
        info.update(status="timeout" if isinstance(exc, TimeoutError) else "environment_or_prefix_error",
                    error=str(exc), traceback=traceback.format_exc(), observed_label=None,
                    failure_evidence=failure_evidence)
    finally:
        if bridge is not None:
            bridge.close()
        stable = unchanged(evidence)
        if not stable:
            info.update(status="invalidated_input_drift", observed_label=None)
        info.update(prefix_responses_verified=prefix_checks, suffix_macro_decisions=macro_count,
                    frozen_inputs_unchanged=stable, seconds=time.monotonic() - started,
                    trace_source=file_evidence(output / "trace.jsonl"),
                    policy_source=file_evidence(output / "policy.jsonl"), suffix_start_trace_index=suffix_start_index)
        atomic_json(output / "solver-calls.json", solve_calls)
        atomic_json(output / "final-state.json", state)
        atomic_json(output / "result.json", info)
    return info


def run_protocol(path):
    path = Path(path).resolve()
    protocol, original = read_json(path), file_evidence(path)
    validate_protocol(protocol)
    out = path.parent
    require(not (out / "execution-started.json").exists(), "Existing experiment cannot be resumed or overwritten")
    require(unchanged(protocol["frozen_sources"] + protocol["historical_sources"]), "Frozen declaration drift")
    atomic_json(out / "execution-started.json", {"protocol": original, "planned_arms":
        sum(len(g["arms"]) for g in protocol["gates"]), "new_worker_per_arm": True})
    results = []
    for gate in protocol["gates"]:
        for arm in gate["arms"]:
            require(file_evidence(path) == original, "Protocol changed during experiment")
            worker_label = f"prefix-{path.parent.name}-{gate['gate_id']}-{arm['arm_id']}"
            result = run_arm(protocol, gate, arm, out / worker_label)
            results.append(result)
            atomic_json(out / "results.json", results)
            print(json.dumps({"completed": len(results), "gate_id": gate["gate_id"], "arm": arm["arm_id"],
                              "status": result["status"], "observed": result["observed_label"]}), flush=True)
            require(result["frozen_inputs_unchanged"], "Stopping experiment after runtime drift")
    atomic_json(out / "completion.json", {"protocol": original, "planned_arms": len(results),
        "observed_boundaries": sum(r["observed_label"] is not None for r in results),
        "failed_or_unavailable_arms": sum(r["observed_label"] is None for r in results),
        "natural_A10_win_rate_claim": False, "training_loader_audit_pending": True})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    declaration = sub.add_parser("prepare")
    declaration.add_argument("--batch", type=Path, required=True)
    declaration.add_argument("--output", type=Path, required=True)
    declaration.add_argument("--max-gates", type=int, default=30)
    execute = sub.add_parser("run")
    execute.add_argument("--protocol", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        protocol = prepare(args.batch, args.output, max_gates=args.max_gates)
        print(json.dumps({"gates": len(protocol["gates"]), "unavailable": len(protocol["unavailable_gates"]),
                          "arms": sum(len(g["arms"]) for g in protocol["gates"])}))
    else:
        run_protocol(args.protocol)


if __name__ == "__main__":
    main()
