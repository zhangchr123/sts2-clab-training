"""Synthetic transition tests only; no game workers or training labels."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import prefix_interventions as pi


def state(decision="card_reward", *, floor=2, hp=60, combat=False):
    result = {"type": "decision", "decision": decision,
        "context": {"act": 1, "ascension": 10, "floor": floor, "room_type": "Monster",
            "combat_in_progress": combat, "integrity_recovery_used": False, "encounter_id": "SYNTHETIC"},
        "player": {"hp": hp, "max_hp": 75, "gold": 0, "deck": []},
        "cards": [{"index": 0, "id": "LEAP", "cost": 1, "type": "Skill", "stats": {"Block": 9}}],
        "can_skip": True}
    if decision == "map_select":
        result["choices"] = [{"col": 0, "row": 3, "type": "Monster"}]
    return result


def prefix():
    return [{"request": {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": "synthetic"},
             "response": state("event_choice", floor=1)},
            {"request": {"cmd": "action", "action": "end_turn"}, "response": state()}]


class PrefixInterventionTests(unittest.TestCase):
    def test_first_reward_is_selected_without_reading_final_outcome(self):
        traces = prefix() + [{"request": {"cmd": "set_player"}, "response": {"type": "error"}}]
        gate = pi.select_gate(traces, "synthetic")
        self.assertEqual(gate["trace_index"], 1)
        self.assertEqual(len(gate["candidates"]), 2)

    def test_bad_start_injection_or_failed_prefix_is_rejected(self):
        for mutate in (lambda t: t[0]["request"].update(seed="wrong"),
                       lambda t: t.insert(1, {"request": {"cmd": "load_save"}, "response": {"type": "ok"}}),
                       lambda t: t[0].update(response={"type": "error"}),
                       lambda t: t[0]["response"]["context"].update(integrity_recovery_used=True)):
            traces = prefix()
            mutate(traces)
            with self.assertRaises(ValueError):
                pi.select_gate(traces, "synthetic")

    def test_only_explicit_readonly_audit_field_is_ignored(self):
        first, second = state(), state()
        second["choice_audit"] = {"new_observer": True}
        self.assertEqual(pi.public_state(first), pi.public_state(second))
        second["player"]["hp"] -= 1
        self.assertNotEqual(pi.public_state(first), pi.public_state(second))
        first, second = state(), state()
        second["unexpected_new_gameplay_field"] = 1
        self.assertNotEqual(pi.public_state(first), pi.public_state(second))

    def test_gate_does_not_accept_events_bosses_combat_or_later_acts(self):
        for field, value in (("room_type", "Boss"), ("room_type", "Event"), ("act", 2),
                             ("combat_in_progress", True), ("floor", 9), ("ascension", 9)):
            current = state()
            current["context"][field] = value
            self.assertFalse(pi.eligible_gate(current))

    def test_nonfinite_and_duplicate_json_are_rejected(self):
        for raw in ('{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}'):
            with self.assertRaises(ValueError):
                pi.parse_json(raw)

    def exercise_arm(self, *, mismatch=False, fail_action=False, drift=False):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        directory = Path(tmp.name)
        source = directory / "old-trace.jsonl"
        old = prefix()
        source.write_text("".join(json.dumps(r) + "\n" for r in old), encoding="utf-8")
        gate = pi.select_gate(old, "synthetic")
        candidate = gate["candidates"][-1]
        arm = {"arm_id": "skip", "candidate_id": candidate["candidate_id"], "request": candidate["request"],
               "is_duplicate_control": False}
        gate.update(seed="synthetic", gate_id="synthetic", sources={"trace.jsonl": pi.file_evidence(source)},
                    source_solver_config={}, arms=[arm])
        protocol = {"frozen_sources": [], "historical_sources": [pi.file_evidence(source)],
            "provenance": "synthetic_test", "horizon": "first_actual_next_combat_end_under_frozen_rule_suffix",
            "suffix": {"epsilon": .1}, "limits": {"max_seconds_per_arm": 300, "max_suffix_decisions": 60}}
        responses = [copy.deepcopy(r["response"]) for r in old]
        responses += [state("map_select"), state("combat_play", floor=3, combat=True), state(floor=3, hp=51)]
        if mismatch:
            responses[0]["player"]["hp"] -= 1
        if fail_action:
            responses[2] = {"type": "error", "message": "synthetic actual action failure"}
        requests, closed = [], []
        class FakeBridge:
            def __init__(self, label):
                pass
            def send(self, **request):
                requests.append(request)
                response = responses.pop(0)
                if drift:
                    source.write_text("changed", encoding="utf-8")
                return response
            def close(self):
                closed.append(True)
        class FakeExecutor:
            def __init__(self, send, config):
                self.send, self.solve_calls = send, []
            def advance(self, direct):
                if direct["context"]["combat_in_progress"]:
                    return self.send(cmd="action", action="end_turn")
                return direct
        class FakePolicy:
            def __init__(self, *args, **kwargs):
                pass
            def choose(self, before, candidates, selection_purpose=None):
                return {"request": candidates["candidates"][0]["request"]}
        output = directory / "synthetic-arm"
        with patch.object(pi, "Bridge", FakeBridge), patch.object(pi, "CombatExecutor", FakeExecutor), \
             patch.object(pi, "SelectionPolicy", FakePolicy):
            result = pi.run_arm(protocol, gate, arm, output)
        self.assertEqual(closed, [True])
        return result, requests, output

    def test_actual_boundary_and_all_actions_are_retained(self):
        result, requests, output = self.exercise_arm()
        self.assertEqual(result["status"], "observed_next_combat_boundary", result.get("traceback"))
        self.assertEqual(result["observed_label"]["hp"], 51)
        self.assertEqual(result["prefix_responses_verified"], 2)
        self.assertEqual(result["suffix_macro_decisions"], 2)
        self.assertFalse(result["natural_training_eligible"])
        self.assertFalse(result["rng_equality_verified"])
        self.assertEqual(len(pi.read_lines(output / "trace.jsonl")), len(requests))

    def test_prefix_mismatch_stops_before_intervention(self):
        result, requests, _ = self.exercise_arm(mismatch=True)
        self.assertEqual(len(requests), 1)
        self.assertIsNone(result["observed_label"])
        self.assertIn("Public prefix mismatch", result["error"])

    def test_engine_error_is_never_a_death_label_or_retried(self):
        result, requests, output = self.exercise_arm(fail_action=True)
        self.assertEqual(len(requests), 3)
        self.assertIsNone(result["observed_label"])
        self.assertEqual(result["status"], "environment_or_prefix_error")
        self.assertEqual(pi.read_lines(output / "trace.jsonl")[-1]["response"]["type"], "error")

    def test_input_drift_invalidates_even_a_matching_public_response(self):
        result, requests, _ = self.exercise_arm(drift=True)
        self.assertEqual(result["status"], "invalidated_input_drift")
        self.assertIsNone(result["observed_label"])
        self.assertFalse(result["frozen_inputs_unchanged"])


if __name__ == "__main__":
    unittest.main()
