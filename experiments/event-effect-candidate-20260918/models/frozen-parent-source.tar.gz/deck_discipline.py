"""User-requested compact-deck preference, with explicit special-build evidence."""
import math
import re
from decision_data import DataContractError

CONTRACT={'version':'compact-deck-known-ancient-gain-v4','preferred_maximum':25,'ordinary_hard_maximum':36,
          'special_build_scope':'whole_run_after_observed_BingBong_Clone_or_Reflections_Shatter',
          'exploration_epsilon':0.,'soft_cost':'per_added_card: 1 below 20; 3 at 20..24; 14+2*(size-25) at 25+',
          'forced_unknown_gains_are_not_silently_removed':True,
          'known_event_gains':{'BRAIN_LEECH.pages.INITIAL.options.SHARE_KNOWLEDGE':1,
                               'VAKUU.pages.INITIAL.options.SERE_TALON':3,
                               'VAKUU.pages.INITIAL.options.DISTINGUISHED_CAPE':5,
                               'PAEL.pages.INITIAL.options.PAELS_HORN':2,
                               'NONUPEIPE.pages.INITIAL.options.JEWELRY_BOX':1,
                               'TEZCATARA.pages.INITIAL.options.STORYBOOK':1,
                               'NEOW.pages.INITIAL.options.LARGE_CAPSULE':2},
          'ordinary_future_forced_gain_guard':{
              'VAKUU.pages.INITIAL.options.LORDS_PARASOL':'avoid_when_another_legal_event_option_exists'},
          'lords_parasol_is_not_a_special_build_exception':True}
MIRROR='REFLECTIONS.pages.INITIAL.options.SHATTER'

def deck_size(state):
    player=state.get('player',{});deck=player.get('deck')
    if not isinstance(deck,list) or not deck:raise DataContractError('Compact policy requires full public deck')
    if player.get('deck_size',len(deck))!=len(deck):raise DataContractError('Public deck size mismatch')
    return len(deck)

def visible_special_builds(state):
    sources=[];player=state.get('player',{})
    if any(isinstance(r,dict) and r.get('id') in {'RELIC.BING_BONG','BING_BONG'} for r in player.get('relics',[])):
        sources.append('BING_BONG')
    for c in player.get('deck',[]):
        # Current engine exports the localized bilingual enchantment title.
        title=c.get('enchantment','')
        if c.get('enchantment_id') in {'CLONE','ENCHANTMENT.CLONE'} or isinstance(title,str) and (
                re.search(r'\bClone\b',title) or '克隆' in title):
            sources.append('CLONE');break
    return sources

def addition_count(state,row,candidate):
    action=row['request']['action'];item=candidate['evidence']
    if action in {'select_card_reward','buy_card'}:return 1
    if action=='choose_option' and item.get('text_key')=='BRAIN_LEECH.pages.INITIAL.options.SHARE_KNOWLEDGE':
        # The original BrainLeech.ShareKnowledge opens a noncancelable one-card
        # acquisition. Count the known gain before entering that selection.
        variables=item.get('vars',{})
        if not isinstance(variables,dict) or type(variables.get('CardChoiceCount')) is not int or variables['CardChoiceCount']!=1:
            raise DataContractError('Known Brain Leech one-card acquisition contract differs')
        return 1
    if action=='choose_option' and item.get('text_key')=='VAKUU.pages.INITIAL.options.SERE_TALON':
        variables=item.get('vars',{})
        if (not isinstance(variables,dict) or type(variables.get('Wishes')) is not int
                or variables['Wishes']!=3):
            raise DataContractError('Known Sere Talon three-card acquisition contract differs')
        return 3
    if action=='choose_option':
        key=item.get('text_key')
        if key=='VAKUU.pages.INITIAL.options.DISTINGUISHED_CAPE':
            variables=item.get('vars',{})
            if (not isinstance(variables,dict) or type(variables.get('Cards')) is not int or variables['Cards']!=3
                    or type(variables.get('Curses')) is not int or variables['Curses']!=2):
                raise DataContractError('Known Distinguished Cape five-card acquisition contract differs')
            return 5
        if key=='NEOW.pages.INITIAL.options.LARGE_CAPSULE':
            variables=item.get('vars',{})
            if not isinstance(variables,dict) or type(variables.get('Relics')) is not int or variables['Relics']!=2:
                raise DataContractError('Known Large Capsule public relic count differs')
            return 2
        if key in {'PAEL.pages.INITIAL.options.PAELS_HORN','NONUPEIPE.pages.INITIAL.options.JEWELRY_BOX',
                   'TEZCATARA.pages.INITIAL.options.STORYBOOK'}:
            return CONTRACT['known_event_gains'][key]
    if action=='select_bundle' or action=='select_cards' and row['features'].get('selection_acquire')==1.:
        cards=item.get('cards')
        if not isinstance(cards,list):raise DataContractError('Missing acquisition cards')
        return len(cards)
    return 0

def adjust(state,packet,candidates,latched_sources=()):
    size=deck_size(state);special=sorted(set(latched_sources)|set(visible_special_builds(state)))
    for row in packet['scores']:
        candidate=candidates[row['candidate_id']];gain=addition_count(state,row,candidate)
        direct_blocked=bool(gain and not special and size+gain>36)
        # No fictitious immediate count: the relic enables later compulsory
        # merchant acquisitions. Ordinary runs avoid accepting that effect.
        key=candidate['evidence'].get('text_key')
        alternative=any(other['request']['action']=='choose_option'
            and candidates[other['candidate_id']]['evidence'].get('text_key')!=key
            for other in packet['scores'])
        future_blocked=bool(not special and row['request']['action']=='choose_option'
            and key in CONTRACT['ordinary_future_forced_gain_guard'] and alternative)
        blocked=direct_blocked or future_blocked
        penalty=0.
        if not special:
            for n in range(size,size+gain):penalty += 1. if n<20 else 3. if n<25 else 14.+2.*(n-25)
        before=row['score']
        if not math.isfinite(before) or abs(before)>1e80:raise DataContractError('Invalid compact policy score')
        row['deck_discipline']={'deck_size_before':size,'direct_added_cards':gain,'known_size_after':size+gain,
            'special_builds':special,'hard_blocked':blocked,'penalty':penalty,'score_before':before,
            'direct_gain_exceeds_cap':direct_blocked,'future_forced_gain_blocked':future_blocked}
        row['score']=-1e100 if blocked else before-penalty
        row['reasons'].append({'source':CONTRACT['version'],'score':row['score']-before,
                              'explanation':'user_requested_deck_size_preference_and_ordinary_acquisition_cap'})
    skip=next((r['score'] for r in packet['scores'] if r['is_skip']),None)
    for row in packet['scores']:row['delta_from_skip']=None if skip is None else row['score']-skip
    packet['deck_contract']=CONTRACT.copy()
    return packet
