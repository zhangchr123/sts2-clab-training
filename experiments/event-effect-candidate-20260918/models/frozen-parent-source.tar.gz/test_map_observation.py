"""Synthetic map observations only: no worker, query, RNG or model scoring."""
import copy
import unittest

from decision_data import DataContractError, enumerate_candidates, state_hash
from map_observation import make_map_observation, validate_map_observation
from test_route_features import fixtures


def inputs():
    state, response = fixtures()
    state["context"]["combat_in_progress"] = False
    response["context"]["combat_in_progress"] = False
    return state, response


def trace(state, response):
    return {"request": {"cmd": "get_map"}, "response": copy.deepcopy(response),
            "decision_state_hash": state_hash(state), "elapsed": 2., "seconds": .01}


class MapObservationTests(unittest.TestCase):
    def test_capture_is_pure_and_binds_raw_public_graph_and_candidates(self):
        state, response = inputs()
        originals = copy.deepcopy((state, response))
        evidence = make_map_observation(state, response)
        self.assertEqual((state, response), originals)
        self.assertEqual(evidence["response_hash"], state_hash(response))
        self.assertEqual(evidence["public_map_hash"], state_hash(evidence["public_map"]))
        self.assertEqual(evidence["candidate_set"], enumerate_candidates(state))
        self.assertIs(evidence["policy_used"], False)
        self.assertEqual(evidence["status"], "available")
        self.assertFalse(validate_map_observation(state, evidence)["trace_verified"])
        verified = validate_map_observation(state, evidence, trace(state, response))
        self.assertTrue(verified["trace_verified"])
        self.assertEqual(verified["candidate_count"], 2)
        evidence["raw_response"]["rows"].clear()
        evidence["candidate_set"]["candidates"][0]["request"]["args"]["col"] = 999
        self.assertEqual((state, response), originals)

    def test_shadow_fields_change_audit_hash_but_never_public_graph_or_features(self):
        state, response = inputs()
        first = make_map_observation(state, response)
        response["boss"]["id"] = "unconsumed_identity"
        response["context"]["second_boss"] = "unconsumed_future_context"
        response["secret_reward"] = {"id": "must_not_be_a_feature"}
        response["rows"][0][0]["rng"] = [12345]
        second = make_map_observation(state, response)
        self.assertNotEqual(first["response_hash"], second["response_hash"])
        self.assertEqual(first["public_map"], second["public_map"])
        self.assertEqual(first["public_map_hash"], second["public_map_hash"])
        self.assertEqual(first["route_features"]["per_candidate"], second["route_features"]["per_candidate"])
        self.assertTrue(validate_map_observation(state, second, trace(state, response))["valid"])

    def test_missing_start_candidate_is_kept_with_partial_route_coverage(self):
        state, response = inputs()
        state["choices"].append({"col": -1, "row": 0, "type": "Ancient"})
        evidence = make_map_observation(state, response)
        self.assertEqual(evidence["status"], "partial")
        self.assertEqual(len(evidence["candidate_set"]["candidates"]), 3)
        self.assertEqual(len(evidence["route_features"]["per_candidate"]), 3)
        self.assertEqual(evidence["route_features"]["per_candidate"][-1]["features"]["route_available"], 0)
        self.assertTrue(validate_map_observation(state, evidence)["valid"])

    def test_error_absent_or_invalid_graph_is_unavailable_not_a_smaller_action_space(self):
        state, response = inputs()
        malformed = copy.deepcopy(response)
        malformed["rows"][0][0]["children"].append({"col": 999, "row": 999})
        for raw in ({"type": "error", "message": "No map available"}, None, malformed):
            with self.subTest(raw_type=type(raw).__name__):
                evidence = make_map_observation(state, raw)
                self.assertEqual(evidence["status"], "unavailable")
                self.assertIsNone(evidence["public_map"])
                self.assertFalse(evidence["graph_status"]["valid"])
                self.assertEqual(evidence["candidate_set"], enumerate_candidates(state))
                self.assertEqual(len(evidence["route_features"]["per_candidate"]), 2)
                self.assertTrue(validate_map_observation(state, evidence)["valid"])
        row = trace(state, None)
        row["transport_error"] = "TimeoutError: synthetic absent map response"
        self.assertTrue(validate_map_observation(state, make_map_observation(state, None), row)["trace_verified"])

    def test_wrong_state_or_context_scope_is_rejected(self):
        state, response = inputs()
        evidence = make_map_observation(state, response)
        changed = copy.deepcopy(state)
        changed["context"]["floor"] += 1
        with self.assertRaises(DataContractError):
            validate_map_observation(changed, evidence)
        for key, value in (("act", True), ("act", 2), ("floor", 3.), ("ascension", 9)):
            wrong = copy.deepcopy(response)
            wrong["context"][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(DataContractError):
                make_map_observation(state, wrong)
        for changes in ({"ascension": 9}, {"combat_in_progress": True}, {"act": 0}):
            wrong = copy.deepcopy(state)
            wrong["context"].update(changes)
            with self.assertRaises(DataContractError):
                make_map_observation(wrong, response)
        wrong = copy.deepcopy(state)
        wrong["decision"] = "card_reward"
        with self.assertRaises(DataContractError):
            make_map_observation(wrong, response)

    def test_evidence_tampering_cannot_change_policy_usage_request_or_route_values(self):
        state, response = inputs()
        clean = make_map_observation(state, response)
        changes = [lambda e: e.update(policy_used=True), lambda e: e.update(policy_used=0),
            lambda e: e["request"].update(extra="not-part-of-get_map"),
            lambda e: e.update(response_hash="0" * 64), lambda e: e.update(public_map_hash="0" * 64),
            lambda e: e["candidate_set"]["candidates"].pop(),
            lambda e: e["route_features"]["per_candidate"][0]["features"].update(route_rest_min_steps=0),
            lambda e: e["public_map"]["nodes"][0].update(type="RestSite"),
            lambda e: e.update(unregistered_field=True), lambda e: e.pop("raw_response")]
        for index, change in enumerate(changes):
            evidence = copy.deepcopy(clean)
            change(evidence)
            with self.subTest(index=index), self.assertRaises(DataContractError):
                validate_map_observation(state, evidence)

    def test_trace_must_prove_its_pre_state_and_exact_query_response(self):
        state, response = inputs()
        evidence = make_map_observation(state, response)
        changes = [lambda t: t.pop("decision_state_hash"), lambda t: t.update(decision_state_hash="0" * 64),
            lambda t: t["request"].update(cmd="branch_audit"),
            lambda t: t["request"].update(seed="forbidden-query-extra"),
            lambda t: t["response"]["boss"].update(id="modified-audit-response"),
            lambda t: t.update(transport_error="failed despite supplied response")]
        for index, change in enumerate(changes):
            row = trace(state, response)
            change(row)
            with self.subTest(index=index), self.assertRaises(DataContractError):
                validate_map_observation(state, evidence, row)
        with self.assertRaises(DataContractError):
            validate_map_observation(state, make_map_observation(state, None), trace(state, None))


if __name__ == "__main__":
    unittest.main()
