"""Unactivated public-feature prototype; contains no fitted policy or rollout.

Preserves all v1 residual terms and adds currently exported mechanism tags and
bounded deck-context interactions. Tags remain incomplete metadata, not exact
effect magnitudes or claims that a combat trigger will occur.
"""
import math

from decision_data import DataContractError
from initial_policy import MECHANISMS
from whole_run_policy import PARAMETERS as BASE_PARAMETERS, residual_features

VERSION = 'contextual-residual-feature-prototype-v2'
EXTRA_TAGS = (
    'aoe', 'block_per_turn', 'dark_source', 'decaying_focus',
    'discard_retrieval', 'evoke', 'forge_per_turn', 'frost_threshold_end_turn',
    'increasing_cost', 'lightning_source', 'orb_capacity', 'orb_diversity',
    'orb_passive_trigger', 'plasma_source', 'power_trigger', 'random_orb_source',
    'status_conversion', 'status_creation_trigger', 'status_exhaust',
    'status_source', 'temporary_focus',
)
CONTEXT_PARAMETERS = (
    'focus_with_orb_density', 'capacity_with_orb_density',
    'power_trigger_with_power_density', 'status_handling_with_status_density',
    'status_trigger_with_source_density', 'acquire_late_act', 'power_late_act',
)
PARAMETERS = (*BASE_PARAMETERS, *('card_tag_' + tag for tag in EXTRA_TAGS),
              *CONTEXT_PARAMETERS)


def _number(features, name):
    value = features.get(name)
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        raise DataContractError('Missing or invalid prototype public feature: ' + name)
    return float(value)


def features(state, row, candidate):
    if row['request'] != candidate['request']:
        raise DataContractError('Prototype row/candidate mismatch')
    known_tags = set().union(*MECHANISMS.values())
    if known_tags != set(EXTRA_TAGS) | {'draw', 'energy', 'frost_source', 'sustained_focus'}:
        raise DataContractError('Prototype tag schema drift')
    values = residual_features(state, row, candidate)
    values.update(dict.fromkeys(PARAMETERS[len(BASE_PARAMETERS):], 0.))
    if row['request']['action'] not in {'select_card_reward', 'buy_card'}:
        return values
    act = state['context']['act']
    if type(act) is not int or act not in (1, 2, 3):
        raise DataContractError('Prototype requires actual Act 1-3')
    f = row['features']
    tags = {tag: _number(f, 'mechanism_' + tag) for tag in known_tags}
    if any(value not in (0., 1.) for value in tags.values()):
        raise DataContractError('Expected individual-card mechanism indicators')
    values.update({'card_tag_' + tag: tags[tag] for tag in EXTRA_TAGS})
    deck_size = _number(f, 'deck_size')
    if deck_size < 1:
        raise DataContractError('Expected nonempty public deck')
    # These are counts in the public deck, not trigger probabilities.
    orb_density = min(1., _number(f, 'orb_sources') / deck_size)
    power_density = min(1., _number(f, 'power_count') / deck_size)
    status_density = min(1., (_number(f, 'status_sources')
                             + _number(f, 'deck_statuses')) / deck_size)
    status_source_density = min(1., _number(f, 'status_sources') / deck_size)
    values.update(
        focus_with_orb_density=max(tags['sustained_focus'], tags['temporary_focus'],
                                   tags['decaying_focus']) * orb_density,
        capacity_with_orb_density=tags['orb_capacity'] * orb_density,
        power_trigger_with_power_density=tags['power_trigger'] * power_density,
        status_handling_with_status_density=max(tags['status_conversion'],
                                                tags['status_exhaust']) * status_density,
        status_trigger_with_source_density=tags['status_creation_trigger'] * status_source_density,
        acquire_late_act=(act - 1) / 2.,
        power_late_act=float(candidate['evidence'].get('type') == 'Power') * (act - 1) / 2.,
    )
    return values


def zero_extend(parameters):
    """Return a parameter vector only, never a deployable artifact."""
    if set(parameters) != set(BASE_PARAMETERS) or any(
            type(v) not in (int, float) or not math.isfinite(v) or abs(v) > 4
            for v in parameters.values()):
        raise DataContractError('Invalid source parameter vector')
    return {name: float(parameters.get(name, 0.)) for name in PARAMETERS}
