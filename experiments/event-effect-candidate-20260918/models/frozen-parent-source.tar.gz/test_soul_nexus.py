"""Actual original-engine death boundary; artificial fixture, never training data."""
import json
import unittest
import uuid
from combat_executor import CombatExecutor
from probe import Bridge, ROOT


class SoulNexusTests(unittest.TestCase):
    def test_death_returns_original_reward_without_display_room(self):
        label = "soul-nexus-death-" + uuid.uuid4().hex[:10]
        bridge = Bridge(label)
        requests = []
        def send(**request):
            requests.append(request)
            response = bridge.send(**request)
            self.assertNotEqual(response.get("type"), "error", response)
            return response
        try:
            send(cmd="start_run", character="Defect", ascension=10, seed="soul-nexus-death-fixture")
            send(cmd="set_player", hp=1000, max_hp=1000, deck=["HYPERBEAM"] * 5, potions=[])
            before = send(cmd="enter_room", type="combat", encounter="SOUL_NEXUS_ELITE")
            self.assertEqual(before["context"]["encounter_id"], "SOUL_NEXUS_ELITE")
            executor = CombatExecutor(send)
            after = executor.advance(before)
            self.assertEqual(after["decision"], "card_reward")
            self.assertFalse(after["context"]["combat_in_progress"])
            self.assertFalse(after["context"]["integrity_recovery_used"])
            self.assertGreater(after["player"]["hp"], 0)
            self.assertLess(after["player"]["hp"], before["player"]["hp"])
            self.assertTrue(after["cards"])
            self.assertEqual(send(cmd="action", action="skip_card_reward")["decision"], "map_select")
        finally:
            bridge.close()
            (ROOT / "outputs" / (label + ".json")).write_text(json.dumps({
                "origin": "artificial_fixture", "training_eligible": False,
                "requests": requests, "responses": bridge.rows}, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__": unittest.main()
