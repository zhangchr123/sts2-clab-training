"""Non-LLM cold-start macro scoring with explicit uncertainty and exploration.

Scores are arbitrary relative heuristic utilities, never calibrated win rates.
The local CSV supplies at most +/-0.15 points of association-based prior; it
does not provide sample sizes, version, ascension or deck context. Mechanism
tags below were checked against this bridge's current localization_eng/cards.json.
They are deliberately incomplete and are not mutually exclusive archetypes.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import math
from pathlib import Path
import random
import re
from typing import Any, Mapping

from decision_data import (DEFAULT_ENUMERATION_LIMIT, LEGACY_ENUMERATION_LIMIT, DataContractError,
                           enumerate_candidates, materialize_candidate, state_hash, validate_candidate_set)
from mechanism_facts import DEFAULT_ENGINE, FACTS, MINIGAME_FACTS, verified_source


POLICY_VERSION = "initial-stat-mechanism-v5"
DEFAULT_PRIOR = Path(__file__).resolve().parent.parent / "sts2-draw-rate" / "result_cleaned.csv"
PRIOR_MISSING = ["sample_size", "game_version", "ascension", "deck_context", "sampling_protocol"]
MECHANISMS = {
    "ZAP": {"lightning_source"}, "BALL_LIGHTNING": {"lightning_source"},
    "COOLHEADED": {"frost_source", "draw"}, "GLACIER": {"frost_source"}, "COLD_SNAP": {"frost_source"},
    "DARKNESS": {"dark_source"}, "RAINBOW": {"lightning_source", "frost_source", "dark_source"},
    "CHAOS": {"random_orb_source"}, "FUSION": {"plasma_source"},
    "DUALCAST": {"evoke"}, "MULTI_CAST": {"evoke"}, "LOOP": {"orb_passive_trigger"},
    "DEFRAGMENT": {"sustained_focus"},
    "HOTFIX": {"temporary_focus"}, "FOCUSED_STRIKE": {"temporary_focus"},
    "SYNCHRONIZE": {"temporary_focus", "orb_diversity"},
    "BIASED_COGNITION": {"decaying_focus"},
    "CAPACITOR": {"orb_capacity"}, "MODDED": {"orb_capacity", "draw", "increasing_cost"},
    "SKIM": {"draw"}, "OVERCLOCK": {"draw", "status_source"},
    "TURBO": {"energy", "status_source"}, "HOLOGRAM": {"discard_retrieval"},
    "COMPACT": {"status_conversion"}, "FLAK_CANNON": {"status_exhaust"},
    "SMOKESTACK": {"status_creation_trigger", "aoe"},
    "FURNACE": {"forge_per_turn"},
    "STORM": {"power_trigger", "lightning_source"}, "SUBROUTINE": {"power_trigger", "energy"},
    "COOLANT": {"orb_diversity", "block_per_turn"},
    "GUNK_UP": {"status_source"},
    "HAILSTORM": {"aoe", "frost_threshold_end_turn"},
}
QUANTITY_FEATURES = ("damage_per_hit", "attack_hit_count", "single_target_nominal_damage",
                     "draw_cards", "draw_cards_per_cost", "energy_gain", "energy_gain_per_cost",
                     "frost_channel_count", "frost_channel_count_known", "combat_discard_status_cards",
                     "conditional_end_turn_aoe_damage", "conditional_end_turn_aoe_requires_frost",
                     "conditional_end_turn_aoe_trigger_unknown")
ACTION_NAMES = ("select_card_reward", "skip_card_reward", "select_bundle", "select_cards",
                "choose_option", "select_map_node", "buy_card", "buy_relic", "buy_potion",
                "remove_card", "discard_potion", "leave_room", "crystal_sphere_reveal")
FEATURE_NAMES = ("base_damage_per_cost", "base_block_per_cost", "health_deficit", "existing_copies",
                 "deck_size", "orb_sources", "status_sources", "deck_statuses", "power_count",
                 "gold_spend", "selected_count", "is_skip", "missing_count", "prior_association",
                 "selection_upgrade", "selection_remove", "selection_transform", "selection_enchant", "selection_acquire",
                 "selection_unknown", "selected_card_damage_per_cost", "selected_card_block_per_cost",
                 "selected_card_utility_proxy", "actual_upgrade_delta_proxy", "missing_upgrade_previews",
                 "first_selected_damage_per_cost", "first_selected_block_per_cost", "first_selected_utility_proxy",
                 "last_selected_damage_per_cost", "last_selected_block_per_cost", "last_selected_utility_proxy",
                 "bundle_card_count", "rest_heal", "rest_smith", "rest_other", "missing_hp",
                 "best_upgrade_delta_proxy", "map_monster", "map_elite", "map_rest", "map_shop",
                 "map_treasure", "map_unknown", "map_boss", "map_ancient", "map_other",
                 "acquisition_opportunity_cost", *QUANTITY_FEATURES,
                 "crystal_hidden_cells_covered", "crystal_tool_small", "crystal_tool_big",
                 *["action_" + name for name in ACTION_NAMES],
                 *["mechanism_" + tag for tag in sorted(set().union(*MECHANISMS.values()))])


def card_id(card: Mapping[str, Any]) -> str:
    return str(card.get("id", "")).split(".")[-1].upper()


def _join_id(value: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", value.upper().split(".")[-1])


def _number(value: Any) -> float | None:
    return float(value) if type(value) in (int, float) and math.isfinite(value) else None


def card_mechanisms(card: Mapping[str, Any]) -> set[str]:
    """Only checked identity tags; no inference that Status creation removes it."""
    return set(MECHANISMS.get(card_id(card), set()))


def crystal_public_coverage(state, x, y, tool):
    """Count only publicly hidden coordinates. Reward identities are never read."""
    if type(x) is not int or type(y) is not int or tool not in {"small", "big"}:
        raise DataContractError("Invalid Crystal Sphere tool or coordinates")
    hidden = set()
    for cell in state["cells"]:
        if type(cell.get("hidden")) is not bool or type(cell.get("x")) is not int or type(cell.get("y")) is not int:
            raise DataContractError("Invalid public Crystal Sphere cell")
        if cell["hidden"]:
            if set(cell) != {"x", "y", "hidden"}:
                raise DataContractError("Hidden Crystal Sphere cells must not expose reward information")
            hidden.add((cell["x"], cell["y"]))
    if (x, y) not in hidden:
        raise DataContractError("Crystal Sphere action must target a hidden cell")
    offsets = MINIGAME_FACTS["CRYSTAL_SPHERE"][tool + "_offsets"]
    return sum((x + dx, y + dy) in hidden for dx, dy in offsets)


class CardPrior:
    def __init__(self, path: str | Path | None = DEFAULT_PRIOR):
        self.rows: dict[str, dict[str, Any]] = {}
        self.source = {"path": str(Path(path).resolve()) if path is not None else None,
                       "sha256": None, "missing": list(PRIOR_MISSING),
                       "semantics": "uncontrolled_card_statistics_not_causal_action_values"}
        if path is None or not Path(path).is_file():
            self.source["missing"].append("source_file")
            self.center = 0.0
            return
        raw = Path(path).read_bytes()
        self.source["sha256"] = hashlib.sha256(raw).hexdigest()
        lines = list(csv.DictReader(raw.decode("utf-8-sig").splitlines()))
        for line in lines:
            key = _join_id(line.get("InternalName", ""))
            if not key or key in self.rows:
                raise DataContractError("Prior CSV has missing or duplicate normalized card identity")
            try:
                values = {name: float(line[column]) for name, column in
                          (("win_rate", "胜率"), ("pick_rate", "选取率"), ("skip_rate", "略过率"))}
            except (KeyError, ValueError) as exc:
                raise DataContractError("Malformed prior CSV rates") from exc
            if any(not math.isfinite(value) or not 0 <= value <= 100 for value in values.values()):
                raise DataContractError("Prior rates must be finite percentages")
            self.rows[key] = {"internal_name": line["InternalName"], **values}
        rates = sorted(row["win_rate"] for row in self.rows.values())
        self.center = rates[len(rates) // 2] if rates else 0.0
        self.source["row_count"] = len(self.rows)

    def lookup(self, card: Mapping[str, Any]) -> dict[str, Any]:
        row = self.rows.get(_join_id(card_id(card)))
        # Deliberately bounded even when apparent rate differences are large.
        score = 0.0 if row is None else max(-0.15, min(0.15, (row["win_rate"] - self.center) * 0.01))
        return {"score": score, "statistics": row, "source": self.source,
                "missing": list(PRIOR_MISSING) + (["card_statistics"] if row is None else [])}


class InitialPolicy:
    def __init__(self, prior_path: str | Path | None = DEFAULT_PRIOR, *, epsilon: float = 0.10,
                 random_seed: str | int = 0, origin: str = "natural", engine_path: str | Path = DEFAULT_ENGINE):
        if _number(epsilon) is None or not 0 <= epsilon <= 1:
            raise DataContractError("epsilon must be in [0, 1]")
        self.prior = CardPrior(prior_path)
        self.mechanism_source = verified_source(engine_path)
        self.epsilon = float(epsilon)
        self.random_seed = random_seed
        self.rng = random.Random(random_seed)
        self.origin = origin
        self.choice_count = 0

    @property
    def provenance(self) -> dict[str, Any]:
        """Run-level identity; per-decision RNG position is added by choose()."""
        return {"origin": self.origin, "kind": "rules", "id": "initial-stat-mechanism",
                "version": POLICY_VERSION, "llm_involved": False,
                "prior_sha256": self.prior.source["sha256"], "epsilon": self.epsilon,
                "random_seed": self.random_seed, "mechanism_facts": dict(self.mechanism_source)}

    def _card_score(self, card: Mapping[str, Any], state: Mapping[str, Any]) -> dict[str, Any]:
        tags = card_mechanisms(card)
        player = state.get("player", {})
        deck = player.get("deck", [])
        deck_tags = [card_mechanisms(c) for c in deck]
        hp, max_hp = _number(player.get("hp")), _number(player.get("max_hp"))
        health_deficit = max(0.0, 1.0 - hp / max_hp) if hp is not None and max_hp else 0.0
        stats = {str(k).lower(): v for k, v in (card.get("stats") or {}).items()}
        facts = copy.deepcopy(FACTS.get(card_id(card), {}))
        cost = _number(card.get("card_cost", card.get("cost")))
        missing = []
        if cost is None or cost < 0:
            missing.append("resolved_card_cost")
            divisor = 3.0  # Explicit conservative proxy for unknown/X costs.
        else:
            divisor = 1.0 + cost
        if not card.get("stats"):
            missing.append("current_card_stats")
        if not tags:
            missing.append("mechanism_coverage")
        if not card.get("description"):
            missing.append("current_card_description")
        used_stats = {"damage", "block", "cards", "energy", "focuspower"}
        if "attack" in facts:
            used_stats.add(facts["attack"]["hit_count_stat"])
        if "conditional_damage" in facts:
            used_stats.add(facts["conditional_damage"]["amount_stat"])
        missing.extend("unmodeled_stats:" + key for key in stats.keys() - used_stats)
        if "cards" in stats and "draw" not in tags:
            missing.append("cards_effect_semantics")
        if "energy" in stats and "energy" not in tags:
            missing.append("energy_effect_semantics")
        features = {"base_damage_per_cost": max(0.0, _number(stats.get("damage")) or 0.0) / divisor,
                    "base_block_per_cost": max(0.0, _number(stats.get("block")) or 0.0) / divisor,
                    "health_deficit": health_deficit,
                    "existing_copies": float(sum(card_id(c) == card_id(card) for c in deck)),
                    "deck_size": float(len(deck))}
        features.update({name: 0.0 for name in QUANTITY_FEATURES})
        if attack := facts.get("attack"):
            damage, hits = _number(stats.get(attack["damage_stat"])), _number(stats.get(attack["hit_count_stat"]))
            if damage is None or damage < 0 or hits is None or hits < 0 or not hits.is_integer():
                missing.append("verified_attack_quantities")
            else:
                features.update(damage_per_hit=damage, attack_hit_count=hits,
                                single_target_nominal_damage=damage * hits)
                features["base_damage_per_cost"] = damage * hits / divisor
        if channel := facts.get("channel"):
            if channel["orb"] == "Frost":
                features["frost_channel_count"] = float(channel["count"])
                features["frost_channel_count_known"] = 1.0
        if generated := facts.get("generated_status"):
            features["combat_discard_status_cards"] = float(generated["count"])
        for effect, quantity, normalized in (("draw", "draw_cards", "draw_cards_per_cost"),
                                             ("energy", "energy_gain", "energy_gain_per_cost")):
            if effect in facts:
                amount = _number(stats.get(facts[effect]["amount_stat"]))
                if amount is None or amount < 0:
                    missing.append("verified_" + effect + "_quantity")
                else:
                    features[quantity] = amount
                    features[normalized] = amount / divisor
        components = {"base_damage_proxy": 0.18 * features["base_damage_per_cost"],
                      "base_block_proxy": (0.15 + 0.08 * health_deficit) * features["base_block_per_cost"]}
        orb_sources = sum(bool(t & {"lightning_source", "frost_source", "dark_source", "random_orb_source"}) for t in deck_tags)
        status_sources = sum("status_source" in t for t in deck_tags)
        statuses = sum(c.get("type") == "Status" for c in deck)
        power_count = sum(c.get("type") == "Power" for c in deck)
        features.update(orb_sources=float(orb_sources), status_sources=float(status_sources),
                        deck_statuses=float(statuses), power_count=float(power_count))
        if "draw" in tags:
            amount = _number(stats.get("cards"))
            if amount is None:
                missing.append("draw_amount")
            else:
                components["draw_proxy"] = 0.60 * amount / divisor
        if "energy" in tags and (amount := _number(stats.get("energy"))) is not None:
            components["energy_proxy"] = 0.50 * amount / divisor
        for tag, weight in (("lightning_source", 0.55), ("frost_source", 0.75), ("dark_source", 0.4),
                            ("random_orb_source", 0.25), ("plasma_source", 0.4), ("discard_retrieval", 0.45)):
            if tag in tags:
                amount = features["frost_channel_count"] if tag == "frost_source" and features["frost_channel_count_known"] else 1.0
                components[tag + "_proxy"] = weight * amount / divisor
        if conditional := facts.get("conditional_damage"):
            amount = _number(stats.get(conditional["amount_stat"]))
            features["conditional_end_turn_aoe_requires_frost"] = 1.0
            features["conditional_end_turn_aoe_trigger_unknown"] = 1.0
            if amount is None or amount < 0:
                missing.append("conditional_end_turn_aoe_amount")
            else:
                features["conditional_end_turn_aoe_damage"] = amount
                # Facts alone do not establish a trigger probability or return.
                # Do not turn a Frost source in the deck into a hand-tuned bonus.
            missing.extend(["end_turn_frost_presence_distribution", "end_turn_aoe_trigger_count_and_targets"])
        focus = _number(stats.get("focuspower"))
        if tags & {"sustained_focus", "temporary_focus", "decaying_focus"}:
            if focus is None:
                missing.append("focus_amount")
            else:
                weight = 0.32 if "sustained_focus" in tags else 0.13
                components["focus_synergy_proxy"] = weight * focus * min(3, orb_sources) / divisor
            if "decaying_focus" in tags:
                components["focus_decay_uncertainty"] = -0.2
                missing.append("combat_duration_distribution")
        if "orb_capacity" in tags:
            components["orb_capacity_synergy_proxy"] = 0.12 * min(4, orb_sources) / divisor
        if tags & {"status_conversion", "status_exhaust"}:
            components["status_handling_synergy_proxy"] = 0.3 * min(4, status_sources + statuses) / divisor
        if "status_creation_trigger" in tags:
            components["status_creation_synergy_proxy"] = 0.3 * min(4, status_sources) / divisor
        if "status_source" in tags:
            components["status_creation_cost_proxy"] = -0.25
        if "power_trigger" in tags:
            components["power_trigger_synergy_proxy"] = 0.12 * min(5, power_count) / divisor
        if card.get("type") in {"Curse", "Status"}:
            components["unplayable_deck_burden_proxy"] = -3.0
        prior = self.prior.lookup(card)
        components["weak_association_prior"] = prior["score"]
        return {"score": sum(components.values()), "features": features, "components": components,
                "mechanisms": sorted(tags), "missing": sorted(set(missing)), "prior": prior,
                "verified_effect_facts": facts, "mechanism_facts_source": dict(self.mechanism_source),
                "reason": "Handwritten base-stat and mechanism proxies; conditional effects and multiplicities are incomplete."}

    def _upgrade(self, card: Mapping[str, Any], state: Mapping[str, Any]) -> tuple[float, list[str]]:
        upgraded = card.get("after_upgrade")
        if not isinstance(upgraded, Mapping):
            return 0.0, ["upgrade_preview"]
        # CLI previews start from canonical + upgrade level. They do not clone
        # every permanent growth, enchantment or other instance modification.
        merged = {**card, **upgraded}
        if "card_cost" in merged and "cost" in upgraded:
            merged["card_cost"] = upgraded["cost"]
        return (self._card_score(merged, state)["score"] - self._card_score(card, state)["score"],
                ["upgrade_preview_instance_modifications"])

    def _selected_features(self, cards, state, features):
        """Represent actual candidate cards, including ordered multi-select ends.

        Utility and upgrade fields are explicitly heuristic proxies; base card
        stats and mechanism membership come from the current selected cards.
        Neither candidate index nor an opaque teacher score substitutes for them.
        """
        details = [self._card_score(card, state) for card in cards]
        previews = [self._upgrade(card, state) for card in cards]
        features["selected_count"] = float(len(cards))
        features["selected_card_damage_per_cost"] = sum(d["features"]["base_damage_per_cost"] for d in details)
        features["selected_card_block_per_cost"] = sum(d["features"]["base_block_per_cost"] for d in details)
        features["selected_card_utility_proxy"] = sum(d["score"] for d in details)
        features["actual_upgrade_delta_proxy"] = sum(value for value, _ in previews)
        features["missing_upgrade_previews"] = float(sum("upgrade_preview" in gaps for _, gaps in previews))
        for name in QUANTITY_FEATURES:
            features[name] = sum(detail["features"][name] for detail in details)
        for detail in details:
            for tag in detail["mechanisms"]:
                features["mechanism_" + tag] += 1.0
        if details:
            for prefix, detail in (("first_selected", details[0]), ("last_selected", details[-1])):
                features[prefix + "_damage_per_cost"] = detail["features"]["base_damage_per_cost"]
                features[prefix + "_block_per_cost"] = detail["features"]["base_block_per_cost"]
                features[prefix + "_utility_proxy"] = detail["score"]
        return details, previews

    def score(self, state: Mapping[str, Any], candidates: Mapping[str, Any] | None = None, *,
              selection_purpose: str | None = None) -> dict[str, Any]:
        supplied = validate_candidate_set(candidates) if candidates is not None else None
        actual = enumerate_candidates(state, max_candidates=(
            supplied.get("enumeration_limit", LEGACY_ENUMERATION_LIMIT)
            if supplied is not None else DEFAULT_ENUMERATION_LIMIT))
        if not actual["complete"]:
            raise DataContractError(actual["reason"])
        if candidates is not None and candidates != actual:
            raise DataContractError("Stale or modified candidates supplied to policy")
        if actual.get("representation") == "ordered_selection_implicit_v1":
            raise DataContractError("Implicit selection space requires bounded selection search")
        return self._score_candidates(state, actual, actual["candidates"], selection_purpose)

    def score_requests(self, state, requests, *, selection_purpose=None):
        """Score validated complete actions; partial evaluation is explicit."""
        actual = enumerate_candidates(state)
        if not actual["complete"]:
            raise DataContractError(actual["reason"])
        if not isinstance(requests, list) or not requests:
            raise DataContractError("Scoring requires a nonempty list of complete action requests")
        selected = [materialize_candidate(actual, request) for request in requests]
        if len({c["candidate_id"] for c in selected}) != len(selected):
            raise DataContractError("Duplicate action in scoring request")
        return self._score_candidates(state, actual, selected, selection_purpose)

    def _score_candidates(self, state, actual, candidates, selection_purpose):
        player = state.get("player", {})
        deck = player.get("deck", [])
        score_rows = []
        for candidate in candidates:
            action, item = candidate["request"]["action"], candidate["evidence"]
            score, reasons, missing = 0.0, [], []
            features = {name: 0.0 for name in FEATURE_NAMES}
            features["action_" + action] = 1.0
            features["is_skip"] = float(candidate["is_skip"])
            features["deck_size"] = float(len(deck))
            hp, maximum = _number(player.get("hp")), _number(player.get("max_hp"))
            features["health_deficit"] = max(0.0, 1 - hp / maximum) if hp is not None and maximum else 0.0
            features["missing_hp"] = max(0.0, maximum - hp) if hp is not None and maximum is not None else 0.0
            features["selection_" + (selection_purpose if selection_purpose in {"upgrade", "remove", "transform", "enchant", "acquire"} else "unknown")] = 1.0
            detail = None
            if action in {"select_card_reward", "buy_card"}:
                detail = self._card_score(item, state)
                features.update(detail["features"])
                features["prior_association"] = detail["prior"]["score"]
                for tag in detail["mechanisms"]:
                    features["mechanism_" + tag] = 1.0
                score = detail["score"] - 0.75 - 0.12 * min(4, features["existing_copies"])
                features["acquisition_opportunity_cost"] = 0.75 + 0.12 * min(4, features["existing_copies"])
                reasons.append("Card contribution proxy minus acquisition/duplication opportunity cost")
                missing.extend(detail["missing"])
                if action == "buy_card":
                    price = _number(item.get("cost"))
                    if price is None:
                        raise DataContractError("Purchasable shop card lacks price")
                    score -= price / 150.0
                    features["gold_spend"] = price
            elif action == "select_bundle":
                details, _ = self._selected_features(item["cards"], state, features)
                features["bundle_card_count"] = float(len(item["cards"]))
                score = sum(row["score"] - 0.75 for row in details)
                reasons.append("Aggregate card contribution proxy; pack interactions unmodeled")
                missing.extend(["pack_interactions", *[m for row in details for m in row["missing"]]])
                detail = details
            elif action == "select_cards":
                cards = item["cards"]
                details, gains = self._selected_features(cards, state, features)
                if selection_purpose == "upgrade":
                    score = sum(value for value, _ in gains)
                    missing.extend(m for _, gaps in gains for m in gaps)
                    reasons.append("Canonical upgrade preview difference under the same heuristic; instance modifiers are not preserved")
                elif selection_purpose == "acquire":
                    seen = {}
                    contribution = []
                    for selected, card_detail in zip(cards, details):
                        identity = card_id(selected)
                        copies = card_detail["features"]["existing_copies"] + seen.get(identity, 0)
                        cost = 0.75 + 0.12 * min(4, copies)
                        seen[identity] = seen.get(identity, 0) + 1
                        features["acquisition_opportunity_cost"] += cost
                        contribution.append({"card_id": selected.get("id"), "opportunity_cost": cost,
                                             "contribution_proxy": card_detail["score"] - cost,
                                             "card_detail": card_detail})
                    score = sum(row["contribution_proxy"] for row in contribution)
                    detail = contribution
                    missing.extend(m for row in details for m in row["missing"])
                    if cards:
                        missing.extend(["add_to_deck_hooks", "ordered_acquisition_interactions"])
                    reasons.append("Ordered acquisition: sum card contribution minus existing acquisition and duplication costs; deck hooks are unmodeled")
                elif selection_purpose in {"remove", "transform"}:
                    score = sum(-detail["score"] for detail in details)
                    reasons.append("Prefer lower contribution removal targets; no fixed Strike-first rule")
                    if selection_purpose == "transform":
                        missing.append("transform_outcome_distribution")
                else:
                    score = -0.01 * len(cards)
                    reasons.append("Unknown selection effect: minimal permitted cardinality, uniform ties")
                    missing.append("selection_effect_model")
            elif action == "crystal_sphere_reveal":
                args = candidate["request"]["args"]
                coverage = crystal_public_coverage(state, args["x"], args["y"], args["tool"])
                if type(item.get("hidden_cells_covered")) is not int or item["hidden_cells_covered"] != coverage:
                    raise DataContractError("Crystal Sphere candidate public coverage is inconsistent")
                features["crystal_hidden_cells_covered"] = float(coverage)
                features["crystal_tool_" + args["tool"]] = 1.0
                score = .01 * coverage
                detail = {"verified_effect_facts": copy.deepcopy(MINIGAME_FACTS["CRYSTAL_SPHERE"]),
                          "mechanism_facts_source": dict(self.mechanism_source)}
                reasons.append("Weak public reveal-coverage proxy: 0.01 per currently hidden cell")
                missing.extend(["hidden_reward_value", "minigame_reward_and_risk_model"])
            elif action == "choose_option" and state["decision"] == "rest_site":
                identity = _join_id(str(item.get("option_id", item.get("name", ""))))
                if identity in {"HEAL", "HEALRESTSITEOPTION", "REST"}:
                    features["rest_heal"] = 1.0
                    hp, maximum = _number(player.get("hp")), _number(player.get("max_hp"))
                    score = 3.0 * max(0.0, 1 - hp / maximum) if hp is not None and maximum else 0.0
                    reasons.append("Missing-health utility proxy; does not invent actual heal amount")
                    missing.extend(["actual_rest_heal_amount", "future_route_damage_distribution"])
                elif identity in {"SMITH", "SMITHRESTSITEOPTION"}:
                    features["rest_smith"] = 1.0
                    previews = [self._upgrade(card, state)[0] for card in deck if card.get("after_upgrade")]
                    score = max(previews, default=0.0)
                    features["best_upgrade_delta_proxy"] = score
                    reasons.append("Best currently exported upgrade preview utility")
                    if not previews:
                        missing.append("upgrade_preview")
                    else:
                        missing.append("upgrade_preview_instance_modifications")
                else:
                    features["rest_other"] = 1.0
                    reasons.append("Unknown rest option effect: neutral utility, uniform ties")
                    missing.append("rest_effect_model")
            elif action == "choose_option":
                doll_costs = {
                    "DOLL_ROOM.pages.INITIAL.options.RANDOM": (None, "ChooseRandom"),
                    "DOLL_ROOM.pages.INITIAL.options.TAKE_SOME_TIME": ("TakeTimeHpLoss", "TakeSomeTime"),
                    "DOLL_ROOM.pages.INITIAL.options.EXAMINE": ("ExamineHpLoss", "Examine"),
                }
                if item.get("text_key") in doll_costs:
                    # Exact engine-checked option keys select their own exported
                    # variable; every option exports BOTH cost variables.
                    variable, method = doll_costs[item["text_key"]]
                    cost = 0.0 if variable is None else _number(item.get("vars", {}).get(variable))
                    hp = _number(player.get("hp"))
                    if cost is None or cost < 0 or hp is None or hp <= 0:
                        raise DataContractError("Doll Room requires its public option cost and positive current HP")
                    score = -cost / hp - (10.0 if cost >= hp else 0.0)
                    reasons.append("Public nominal HP cost proxy; strongly disfavor spending current HP before a Doll reward")
                    detail = {"source_method": "DollRoom." + method, "public_cost_variable": variable,
                        "nominal_hp_cost": cost, "current_hp": hp,
                        "engine_sha256": self.mechanism_source["engine_sha256"],
                        "actual_hp_loss_claimed": False, "guaranteed_death_claimed": False}
                    missing.extend(["doll_reward_choice_value", "out_of_combat_damage_hooks"])
                elif item.get("text_key") == "TRIAL.pages.REJECT.options.DOUBLE_DOWN":
                    # Verified against this engine's Trial.DoubleDown: the option
                    # opens an abandon-run confirmation, not a combat reward.
                    score = -10.0
                    reasons.append("Known abandon-run confirmation entry; prefer continuing the run")
                    detail = {"source_method": "Trial.DoubleDown", "effect": "opens_abandon_run_confirmation",
                        "engine_sha256": self.mechanism_source["engine_sha256"],
                        "automatic_abandonment_or_damage_claimed": False}
                else:
                    reasons.append("Event effect/probability model unavailable: neutral utility, uniform ties")
                    missing.append("event_effect_and_probability_model")
            elif action == "select_map_node":
                room = str(item.get("type", "")).lower()
                feature = {"monster": "map_monster", "elite": "map_elite", "restsite": "map_rest",
                           "rest": "map_rest", "rest_site": "map_rest", "shop": "map_shop",
                           "merchant": "map_shop", "treasure": "map_treasure", "chest": "map_treasure",
                           "unknown": "map_unknown", "boss": "map_boss", "ancient": "map_ancient"}.get(room, "map_other")
                features[feature] = 1.0
                hp, maximum = _number(player.get("hp")), _number(player.get("max_hp"))
                deficit = max(0.0, 1 - hp / maximum) if hp is not None and maximum else 0.0
                if room in {"restsite", "rest", "rest_site"}:
                    score = 0.3 + deficit
                elif room in {"treasure", "chest"}:
                    score = 0.4
                elif room in {"shop", "merchant"}:
                    score = min(0.4, (_number(player.get("gold")) or 0.0) / 500.0)
                elif room == "elite":
                    score = 0.25 - 0.7 * deficit
                reasons.append("Visible next-room resource proxy; no hidden encounter or RNG lookahead")
                missing.extend(["full_route_evaluation", "encounter_damage_distribution"])
            elif action in {"buy_relic", "buy_potion"}:
                score = -0.25 - (_number(item.get("cost")) or 0.0) / 150.0
                reasons.append("Unmodeled item effect: conserve gold except during explicit exploration")
                missing.append("item_effect_model")
            elif action == "remove_card":
                removable = deck
                if any("is_removable" in card for card in deck):
                    if not all(type(card.get("is_removable")) is bool for card in deck):
                        raise DataContractError("Partial or invalid original removal eligibility")
                    removable = [card for card in deck if card["is_removable"]]
                weakest = min((self._card_score(card, state)["score"] for card in removable), default=0.0)
                score = -weakest - float(item["card_removal_cost"]) / 150.0
                features["selected_card_utility_proxy"] = weakest
                features["gold_spend"] = float(item["card_removal_cost"])
                reasons.append("Best estimated removal benefit minus gold opportunity cost")
            elif action == "use_potion":
                score = 0.0
                detail = {"potion_id": item["id"], "exported_base_max_hp": item["vars"]["MaxHp"],
                          "actual_gain_claimed": False}
                reasons.append("Fruit Juice is a known noncombat action; its priority is a separate fixed policy rule")
            elif action == "discard_potion":
                score = -0.5
                reasons.append("Preserve held potion; replacement utility unavailable")
                missing.append("potion_replacement_utility")
            elif candidate["is_skip"]:
                reasons.append("Explicit skip/leave baseline")
            else:
                reasons.append("Known legal action with unmodeled effect: neutral utility")
                missing.append("action_effect_model")
            features["missing_count"] = float(len(set(missing)))
            features = {name: float(features[name]) for name in FEATURE_NAMES}
            score_rows.append({"candidate_id": candidate["candidate_id"], "request": candidate["request"],
                               "score": score, "is_skip": candidate["is_skip"], "features": features,
                               "reasons": reasons, "missing": sorted(set(missing)), "card_detail": detail})
        skip_scores = [row["score"] for row in score_rows if row["is_skip"]]
        baseline = max(skip_scores) if skip_scores else None
        for row in score_rows:
            row["delta_from_skip"] = row["score"] - baseline if baseline is not None else None
            row["uncertainty"] = "uncalibrated_incomplete_coverage"
        return {"policy_id": "initial-stat-mechanism", "policy_version": POLICY_VERSION,
                "score_semantics": "relative_heuristic_utility_not_win_probability",
                "state_hash": state_hash(state), "candidate_source": actual["source"],
                "candidate_space_representation": actual.get("representation", "explicit_v1"),
                "candidate_count": actual.get("candidate_count", len(actual["candidates"])),
                "evaluated_candidates_complete": len(candidates) == actual.get("candidate_count", len(actual["candidates"])),
                "selection_purpose": selection_purpose, "scores": score_rows,
                "prior_source": self.prior.source, "mechanism_facts": dict(self.mechanism_source),
                "upgrade_preview_semantics": "canonical_plus_upgrade_level_not_full_instance", "calibrated": False}

    def choose(self, state: Mapping[str, Any], candidates: Mapping[str, Any] | None = None, *,
               selection_purpose: str | None = None) -> dict[str, Any]:
        scoring = self.score(state, candidates, selection_purpose=selection_purpose)
        rows = scoring["scores"]
        if not rows:
            raise DataContractError("No action is selectable at a terminal state")
        best = max(row["score"] for row in rows)
        greedy = [row for row in rows if abs(row["score"] - best) <= 1e-12]
        explored = self.rng.random() < self.epsilon
        chosen = self.rng.choice(rows if explored else greedy)
        probability = self.epsilon / len(rows)
        if chosen in greedy:
            probability += (1.0 - self.epsilon) / len(greedy)
        result = {"request": chosen["request"], "candidate_id": chosen["candidate_id"],
                  "scoring": scoring,
                  "policy_provenance": {**self.provenance, "choice_count": self.choice_count},
                  "exploration": {"epsilon": self.epsilon, "explored": explored,
                                  "chosen_probability": probability, "greedy_tie_count": len(greedy),
                                  "candidate_count": len(rows), "random_seed": self.random_seed,
                                  "choice_count": self.choice_count}}
        self.choice_count += 1
        return result
