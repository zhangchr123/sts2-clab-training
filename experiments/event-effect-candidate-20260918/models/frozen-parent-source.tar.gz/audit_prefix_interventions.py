"""Reconcile restart-prefix interventions with real traces before learning.

This is a separate dataset contract: it never promotes these arms to natural
full-run samples, treats engine errors as missing, or claims hidden RNG equality.
"""
from __future__ import annotations

import argparse
import copy
from pathlib import Path

from compare_batches import validate_solve
from decision_data import enumerate_candidates, materialize_candidate, state_hash
from initial_policy import InitialPolicy
from prefix_interventions import (VERSION, read_json, read_lines, public_state, require,
                                 select_gate, unchanged, validate_protocol)
from replay_evidence import solver_projection, validate_replay_evidence
from run_metadata import atomic_json, file_evidence
from selection_context import bind_selection_context, direct_action_evidence
from selection_policy import SelectionPolicy


def same(left, right):
    return state_hash(left) == state_hash(right)


def audit_observed_arm(protocol, gate, arm, directory):
    directory = Path(directory)
    result = read_json(directory / "result.json")
    declaration = read_json(directory / "declaration.json")
    require(same(declaration, {"protocol_sha256": state_hash(protocol), "gate": gate, "arm": arm}),
            "Arm declaration differs from frozen allocation")
    require(result.get("schema_version") == VERSION and same(result.get("arm"), arm)
            and result.get("gate_id") == gate["gate_id"] and result.get("seed") == gate["seed"]
            and result.get("natural_training_eligible") is False
            and result.get("full_state_equality_verified") is False and result.get("rng_equality_verified") is False,
            "Arm identity or data semantics changed")
    require(result.get("frozen_inputs_unchanged") is True, "Arm recorded runtime drift")
    require(result["trace_source"] == file_evidence(directory / "trace.jsonl")
            and result["policy_source"] == file_evidence(directory / "policy.jsonl"),
            "Arm evidence does not bind the actual trace and policy files")
    require(unchanged([result["trace_source"], result["policy_source"]]), "Arm trace or policy content changed")
    if result.get("status") != "observed_next_combat_boundary":
        require(result.get("status") in {"environment_or_prefix_error", "timeout", "terminal_before_next_combat"}
                and result.get("observed_label") is None, "Failed/missing arm was relabeled")
        failed_traces = read_lines(directory / "trace.jsonl")
        entered = False
        for attempted in failed_traces:
            if attempted.get("phase") != "intervention_suffix":
                continue
            response = attempted.get("response")
            if not isinstance(response, dict) or response.get("type") != "decision":
                continue
            active = response.get("context", {}).get("combat_in_progress")
            require(not (entered and active is False),
                    "A later error cannot relabel an already completed next-combat boundary")
            entered = entered or active is True
        failure = result.get("failure_evidence") or {}
        kind = failure.get("kind")
        if result["status"] == "terminal_before_next_combat":
            require(bool(failed_traces), "Terminal-before-battle lacks trace")
            last = failed_traces[-1].get("response", {})
            suffix = failed_traces[result["suffix_start_trace_index"]:]
            require(last.get("decision") == "game_over" and last.get("victory") is False
                    and not any(r.get("response", {}).get("context", {}).get("combat_in_progress") is True
                                for r in suffix), "No actual terminal-before-next-combat evidence")
        elif kind in {"transport_error", "engine_error"}:
            require(bool(failed_traces) and failure.get("actual_trace_index") == len(failed_traces) - 1,
                    "Failure does not bind last trace attempt")
            last = failed_traces[-1]
            if kind == "transport_error":
                require(last.get("response_received") is False and last.get("response") is None
                        and bool(last.get("transport_error")), "No actual transport error")
            else:
                require(last.get("response_received") is True and isinstance(last.get("response"), dict)
                        and last["response"].get("type") == "error", "No actual engine error")
        elif kind == "public_prefix_mismatch":
            require(bool(failed_traces) and failure.get("actual_trace_index") == len(failed_traces) - 1,
                    "Prefix failure does not bind the last trace response")
            original = read_lines(gate["sources"]["trace.jsonl"]["path"])
            index = failure.get("historical_trace_index")
            require(type(index) is int and 0 <= index <= gate["trace_index"], "Invalid prefix mismatch index")
            actual = failed_traces[-1]
            require(actual.get("phase") == "historical_prefix" and actual.get("historical_trace_index") == index
                    and same(actual["request"], original[index]["request"])
                    and not same(public_state(actual["response"]), public_state(original[index]["response"])),
                    "No actual public prefix mismatch")
        elif kind == "deadline_before_send":
            require(result["status"] == "timeout" and type(failure.get("elapsed")) in (int, float)
                    and failure["elapsed"] >= protocol["limits"]["max_seconds_per_arm"]
                    and result["seconds"] >= failure["elapsed"]
                    and failure.get("trace_count") == len(failed_traces)
                    and isinstance(failure.get("request_not_sent"), dict), "No declared deadline evidence")
        elif kind == "macro_limit_before_choice":
            require(result["status"] == "timeout"
                    and failure.get("completed_choices") == protocol["limits"]["max_suffix_decisions"]
                    and len(read_lines(directory / "policy.jsonl")) == failure["completed_choices"]
                    and failure.get("trace_count") == len(failed_traces), "No actual macro limit evidence")
        else:
            raise ValueError("Execution failure needs independently verified trace evidence")
        return {"status": result["status"], "observed_label": None, "usable_observation": False,
                "error": result.get("error")}
    traces = read_lines(directory / "trace.jsonl")
    policies = read_lines(directory / "policy.jsonl")
    calls = read_json(directory / "solver-calls.json")
    final = read_json(directory / "final-state.json")
    actual_gate = read_json(directory / "gate-state.json")
    original = read_lines(gate["sources"]["trace.jsonl"]["path"])[:gate["trace_index"] + 1]
    expected_gate = select_gate(original, gate["seed"])
    require(all(same(expected_gate[k], gate[k]) for k in expected_gate), "Historical gate is not the declared first gate")
    original_actions = [(i, r) for i, r in enumerate(original) if r["request"]["cmd"] in {"start_run", "action"}]
    count = len(original_actions)
    require(result.get("prefix_responses_verified") == count and result.get("suffix_start_trace_index") == count,
            "Prefix coverage is incomplete")
    require(len(traces) > count and bool(policies), "Missing actual suffix")
    for actual, (index, old) in zip(traces[:count], original_actions):
        require(actual.get("phase") == "historical_prefix" and actual.get("historical_trace_index") == index
                and actual.get("response_received") is True and same(actual.get("request"), old["request"])
                and same(public_state(actual.get("response")), public_state(old["response"])),
                "Actual prefix action/response differs from historical evidence")
    require(same(traces[count - 1]["response"], actual_gate)
            and state_hash(public_state(actual_gate)) == gate["public_state_hash"], "Gate readback mismatch")
    previous, before, observed_battle, battle_start, macros, actual_calls = actual_gate, [], False, None, [], []
    boundary_seen = False
    for index, row in enumerate(traces[count:]):
        req, res = row.get("request", {}), row.get("response")
        require(row.get("phase") == "intervention_suffix" and row.get("historical_trace_index") is None
                and row.get("response_received") is True and not row.get("transport_error")
                and isinstance(res, dict), "Unclean actual suffix response")
        require(req.get("cmd") in {"action", "solve", "combat_meta", "choice_meta"}, "Injection or restart in suffix")
        if boundary_seen:
            require(req.get("cmd") in {"combat_meta", "choice_meta"} and res.get("type") == req["cmd"],
                    "Actions or new solves continued beyond first actual combat boundary")
        if res.get("type") == "error":
            require(req["cmd"] == "solve" and "OperationCanceledException" in str(res)
                    and req.get("budget_ms") != gate["source_solver_config"]["retry_budget_ms"],
                    "Unrecovered engine/solver error in observed arm")
            next_index = count + index + 1
            require(next_index < len(traces), "Canceled solve has no original bounded retry")
            retry = traces[next_index]
            require(same(retry.get("request"), {**req, "budget_ms": gate["source_solver_config"]["retry_budget_ms"]})
                    and retry.get("response", {}).get("type") == "solver_result",
                    "Canceled solve was not followed by the exact declared successful retry")
        before.append(copy.deepcopy(previous))
        if req["cmd"] == "solve":
            validate_solve(row, gate["source_solver_config"], gate["source_solver_config"]["solver_backend"])
            actual_calls.append({"request": req, "response": res})
        if req["cmd"] == "action" and previous["context"]["combat_in_progress"] is False:
            macros.append((index, req, res, copy.deepcopy(previous)))
        if res.get("type") == "decision":
            require(req["cmd"] == "action" and res.get("context", {}).get("integrity_recovery_used") is False,
                    "Decision response is not an original clean action result")
            # Validate any explicitly excluded observer rather than removing arbitrary new fields.
            public_state(res)
            require(previous.get("decision") != "game_over", "Action after terminal outcome")
            active = res["context"].get("combat_in_progress")
            require(type(active) is bool, "Missing combat ownership")
            if active:
                if not observed_battle:
                    battle_start = copy.deepcopy(res)
                observed_battle = True
            if observed_battle and active is False:
                # The executor may make a read-only choice_meta query to prove
                # original ending choices. Keep it in the trace and replay audit.
                boundary_seen = True
            previous = res
    require(observed_battle and same(previous, final) and final["context"]["combat_in_progress"] is False,
            "No actual completed next battle")
    require(same(actual_calls, solver_projection(calls)) and bool(actual_calls),
            "Actual battle lacks matching original solver calls")
    validate_replay_evidence(calls, traces[count:])
    require(len(macros) == len(policies) == result.get("suffix_macro_decisions"), "Missing or extra suffix macro choices")
    policy = SelectionPolicy(InitialPolicy(epsilon=.1, random_seed=gate["seed"] + ":prefix-next-combat-v1",
                                           origin="prefix_intervention"), max_evaluations=256)
    context = None
    for n, (logged, (index, request, direct, pre)) in enumerate(zip(policies, macros)):
        candidates = enumerate_candidates(pre)
        require(candidates.get("complete") and same(logged["state"], pre)
                and same(logged["candidate_set"], candidates) and same(logged["selection_context"], context),
                "Suffix policy state/candidates/context differs from actual execution")
        expected = ({"request": copy.deepcopy(arm["request"]), "origin": "predeclared_intervention"}
            if n == 0 else policy.choose(pre, candidates=candidates,
                                        selection_purpose=context["purpose"] if context else None))
        require(same(logged["picked"], expected) and same(request, expected["request"]),
                "Suffix action was not the declared candidate or recomputed frozen rules")
        next_state = policies[n + 1]["state"] if n + 1 < len(policies) else final
        chosen = materialize_candidate(candidates, request)
        context = bind_selection_context(chosen, logged["decision_id"], pre, direct, next_state,
                                         captured_direct=direct_action_evidence(direct))
    player = final["player"]
    label = {"horizon": protocol["horizon"], "hp": player["hp"], "max_hp": player["max_hp"],
        "gate_hp": gate["state"]["player"]["hp"], "combat_metrics": copy.deepcopy(player.get("combat_metrics")),
        "actual_death": final.get("decision") == "game_over" and final.get("victory") is False,
        "boundary_state_hash": state_hash(final), "battle_start_state_hash": state_hash(battle_start),
        "battle_start_context": copy.deepcopy(battle_start.get("context")),
        "context": copy.deepcopy(final.get("context")),
        "potions_used": sum(row["request"].get("action") == "use_potion" for row in traces[count:])}
    require(same(label, result.get("observed_label")), "Reported label differs from actual trace boundary")
    return {"status": result["status"], "observed_label": label, "usable_observation": True,
            "prefix_public_equality_only": True, "recomputed_suffix_macro_choices": len(policies),
            "original_solver_calls": len(calls)}


def audit_protocol(path, *, output=None):
    path = Path(path).resolve()
    protocol = validate_protocol(read_json(path))
    require(unchanged(protocol["frozen_sources"] + protocol["historical_sources"]), "Frozen input content changed")
    started = read_json(path.parent / "execution-started.json")
    require(started.get("protocol") == file_evidence(path), "Execution used another protocol file")
    expected_arms = sum(len(g["arms"]) for g in protocol["gates"])
    require(started.get("planned_arms") == expected_arms, "Allocation count changed")
    results, issues, gates = [], [], []
    for gate in protocol["gates"]:
        observed = []
        for arm in gate["arms"]:
            directory = path.parent / f"prefix-{path.parent.name}-{gate['gate_id']}-{arm['arm_id']}"
            row = {"gate_id": gate["gate_id"], "seed": gate["seed"], "arm": arm, "directory": str(directory)}
            try:
                row.update(audit_observed_arm(protocol, gate, arm, directory))
            except Exception as exc:
                row.update(status="invalid_or_missing_evidence", usable_observation=False, observed_label=None,
                           audit_error=str(exc))
                issues.append({"gate_id": gate["gate_id"], "arm_id": arm["arm_id"], "error": str(exc)})
            results.append(row)
            observed.append(row)
        complete = all(r["usable_observation"] for r in observed)
        controls = [r for r in observed if r["arm"]["request"]["action"] == "skip_card_reward"
                    and r["usable_observation"]]
        controls_hp = [r["observed_label"]["hp"] for r in controls]
        gates.append({"gate_id": gate["gate_id"], "seed": gate["seed"], "complete_candidate_group": complete,
            "planned_arms": len(observed), "observed_arms": sum(r["usable_observation"] for r in observed),
            "duplicate_skip_hp": controls_hp,
            "duplicate_skip_abs_hp_difference": abs(controls_hp[0] - controls_hp[1]) if len(controls_hp) == 2 else None,
            "same_encounter_for_all_arms": complete
                and all(isinstance(r["observed_label"]["battle_start_context"].get("encounter_id"), str)
                        and bool(r["observed_label"]["battle_start_context"]["encounter_id"]) for r in observed)
                and len({r["observed_label"]["battle_start_context"]["encounter_id"] for r in observed}) == 1,
            "candidate_hp_range": [min(r["observed_label"]["hp"] for r in observed),
                                   max(r["observed_label"]["hp"] for r in observed)] if complete else None})
    audit = {"schema_version": VERSION + ":audit-v1", "protocol": file_evidence(path), "passed": not issues,
        "issues": issues, "planned_arms_denominator": expected_arms, "planned_root_seed_gates": len(gates),
        "complete_candidate_groups": sum(g["complete_candidate_group"] for g in gates),
        "usable_observations": sum(r["usable_observation"] for r in results), "gates": gates, "arms": results,
        "natural_training_eligible": False, "A10_win_rate_claim": False,
        "target_semantics": "actual next-combat boundary under a new frozen suffix after observed prefix replay",
        "full_state_or_rng_equality_claim": False}
    if output is not None:
        require(not Path(output).exists(), "Use a fresh audit output")
        atomic_json(output, audit)
    return audit


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = audit_protocol(args.protocol, output=args.output)
    print({k: result[k] for k in ("passed", "planned_arms_denominator", "complete_candidate_groups", "usable_observations", "issues")})
