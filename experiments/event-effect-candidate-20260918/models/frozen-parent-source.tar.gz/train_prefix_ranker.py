"""One predeclared paired ridge fit on actual restart-intervention observations.

Target: boundary HP difference / gate max HP versus the mean of two actual
skip controls. This is short-horizon feedback, not an A10 value or probability.
Every arm within a root seed stays in one split. No policy is auto-deployed.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

from audit_prefix_interventions import audit_protocol
from decision_data import split_by_seed, state_hash
from initial_policy import InitialPolicy
from interaction_features import FEATURE_NAMES, extend_scoring_packet
from prefix_interventions import read_json, require, unchanged
from run_metadata import atomic_json, file_evidence
from train_ranker import fit, predict, validate_model


VERSION = "paired-prefix-next-combat-hp-ridge-v1"
LEARNER = {"version": VERSION, "target": "candidate_boundary_hp_minus_mean_skip_hp_divided_by_gate_max_hp",
    "regularization": 1., "features": "119_public_candidate_minus_skip_features",
    "weighting": "equal_root_seed_then_equal_non_skip_candidate_then_equal_mirror",
    "normalization": "unweighted_mirrored_candidate_rows_in_train_only; equal_root_weighted_loss",
    "split_salt": "sts2-macro-split-v1", "validation_fraction": .2, "test_fraction": .1,
    "fit_count": 1, "test_used_for_fit_or_tuning": False,
    "group_inclusion": "all_predeclared_candidate_and_control_arms_have_audited_boundary",
    "source_terminal_outcome_used": False, "impute_missing_arms": False,
    "test_comparison": "single_frozen_model_greedy_uniform_ties_vs_rule_greedy_uniform_ties_on_actual_candidate_returns"}
FEATURE_SOURCES = ("train_prefix_ranker.py", "interaction_features.py", "initial_policy.py", "decision_data.py",
                   "selection_space.py", "mechanism_facts.py", "train_ranker.py")


def exclusive_receipt(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)


def validate_artifact(model, protocol, protocol_path):
    """Reject relabeled natural models and incomplete feature/source identities."""
    validate_model(model)
    require(model.get("format") == VERSION and model.get("planned_learner") == LEARNER
            and model.get("target_semantics") == LEARNER["target"]
            and model.get("feature_names") == list(FEATURE_NAMES)
            and model.get("fit_count") == 1
            and all(model.get(k) is False for k in ("calibrated_probability", "A10_victory_model",
                "automatic_deployment", "natural_run_training", "exact_state_or_rng_clone", "test_used_for_fit_or_tuning")),
            "Wrong paired model format, schema, semantics or scope")
    sources = model.get("feature_sources")
    require(isinstance(sources, dict) and set(sources) == set(FEATURE_SOURCES), "Incomplete paired feature source set")
    root = Path(__file__).resolve().parent
    require(all(sources[name] == file_evidence(root / name) for name in FEATURE_SOURCES), "Paired feature source drift")
    fallback = InitialPolicy()
    require(model.get("prior_source") == fallback.prior.source and model.get("mechanism_facts") == fallback.mechanism_source,
            "Paired feature prior or mechanism facts differ")
    first_gate = protocol["gates"][0]
    current_transform = extend_scoring_packet(first_gate["state"], fallback.score_requests(
        first_gate["state"], [c["request"] for c in first_gate["candidates"]]))["interaction_feature_source"]
    require(model.get("feature_transform") == current_transform, "Paired interaction feature definition differs")
    require(model.get("source_protocol") == file_evidence(Path(protocol_path).resolve())
            and model.get("runtime_and_collection_sources") == protocol["frozen_sources"], "Model collection identity differs")
    require(abs(model["weights"][0]) < 1e-8 and all(abs(v) < 1e-12 for v in model["means"]),
            "Paired model lacks zero skip and antisymmetry")
    return model


def candidate_features(gate, policy=None):
    policy = policy or InitialPolicy()
    state = gate["state"]
    packet = extend_scoring_packet(state, policy.score_requests(state, [c["request"] for c in gate["candidates"]]))
    skip = next(row for row in packet["scores"] if row["is_skip"])
    return {row["candidate_id"]: {"features": {name: row["features"][name] - skip["features"][name]
                                               for name in FEATURE_NAMES},
             "rule_score": row["score"], "is_skip": row["is_skip"], "request": row["request"]}
            for row in packet["scores"]}


def build_groups(protocol, audit):
    require(audit["passed"], "All source/trace audits must pass before training")
    complete = {g["gate_id"] for g in audit["gates"] if g["complete_candidate_group"]}
    grouped = split_by_seed([{"run_id": g["gate_id"], "seed": g["seed"], "gate": g}
                            for g in protocol["gates"]], salt=LEARNER["split_salt"])
    result = {}
    for split, gates in grouped.items():
        result[split] = {"planned_gates": gates, "complete_gates": [g for g in gates if g["run_id"] in complete]}
    return result


def gate_observations(gate, audit, policy=None):
    arms = [r for r in audit["arms"] if r["gate_id"] == gate["gate_id"]]
    require(len(arms) == len(gate["arms"]) and all(r["usable_observation"] for r in arms),
            "Whole gate is unavailable when any declared arm is missing")
    controls = [r["observed_label"]["hp"] for r in arms if r["arm"]["request"]["action"] == "skip_card_reward"]
    require(len(controls) == 2, "Both actual skip controls are required")
    skip_hp = sum(controls) / 2
    features = candidate_features(gate, policy)
    max_hp = gate["state"]["player"]["max_hp"]
    require(type(max_hp) is int and max_hp > 0, "Missing actual gate max HP")
    observations = []
    for arm in arms:
        if arm["arm"]["is_duplicate_control"]:
            continue
        identity = arm["arm"]["candidate_id"]
        row = features[identity]
        hp = skip_hp if row["is_skip"] else arm["observed_label"]["hp"]
        observations.append({"seed": gate["seed"], "gate_id": gate["gate_id"], "candidate_id": identity,
            **copy.deepcopy(row), "actual_hp": hp, "target": (hp - skip_hp) / max_hp,
            "skip_controls": controls, "gate_max_hp": max_hp})
    return observations


def pair_examples(observations):
    rows = [r for r in observations if not r["is_skip"]]
    require(bool(rows), "No actual non-skip alternatives")
    result = []
    for row in rows:
        for direction in (1, -1):
            result.append({**copy.deepcopy(row), "features": {k: v * direction for k, v in row["features"].items()},
                           "target": row["target"] * direction, "weight": 1 / (2 * len(rows))})
    return result


def regression_metrics(model, examples):
    if not examples:
        return {"examples": 0, "root_seeds": 0, "weighted_rmse": None, "weighted_mae": None}
    total = sum(r["weight"] for r in examples)
    errors = [(predict(model, r["features"]) - r["target"], r["weight"]) for r in examples]
    return {"examples": len(examples), "root_seeds": len({r["seed"] for r in examples}),
            "weighted_rmse": math.sqrt(sum(e*e*w for e, w in errors) / total),
            "weighted_mae": sum(abs(e)*w for e, w in errors) / total,
            "zero_delta_baseline_rmse": math.sqrt(sum(r["target"]**2*r["weight"] for r in examples) / total)}


def train(protocol_path, output):
    protocol_path, output = Path(protocol_path).resolve(), Path(output).resolve()
    require(not output.exists(), "Use a fresh model output; no repeated fit overwrite")
    protocol = read_json(protocol_path)
    require(protocol.get("planned_learner") == LEARNER, "Learning method was not frozen before collection")
    receipt_path = protocol_path.parent / "training-fit-receipt.json"
    require(not receipt_path.exists(), "This protocol already has its exclusive training fit")
    audit = audit_protocol(protocol_path)
    groups = build_groups(protocol, audit)
    require(len(groups["train"]["complete_gates"]) >= 10, "Need at least 10 complete training root seeds")
    fallback = InitialPolicy()
    examples = {split: [e for g in groups[split]["complete_gates"]
                      for e in pair_examples(gate_observations(g["gate"], audit, fallback))]
                for split in ("train", "validation")}
    require(any(abs(row["target"]) > 1e-12 for row in examples["train"]), "No observed candidate contrast to learn")
    audit_path = protocol_path.parent / "TRAINING_AUDIT.json"
    require(not audit_path.exists(), "Existing training audit without fresh fit declaration")
    atomic_json(audit_path, audit)
    receipt = {"schema_version": VERSION + ":fit-receipt-v1", "status": "fit_started",
               "source_protocol": file_evidence(protocol_path), "training_audit": file_evidence(audit_path),
               "model_output": str(output), "planned_learner": copy.deepcopy(LEARNER)}
    exclusive_receipt(receipt_path, receipt)
    model = fit(examples["train"], FEATURE_NAMES, 1.)
    require(abs(model["weights"][0]) < 1e-8 and all(abs(value) < 1e-12 for value in model["means"]),
            "Mirrored pair fitting did not preserve zero skip and antisymmetry")
    model.update(format=VERSION, planned_learner=copy.deepcopy(LEARNER), calibrated_probability=False,
        A10_victory_model=False, automatic_deployment=False, natural_run_training=False,
        exact_state_or_rng_clone=False, target_semantics=LEARNER["target"],
        feature_sources={name: file_evidence(Path(__file__).resolve().parent / name) for name in FEATURE_SOURCES},
        mechanism_facts=copy.deepcopy(fallback.mechanism_source), prior_source=copy.deepcopy(fallback.prior.source),
        feature_transform=extend_scoring_packet(protocol["gates"][0]["state"], fallback.score_requests(
            protocol["gates"][0]["state"], [c["request"] for c in protocol["gates"][0]["candidates"]]))["interaction_feature_source"],
        source_protocol=file_evidence(protocol_path), runtime_and_collection_sources=protocol["frozen_sources"],
        training_audit=file_evidence(audit_path),
        split_seeds={k: [g["seed"] for g in v["planned_gates"]] for k, v in groups.items()},
        complete_split_seeds={k: [g["seed"] for g in v["complete_gates"]] for k, v in groups.items()},
        validation={k: regression_metrics(model, examples[k]) for k in examples},
        complete_gate_count=audit["complete_candidate_groups"], planned_gate_count=len(protocol["gates"]),
        fit_count=1, test_used_for_fit_or_tuning=False,
        limitations=["first_ordinary_Act1_reward_only", "next_combat_HP_omits_long_term_growth",
            "actual_restarted_prefix_interventions_not_exact_natural_state_clones",
            "original_solver_time_budget_can_cause_run_to_run_variation",
            "duplicate_skip_controls_quantify_only_part_of_the_noise",
            "incomplete_groups_excluded_from_fit_but_retained_in_experiment_denominator",
            "no_A10_policy_improvement_claim_without_fresh_full_run_comparison"])
    require(unchanged(protocol["frozen_sources"] + protocol["historical_sources"]), "Input drift during fit")
    validate_artifact(model, protocol, protocol_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    atomic_json(output, model)
    atomic_json(receipt_path, {**receipt, "status": "fit_completed", "model": file_evidence(output)})
    return model


def compare_frozen_test(protocol_path, model_path, output):
    """A single held-out assessment of a frozen fit, without training or tuning."""
    output = Path(output)
    require(not output.exists(), "Use a fresh held-out assessment artifact")
    protocol_path, model_path = Path(protocol_path).resolve(), Path(model_path).resolve()
    protocol, model = read_json(protocol_path), read_json(model_path)
    validate_artifact(model, protocol, protocol_path)
    receipt_path = protocol_path.parent / "test-evaluation-receipt.json"
    require(not receipt_path.exists(), "This protocol already has its exclusive held-out assessment")
    fit_receipt = read_json(protocol_path.parent / "training-fit-receipt.json")
    require(fit_receipt.get("status") == "fit_completed" and fit_receipt.get("model") == file_evidence(model_path)
            and fit_receipt.get("model_output") == str(model_path)
            and fit_receipt.get("source_protocol") == file_evidence(protocol_path)
            and fit_receipt.get("planned_learner") == LEARNER
            and fit_receipt.get("training_audit") == model.get("training_audit")
            and model.get("training_audit") == file_evidence(protocol_path.parent / "TRAINING_AUDIT.json"),
            "Model was not registered by this protocol's one completed fit")
    audit = audit_protocol(protocol_path)
    require(state_hash(audit) == state_hash(read_json(protocol_path.parent / "TRAINING_AUDIT.json")),
            "Actual collection audit changed after model fitting")
    groups = build_groups(protocol, audit)
    require(model["split_seeds"] == {k: [g["seed"] for g in v["planned_gates"]] for k, v in groups.items()},
            "Root seed splits changed")
    receipt = {"schema_version": VERSION + ":test-receipt-v1", "status": "assessment_started",
        "model": file_evidence(model_path), "protocol": file_evidence(protocol_path),
        "training_audit": model["training_audit"], "output": str(output.resolve())}
    exclusive_receipt(receipt_path, receipt)
    rows = []
    for group in groups["test"]["complete_gates"]:
        observed = gate_observations(group["gate"], audit)
        best_model = max(predict(model, row["features"]) for row in observed)
        best_rule = max(row["rule_score"] for row in observed)
        model_set = [r for r in observed if abs(predict(model, r["features"]) - best_model) <= 1e-12]
        rule_set = [r for r in observed if abs(r["rule_score"] - best_rule) <= 1e-12]
        model_hp = sum(r["actual_hp"] for r in model_set) / len(model_set)
        rule_hp = sum(r["actual_hp"] for r in rule_set) / len(rule_set)
        rows.append({"seed": group["seed"], "gate_id": group["run_id"], "model_expected_observed_hp": model_hp,
            "rule_expected_observed_hp": rule_hp, "difference": model_hp - rule_hp,
            "model_candidate_ids": [r["candidate_id"] for r in model_set],
            "rule_candidate_ids": [r["candidate_id"] for r in rule_set],
            "actual_skip_controls": observed[0]["skip_controls"],
            "semantics": "uniform_greedy_tie_weighting_of_already_executed_test_candidate_arms"})
    report = {"schema_version": VERSION + ":heldout-v1", "model": file_evidence(model_path),
        "protocol": file_evidence(protocol_path), "planned_test_root_seeds": len(groups["test"]["planned_gates"]),
        "complete_test_root_seeds": len(rows), "missing_test_root_seeds": len(groups["test"]["planned_gates"]) - len(rows),
        "mean_hp_difference_on_complete_groups": sum(r["difference"] for r in rows)/len(rows) if rows else None,
        "model_better_groups": sum(r["difference"] > 0 for r in rows),
        "rule_better_groups": sum(r["difference"] < 0 for r in rows),
        "equal_groups": sum(r["difference"] == 0 for r in rows), "rows": rows,
        "new_full_A10_games_executed": False, "A10_improvement_claim": False, "automatic_deployment": False,
        "training_or_tuning_performed": False, "small_test_set_supports_only_exploratory_short_horizon_assessment": True}
    require(file_evidence(model_path) == receipt["model"]
            and unchanged(protocol["frozen_sources"] + protocol["historical_sources"]), "Input drift during held-out assessment")
    atomic_json(output, report)
    atomic_json(receipt_path, {**receipt, "status": "assessment_completed", "assessment": file_evidence(output)})
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--evaluate-model", type=Path)
    args = parser.parse_args()
    result = (compare_frozen_test(args.protocol, args.evaluate_model, args.output) if args.evaluate_model
              else train(args.protocol, args.output))
    print({k: v for k, v in result.items() if k in {"format", "validation", "complete_gate_count",
           "planned_gate_count", "mean_hp_difference_on_complete_groups", "complete_test_root_seeds"}})
