"""Read-only advisor contract checks with temporary synthetic state and model."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from advisor_scores import advice
from initial_policy import FEATURE_NAMES, POLICY_VERSION, InitialPolicy
from test_initial_policy import card, state
from train_ranker import VERSION


class AdvisorScoreTests(unittest.TestCase):
    def selection(self):
        current = state([card("GLACIER", block=6), card("GUNK_UP", damage=4)])
        current.update(decision="card_select", min_select=0, max_select=2)
        return current

    def test_acquire_advice_exports_frozen_facts_without_executing(self):
        result = advice(self.selection(), selection_purpose="acquire")
        self.assertEqual(result["schema"], "sts2.candidate_advice.v3")
        self.assertEqual(result["mechanism_facts"], InitialPolicy().mechanism_source)
        self.assertEqual(result["feature_policy_version"], POLICY_VERSION)
        self.assertEqual(result["selection_purpose"], "acquire")
        self.assertEqual(result["execution"], "none")
        self.assertFalse(result["calibrated_win_probability"])
        self.assertTrue(any(r["features"]["selection_acquire"] > 0 for r in result["scores"]))

    def test_model_and_cli_advice_preserve_the_same_facts(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            policy = InitialPolicy()
            count = len(FEATURE_NAMES)
            model = {"format": VERSION, "feature_policy_version": POLICY_VERSION, "mode": "prior",
                     "feature_prior_sha256": policy.prior.source["sha256"],
                     "feature_mechanism_facts": policy.mechanism_source,
                     "feature_names": list(FEATURE_NAMES), "means": [0.] * count,
                     "scales": [1.] * count, "weights": [0.] * (count + 1),
                     "feature_min": [0.] * count, "feature_max": [100.] * count}
            model_path, state_path = root / "model.json", root / "state.json"
            model_path.write_text(json.dumps(model), encoding="utf-8")
            state_path.write_text(json.dumps(self.selection()), encoding="utf-8")
            run = subprocess.run([sys.executable, str(Path(__file__).with_name("advisor_scores.py")),
                "--state", str(state_path), "--model", str(model_path), "--selection-purpose", "acquire"],
                capture_output=True, text=True, check=True, timeout=20)
            result = json.loads(run.stdout)
            self.assertEqual(result["mechanism_facts"], model["feature_mechanism_facts"])
            self.assertEqual(result["model"]["feature_mechanism_facts"], result["mechanism_facts"])
            self.assertEqual(result["selection_purpose"], "acquire")
            self.assertEqual(result["execution"], "none")


if __name__ == "__main__":
    unittest.main()
