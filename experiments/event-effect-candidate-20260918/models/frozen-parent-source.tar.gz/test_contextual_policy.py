"""Isolated policy contracts; no natural games, fitting or evaluation seeds."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

STAGE = Path(__file__).resolve().parent
sys.path.insert(0, str(STAGE.parents[2]))
sys.path.insert(0, str(STAGE))
import contextual_policy as v2
import whole_run_policy as v1
from decision_data import DataContractError
from selection_policy import SelectionPolicy
from test_initial_policy import card, state
from test_selection_policy import selection_state
import sample_runs
from audit_batch import _Audit
from whole_run_audit import validate_whole_run_choices
from run_metadata import file_evidence


class ContextualPolicyTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.config = json.loads((v1.ROOT / 'configs/defect-v3-base.json').read_text())

    def policy(self, module, parameters, name):
        artifact = module.make_artifact(parameters, self.config, training={'synthetic_test_only': True})
        path = self.root / (name + '.json')
        path.write_text(json.dumps(artifact), encoding='utf-8')
        cls = module.ContextualPolicy if module is v2 else module.WholeRunPolicy
        return SelectionPolicy(cls(path, solver_config=self.config, seed='fixture', epsilon=.31),
                               max_evaluations=8)

    def test_nonzero_legacy_vector_zero_extension_preserves_scores_choices_and_rng(self):
        old = {name: ((i % 7) - 3) / 2 for i, name in enumerate(v1.PARAMETERS)}
        new = {name: old.get(name, 0.) for name in v2.PARAMETERS}
        self.assertEqual(len(new), 51)
        before = self.policy(v1, old, 'v1')
        after = self.policy(v2, new, 'v2')
        for act in (1, 2, 3):
            for current, purpose in ((state(), None),
                                     (selection_state(n=9, minimum=0, maximum=9), 'remove')):
                current['context'].update(act=act, ascension=10, combat_in_progress=False)
                a = before.choose(current, selection_purpose=purpose)
                b = after.choose(current, selection_purpose=purpose)
                self.assertEqual(a['request'], b['request'])
                self.assertEqual(a['exploration'], b['exploration'])
                self.assertEqual([r['score'] for r in a['scoring']['scores']],
                                 [r['score'] for r in b['scoring']['scores']])
                self.assertEqual(before.base.rng.getstate(), after.base.rng.getstate())

    def test_original_effects_can_independently_change_acquisition_ranking(self):
        ids = ('SPINNER', 'TRASH_TO_TREASURE', 'ITERATION', 'BUFFER')
        current = state([card(identity, type='Power') for identity in ids])
        current['context']['act'] = 2
        zero = self.policy(v2, dict.fromkeys(v2.PARAMETERS, 0.), 'zero').score(current)
        for index, parameter in enumerate(v2.EFFECT_PARAMETERS):
            weights = dict.fromkeys(v2.PARAMETERS, 0.)
            weights[parameter] = 2.
            packet = self.policy(v2, weights, parameter).score(current)
            for i, (baseline, row) in enumerate(zip(zero['scores'], packet['scores'])):
                self.assertEqual(row['score'] - baseline['score'], 2. if i == index else 0.)
                self.assertEqual(tuple(row['search_features']), v2.PARAMETERS)
            self.assertFalse(packet.get('calibrated', True))

    def test_new_artifact_and_every_extra_source_are_bound(self):
        policy = self.policy(v2, dict.fromkeys(v2.PARAMETERS, 0.), 'bound')
        original = v2.feature_sources()
        self.assertTrue(all(original.values()))
        self.assertTrue(set(v2.LOCAL_SOURCES) <= set(policy.base.artifact['source_files']))
        current = state(); current['context']['act'] = 1
        for name in v2.LOCAL_SOURCES:
            changed = copy.deepcopy(original)
            changed[name]['sha256'] = '0' * 64
            with patch.object(v2, 'feature_sources', return_value=changed):
                with self.assertRaises(DataContractError):
                    policy.score(current)
        policy.base.artifact['parameters'][v2.EFFECT_PARAMETERS[0]] = 1.
        with self.assertRaises(DataContractError):
            policy.score(current)

    def test_old_schema_and_nonfinite_parameters_are_rejected(self):
        for value in (True, float('nan'), 4.01):
            weights = dict.fromkeys(v2.PARAMETERS, 0.)
            weights[v2.EFFECT_PARAMETERS[0]] = value
            with self.assertRaises(DataContractError):
                self.policy(v2, weights, 'invalid')
        old = self.policy(v1, dict.fromkeys(v1.PARAMETERS, 0.), 'old')
        with self.assertRaises(DataContractError):
            v2.ContextualPolicy(old.base.path, solver_config=self.config, seed='fixture')

    def test_nonacquisition_selections_keep_existing_behavior(self):
        current = selection_state(n=7, minimum=3, maximum=3)
        current['context'].update(act=2, ascension=10, combat_in_progress=False)
        weights = {name: 0. if name in v1.PARAMETERS else 4. for name in v2.PARAMETERS}
        policy = self.policy(v2, weights, 'selection')
        with patch('decision_data.materialize_candidate', side_effect=AssertionError('Quadratic enumeration')):
            packet = policy.base.score(current, selection_purpose='remove')
        self.assertEqual(len(packet['scores']), 210)
        self.assertTrue(all(row['learned_residual'] == 0. for row in packet['scores']))

    def test_sampler_full_raw_reconstruction_and_new_feature_tamper_rejection(self):
        weights = dict.fromkeys(v2.PARAMETERS, 0.)
        weights[v2.EFFECT_PARAMETERS[0]] = 2.
        policy = self.policy(v2, weights, 'sampled')
        initial = state([card('SPINNER', type='Power'), card('BUFFER', type='Power')])
        initial['context'].update(act=1, floor=2, integrity_recovery_used=False)
        terminal = copy.deepcopy(initial)
        terminal.update(decision='game_over', victory=False)
        terminal['player']['hp'] = 0

        class FakeBridge:
            def send(self, **request):
                return copy.deepcopy(initial if request['cmd'] == 'start_run' else terminal)
            def close(self):
                pass

        original_metadata = sample_runs.metadata
        def staged_metadata(*args, **kwargs):
            meta = original_metadata(*args, **kwargs)
            # These modules really execute from this isolated directory.
            for name in (*v2.LOCAL_SOURCES, 'sample_runs.py', 'whole_run_audit.py', 'audit_batch.py'):
                meta['versions']['sources'][name] = file_evidence(STAGE / name)
            return meta

        with patch.object(sample_runs, 'ROOT', self.root), \
                patch.object(sample_runs, 'metadata', side_effect=staged_metadata), \
                patch.object(sample_runs, 'Bridge', return_value=FakeBridge()):
            report = sample_runs.run_one('context-fixture', 'context-fixture', settings=self.config,
                epsilon=0., model_path=policy.base.path, selection_budget=8)
        audit = _Audit(self.root / 'outputs' / 'audit')
        records, _ = audit.run(report)
        self.assertEqual(audit.issues, [])
        self.assertTrue(audit.checks['prefix_actual_natural_run_start'])
        self.assertTrue(audit.checks['prefix_entire_macro_trace_coverage'])
        policies = {row['decision_id']: row for row in map(json.loads,
            (self.root / 'outputs/context-fixture/policy.jsonl').read_text().splitlines())}
        self.assertTrue(validate_whole_run_choices(records, policies))
        first = policies[records[0]['decision_id']]['scoring']['scores'][0]
        first['search_features'][v2.EFFECT_PARAMETERS[0]] += 1.
        with self.assertRaises(DataContractError):
            validate_whole_run_choices(records, policies)


if __name__ == '__main__':
    unittest.main(verbosity=2)
