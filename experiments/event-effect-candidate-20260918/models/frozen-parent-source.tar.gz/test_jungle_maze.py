"""Artificial event fixtures: exact engine effects, never natural training data."""
import json
import unittest
import uuid

from probe import Bridge, ROOT


class JungleMazeTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.b = Bridge(self.label)
        started = self.b.send(cmd="start_run", character="Defect", ascension=10,
                              seed="integrity-jungle-maze")
        self.assertEqual(started["type"], "decision", started)
        self.state = self.b.send(cmd="enter_room", type="event", event="JUNGLE_MAZE_ADVENTURE")
        self.assertEqual(self.state.get("decision"), "event_choice", self.state)

    def tearDown(self):
        (ROOT / "outputs" / f"{self.label}.json").write_text(
            json.dumps({"provenance": "artificial Jungle Maze integrity fixture; not training data",
                        "responses": self.b.rows}, ensure_ascii=False, indent=2), encoding="utf-8")
        self.b.close()

    def select(self, suffix):
        option = next(o for o in self.state["options"]
                      if o["text_key"] == "JUNGLE_MAZE_ADVENTURE.pages.INITIAL.options." + suffix)
        self.assertIs(option["is_locked"], False)
        after = self.b.send(cmd="action", action="choose_option", args={"option_index": option["index"]})
        self.assertEqual(after.get("decision"), "map_select", after)
        self.assertIs(after["context"]["integrity_recovery_used"], False)
        self.assertEqual(after["player"]["deck"], self.state["player"]["deck"])
        self.assertEqual(after["player"]["relics"], self.state["player"]["relics"])
        return option["vars"], after["player"]

    def test_join_forces_grants_exported_gold_and_preserves_hp(self):
        variables, player = self.select("JOIN_FORCES")
        self.assertEqual(player["gold"] - self.state["player"]["gold"], variables["JoinForcesGold"])
        self.assertEqual(player["hp"], self.state["player"]["hp"])

    def test_solo_quest_preserves_original_gold_and_hp_cost(self):
        variables, player = self.select("SOLO_QUEST")
        self.assertEqual(player["gold"] - self.state["player"]["gold"], variables["SoloGold"])
        self.assertEqual(self.state["player"]["hp"] - player["hp"], variables["SoloHp"])


if __name__ == "__main__":
    unittest.main()
