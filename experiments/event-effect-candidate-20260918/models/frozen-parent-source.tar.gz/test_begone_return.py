"""Original Begone returns; replay and synthetic boundaries are never training samples."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers
from test_original_return_live import visible

ORIGINAL = Path(r'C:\Users\zhangchr\Documents\code\sts2-solver-bridge')


class BegoneReturnTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def observe(self, send, before, after, action, request):
        observer = CombatExecutor(send)
        observer.last_action_request = request
        observer.solve_calls = [{'request': {'cmd': 'solve'},
            'response': {'type': 'solver_result', 'actions': [action]}}]
        self.assertTrue(observer.resolve_original_automatic_choice(before, after, action))
        return observer

    def test_two_original_failures_transform_exact_returned_card_and_continue(self):
        for candidate, expected in ((7, 'LEAP'), (12, 'ASCENDERS_BANE')):
            with self.subTest(candidate=candidate):
                name = f'defect-contextual-parallel-20260914a-g02-c{candidate:02d}-s00'
                source = ORIGINAL / 'outputs' / name
                receipt = read_json(ORIGINAL / 'outputs/defect-contextual-parallel-20260914a/generation-02' / (name + '-audit.json'))
                self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
                rows = read_lines(source / 'trace.jsonl')
                solve = max(i for i, r in enumerate(rows) if r['request']['cmd'] == 'solve')
                parent = rows[-1]['response']['choice_audit']['parent']
                actions = [a for a in rows[solve]['response']['actions'] if a.get('CardId') == 'BEGONE'
                           and a.get('CardStateKey') == parent['card_key'] and a['Turn'] == parent['player_turn']]
                self.assertEqual(len(actions), 1)
                action = copy.deepcopy(actions[0])
                label = f'begone-prefix-c{candidate:02d}-' + uuid.uuid4().hex[:10]
                bridge, traces, send = self.worker(label)
                matched = 0
                try:
                    for row in rows[:-1]:
                        if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}:
                            continue
                        before = send(row['request'])
                        self.assertEqual(visible(before), visible(row['response']))
                        matched += 1
                    meta = send(cmd='combat_meta')
                    after = send(rows[-1]['request'])
                    self.assertEqual(visible(after), visible(rows[-1]['response']))
                    observer = self.observe(send, before, after, action, rows[-1]['request'])
                    proof = observer.solve_calls[0]['replay'][0]
                    self.assertEqual(proof['selected_cards'][0]['CardId'], expected)
                    self.assertFalse(proof['selection_request_sent'])
                    self.assertEqual(sum(c['id'] == 'CARD.' + expected for c in after['hand']),
                                     sum(c['id'] == 'CARD.' + expected for c in before['hand']) - 1)
                    self.assertEqual(sum(c['id'] == 'CARD.MINION_STRIKE' for c in after['hand']),
                                     sum(c['id'] == 'CARD.MINION_STRIKE' for c in before['hand']) + 1)
                    synthetic = [{'request': {'cmd': 'start_run'}, 'response': before},
                        {'request': observer.solve_calls[0]['request'], 'response': observer.solve_calls[0]['response']},
                        {'request': {'cmd': 'combat_meta'}, 'response': meta},
                        {'request': rows[-1]['request'], 'response': after}, traces[-1]]
                    self.assertTrue(validate_replay_evidence(observer.solve_calls, synthetic)['verified'])
                    for field in ('source', 'fingerprint', 'filter', 'task', 'selector', 'pending',
                                  'objects', 'count', 'callsite', 'ending', 'raw_count', 'effect'):
                        with self.subTest(corruption=field):
                            altered = copy.deepcopy(after)
                            event = altered['choice_audit']['original_returns'][0]
                            if field == 'source': event['source_id'] = 'TRANSFIGURE'
                            elif field == 'fingerprint': event['returned_cards'][0]['StateKey'] += '-changed'
                            elif field == 'filter': event['filter_is_null'] = False
                            elif field == 'task': event['original_task_completed_successfully'] = False
                            elif field == 'selector': event['selector_invocations_after'] += 1
                            elif field == 'pending': event['selector_pending_after'] = True
                            elif field == 'objects': event['returned_objects_match_original_source'] = False
                            elif field == 'count': event['returned_count'] += 1
                            elif field == 'callsite': event['effect_callsite'] = 'Other.OnPlay'
                            elif field == 'ending': event['is_over_or_ending_at_entry'] = True
                            elif field == 'raw_count': event['raw_source_count_at_entry'] += 1
                            else: event['effect'] = 'Upgrade'
                            with self.assertRaises(RuntimeError):
                                observer.resolve_original_automatic_choice(before, altered, action)
                    for field in ('selected_cards', 'plan', 'selection_request_sent', 'missing'):
                        bad = copy.deepcopy(observer.solve_calls)
                        p = bad[0]['replay'][0]
                        if field == 'selected_cards': p[field][0]['StateKey'] += '-changed'
                        elif field == 'plan': p[field]['Effect'] = 'Upgrade'
                        elif field == 'selection_request_sent': p[field] = True
                        else: bad[0]['replay'] = []
                        with self.assertRaises(ValueError): validate_replay_evidence(bad, synthetic)
                    executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
                    final = executor.advance(after)
                    self.assertIn(final['decision'], {'card_reward', 'map_select', 'game_over'})
                    self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
                    self.save(label, traces, passed=True, origin='recorded_public_prefix_diagnostic',
                        prefix_responses_verified=matched, original_source=receipt['actual_source_evidence'],
                        historical_recorded_action=action, actual_recorded_action_proof=proof,
                        synthetic_offline_contract_checked=True, solver_calls=executor.solve_calls,
                        full_state_or_rng_equality_claimed=False)
                finally:
                    bridge.close()

    def test_empty_hand_returns_without_transform_and_two_options_stay_manual(self):
        for count in (0, 2):
            with self.subTest(remaining_cards=count):
                label = f'begone-boundary-{count}-' + uuid.uuid4().hex[:10]
                bridge, traces, send = self.worker(label)
                try:
                    send(cmd='start_run', character='Defect', ascension=10, seed='begone-synthetic-boundary')
                    send(cmd='set_player', hp=1000, max_hp=1000, relics=[], potions=[],
                         deck=['BEGONE'] + ['DEFEND_DEFECT'] * count)
                    before = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
                    index = next(c['index'] for c in before['hand'] if c['id'] == 'CARD.BEGONE')
                    key = next(c['key'] for c in send(cmd='combat_meta')['hand'] if c['index'] == index)
                    request = {'cmd': 'action', 'action': 'play_card', 'args': {'card_index': index}}
                    after = send(request)
                    if count == 2:
                        self.assertEqual(after['decision'], 'card_select')
                        self.assertEqual(len(after['cards']), 2)
                        self.assertFalse(CombatExecutor(send).resolve_original_automatic_choice(before, after, {}))
                        final = send(cmd='action', action='select_cards', args={'indices': '1'})
                        self.assertEqual(final['decision'], 'combat_play')
                        self.assertEqual(sum(c['id'] == 'CARD.MINION_STRIKE' for c in final['hand']), 1)
                    else:
                        self.assertEqual(after['decision'], 'combat_play')
                        plan = {'Effect': 'Transform', 'SourcePile': 'Hand', 'Cards': [],
                                'SourceId': '', 'ContextId': '', 'Timing': 'Action'}
                        action = {'Kind': 'PlayCard', 'CardId': 'BEGONE', 'CardStateKey': key,
                            'Turn': before['player_turn'], 'Choice': plan, 'NestedChoices': [],
                            'NestedChoicesBeforePrimary': 0, 'EndsPlayerTurn': False, 'ReplayCount': 0}
                        proof = self.observe(send, before, after, action, request).solve_calls[0]['replay'][0]
                        self.assertEqual(proof['selected_cards'], [])
                        self.assertEqual(after['hand'], [])
                    self.save(label, traces, passed=True, origin='synthetic_boundary_not_training')
                finally:
                    bridge.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)
