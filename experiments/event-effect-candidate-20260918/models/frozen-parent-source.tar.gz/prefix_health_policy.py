"""Optional prospective first-reward paired-prefix scorer; never a default.

One instance must receive a run's macro choices in order. Only its first eligible
ordinary Act1 reward uses the registered candidate-minus-skip HP model. Scoring
does not consume RNG or scope; a successful choose() consumes that opportunity.
Returning a request is not evidence that the engine executed it. Callers must
stop on execution failure, and create a new instance for a new run.
"""
from __future__ import annotations

import copy
import math
from pathlib import Path

from decision_data import (DataContractError, enumerate_candidates, materialize_candidate, state_hash,
                           DEFAULT_ENUMERATION_LIMIT, LEGACY_ENUMERATION_LIMIT, validate_candidate_set)
from initial_policy import InitialPolicy, POLICY_VERSION
from interaction_features import FEATURE_NAMES, extend_scoring_packet
from prefix_interventions import VERSION as PROTOCOL_VERSION, eligible_gate, read_json
from run_metadata import file_evidence
from train_prefix_ranker import LEARNER, VERSION as MODEL_FORMAT, predict, validate_artifact


VERSION = "first-ordinary-act1-reward-prefix-health-with-v3-fallback-v1"
TARGET = LEARNER["target"]
TIE_TOLERANCE = 1e-12
CONDITIONS = {"character": "Defect", "ascension": 10, "mode": "standard"}
SCOPE = {**CONDITIONS, "act": 1, "decision": "card_reward", "room_type": "Monster",
         "floor_min": 2, "floor_max": 8, "uses_per_run": 1,
         "selection": "first_eligible_gate_in_sequential_choose_calls"}
LIMITATIONS = ["uncalibrated_next_combat_HP_difference_not_survival_or_A10_win_probability",
    "short_horizon_omits_long_term_growth", "restart_interventions_are_not_exact_state_or_RNG_clones",
    "registered_fit_is_not_evidence_of_benefit", "fresh_full_run_comparison_required",
    "optional_model_requires_explicit_prospective_evaluation_not_automatic_deployment"]


def _require(condition, message):
    if not condition:
        raise DataContractError(message)


class PrefixHealthPolicy:
    """Pure scoring plus explicit once-per-run choice state; no engine or LLM.

The constructor validates the original trainer's artifact and completed fit
receipt, including its recorded protocol/audit/model SHA. It does not re-fit or
reassess held-out observations. Training runtime evidence remains historical;
live feature sources and the declared solver configuration must match.
"""
    def __init__(self, path, *, protocol_path, solver_config, epsilon=.1,
                 seed="prefix-health-policy", character="Defect", ascension=10, mode="standard"):
        _require(character == "Defect" and type(ascension) is int and ascension == 10
                 and mode == "standard", "Prefix health policy requires standard Defect A10")
        _require(type(epsilon) in (int, float) and math.isfinite(epsilon) and 0 <= epsilon <= 1,
                 "epsilon must be finite and in [0, 1]")
        _require(type(seed) in (str, int), "A recorded string or integer random seed is required")
        _require(isinstance(solver_config, dict) and bool(solver_config), "Explicit solver_config is required")
        path, protocol_path = Path(path).resolve(), Path(protocol_path).resolve()
        receipt_path = protocol_path.parent / "training-fit-receipt.json"
        audit_path = protocol_path.parent / "TRAINING_AUDIT.json"
        self._registered_sources = [file_evidence(p) for p in (path, protocol_path, receipt_path, audit_path)]
        _require(all(self._registered_sources), "Missing registered model, protocol, fit receipt or training audit")
        model, protocol, receipt, audit = map(read_json, (path, protocol_path, receipt_path, audit_path))
        _require(protocol.get("schema_version") == PROTOCOL_VERSION
                 and protocol.get("character") == "Defect" and type(protocol.get("ascension")) is int
                 and protocol["ascension"] == 10 and protocol.get("planned_learner") == LEARNER
                 and protocol.get("provenance") == "same_seed_action_prefix_intervention"
                 and all(protocol.get(k) is False for k in ("natural_training_eligible", "llm_involved",
                    "full_state_equality_verified", "rng_equality_verified", "prospective_A10_win_rate_sample"))
                 and protocol.get("horizon") == "first_actual_next_combat_end_under_frozen_rule_suffix",
                 "Wrong prefix collection source or scope")
        gates = protocol.get("gates")
        _require(isinstance(gates, list) and bool(gates)
                 and all(isinstance(g, dict) and eligible_gate(g.get("state"))
                         and g.get("source_solver_config") == solver_config for g in gates),
                 "Collection gates or solver configurations differ from the declared scope")
        # The authoritative trainer rejects wrong dimensions, feature source
        # hashes, prior/facts, transform, target and relabeled natural models.
        validate_artifact(model, protocol, protocol_path)
        _require(set(receipt) == {"schema_version", "status", "source_protocol", "training_audit",
                                  "model_output", "planned_learner", "model"}
                 and receipt.get("schema_version") == MODEL_FORMAT + ":fit-receipt-v1"
                 and receipt.get("status") == "fit_completed"
                 and receipt.get("model") == self._registered_sources[0]
                 and receipt.get("model_output") == str(path)
                 and receipt.get("source_protocol") == self._registered_sources[1]
                 and receipt.get("planned_learner") == LEARNER
                 and receipt.get("training_audit") == model.get("training_audit")
                 and model.get("training_audit") == self._registered_sources[3]
                 and audit.get("passed") is True,
                 "Model is not registered by this protocol's one completed audited fit")
        _require(all(lo <= hi for lo, hi in zip(model["feature_min"], model["feature_max"])),
                 "Invalid model feature ranges")
        self._model = copy.deepcopy(model)
        self._model_hash = state_hash(model)
        self._solver_config = copy.deepcopy(solver_config)
        self._protocol_source, self._fit_source = copy.deepcopy(self._registered_sources[1:3])
        self._source = copy.deepcopy(self._registered_sources[0])
        self._live_sources = copy.deepcopy(list(model["feature_sources"].values()))
        self.fallback = InitialPolicy(epsilon=epsilon, random_seed=seed)
        _require(self.fallback.prior.source == model["prior_source"]
                 and self.fallback.mechanism_source == model["mechanism_facts"],
                 "Fallback features changed while loading the registered model")
        self._fallback_identity = copy.deepcopy(self.fallback.provenance)
        self._fallback_state_hash = self._fallback_hash()
        self.epsilon, self.seed, self.random_seed = float(epsilon), seed, seed
        # Use exactly the rule policy's seeded RNG and draw convention, without
        # calling fallback.choose() and double-consuming randomness.
        self.rng, self.choice_count = self.fallback.rng, 0
        self._gate_use = None
        self._check_integrity()

    def _fallback_hash(self):
        return state_hash({"provenance": self.fallback.provenance, "prior": vars(self.fallback.prior)})

    def _check_integrity(self):
        _require(state_hash(self._model) == self._model_hash
                 and type(self.fallback) is InitialPolicy and self._fallback_hash() == self._fallback_state_hash,
                 "Loaded paired model or frozen v3 fallback changed")
        _require(all(file_evidence(e["path"]) == e for e in self._registered_sources + self._live_sources),
                 "Registered artifact or live feature source changed")

    @property
    def source(self):
        return copy.deepcopy(self._source)

    @property
    def sha256(self):
        return self._source["sha256"]

    @property
    def model(self):
        return copy.deepcopy(self._model)

    @property
    def mechanism_source(self):
        return copy.deepcopy(self._model["mechanism_facts"])

    @property
    def gate_use(self):
        return copy.deepcopy(self._gate_use)

    @property
    def provenance(self):
        return {"origin": "natural", "kind": "model", "id": VERSION, "version": self.sha256,
            "llm_involved": False, "epsilon": self.epsilon, "random_seed": self.seed,
            "prior_sha256": self._model["prior_source"]["sha256"], "mechanism_facts": self.mechanism_source,
            "model_source": self.source, "source_protocol": copy.deepcopy(self._protocol_source),
            "registered_fit_source": copy.deepcopy(self._fit_source), "model_scope": copy.deepcopy(SCOPE),
            "target_semantics": TARGET, "calibrated_probability": False, "A10_victory_model": False,
            "training_source_kind": "same_seed_action_prefix_intervention",
            "fallback": {**{key: copy.deepcopy(value) for key, value in self._fallback_identity.items()
                             if key not in {"random_seed", "choice_count"}},
                         "scope": "every_other_macro_choice_including_later_eligible_rewards",
                         "rng": "shared_top_level_random_seed_and_global_choice_count"},
            "solver_requested_config": copy.deepcopy(self._solver_config),
            "selection_method": "epsilon_uniform_all_candidates_plus_uniform_greedy_ties",
            "tie_tolerance": TIE_TOLERANCE,
            "scope_commit": "successful_choose_return_not_engine_execution",
            "automatic_deployment": False}

    def _actual(self, state, candidates=None):
        _require(isinstance(state, dict) and isinstance(state.get("context"), dict), "Missing actual state context")
        ctx = state["context"]
        _require(state.get("type") == "decision" and state.get("decision") != "game_over"
                 and type(ctx.get("act")) is int and ctx["act"] in (1, 2, 3)
                 and type(ctx.get("ascension")) is int and ctx["ascension"] == 10
                 and ctx.get("combat_in_progress") is False and ctx.get("integrity_recovery_used") is False,
                 "Policy requires a clean actual noncombat A10 macro decision")
        self._check_integrity()
        supplied = validate_candidate_set(candidates) if candidates is not None else None
        actual = enumerate_candidates(state, max_candidates=(
            supplied.get("enumeration_limit", LEGACY_ENUMERATION_LIMIT)
            if supplied is not None else DEFAULT_ENUMERATION_LIMIT))
        _require(actual["complete"], actual.get("reason") or "Incomplete legal action space")
        return actual

    def score(self, state, candidates=None, *, selection_purpose=None):
        actual = self._actual(state, candidates)
        _require(candidates is None or candidates == actual, "Stale or modified candidates")
        _require(actual.get("representation") != "ordered_selection_implicit_v1",
                 "Implicit action spaces require an external bounded selection policy")
        return self.score_requests(state, [c["request"] for c in actual["candidates"]],
                                   selection_purpose=selection_purpose)

    def score_requests(self, state, requests, *, selection_purpose=None):
        actual = self._actual(state)
        # Base scorer validates every request and duplicate, and keeps explicit
        # coverage metadata even when an external advisor requests a subset.
        packet = self.fallback.score_requests(state, requests, selection_purpose=selection_purpose)
        active = self._gate_use is None and eligible_gate(state)
        reason = None if active else ("first_eligible_gate_already_chosen" if self._gate_use is not None
                                      else "outside_first_ordinary_Act1_reward_scope")
        if active:
            candidates = actual["candidates"]
            _require(2 <= len(candidates) <= 6 and sum(c["is_skip"] for c in candidates) == 1
                     and all(c["request"]["action"] in {"select_card_reward", "skip_card_reward"}
                             for c in candidates), "Eligible gate lacks the trained complete reward-and-skip space")
            _require(selection_purpose is None, "Prefix training used no reward selection-purpose override")
            player = state.get("player") or {}
            hp, maximum = player.get("hp"), player.get("max_hp")
            _require(type(hp) in (int, float) and type(maximum) in (int, float)
                     and math.isfinite(hp) and math.isfinite(maximum) and 0 <= hp <= maximum and maximum > 0,
                     "Paired HP target requires actual HP and positive gate max HP")
            full = extend_scoring_packet(state, self.fallback.score(state, actual))
            _require(full["interaction_feature_source"] == self._model["feature_transform"],
                     "Live paired feature transform changed")
            skip = next(row for row in full["scores"] if row["is_skip"])
            skip_score = predict(self._model, {name: 0. for name in FEATURE_NAMES})
            _require(math.isfinite(skip_score), "Nonfinite paired skip reference score")
            by_id = {row["candidate_id"]: row for row in full["scores"]}
            scored = []
            for requested in packet["scores"]:
                row = copy.deepcopy(by_id[requested["candidate_id"]])
                delta = {name: row["features"][name] - skip["features"][name] for name in FEATURE_NAMES}
                value = predict(self._model, delta)
                _require(math.isfinite(value), "Nonfinite paired model score")
                row.update(rule_score=row["score"], rule_delta_from_skip=row["delta_from_skip"],
                    rule_reasons=row["reasons"], score=value,
                    delta_from_skip=value - skip_score, model_features=delta,
                    reasons=[{"source": MODEL_FORMAT, "semantics": TARGET, "value": value}],
                    model_reference_candidate_id=skip["candidate_id"],
                    model_reference_score=skip_score,
                    model_coverage={"out_of_training_range": [name for name, lo, hi in
                        zip(FEATURE_NAMES, self._model["feature_min"], self._model["feature_max"])
                        if not lo <= delta[name] <= hi], "uncertainty_calibrated": False},
                    uncertainty="uncalibrated_short_horizon_paired_intervention_model")
                scored.append(row)
            # Keep the subset's genuine coverage; adding a skip reference is
            # feature evaluation, not permission to invent an evaluated action.
            coverage = {"evaluated_candidates_complete": packet["evaluated_candidates_complete"]}
            packet = full
            packet.update(coverage, scores=scored,
                score_semantics="uncalibrated_next_combat_HP_difference_over_gate_max_HP_vs_skip_not_win_probability",
                model_input_representation="119_public_candidate_features_minus_same_gate_skip_features",
                model_feature_names=list(FEATURE_NAMES), interaction_scores_applied=True)
        packet = copy.deepcopy(packet)
        packet.update(policy_id=VERSION, policy_version=VERSION,
            effective_scorer=MODEL_FORMAT if active else POLICY_VERSION,
            model={**self.source, "active": active, "scope": copy.deepcopy(SCOPE), "target_semantics": TARGET,
                   "inactive_reason": reason, "calibrated_probability": False, "A10_victory_model": False},
            scope_state={"first_eligible_gate_used": self._gate_use is not None,
                         "consumed_by": self.gate_use, "scoring_consumes_scope": False},
            policy_limitations=list(LIMITATIONS), calibrated=False)
        if not active:
            # Fallback score/features/semantics are exactly the existing v3 rules.
            packet["feature_policy_version"] = POLICY_VERSION
        return packet

    def choose(self, state, candidates=None, *, selection_purpose=None):
        scoring = self.score(state, candidates, selection_purpose=selection_purpose)
        rows = scoring["scores"]
        _require(bool(rows), "No selectable action")
        _require(all(type(row["score"]) in (int, float) and math.isfinite(row["score"]) for row in rows),
                 "Nonfinite policy score")
        best = max(row["score"] for row in rows)
        greedy = [row for row in rows if abs(row["score"] - best) <= TIE_TOLERANCE]
        explored = self.rng.random() < self.epsilon
        chosen = self.rng.choice(rows if explored else greedy)
        legal = materialize_candidate(enumerate_candidates(state), chosen["request"])
        _require(legal["candidate_id"] == chosen["candidate_id"], "Chosen model action is not legal")
        probability = self.epsilon / len(rows) + ((1 - self.epsilon) / len(greedy) if chosen in greedy else 0)
        commit = ({"state_hash": state_hash(state), "candidate_id": chosen["candidate_id"],
                   "choice_count": self.choice_count, "engine_execution_verified": False}
                  if scoring["model"]["active"] else None)
        result = {"request": copy.deepcopy(chosen["request"]), "candidate_id": chosen["candidate_id"],
            "scoring": scoring, "policy_provenance": {**self.provenance, "choice_count": self.choice_count},
            "scope_transition": {"consumed_first_eligible_gate": commit is not None, "commit": copy.deepcopy(commit)},
            "exploration": {"epsilon": self.epsilon, "explored": explored, "chosen_probability": probability,
                "greedy_tie_count": len(greedy), "candidate_count": len(rows), "random_seed": self.seed,
                "choice_count": self.choice_count,
                "probability_semantics": "epsilon_uniform_all_candidates_plus_uniform_greedy_ties",
                "probability_precision": "nominal_float_threshold"}}
        if commit is not None:
            self._gate_use = commit
        self.choice_count += 1
        return result
