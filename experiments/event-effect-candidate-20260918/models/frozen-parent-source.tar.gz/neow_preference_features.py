"""Offer identity features on the original three-option Neow opening only."""
from reference_archetype_features import PARAMETERS as BASE_PARAMETERS, features as base_features

OPTIONS = ('ARCANE_SCROLL', 'BOOMING_CONCH', 'CURSED_PEARL', 'DOWSING_ROD',
    'FISHING_ROD', 'GOLDEN_PEARL', 'HEFTY_TABLET', 'KALEIDOSCOPE', 'LARGE_CAPSULE',
    'LAVA_ROCK', 'LEAD_PAPERWEIGHT', 'LEAFY_POULTICE', 'LOST_COFFER', 'MASSIVE_SCROLL',
    'NEOWS_BONES', 'NEOWS_SACRIFICE', 'NEOWS_TALISMAN', 'NEOWS_TORMENT', 'NEW_LEAF',
    'NUTRITIOUS_OYSTER', 'PHIAL_HOLSTER', 'POMANDER', 'PRECARIOUS_SHEARS',
    'PRECISE_SCISSORS', 'SCROLL_BOXES', 'SILKEN_TRESS', 'SILVER_CRUCIBLE',
    'SMALL_CAPSULE', 'STONE_HUMIDIFIER', 'WINGED_BOOTS')
NEOW_PARAMETERS = tuple('neow_'+key.lower() for key in OPTIONS)
PARAMETERS = (*BASE_PARAMETERS, *NEOW_PARAMETERS)
PREFIX = 'NEOW.pages.INITIAL.options.'
CONTRACT = dict(version='public-neow-offer-identity-v1', scope='Defect A10 act1 floor1 original 3-option Neow',
    option_ids=list(OPTIONS), feature_names=list(NEOW_PARAMETERS), unknown_or_nonopening='all_neow_features_zero',
    model='conditional_softmax_regularized_human_choice_preference', weight_bound=1.,
    no_post_choice_or_future_state=True, win_probability=False)


def option_identity(state, candidate):
    ctx = state.get('context', {})
    if (state.get('decision') != 'event_choice' or state.get('event_name') != 'Neow'
            or ctx.get('act') != 1 or ctx.get('floor') != 1 or ctx.get('ascension') != 10
            or ctx.get('combat_in_progress') is not False or candidate['request'].get('action') != 'choose_option'):
        return None
    offered = state.get('options', [])
    if len(offered) != 3 or any(o.get('is_locked') is not False for o in offered): return None
    keys = [o.get('text_key') for o in offered]
    if len(set(keys)) != 3 or any(k not in {PREFIX+name for name in OPTIONS} for k in keys): return None
    key = candidate.get('evidence', {}).get('text_key')
    return key[len(PREFIX):] if key in keys else None


def features(state, row, candidate, route_input):
    values = base_features(state, row, candidate, route_input)
    values.update(dict.fromkeys(NEOW_PARAMETERS, 0.))
    identity = option_identity(state, candidate)
    if identity is not None: values['neow_'+identity.lower()] = 1.
    return values
