"""Original Thinking Ahead hand return and shared online/offline evidence contracts."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers
from inspection.trial_cosmetic_projection import project_trial_number


class ThinkingAheadReturnTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def test_original_full_plan_and_joint_corruption_rejection(self):
        source = Path('D:/sts2-training/staging/wish-original-draw-return/sts2-solver-bridge')
        batch = 'defect-power-pressure-pilot-20260915a'
        name = batch + '-positive-000'
        run = source / 'outputs' / name
        audit = read_json(source / 'outputs' / batch / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        self.assertEqual(audit['report']['outcome'], 'environment_error')
        rows = read_lines(run / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'thinking-full-fixed-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, matched, executor = False, 0, None
        display_differences = []
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}:
                    continue
                before = send(row['request'])
                actual_public, actual_display = project_trial_number(checked_public(before))
                original_public, original_display = project_trial_number(checked_public(row['response']))
                self.assertEqual(actual_public, original_public)
                if actual_display or original_display:
                    display_differences.append({'public_prefix_index': matched, 'actual': actual_display, 'original': original_display})
                matched += 1
            executor = CombatExecutor(send, read_json(run / 'manifest.json')['solver_requested_config'])
            actual_solve, supplied = executor.solve, False
            def recorded(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied:
                    return actual_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded
            final = executor.advance(before)
            self.assertIn(final['decision'], {'card_reward', 'game_over', 'map_select'})
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            proofs = [p for p in executor.solve_calls[0].get('replay', [])
                if p.get('actual_choice_audit', {}).get('parent', {}).get('card_id') == 'THINKING_AHEAD']
            self.assertEqual(len(proofs), 1)
            self.assertEqual(proofs[0]['kind'], 'original_choice_return_completed')
            self.assertEqual(proofs[0]['selected_cards'][0]['CardId'], 'RELAX')
            self.assertFalse(proofs[0]['selection_request_sent'])
            for field, value in [('source_is_actual_parent_object', False),
                ('original_task_completed_successfully', False), ('returned_objects_match_original_source', False),
                ('filter_is_null', False), ('filter_reexecuted_by_observer', True),
                ('selector_pending_after', True), ('selector_invocations_after', -1),
                ('raw_source_count_at_entry', 2), ('returned_count', 0), ('player_turn', -1),
                ('source_id', 'SCAVENGE'), ('effect_callsite', 'Scavenge.OnPlay')]:
                def corrupt(data):
                    if isinstance(data, dict):
                        for key in data:
                            if key == field:
                                data[key] = value
                            else:
                                corrupt(data[key])
                    elif isinstance(data, list):
                        for item in data:
                            corrupt(item)
                bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                corrupt(bad_calls)
                corrupt(bad_traces)
                with self.subTest(field=field), self.assertRaises((ValueError, RuntimeError)):
                    validate_replay_evidence(bad_calls, bad_traces)
            bad_calls = copy.deepcopy(executor.solve_calls)
            bad_calls[0]['replay'].remove(proofs[0])
            with self.assertRaises(ValueError):
                validate_replay_evidence(bad_calls, traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='recorded_full_original_solver_envelope_diagnostic',
                public_prefix_responses_verified=matched, original_sources=audit['actual_source_evidence'],
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                hidden_state_or_rng_equality_claimed=False, all_public_fields_identical_claimed=False,
                diagnostic_only_Trial_display_number_projection=display_differences,
                solver_calls=executor.solve_calls if executor else [])
            bridge.close()

    def boundary(self, count, draw_case=False, fiddle=False):
        label = f'thinking-hand-n{count}-draw{int(draw_case)}-fiddle{int(fiddle)}-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, action, proofs = False, None, []
        try:
            send(cmd='start_run', character='Defect', ascension=10, seed='thinking-hand-boundaries')
            deck = ['THINKING_AHEAD'] * 10 if draw_case else ['THINKING_AHEAD'] + ['DEFEND_DEFECT'] * count
            send(cmd='set_player', hp=1000, max_hp=1000, relics=['FIDDLE'] if fiddle else [], potions=[], deck=deck)
            before = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
            actor = next(c for c in before['hand'] if c['id'] == 'CARD.THINKING_AHEAD')
            meta = send(cmd='combat_meta')
            key = next(c['key'] for c in meta['hand'] if c['index'] == actor['index'])
            cards = []
            if draw_case or count:
                card = next(c for c in before['hand'] if c['index'] != actor['index'])
                token_key = next(c['key'] for c in meta['hand'] if c['index'] == card['index'])
                cards = [{'CardId': card['id'].removeprefix('CARD.'), 'UpgradeLevel': 0,
                    'StateKey': token_key, 'SourceOccurrence': 0, 'OptionOccurrence': 0}]
            action = {'Kind': 'PlayCard', 'CardId': 'THINKING_AHEAD', 'CardStateKey': key,
                'CardUpgradeLevel': 0, 'CardStateOccurrence': 0, 'ReplayCount': 0,
                'Turn': before['player_turn'], 'TargetIndex': -1, 'TargetCombatId': None,
                'Choice': {'Effect': 'MoveToDrawTop', 'SourcePile': 'Hand', 'SourceId': '',
                    'ContextId': '', 'Timing': 'Action', 'Cards': cards}}
            request = {'cmd': 'action', 'action': 'play_card', 'args': {'card_index': actor['index']}}
            after = send(request)
            drawn = 0 if not draw_case or fiddle else 2
            expected_count = len(before['hand']) - 1 + drawn
            event = after['choice_audit']['original_returns'][0]
            self.assertEqual(event['raw_source_count_at_entry'], expected_count)
            self.assertEqual(event['source_id'], 'THINKING_AHEAD')
            self.assertTrue(event['filter_is_null'])
            self.assertFalse(event['filter_reexecuted_by_observer'])
            executor = CombatExecutor(send)
            executor.last_action_request = request
            executor.solve_calls = [{'test_only_synthetic_plan': True}]
            if expected_count < 2:
                self.assertEqual(after['decision'], 'combat_play')
                self.assertEqual(event['returned_cards'], cards)
                self.assertEqual(event['original_returned_collection'], 'List<CardModel>')
                self.assertTrue(event['original_task_completed_successfully'])
                self.assertEqual(event['selector_invocations_before'], event['selector_invocations_after'])
                self.assertTrue(executor.resolve_original_automatic_choice(before, after, action))
                proofs = executor.solve_calls[0]['replay']
                self.assertFalse(proofs[0]['selection_request_sent'])
                self.assertFalse(proofs[0]['remaining_battle_plan_stopped'])
            else:
                self.assertEqual(after['decision'], 'card_select')
                self.assertEqual(len(after['cards']), expected_count)
                self.assertTrue(event['selector_pending_after'])
                self.assertFalse(event['original_task_completed_successfully'])
                self.assertFalse(executor.resolve_original_automatic_choice(before, after, action))
                after = send(cmd='action', action='select_cards', args={'indices': '0'})
                self.assertEqual(after['decision'], 'combat_play')
            self.assertEqual(len(after['hand']), expected_count - min(expected_count, 1))
            self.assertEqual(after['draw_pile_count'], before['draw_pile_count'] - drawn + min(expected_count, 1))
            self.assertEqual(after['player_turn'], before['player_turn'])
            self.assertTrue(after['context']['combat_in_progress'])
            self.assertEqual(sum((len(before['hand']), before['draw_pile_count'], before['discard_pile_count']))
                - sum((len(after['hand']), after['draw_pile_count'], after['discard_pile_count'])), 1)
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='synthetic_original_hand_boundary',
                constructed_plan_is_not_solver_output=True, synthetic_plan=action, direct_unit_proofs=proofs,
                draw_case=draw_case, fiddle=fiddle, hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_empty_singleton_and_manual_hand(self):
        for count in (0, 1, 2):
            with self.subTest(count=count): self.boundary(count)

    def test_original_draw_and_fiddle_blocked_draw_remain_manual(self):
        for fiddle in (False, True):
            with self.subTest(fiddle=fiddle): self.boundary(6, draw_case=True, fiddle=fiddle)


if __name__ == '__main__':
    unittest.main(verbosity=2)

