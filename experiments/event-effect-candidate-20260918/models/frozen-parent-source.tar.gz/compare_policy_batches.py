"""Predeclared natural macro-policy comparison; A10 wins and act reach stay distinct.

paired-macro-policy-v1 declares created_utc, seeds, conditions(character/ascension),
and two arms(batch, full solver_config, full policy_identity excluding RNG position,
full sampling, model_artifacts). Model references are allowlisted to model_path and
must bind their SHA256 to policy_identity.version or policy_identity.model_sha256.
No choices, model predictions, training, or game execution occur in this tool.
Registered prefix models use their trusted local wrapper only to verify identity.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from replay_evidence import validate_replay_evidence

from compare_batches import (BACKENDS, BEHAVIOR_SOURCES, PROFILE_LIMITS, SOLVER_FIELDS,
    config_differences, file_identity, finite_nonnegative, load_arm, load_json, load_jsonl,
    policy_identity, same_json, summarize, validate_protocol_arm, verify_execution_plan, wilson95)


POLICY_SOURCES = (*BEHAVIOR_SOURCES, "train_ranker.py", "train_act_survival.py", "survival_policy.py", "replay_evidence.py")
INTERACTION_POLICY_SOURCES = ("interaction_features.py", "train_interaction_survival.py", "interaction_survival_policy.py")
PREFIX_POLICY_ID = "first-ordinary-act1-reward-prefix-health-with-v3-fallback-v1"
PREFIX_POLICY_SOURCES = ("prefix_health_policy.py", "train_prefix_ranker.py", "prefix_interventions.py",
                         "audit_prefix_interventions.py", "interaction_features.py")
SAMPLING_FIELDS = {"epsilon", "max_seconds", "max_decisions", "model_path",
                   "hidden_audit_features_used", "selection_budget"}
MODEL_PATH_FIELDS = {"model_path"}
MODEL_HASH_FIELDS = {"version", "model_sha256"}


def required_policy_sources(document):
    """Freeze both arms' common code union without rewriting historical schemas."""
    interaction = any(arm["policy_identity"].get("id") == "act1-interaction-survival-with-v3-fallback-v1"
                      for arm in document["arms"].values())
    prefix = any(arm["policy_identity"].get("id") == PREFIX_POLICY_ID for arm in document["arms"].values())
    return tuple(dict.fromkeys((*POLICY_SOURCES, *(INTERACTION_POLICY_SOURCES if interaction else ()),
                                *(PREFIX_POLICY_SOURCES if prefix else ()))))


def validate_prefix_registration(declared, seeds, conditions):
    """Bind a prospective arm to its registered paired fit and unused root seeds.

    No source outcome is used to select seeds or score candidates. Historical
    source code/runtime evidence stays in the collection artifact; both live
    arms must separately expose one common source/runtime identity.
    """
    if declared.get("policy_identity", {}).get("id") != PREFIX_POLICY_ID:
        if "registered_prefix_sources" in declared:
            raise ValueError("Only a prefix health policy may declare registered prefix sources")
        return None
    from prefix_health_policy import PrefixHealthPolicy
    from run_metadata import file_evidence
    from selection_policy import SelectionPolicy

    if conditions != {"character": "Defect", "ascension": 10}:
        raise ValueError("Prefix health comparison requires standard Defect A10")
    sources = declared.get("registered_prefix_sources")
    if not isinstance(sources, dict) or set(sources) != {"model", "protocol", "fit_receipt", "training_audit"}:
        raise ValueError("Prefix arm must predeclare its complete registered model/protocol/fit/audit sources")
    for name, evidence in sources.items():
        if (not isinstance(evidence, dict) or set(evidence) != {"path", "sha256", "bytes"}
                or not isinstance(evidence.get("path"), str) or not Path(evidence["path"]).is_absolute()
                or Path(evidence["path"]).suffix.lower() != ".json"
                or not same_json(evidence, file_evidence(evidence["path"]))):
            raise ValueError("Registered prefix source bytes/path/hash changed: " + name)
    identity, sampling = declared["policy_identity"], declared["sampling"]
    source_protocol = Path(sources["protocol"]["path"])
    if (sampling.get("model_path") != sources["model"]["path"]
            or sources["fit_receipt"]["path"] != str(source_protocol.parent / "training-fit-receipt.json")
            or sources["training_audit"]["path"] != str(source_protocol.parent / "TRAINING_AUDIT.json")
            or not same_json(identity.get("model_source"), sources["model"])
            or not same_json(identity.get("source_protocol"), sources["protocol"])
            or not same_json(identity.get("registered_fit_source"), sources["fit_receipt"])):
        raise ValueError("Prefix identity or sampling differs from its registered source declaration")
    base = PrefixHealthPolicy(sources["model"]["path"], protocol_path=source_protocol,
        solver_config=declared["solver_config"], epsilon=sampling["epsilon"], seed="comparison-identity-only")
    expected_identity = policy_identity(SelectionPolicy(base, max_evaluations=sampling["selection_budget"]).provenance)
    if not same_json(identity, expected_identity):
        raise ValueError("Prefix policy identity differs from its actual registered wrapper and search budget")
    model = base.model
    collection = load_json(source_protocol)
    if not same_json(model.get("training_audit"), sources["training_audit"]):
        raise ValueError("Prefix training audit is not the registered model's original audited collection")
    split_seeds = model.get("split_seeds")
    if not isinstance(split_seeds, dict) or set(split_seeds) != {"train", "validation", "test"}:
        raise ValueError("Prefix model lacks all planned root seed splits")
    all_split_seeds = []
    for values in split_seeds.values():
        if not isinstance(values, list) or any(not isinstance(seed, str) or not seed for seed in values):
            raise ValueError("Prefix model split contains an invalid root seed")
        all_split_seeds.extend(values)
    if len(all_split_seeds) != len(set(all_split_seeds)):
        raise ValueError("Prefix model repeats root seeds within or across splits")
    gates = collection.get("gates", [])
    gate_seeds = [gate.get("seed") for gate in gates]
    if (any(not isinstance(seed, str) or not seed for seed in gate_seeds)
            or len(gate_seeds) != len(set(gate_seeds)) or set(gate_seeds) != set(all_split_seeds)):
        raise ValueError("Prefix model splits omit or substitute declared collection root seeds")
    source_runtime = gates[0].get("source_runtime")
    if (not isinstance(source_runtime, dict) or set(source_runtime) != {"engine", "solver", "ritsu"}
            or any(not same_json(gate.get("source_runtime"), source_runtime) for gate in gates)
            or any(not any(same_json(evidence, frozen) for frozen in collection["frozen_sources"])
                   for evidence in source_runtime.values())):
        raise ValueError("Prefix collection lacks one frozen original engine/solver/Ritsu identity")
    for name, evidence in source_runtime.items():
        file_identity(evidence, "prefix source " + name)
    complete = model.get("complete_split_seeds")
    if (not isinstance(complete, dict) or set(complete) != set(split_seeds)
            or any(not isinstance(values, list)
                   or any(not isinstance(seed, str) or seed not in split_seeds[split] for seed in values)
                   or len(values) != len(set(values))
                   for split, values in complete.items())):
        raise ValueError("Prefix model complete split roots differ from their planned allocation")
    unavailable = collection.get("unavailable_gates", [])
    if not isinstance(unavailable, list) or any(not isinstance(gate, dict)
            or not isinstance(gate.get("seed"), str) or not gate["seed"] for gate in unavailable):
        raise ValueError("Prefix source declaration has invalid unavailable root seed evidence")
    source_roots = set(all_split_seeds) | {gate["seed"] for gate in unavailable}
    if (not isinstance(seeds, list) or not seeds
            or any(not isinstance(seed, str) or not seed for seed in seeds) or len(seeds) != len(set(seeds))):
        raise ValueError("Prospective seeds must be unique nonempty strings")
    reused = sorted(source_roots & set(seeds))
    if reused:
        raise ValueError("Prospective prefix comparison reuses collection/training/validation/test root seeds: "
                         + ", ".join(reused))
    return {"verified": True, "registered_sources": sources,
            "feature_sources": model["feature_sources"], "source_root_seeds": sorted(source_roots),
            "source_runtime": source_runtime,
            "planned_seed_count": len(seeds), "source_seed_reuse": False,
            "target_semantics": model["target_semantics"], "A10_victory_model": False,
            "scope": identity["model_scope"]}


def load_policy_protocol(path):
    path = Path(path).resolve()
    content = path.read_bytes()
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate protocol field: " + key)
            result[key] = value
        return result
    document = json.loads(content.decode("utf-8-sig"), object_pairs_hook=unique,
                          parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    if not isinstance(document, dict) or document.get("schema_version") != "paired-macro-policy-v1":
        raise ValueError("Expected paired-macro-policy-v1")
    try:
        created = datetime.fromisoformat(document["created_utc"].replace("Z", "+00:00"))
        if created.tzinfo is None or created.utcoffset() != timezone.utc.utcoffset(created):
            raise ValueError("Protocol created_utc must be explicitly UTC")
        created_unix = finite_nonnegative(created.timestamp(), "protocol created_utc")
        seeds = document["seeds"]
        if (not isinstance(seeds, list) or not seeds or any(not isinstance(s, str) or not s for s in seeds)
                or len(set(seeds)) != len(seeds)):
            raise ValueError("Protocol seeds must be unique nonempty strings")
        conditions = document["conditions"]
        if (not isinstance(conditions, dict) or set(conditions) != {"character", "ascension"}
                or not isinstance(conditions["character"], str) or not conditions["character"]
                or type(conditions["ascension"]) is not int or conditions["ascension"] != 10):
            raise ValueError("Conditions must declare character and A10; sampling belongs to each arm")
        arms = document["arms"]
        if not isinstance(arms, dict) or set(arms) != {"left", "right"}:
            raise ValueError("Declare left and right arms")
        prefix_registrations = {}
        for name, arm in arms.items():
            if (not isinstance(arm, dict) or not isinstance(arm.get("batch"), str)
                    or re.fullmatch(r"[A-Za-z0-9_-]+", arm["batch"]) is None):
                raise ValueError("Invalid arm batch: " + name)
            config = arm["solver_config"]
            if not isinstance(config, dict) or set(config) != SOLVER_FIELDS or config["solver_backend"] not in BACKENDS:
                raise ValueError("Each arm needs its full supported solver_config")
            for key in ("first_budget_ms", "replan_budget_ms", "setup_budget_ms", "retry_budget_ms"):
                if type(config[key]) is not int or not 100 <= config[key] <= 30000:
                    raise ValueError("Invalid solver budget: " + key)
            profile = config["search_profile"]
            if (not isinstance(profile, dict) or set(profile) != {*PROFILE_LIMITS, "recover_deferred_turn_frontier"}
                    or type(profile["recover_deferred_turn_frontier"]) is not bool
                    or any(type(profile[k]) is not int or not 1 <= profile[k] <= maximum
                           for k, maximum in PROFILE_LIMITS.items())):
                raise ValueError("Invalid full search profile")
            identity = arm["policy_identity"]
            if not same_json(policy_identity(identity), identity):
                raise ValueError("Policy declaration must omit only random_seed and choice_count")
            sampling = arm["sampling"]
            if (not isinstance(sampling, dict) or SAMPLING_FIELDS - set(sampling)
                    or sampling["hidden_audit_features_used"] is not False):
                raise ValueError("Each arm needs exact sampling and hidden-feature exclusion evidence")
            if finite_nonnegative(sampling["epsilon"], "sampling epsilon") > 1:
                raise ValueError("Invalid epsilon")
            if identity.get("epsilon") != sampling["epsilon"]:
                raise ValueError("Policy and sampling epsilon differ")
            for key in ("max_seconds", "max_decisions", "selection_budget"):
                if type(sampling[key]) is not int or sampling[key] <= 0:
                    raise ValueError("Invalid sampling bound: " + key)
            if any(k.endswith("_path") and v is not None and k not in MODEL_PATH_FIELDS for k, v in sampling.items()):
                raise ValueError("Sampling contains a model reference outside the artifact allowlist")
            artifacts = arm["model_artifacts"]
            if not isinstance(artifacts, list):
                raise ValueError("model_artifacts must be an explicit list")
            references = {k for k in MODEL_PATH_FIELDS if sampling.get(k) is not None}
            seen = set()
            for artifact in artifacts:
                if (not isinstance(artifact, dict) or set(artifact) != {
                        "sampling_field", "path", "sha256", "bytes", "policy_hash_field"}
                        or artifact["sampling_field"] not in MODEL_PATH_FIELDS
                        or artifact["policy_hash_field"] not in MODEL_HASH_FIELDS):
                    raise ValueError("Model artifact reference is outside the explicit allowlist")
                field = artifact["sampling_field"]
                if field in seen:
                    raise ValueError("Duplicate model artifact reference")
                seen.add(field)
                model_path = Path(artifact["path"])
                if not model_path.is_absolute() or model_path.suffix.lower() != ".json":
                    raise ValueError("Model artifact must name an absolute JSON file")
                immutable = file_identity(artifact, "model artifact")
                if sampling.get(field) != artifact["path"] or identity.get(artifact["policy_hash_field"]) != immutable["sha256"]:
                    raise ValueError("Model artifact must match sampling path and policy hash")
            if seen != references or (identity["kind"] == "model" and not artifacts):
                raise ValueError("Every model reference needs a declared artifact and policy hash")
            registration = validate_prefix_registration(arm, seeds, conditions)
            if registration is not None:
                prefix_registrations[name] = registration
        if arms["left"]["batch"] == arms["right"]["batch"]:
            raise ValueError("Arms must name distinct batches")
        if not same_json(arms["left"]["solver_config"], arms["right"]["solver_config"]):
            raise ValueError("Macro-policy comparison requires identical solver configs")
        if same_json(arms["left"]["policy_identity"], arms["right"]["policy_identity"]):
            raise ValueError("Protocol must declare distinct macro policy identities")
    except (KeyError, TypeError, AttributeError, OverflowError) as exc:
        raise ValueError("Malformed macro policy protocol: " + str(exc)) from exc
    return {"path": str(path), "sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content),
            "created_unix": created_unix, "document": document,
            **({"prefix_registrations": prefix_registrations} if prefix_registrations else {})}


def validate_policy_arm(arm, declared, protocol):
    required_sources = required_policy_sources(protocol["document"])
    identity = arm["identity"]
    if identity is not None:
        if INTERACTION_POLICY_SOURCES[0] in required_sources and "godot" not in identity["binaries"]:
            arm["errors"].append("Interaction/prefix trial is missing the actual Godot compatibility DLL identity")
        if protocol.get("prefix_registrations") and "ritsu" not in identity["binaries"]:
            arm["errors"].append("Prefix trial is missing the actual Ritsu solver dependency identity")
        for registration in protocol.get("prefix_registrations", {}).values():
            if any(identity["binaries"].get(name) != file_identity(evidence, "prefix source " + name)
                   for name, evidence in registration["source_runtime"].items()):
                arm["errors"].append("Live engine/solver/Ritsu differs from the registered paired-prefix collection")
        if not same_json(identity["policy"], declared["policy_identity"]):
            arm["errors"].append("Observed macro policy differs from protocol")
        if not same_json(identity["sampling"], declared["sampling"]):
            arm["errors"].append("Observed sampling differs from exact arm declaration")
    source_sets = []
    for row in arm["runs"]:
        journal_rows = None
        try:
            manifest = load_json(Path(row["path"]) / "manifest.json")
            sources = manifest["versions"]["sources"]
            immutable = {name: file_identity(sources.get(name), name) for name in required_sources}
            for registration in protocol.get("prefix_registrations", {}).values():
                if any(immutable.get(name) != file_identity(evidence, name)
                       for name, evidence in registration["feature_sources"].items()):
                    raise ValueError("Live arm feature sources differ from the registered paired model")
            journal_rows = load_jsonl(Path(row["path"]) / "decisions.jsonl")
            journal_sources = journal_rows[0]["metadata"]["versions"]["sources"]
            if immutable != {name: file_identity(journal_sources.get(name), name) for name in required_sources}:
                raise ValueError("Policy implementation sources differ between manifest and journal")
            source_sets.append(immutable)
        except (ValueError, KeyError, TypeError, OSError, IndexError) as exc:
            arm["errors"].append(f"{row.get('run_id')}: Policy source evidence: {exc}")
        if journal_rows is not None:
            try:
                # Reuse the journal already parsed for source identity. The
                # legacy load_arm result does not retain its raw trace.
                calls = [call for record in journal_rows if record.get("record_type") == "decision_completed"
                         for call in record["solver_calls"]]
                row["replay_verification"] = validate_replay_evidence(
                    calls, load_jsonl(Path(row["path"]) / "trace.jsonl"))
            except (ValueError, KeyError, TypeError, OSError, IndexError) as exc:
                message = f"{row.get('run_id')}: Solver replay evidence: {exc}"
                arm["errors"].append(message)
                row["errors"].append(message)
                row["replay_verification"] = {"verified": False, "error": str(exc)}
                row["replay_original_category"] = row["category"]
                row.update(category="invalid_evidence", verified_a10_victory=False)
    if source_sets and any(item != source_sets[0] for item in source_sets[1:]):
        arm["errors"].append("Macro implementation sources changed within arm")
    arm["policy_sources"] = source_sets[0] if source_sets else None
    models = []
    for artifact in declared["model_artifacts"]:
        evidence = {**artifact, "verified": False}
        try:
            content = Path(artifact["path"]).read_bytes()
            actual = {"sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content)}
            if actual != file_identity(artifact, "model artifact"):
                raise ValueError("Model artifact bytes/hash differ from predeclared policy")
            evidence["verified"] = True
        except (ValueError, OSError) as exc:
            arm["errors"].append(str(exc))
        models.append(evidence)
    arm["model_artifact_verification"] = models
    if declared["policy_identity"].get("id") == PREFIX_POLICY_ID:
        arm["prefix_model_registration"] = next(registration for name, registration in
            protocol["prefix_registrations"].items() if protocol["document"]["arms"][name] == declared)
    # Reuse exact solver, seed-denominator and timestamp checks with this arm's
    # sampling bounds. Full sampling was compared above, including model_path.
    conditions = {**protocol["document"]["conditions"],
        **{k: declared["sampling"][k] for k in ("epsilon", "max_seconds", "max_decisions", "selection_budget")}}
    local = {**protocol, "document": {**protocol["document"], "conditions": conditions}}
    validate_protocol_arm(arm, declared, local)


def paired_binary(left, right, predicate):
    counts = {"both": 0, "left_only": 0, "right_only": 0, "neither": 0}
    for seed in left:
        a, b = predicate(left[seed]), predicate(right[seed])
        counts["both" if a and b else "left_only" if a else "right_only" if b else "neither"] += 1
    return {"pairs": len(left), **counts,
            "difference_right_minus_left": (counts["right_only"] - counts["left_only"]) / len(left)}


def compare_policy_batches(left_path, right_path, *, protocol):
    declaration = load_policy_protocol(protocol)
    specs = declaration["document"]["arms"]
    left = load_arm(left_path, specs["left"]["solver_config"]["solver_backend"])
    right = load_arm(right_path, specs["right"]["solver_config"]["solver_backend"])
    for name, arm in (("left", left), ("right", right)):
        validate_policy_arm(arm, specs[name], declaration)
    errors = [f"{name}: {error}" for name, arm in (("left", left), ("right", right)) for error in arm["errors"]]
    frozen = [{k: v for k, v in arm["identity"].items() if k not in {"policy", "sampling"}}
              if arm["identity"] else None for arm in (left, right)]
    if frozen[0] is None or frozen[1] is None or frozen[0] != frozen[1]:
        errors.append("Runtime, solver, character or shared behavior sources differ between policy arms")
    if left["policy_sources"] is None or left["policy_sources"] != right["policy_sources"]:
        errors.append("Policy implementation sources differ; only declared model artifacts may differ")
    plan, plan_errors = verify_execution_plan(declaration, (left, right))
    errors.extend(plan_errors)
    lmap = {r["seed"]: r for r in left["runs"] if r.get("seed") is not None}
    rmap = {r["seed"]: r for r in right["runs"] if r.get("seed") is not None}
    paired = None
    if not errors:
        paired = {"verified_a10_victory": paired_binary(lmap, rmap, lambda r: r["verified_a10_victory"]),
            "act_reach": {str(act): paired_binary(lmap, rmap, lambda r, act=act: r["max_act_observed"] >= act)
                          for act in (2, 3)}}
    for arm in (left, right):
        arm["summary"] = summarize(arm["runs"])
        for reach in arm["summary"]["act_reach"].values():
            reach["wilson_95"] = wilson95(reach["count"], arm["summary"]["runs_in_denominator"])
    return {"schema_version": "paired-natural-macro-policy-a10-v1", "comparable": not errors,
        "errors": errors, "protocol": declaration, "execution_plan": plan,
        "predeclaration_chronology_verified": all(a["protocol_verification"]["chronology_verified"] for a in (left, right)),
        "declared_differences": {"policy": config_differences(specs["left"]["policy_identity"], specs["right"]["policy_identity"], "policy_identity"),
            "sampling": config_differences(specs["left"]["sampling"], specs["right"]["sampling"], "sampling")},
        "semantics": "Every planned seed remains in the denominator, including engine failures, timeouts and missing runs. A10 victory requires a verified second-boss terminal. Act2/Act3 reach are separate observed secondary outcomes, never calibrated win probabilities or proof of a model improvement.",
        "protocol_evidence_semantics": "Exact protocol bytes are hashed; declared UTC creation must precede all journal run_start timestamps. An existing execution-plan hash is also checked; no independent timestamp authority is claimed.",
        "left": left, "right": right, "paired": paired,
        "per_seed": [{"seed": seed, "left": lmap.get(seed), "right": rmap.get(seed)} for seed in sorted(lmap.keys() | rmap.keys())]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("left", type=Path)
    parser.add_argument("right", type=Path)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = compare_policy_batches(args.left, args.right, protocol=args.protocol)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    rendered = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered)
    raise SystemExit(0 if result["comparable"] else 2)


if __name__ == "__main__":
    main()
