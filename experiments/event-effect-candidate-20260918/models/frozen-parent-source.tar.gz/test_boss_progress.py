import copy
import unittest
from boss_progress import observed_progress


def state(*, act=3, hp=25, combat=True, second=False, cid=24, decision="combat_play"):
    return {"type": "decision", "decision": decision, "player": {"hp": hp, "combat_metrics": {"combat_id": cid}},
        "context": {"act": act, "floor": 15, "ascension": 10, "integrity_recovery_used": False,
            "combat_in_progress": combat, "is_second_boss": second, "room_type": "Boss" if combat else "Map",
            "boss": {"id": "BOSS_A"}, "encounter_id": "BOSS_B" if second else "BOSS_A" if combat else None}}


def trace():
    return [{"request": {"cmd": "start_run", "character": "Defect", "ascension": 10, "seed": "fixture"},
             "response": state(act=1, combat=False, decision="event_choice")},
            {"request": {"cmd": "action", "action": "select_map_node"}, "response": state()},
            {"request": {"cmd": "action", "action": "end_turn"},
             "response": state(combat=False, decision="map_select")}]


class BossProgressTests(unittest.TestCase):
    def test_original_first_boss_end_not_full_a10_win(self):
        result = observed_progress(trace())
        self.assertTrue(result["verified_first_boss_defeated"])
        self.assertFalse(result["natural_goal_success"])
        self.assertFalse(result["complete_A10_victory_claimed"])

    def test_entering_act3_or_prediction_or_second_boss_does_not_suffice(self):
        for rows in (trace()[:2], [trace()[0], {"request": {"cmd": "solve"}, "response": state(combat=False, decision="map_select")}],
                     [trace()[0], {"request": {"cmd": "action", "action": "end_turn"}, "response": state(second=True)}]):
            self.assertFalse(observed_progress(rows)["verified_first_boss_defeated"])

    def test_zero_hp_wrong_combat_recovery_and_injection_rejected(self):
        for key, value in (("hp", 0), ("cid", 25), ("decision", "game_over")):
            rows = trace(); rows[-1]["response"] = state(combat=False, decision="map_select", **{key:value}) if key != "decision" else state(combat=False, decision=value)
            self.assertFalse(observed_progress(rows)["verified_first_boss_defeated"])
        rows = trace(); rows[1]["request"] = {"cmd":"set_player"}
        self.assertFalse(observed_progress(rows)["verified_first_boss_defeated"])
        rows = trace(); rows[-1]["response"]["context"]["integrity_recovery_used"] = True
        self.assertFalse(observed_progress(rows)["verified_first_boss_defeated"])

    def test_second_boss_defeat_preserves_observed_first_boss_success(self):
        rows=trace(); rows.append({"request":{"cmd":"action","action":"end_turn"},
            "response":state(hp=0,combat=False,second=True,decision="game_over",cid=25)})
        self.assertTrue(observed_progress(rows, natural=True, expected_seed="fixture")["natural_goal_success"])
        self.assertFalse(observed_progress(rows, natural=True, expected_seed="other")["natural_goal_success"])


if __name__ == "__main__":
    unittest.main()
