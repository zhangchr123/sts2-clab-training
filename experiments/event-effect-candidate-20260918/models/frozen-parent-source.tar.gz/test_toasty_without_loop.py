"""Original 24-action plan, ending task evidence, and corruption rejection."""
import copy
from pathlib import Path
import unittest
import uuid
from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json,read_lines,unchanged
from replay_evidence import validate_replay_evidence
from run_metadata import file_evidence
import test_liquid_memories as helpers

class ToastyWithoutLoopTests(unittest.TestCase):
    worker=helpers.LiquidMemoriesTests.worker
    save=helpers.LiquidMemoriesTests.save
    def test_original_plan_reaches_reward_and_rejects_corrupted_ending_tasks(self):
        source=Path('D:/sts2-training/staging/circulation-context-233/sts2-solver-bridge/outputs/defect-circulation-joint-search-20260915a-evaluation-initial-016')
        files=[file_evidence(p) for p in source.iterdir() if p.is_file()]
        rows=read_lines(source/'trace.jsonl');gate=max(i for i,r in enumerate(rows) if r['request']['cmd']=='solve')
        original=copy.deepcopy(rows[gate]);self.assertEqual(len(original['response']['actions']),24)
        label='toasty-no-loop-fixed-'+uuid.uuid4().hex[:10];bridge,traces,send=self.worker(label)
        executor=None;matched=0;passed=False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve','combat_meta','choice_meta'}:continue
                before=send(row['request']);self.assertEqual(checked_public(before),checked_public(row['response']));matched+=1
            executor=CombatExecutor(send,read_json(source/'manifest.json')['solver_requested_config'])
            supplied=False
            def recorded(state,budget,used=0,setup=False):
                nonlocal supplied
                self.assertFalse(supplied);self.assertEqual(state,before);supplied=True
                self.assertEqual(setup,original['request'].get('include_turn_setup',False))
                call=copy.deepcopy(original);traces.append(copy.deepcopy(call));executor.solve_calls.append(call);return call['response']
            executor.solve=recorded;final=executor.advance(before)
            self.assertEqual(final['decision'],'card_reward');self.assertEqual(checked_public(final),checked_public(rows[-2]['response']))
            self.assertEqual(executor.solve_calls[0]['response'],original['response'])
            proof=next(p for p in executor.solve_calls[0]['replay'] if p['kind']=='end_turn_setup_choice_not_executed')
            self.assertEqual(len(proof['actual_turn_end_origin']['calls']),3)
            self.assertFalse(proof['selection_request_sent']);self.assertTrue(proof['remaining_battle_plan_stopped'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
            query=len(traces)-1
            for path,value in [(('calls',0,'original_task_completed_successfully'),False),
                    (('calls',1,'entry','combat_ending'),False),(('calls',2,'returned_count'),1),
                    (('calls',2,'source_is_original_player_object'),False),(('calls',1,'kind'),'UNKNOWN_HOOK'),
                    (('after_action','selector_invocations'),-1),(('setup_capture_before',),-1)]:
                bc,bt=copy.deepcopy(executor.solve_calls),copy.deepcopy(traces)
                bp=next(p for p in bc[0]['replay'] if p['kind']==proof['kind'])
                for obj in (bp['actual_turn_end_origin'],bt[query]['response']['turn_end_origin']):
                    for key in path[:-1]:obj=obj[key]
                    obj[path[-1]]=value
                with self.subTest(path=path),self.assertRaises(ValueError):validate_replay_evidence(bc,bt)
            self.assertTrue(unchanged(files));passed=True
        finally:
            self.save(label,traces,passed=passed,origin='recorded_full_original_solver_diagnostic',original_sources=files,
                public_prefix_responses=matched,solver_calls=executor.solve_calls if executor else [],
                new_natural_games_started=0,hidden_state_or_rng_equality_claimed=False)
            bridge.close()

if __name__=='__main__':unittest.main()
