"""Protocol safety tests with explicit synthetic solver/engine responses."""
import copy
import unittest

from combat_executor import CombatExecutor


def state(decision="combat_play", *, active=True, round=1, player_turn=None, cards=None):
    result = {"type": "decision", "decision": decision, "round": round,
              "player_turn": round if player_turn is None else player_turn,
              "context": {"combat_in_progress": active, "room_type": "Monster"},
              "player": {"combat_metrics": {"source": "Creature.CurrentHpChanged", "hp_lost": 2}}}
    if cards is not None:
        result.update(cards=[{"index": index, "id": "CARD." + card["id"]} for index, card in enumerate(cards)],
                      min_select=1, max_select=1)
    return result


def card(key, *, level=0, id="GENETIC_ALGORITHM"):
    return {"id": id, "key": key, "upgrade_level": level}


def token(key, *, occurrence=0, level=0, id="GENETIC_ALGORITHM"):
    return {"CardId": id, "StateKey": key, "UpgradeLevel": level,
            "OptionOccurrence": occurrence, "SourceOccurrence": occurrence}


def choice_meta(cards, selection="card_select"):
    return {"type": "choice_meta", "selection": selection,
            "cards": [{"index": index, **item} for index, item in enumerate(cards)]}


def solved(actions):
    return {"type": "solver_result", "settings": {"search_profile_verified": True}, "actions": actions}


class FakeEngine:
    def __init__(self, responses):
        self.responses = list(responses)
        self.requests = []

    def __call__(self, **request):
        self.requests.append(request)
        if not self.responses:
            raise AssertionError("Unexpected tool request: " + str(request))
        return copy.deepcopy(self.responses.pop(0))


class CombatExecutorTests(unittest.TestCase):
    def knowledge_fixture(self):
        cards = [card("disintegration=6", id="DISINTEGRATION"), card("mindrot=1", id="MIND_ROT")]
        selection = state("card_select", cards=cards)
        meta = choice_meta(cards)
        meta["knowledge_choice"] = {"schema_version": "knowledge-demon-choice-v1",
            "source_method": "KnowledgeDemon.ChooseCurse", "original_task_pending": True, "source_is_current_live_enemy": True,
            "source_combat_id": 7, "curse_counter": 0, "source_id": "KNOWLEDGE_DEMON:7:0",
            "target_player_id": "1", "effect": "ApplyKnowledgeCurse", "source_pile": "None",
            "timing": "EnemyTurn", "context_id": "", "engine_option_ids": [c["id"] for c in cards],
            "option_keys": [c["key"] for c in cards]}
        plan = {"Effect": "ApplyKnowledgeCurse", "SourcePile": "None", "Timing": "EnemyTurn",
            "SourceId": "KNOWLEDGE_DEMON:7:0", "ContextId": "", "Cards": [token("", id="MIND_ROT")]}
        return selection, meta, plan

    def test_knowledge_effect_uses_unique_card_id_not_option_index(self):
        selection, meta, plan = self.knowledge_fixture()
        engine = FakeEngine([meta, state()])
        executor = CombatExecutor(engine)
        executor.solve_calls = [{"response": solved([])}]
        executor.resolve(selection, [plan])
        # Original token OptionOccurrence is zero even when the effect is at index 1.
        self.assertEqual(engine.requests[-1]["args"], {"indices": "1"})
        self.assertEqual(executor.solve_calls[0]["replay"][0]["plan"], plan)

    def test_knowledge_effect_requires_original_pending_context_and_every_binding(self):
        selection, baseline, plan = self.knowledge_fixture()
        mutations = [{"source_id": "KNOWLEDGE_DEMON:8:0"}, {"curse_counter": 1},
            {"source_combat_id": True}, {"original_task_pending": False}, {"source_is_current_live_enemy": False}, {"target_player_id": ""},
            {"source_method": "unrelated"}, {"effect": "Modify"}, {"source_pile": "Discard"},
            {"timing": "Action"}, {"context_id": "different"}, {"engine_option_ids": ["MIND_ROT"]},
            {"option_keys": ["changed", "mindrot=1"]}, {"schema_version": "unknown"}]
        for mutation in mutations:
            with self.subTest(mutation=mutation):
                meta = copy.deepcopy(baseline)
                meta["knowledge_choice"].update(mutation)
                engine = FakeEngine([meta])
                with self.assertRaisesRegex(RuntimeError, "original effect identity"):
                    CombatExecutor(engine).resolve(selection, [plan])
                self.assertEqual(len(engine.requests), 1)
        for missing in (None, {}):
            meta = {**baseline, "knowledge_choice": missing}
            with self.assertRaises(RuntimeError):
                CombatExecutor(FakeEngine([meta])).resolve(selection, [plan])

    def test_knowledge_token_cannot_relax_generic_or_noncanonical_identity(self):
        selection, meta, baseline = self.knowledge_fixture()
        bad_tokens = [{"StateKey": "invented"}, {"UpgradeLevel": 1}, {"UpgradeLevel": False},
            {"OptionOccurrence": 1}, {"SourceOccurrence": 1}, {"CardId": "SLOTH"}]
        for mutation in bad_tokens:
            with self.subTest(mutation=mutation):
                plan = copy.deepcopy(baseline)
                plan["Cards"][0].update(mutation)
                engine = FakeEngine([meta])
                with self.assertRaises(RuntimeError):
                    CombatExecutor(engine).resolve(selection, [plan])
                self.assertEqual(len(engine.requests), 1)
        for mutation in ({"Effect": "Modify"}, {"SourceId": "KNOWLEDGE_DEMON:7:1"},
                         {"Timing": "Action"}, {"SourcePile": "Hand"}, {"Cards": []}):
            plan = {**baseline, **mutation}
            with self.assertRaises(RuntimeError):
                CombatExecutor(FakeEngine([meta])).resolve(selection, [plan])

    def test_same_id_different_growth_uses_option_occurrence_then_state_key(self):
        cards = [card("growth=3"), card("growth=9")]
        engine = FakeEngine([choice_meta(cards), state()])
        executor = CombatExecutor(engine)
        executor.resolve(state("card_select", cards=cards), [{"Cards": [token("growth=9", occurrence=1)]}])
        self.assertEqual(engine.requests[-1], {"cmd": "action", "action": "select_cards", "args": {"indices": "1"}})

    def test_key_match_elsewhere_cannot_reassign_a_wrong_occurrence(self):
        cards = [card("growth=3"), card("growth=9")]
        engine = FakeEngine([choice_meta(cards)])
        executor = CombatExecutor(engine)
        with self.assertRaisesRegex(RuntimeError, "Choice token mismatch"):
            executor.resolve(state("card_select", cards=cards), [{"Cards": [token("growth=9", occurrence=0)]}])
        self.assertEqual([request["cmd"] for request in engine.requests], ["choice_meta"])

    def test_upgrade_levels_are_not_collapsed_to_boolean(self):
        cards = [card("level=1", level=1), card("level=2", level=2)]
        engine = FakeEngine([choice_meta(cards), state()])
        CombatExecutor(engine).resolve(state("card_select", cards=cards), [{"Cards": [token("level=2", level=2)]}])
        self.assertEqual(engine.requests[-1]["args"]["indices"], "1")

    def test_missing_key_negative_occurrence_and_duplicate_selection_block(self):
        cards = [card("same-state")]
        for tokens in ([token("")], [token("same-state", occurrence=-1)], [token("same-state"), token("same-state")]):
            with self.subTest(tokens=tokens):
                engine = FakeEngine([choice_meta(cards)])
                with self.assertRaises(RuntimeError):
                    CombatExecutor(engine).resolve(state("card_select", cards=cards), [{"Cards": tokens}])
                self.assertFalse(any(request["cmd"] == "action" for request in engine.requests))

    def test_empty_planned_card_selection_obeys_bounds(self):
        cards = [card("same-state")]
        selection = state("card_select", cards=cards)
        selection["min_select"] = 0
        engine = FakeEngine([choice_meta(cards), state()])
        CombatExecutor(engine).resolve(selection, [{"Cards": []}])
        self.assertEqual(engine.requests[-1]["args"], {"indices": ""})

    def test_unplanned_combat_reward_and_bundle_never_escape_to_macro(self):
        for decision in ("card_reward", "card_select", "bundle_select", "unknown_choice"):
            with self.subTest(decision=decision):
                unexpected = state(decision)
                engine = FakeEngine([solved([{"Kind": "EndTurn", "Turn": 1}]), unexpected])
                executor = CombatExecutor(engine)
                with self.assertRaisesRegex(RuntimeError, "Unplanned combat decision"):
                    executor.advance(state())
                self.assertEqual(executor.last_state, unexpected)
                self.assertEqual([request["cmd"] for request in engine.requests], ["solve", "action"])

    def test_known_post_combat_reward_is_returned_to_macro(self):
        reward = state("card_reward", active=False)
        engine = FakeEngine([solved([{"Kind": "EndTurn", "Turn": 1}]), reward])
        executor = CombatExecutor(engine)
        self.assertEqual(executor.advance(state()), reward)

    def test_unknown_choice_ownership_fails_closed(self):
        reward = state("card_reward", active=False)
        del reward["context"]["combat_in_progress"]
        engine = FakeEngine([])
        with self.assertRaisesRegex(RuntimeError, "Missing explicit combat_in_progress"):
            CombatExecutor(engine).advance(reward)

    def test_remaining_unplanned_choice_after_resolution_blocks(self):
        cards = [card("same-state")]
        engine = FakeEngine([choice_meta(cards), state("card_reward")])
        executor = CombatExecutor(engine)
        with self.assertRaisesRegex(RuntimeError, "Unplanned combat decision"):
            executor.resolve(state("card_select", cards=cards), [{"Cards": [token("same-state")]}])
        self.assertEqual(executor.last_state["decision"], "card_reward")

    def test_state_after_successful_action_survives_later_replay_failure(self):
        progressed = state(round=2)
        engine = FakeEngine([solved([{"Kind": "EndTurn", "Turn": 1}, {"Kind": "EndTurn", "Turn": 8}]), progressed])
        executor = CombatExecutor(engine)
        with self.assertRaisesRegex(RuntimeError, "player turn mismatch"):
            executor.advance(state())
        self.assertEqual(executor.last_state, progressed)

    def test_extra_player_turn_replays_while_global_round_stays_unchanged(self):
        extra_turn = state(round=2, player_turn=3)
        reward = state("card_reward", active=False)
        engine = FakeEngine([solved([{"Kind": "EndTurn", "Turn": 2}, {"Kind": "EndTurn", "Turn": 3}]),
                             extra_turn, reward])
        self.assertEqual(CombatExecutor(engine).advance(state(round=2)), reward)
        self.assertEqual([r["action"] for r in engine.requests if r["cmd"] == "action"], ["end_turn", "end_turn"])

    def test_missing_or_invalid_player_turn_never_uses_global_round(self):
        for value in (None, True, 0, "1"):
            with self.subTest(value=value):
                current = state()
                current["player_turn"] = value
                engine = FakeEngine([solved([{"Kind": "EndTurn", "Turn": 1}])])
                with self.assertRaisesRegex(RuntimeError, "Missing actual player_turn"):
                    CombatExecutor(engine).advance(current)
                self.assertFalse(any(r["cmd"] == "action" for r in engine.requests))

    def test_action_error_keeps_actual_error_and_query_does_not_overwrite_state(self):
        error = {"type": "error", "message": "action failed"}
        engine = FakeEngine([solved([{"Kind": "EndTurn", "Turn": 1}]), error])
        executor = CombatExecutor(engine)
        with self.assertRaises(RuntimeError):
            executor.advance(state())
        self.assertEqual(executor.last_state, error)
        self.assertEqual(executor.last_error, error)
        previous = state()
        executor.last_state = previous
        executor.send = FakeEngine([{"type": "combat_meta", "hand": []}])
        executor.checked(cmd="combat_meta")
        self.assertEqual(executor.last_state, previous)

    def test_metadata_surface_mismatch_never_submits_selection(self):
        cards = [card("same-state")]
        engine = FakeEngine([choice_meta(cards, "none")])
        with self.assertRaisesRegex(RuntimeError, "metadata does not match"):
            CombatExecutor(engine).resolve(state("card_select", cards=cards), [{"Cards": [token("same-state")]}])
        self.assertEqual(len(engine.requests), 1)


class EndingChoiceTests(unittest.TestCase):
    """Synthetic evidence only. Real original-DLL fixtures live separately."""
    def fixture(self):
        before = state()
        before["player"]["combat_metrics"]["combat_id"] = 3
        after = state("card_reward", active=False)
        after["player"]["combat_metrics"]["combat_id"] = 3
        plan = {"Effect": "MoveToHand", "SourcePile": "Discard", "Cards": [token("rocket", id="ROCKET_PUNCH")],
                "SourceId": "", "ContextId": "", "Timing": "Action"}
        action = {"Kind": "PlayCard", "CardId": "NEOWS_FURY", "CardStateKey": "neow", "Turn": 1,
                  "Choice": plan, "NestedChoices": None, "TurnStartChoices": None, "ReplayCount": 0}
        audit = {"schema_version": "combat-choice-return-v1", "coverage": "FromCombatPile.IsEnding.synchronous_empty_return_only",
                 "action_id": 8, "closed": True,
                 "parent": {"action": "play_card", "card_index": 2, "card_id": "NEOWS_FURY", "card_key": "neow",
                            "player_id": "1", "combat_id": 3, "player_turn": 1, "combat_active_before": True},
                 "events": [{"event_index": 0, "action_id": 8, "source_method": "CardSelectCmd.FromCombatPile",
                             "source_pile": "Discard", "player_id": "1", "reason": "combat_ending",
                             "is_ending_at_entry": True, "original_task_completed_successfully": True,
                             "original_returned_empty_array": True, "selector_invocations_before": 4,
                             "selector_invocations_after": 4, "selection_executed": False, "selected_cards": []}]}
        after["choice_audit"] = audit
        return before, after, action

    def engine(self, after):
        meta = choice_meta([], "none")
        meta["completion_audit"] = copy.deepcopy(after["choice_audit"])
        executor = CombatExecutor(FakeEngine([meta]))
        executor.last_action_request = {"cmd": "action", "action": "play_card", "args": {"card_index": 2}}
        executor.solve_calls = [{"request": {"cmd": "solve"}, "response": {"actions": []}}]
        return executor

    def test_observed_short_circuit_is_unexecuted_not_a_selected_token(self):
        before, after, action = self.fixture()
        executor = self.engine(after)
        self.assertTrue(executor.resolve_ending_choice(before, after, action))
        proof = executor.solve_calls[-1]["replay"][0]
        self.assertEqual(proof["kind"], "planned_choice_not_executed")
        self.assertEqual(proof["selected_cards"], [])
        self.assertEqual(proof["plan"]["Cards"][0]["CardId"], "ROCKET_PUNCH")
        self.assertEqual(executor.send.requests, [{"cmd": "choice_meta"}])

    def test_every_audit_binding_and_original_return_condition_is_required(self):
        mutations = [
            ("audit", "action_id", True), ("audit", "closed", False),
            ("parent", "card_key", "other"), ("parent", "card_id", "HOLOGRAM"),
            ("parent", "card_index", 0), ("parent", "combat_id", 4),
            ("parent", "player_turn", 2), ("parent", "combat_active_before", False),
            ("event", "action_id", 7), ("event", "event_index", True),
            ("event", "player_id", "other"), ("event", "source_pile", "Draw"),
            ("event", "is_ending_at_entry", False), ("event", "original_returned_empty_array", False),
            ("event", "original_task_completed_successfully", False),
            ("event", "selector_invocations_after", 5), ("event", "selector_invocations_before", True),
            ("event", "selection_executed", True), ("event", "selected_cards", ["ROCKET_PUNCH"]),
        ]
        for section, key, value in mutations:
            with self.subTest(section=section, key=key):
                before, after, action = self.fixture()
                audit = after["choice_audit"]
                target = audit if section == "audit" else audit["parent"] if section == "parent" else audit["events"][0]
                target[key] = value
                executor = self.engine(after)
                with self.assertRaises(RuntimeError):
                    executor.resolve_ending_choice(before, after, action)
                self.assertNotIn("replay", executor.solve_calls[-1])

    def test_absent_short_circuit_or_other_effect_never_skips_plans(self):
        for mutation in ("no_audit", "active", "other_card", "other_effect", "nested", "empty_events", "double_events"):
            with self.subTest(mutation=mutation):
                before, after, action = self.fixture()
                executor = self.engine(after)
                if mutation == "no_audit": del after["choice_audit"]
                elif mutation == "active": after["context"]["combat_in_progress"] = True
                elif mutation == "other_card": action["CardId"] = "HOLOGRAM"
                elif mutation == "other_effect": action["Choice"]["Effect"] = "Upgrade"
                elif mutation == "nested": action["NestedChoices"] = [copy.deepcopy(action["Choice"])]
                elif mutation == "empty_events": after["choice_audit"]["events"] = []
                elif mutation == "double_events": after["choice_audit"]["events"] *= 2
                if mutation in {"empty_events", "double_events"}:
                    executor = self.engine(after)
                    with self.assertRaises(RuntimeError): executor.resolve_ending_choice(before, after, action)
                else:
                    self.assertFalse(executor.resolve_ending_choice(before, after, action))
                self.assertNotIn("replay", executor.solve_calls[-1])

    def test_stale_query_or_pending_selection_never_skips(self):
        for bad in ("stale", "pending"):
            before, after, action = self.fixture()
            executor = self.engine(after)
            meta = executor.send.responses[0]
            if bad == "stale": meta["completion_audit"]["action_id"] = 2
            else: meta["selection"] = "card_select"
            with self.assertRaisesRegex(RuntimeError, "stale or a selector"):
                executor.resolve_ending_choice(before, after, action)


if __name__ == "__main__":
    unittest.main()
