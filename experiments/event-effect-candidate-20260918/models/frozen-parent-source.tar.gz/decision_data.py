"""Auditable macro decisions; recorded choices are observations, never optimal labels.

The state adapter follows Sts2Headless.RunSimulator's exported decision surfaces.
It never executes actions. A caller must stop on ``complete == False``; partial
candidate lists are deliberately not returned. Selection sequences are exact,
including the empty selection when min_select permits it.

Runner integration::

    journal = DecisionJournal(output_dir, metadata)
    candidates = enumerate_candidates(state)
    token = journal.begin(state, request, policy=policy_provenance)
    # Execute once; collect every solve request and its actual response.
    journal.complete(token, next_state, solver_calls=solve_request_responses)
    journal.finalize(final_state, termination="engine_terminal")

``metadata`` requires run_id, seed, character, ascension, mode, versions
({engine, solver, bridge}), solver_requested_config, and provenance. Versions
may be strings or structured build/hash records; null versions remain explicit
missing evidence. Provenance requires origin, kind, id, version, llm_involved.
Natural training origins must use rules/model/search/exploration throughout.
LLM, human, fixture, replay and smoke trajectories remain auditable but excluded.

The append-only JSONL has run_start, decision_started, decision_completed and
run_finished records. A started decision without completion is unresolved, not
a transition or a loss. ``read_decisions`` joins the true run outcome onto each
completed observation and computes conservative training eligibility. Do not
train directly on decision_started records or infer unchosen action outcomes.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import re
import time
from typing import Any, Mapping, Sequence

from selection_space import (DataContractError, build_space, indices_from_request,
                             validate_space)


SCHEMA_VERSION = "sts2.macro_decision.v1"
ADAPTER_VERSION = "runsimulator-candidates.v3"
PREVIOUS_ADAPTER_VERSION = "runsimulator-candidates.v2"
LEGACY_ADAPTER_VERSION = "runsimulator-candidates.v1"
LEGACY_ENUMERATION_LIMIT = 100_000
DEFAULT_ENUMERATION_LIMIT = 256
NON_LLM_KINDS = {"rules", "model", "search", "exploration"}
ORIGINS = {"natural", "fixture", "branch", "replay", "control_smoke", "deployment", "debug"}
POLICY_KINDS = NON_LLM_KINDS | {"human", "manual", "llm", "scripted_fixture", "unknown"}


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def _copy(value: Any) -> Any:
    return json.loads(_json(value))


def state_hash(state: Mapping[str, Any]) -> str:
    return hashlib.sha256(_json(state).encode("utf-8")).hexdigest()


def _integer(value: Any, name: str, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise DataContractError(f"{name} must be an integer >= {minimum}")
    return value


def _boolean(value: Any, name: str) -> bool:
    if type(value) is not bool:
        raise DataContractError(f"{name} must be an explicit boolean")
    return value


def _items(state: Mapping[str, Any], key: str) -> list[dict[str, Any]]:
    values = state.get(key)
    if not isinstance(values, list) or any(not isinstance(v, dict) for v in values):
        raise DataContractError(f"{key} must be an exported list of objects")
    return values


def _indexed(state: Mapping[str, Any], key: str) -> list[dict[str, Any]]:
    values = _items(state, key)
    indices = [_integer(v.get("index"), f"{key}.index") for v in values]
    if len(indices) != len(set(indices)):
        raise DataContractError(f"{key} contains duplicate indices")
    return values


def normalize_request(request: Mapping[str, Any]) -> dict[str, Any]:
    """Accept only actual macro action wire requests, with no ignored extras."""
    if not isinstance(request, Mapping) or set(request) - {"cmd", "action", "args"}:
        raise DataContractError("Chosen request contains unsupported fields")
    if request.get("cmd") != "action" or not isinstance(request.get("action"), str):
        raise DataContractError("Chosen request must be cmd=action")
    args = request.get("args", {})
    if not isinstance(args, Mapping):
        raise DataContractError("Action args must be an object")
    result = {"cmd": "action", "action": request["action"]}
    if args:
        result["args"] = _copy(args)
    return result


def _candidate(request, evidence, *, skip=False):
    return {"candidate_id": "action:" + state_hash(request)[:24], "request": _copy(request),
            "is_skip": skip, "source": "engine_current_state", "evidence": _copy(evidence)}


def enumerate_candidates(state: Mapping[str, Any], *, max_candidates: int = DEFAULT_ENUMERATION_LIMIT,
                         _recorded_version: str | None = None) -> dict[str, Any]:
    """Describe the full legal macro action set or return a blocked result.

    ``complete`` refers to action-space coverage, not to scoring coverage.
    Oversized ordered selections have an exact implicit descriptor and an empty
    candidates list. Never treat that empty list as a terminal or scored surface.

    Shop support intentionally requires exported can_purchase on every item,
    card_removal_available, and can_leave. Existing snapshots that omit these
    fields are insufficient: potion capacity and removal stock cannot be guessed.
    Combat selections belong to CombatSolver; this adapter rejects known combat
    card_select surfaces even when their wire format matches macro selections.
    """
    version = _recorded_version or ADAPTER_VERSION
    if version not in {ADAPTER_VERSION, PREVIOUS_ADAPTER_VERSION, LEGACY_ADAPTER_VERSION}:
        raise DataContractError("Unsupported recorded adapter version")
    result = {"adapter_version": version, "source": "engine_current_state",
              "state_hash": state_hash(state), "decision": state.get("decision"),
              "complete": False, "candidates": [], "reason": None,
              "representation": "explicit_v1", "candidate_count": None,
              "enumeration_limit": max_candidates}
    candidates: list[dict[str, Any]] = []

    def add(action: str, args: dict[str, Any] | None, evidence: Any, *, skip: bool = False) -> None:
        request = {"cmd": "action", "action": action}
        if args:
            request["args"] = args
        candidates.append(_candidate(request, evidence, skip=skip))

    try:
        _integer(max_candidates, "max_candidates", 1)
        if state.get("type") != "decision":
            raise DataContractError("Not an engine decision state")
        decision = state.get("decision")
        if (decision in {"card_select", "card_reward", "bundle_select"}
                and state.get("context", {}).get("combat_in_progress") is True):
            raise DataContractError("Active combat choices must come from CombatSolver")
        if decision in {"event_choice", "rest_site"}:
            key = "is_locked" if decision == "event_choice" else "is_enabled"
            for option in _indexed(state, "options"):
                flag = _boolean(option.get(key), f"options.{key}")
                if flag == (decision == "rest_site"):
                    add("choose_option", {"option_index": option["index"]}, option)
        elif decision == "card_reward":
            skip = _boolean(state.get("can_skip"), "can_skip")
            for card in _indexed(state, "cards"):
                add("select_card_reward", {"card_index": card["index"]}, card)
            if skip:
                add("skip_card_reward", None, {"can_skip": True}, skip=True)
        elif decision == "card_select":
            if state.get("context", {}).get("room_type") in {"Monster", "Elite", "Boss"}:
                raise DataContractError("Combat card selections must come from CombatSolver")
            cards = _indexed(state, "cards")
            space = build_space(cards, state.get("min_select"), state.get("max_select"), result["state_hash"])
            minimum, maximum = space["min_select"], space["effective_max_select"]
            # ResolvePendingByIndices preserves order. Do not assume that RNG
            # assignment during transform/enchant is invariant to that order.
            count = space["candidate_count"]
            if count > max_candidates:
                result.update(complete=True, representation="ordered_selection_implicit_v1",
                              candidate_count=count, selection_space=space)
                return result
            for size in range(minimum, maximum + 1):
                for selected in itertools.permutations(cards, size):
                    indices = [card["index"] for card in selected]
                    add("select_cards", {"indices": ",".join(map(str, indices))},
                        {"indices": indices, "cards": list(selected),
                         "min_select": minimum, "max_select": state["max_select"]}, skip=not indices)
        elif decision == "crystal_sphere":
            size = state.get("grid_size", {})
            if size != {"x": 11, "y": 11}:
                raise DataContractError("Unsupported Crystal Sphere grid size")
            _integer(state.get("divinations_left"), "divinations_left", 1)
            if state.get("tools") != ["small", "big"]:
                raise DataContractError("Unsupported Crystal Sphere tools")
            cells = _items(state, "cells")
            seen, hidden = set(), set()
            for cell in cells:
                x = _integer(cell.get("x"), "cell.x")
                y = _integer(cell.get("y"), "cell.y")
                flag = _boolean(cell.get("hidden"), "cell.hidden")
                expected = {"x", "y", "hidden"} if flag else {"x", "y", "hidden", "item_kind"}
                if set(cell) != expected or x >= 11 or y >= 11 or (x, y) in seen:
                    raise DataContractError("Malformed or non-public Crystal Sphere cell")
                seen.add((x, y))
                if flag:
                    hidden.add((x, y))
            if len(seen) != 121:
                raise DataContractError("Crystal Sphere grid is incomplete")
            for cell in cells:
                if not cell["hidden"]:
                    continue
                for tool, radius in (("small", 0), ("big", 1)):
                    args = {"x": cell["x"], "y": cell["y"], "tool": tool}
                    count = sum(abs(x - cell["x"]) <= radius and abs(y - cell["y"]) <= radius
                                for x, y in hidden)
                    add("crystal_sphere_reveal", args, {**args, "hidden_cells_covered": count})
        elif decision == "map_select":
            seen = set()
            for node in _items(state, "choices"):
                coordinates = (_integer(node.get("col"), "col", -32768),
                               _integer(node.get("row"), "row", -32768))
                if coordinates in seen:
                    raise DataContractError("Duplicate map coordinate in choices")
                seen.add(coordinates)
                add("select_map_node", {"col": coordinates[0], "row": coordinates[1]}, node)
        elif decision == "bundle_select":
            for bundle in _indexed(state, "bundles"):
                _items(bundle, "cards")
                add("select_bundle", {"bundle_index": bundle["index"]}, bundle)
        elif decision == "shop":
            # The boolean is the engine's purchase legality, including slots,
            # stock, gold and relic restrictions. Do not infer from cost alone.
            for key, action, argument in (("cards", "buy_card", "card_index"),
                                           ("relics", "buy_relic", "relic_index"),
                                           ("potions", "buy_potion", "potion_index")):
                for item in _indexed(state, key):
                    if _boolean(item.get("can_purchase"), f"{key}.can_purchase"):
                        add(action, {argument: item["index"]}, item)
            player = state.get("player", {})
            gold = _integer(player.get("gold"), "player.gold")
            if _boolean(state.get("card_removal_available"), "card_removal_available"):
                removal_cost = _integer(state.get("card_removal_cost"), "card_removal_cost")
                if gold >= removal_cost:
                    add("remove_card", None, {"card_removal_available": True,
                                              "card_removal_cost": removal_cost, "gold": gold})
            for potion in _indexed(player, "potions"):
                add("discard_potion", {"potion_index": potion["index"]}, potion)
            if _boolean(state.get("can_leave"), "can_leave"):
                add("leave_room", None, {"can_leave": True}, skip=True)
        elif decision == "game_over":
            _boolean(state.get("victory"), "victory")
        else:
            raise DataContractError(f"Unsupported decision: {decision!r}")
        if not candidates and decision != "game_over":
            raise DataContractError("No explicitly legal room candidates")
        if version == ADAPTER_VERSION:
            from noncombat_potions import eligible_potions
            for potion in eligible_potions(state):
                add("use_potion", {"potion_index": potion["index"]}, potion)
        if not candidates and decision != "game_over":
            raise DataContractError("No explicitly legal candidates")
        if len(candidates) > max_candidates:
            raise DataContractError("Candidate limit exceeded; no truncation")
        result.update(complete=True, candidates=candidates, candidate_count=len(candidates))
    except (DataContractError, TypeError, AttributeError) as exc:
        result["reason"] = str(exc)
    return result


def validate_candidate_set(candidate_set: Mapping[str, Any]) -> dict[str, Any]:
    """Check a descriptor's own schema; state binding is checked by the journal.

    The legacy v1 shape is accepted only with its exact original field set.
    New fields/versions cannot be smuggled in as ignored legacy metadata.
    """
    if not isinstance(candidate_set, Mapping):
        raise DataContractError("Candidate set must be an object")
    base = {"adapter_version", "source", "state_hash", "decision", "complete", "candidates", "reason"}
    version = candidate_set.get("adapter_version")
    legacy = version == LEGACY_ADAPTER_VERSION
    representation = "explicit_v1" if legacy else candidate_set.get("representation")
    required = base if legacy else base | {"representation", "candidate_count", "enumeration_limit"}
    if representation == "ordered_selection_implicit_v1":
        required |= {"selection_space"}
    if (version not in {LEGACY_ADAPTER_VERSION, PREVIOUS_ADAPTER_VERSION, ADAPTER_VERSION} or set(candidate_set) != required
            or representation not in {"explicit_v1", "ordered_selection_implicit_v1"}):
        raise DataContractError("Unsupported or incomplete candidate-set schema")
    if candidate_set.get("complete") is not True or candidate_set.get("reason") is not None:
        raise DataContractError("Candidate set is not a complete legal action-space description")
    if candidate_set.get("source") != "engine_current_state":
        raise DataContractError("Unknown candidate-set source")
    digest = candidate_set.get("state_hash")
    if not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise DataContractError("Candidate set requires a full state SHA-256")
    rows = candidate_set.get("candidates")
    if not isinstance(rows, list):
        raise DataContractError("candidates must be an explicit list, empty for an implicit space")
    limit = LEGACY_ENUMERATION_LIMIT if legacy else _integer(candidate_set["enumeration_limit"], "enumeration_limit", 1)
    count = len(rows) if legacy else _integer(candidate_set["candidate_count"], "candidate_count")
    if representation == "ordered_selection_implicit_v1":
        space = validate_space(candidate_set["selection_space"])
        if (candidate_set["decision"] != "card_select" or rows or count <= limit
                or count != space["candidate_count"] or digest != space["state_hash"]):
            raise DataContractError("Implicit selection descriptor/count/threshold/state identity is inconsistent")
    else:
        if count != len(rows) or count > limit:
            raise DataContractError("Explicit candidate count or threshold is inconsistent")
        seen = set()
        for row in rows:
            if not isinstance(row, Mapping) or set(row) != {"candidate_id", "request", "is_skip", "source", "evidence"}:
                raise DataContractError("Malformed explicit candidate")
            request = normalize_request(row["request"])
            skip = _boolean(row["is_skip"], "candidate.is_skip")
            if _json(row) != _json(_candidate(request, row["evidence"], skip=skip)):
                raise DataContractError("Explicit candidate identity/source is inconsistent")
            if row["candidate_id"] in seen:
                raise DataContractError("Duplicate candidate identity")
            seen.add(row["candidate_id"])
        if not rows and candidate_set["decision"] != "game_over":
            raise DataContractError("Nonterminal explicit action space has no candidates")
    return _copy(candidate_set)


def _materialize_checked(candidate_set, request):
    request = normalize_request(request)
    if candidate_set.get("representation", "explicit_v1") == "ordered_selection_implicit_v1":
        space = candidate_set["selection_space"]
        indices = indices_from_request(space, request)
        cards = {card["index"]: card for card in space["cards"]}
        return _candidate(request, {"indices": indices, "cards": [cards[index] for index in indices],
                                   "min_select": space["min_select"], "max_select": space["max_select"]}, skip=not indices)
    matches = [row for row in candidate_set["candidates"] if _json(row["request"]) == _json(request)]
    if len(matches) != 1:
        raise DataContractError("Chosen action is not in the complete current candidate set")
    return _copy(matches[0])


def materialize_candidate(candidate_set: Mapping[str, Any], request: Mapping[str, Any]) -> dict[str, Any]:
    """Materialize one legal complete action; it remains an observed candidate.

    An implicit space's proposed subset is never used to establish legality.
    Validation always uses the complete descriptor and actual current indices.
    """
    return _materialize_checked(validate_candidate_set(candidate_set), request)


def validate_request(candidate_set: Mapping[str, Any], request: Mapping[str, Any]) -> bool:
    """Return action legality; malformed candidate-set schemas always raise."""
    candidate_set = validate_candidate_set(candidate_set)
    try:
        _materialize_checked(candidate_set, request)
        return True
    except DataContractError:
        return False


def _bind_candidate_set(state, supplied):
    """Reconstruct exactly using the recorded representation threshold."""
    supplied = validate_candidate_set(supplied)
    legacy = supplied["adapter_version"] == LEGACY_ADAPTER_VERSION
    limit = LEGACY_ENUMERATION_LIMIT if legacy else supplied["enumeration_limit"]
    actual = enumerate_candidates(state, max_candidates=limit,
                                  _recorded_version=supplied["adapter_version"])
    if legacy:
        if actual.get("representation") != "explicit_v1":
            raise DataContractError("Legacy explicit schema cannot describe an implicit selection space")
        actual = {key: value for key, value in actual.items()
                  if key not in {"representation", "candidate_count", "enumeration_limit"}}
        actual["adapter_version"] = LEGACY_ADAPTER_VERSION
    if _json(supplied) != _json(actual):
        raise DataContractError("Candidate set is stale, incomplete or does not match the recorded state")
    return supplied


def _provenance(value: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise DataContractError("Explicit policy provenance is required")
    for field in ("origin", "kind", "id", "version", "llm_involved"):
        if field not in value:
            raise DataContractError(f"Missing provenance.{field}")
    if value["origin"] not in ORIGINS or value["kind"] not in POLICY_KINDS:
        raise DataContractError("Unknown provenance origin or policy kind")
    _boolean(value["llm_involved"], "provenance.llm_involved")
    if value["kind"] == "llm" and not value["llm_involved"]:
        raise DataContractError("LLM policy cannot claim llm_involved=false")
    if not value["id"] or not value["version"]:
        raise DataContractError("Policy id and version must be nonempty")
    return _copy(value)


def _metadata(value: Mapping[str, Any]) -> dict[str, Any]:
    required = {"run_id", "seed", "character", "ascension", "mode", "versions",
                "solver_requested_config", "provenance"}
    if missing := required - set(value):
        raise DataContractError(f"Missing run metadata: {sorted(missing)}")
    for field in ("run_id", "seed", "character", "mode"):
        if not isinstance(value[field], str) or not value[field]:
            raise DataContractError(f"metadata.{field} must be a nonempty string")
    _integer(value["ascension"], "ascension")
    if not isinstance(value["versions"], Mapping) or {"engine", "solver", "bridge"} - set(value["versions"]):
        raise DataContractError("versions requires engine, solver and bridge (null if unknown)")
    if not isinstance(value["solver_requested_config"], Mapping):
        raise DataContractError("solver_requested_config must be explicit")
    result = _copy(value)
    result["provenance"] = _provenance(value["provenance"])
    result["seed_group"] = "seed:" + hashlib.sha256(value["seed"].encode()).hexdigest()
    return result


class DecisionJournal:
    """Single-writer, non-resumable audit log; snapshots are copied at each call."""

    def __init__(self, output_dir: str | Path, metadata: Mapping[str, Any]):
        self.metadata = _metadata(metadata)
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        self.path = output_dir / "decisions.jsonl"
        self._log = self.path.open("x", encoding="utf-8")
        self._pending: dict[str, Any] | None = None
        self._sequence = 0
        self._finalized = False
        self._append("run_start", {"metadata": self.metadata})

    def _append(self, kind: str, value: Mapping[str, Any]) -> None:
        self._log.write(_json({"schema_version": SCHEMA_VERSION, "record_type": kind,
                              "recorded_at_unix": time.time(), **value}) + "\n")
        self._log.flush()
        os.fsync(self._log.fileno())

    def begin(self, state: Mapping[str, Any], chosen: Mapping[str, Any], *,
              policy: Mapping[str, Any], candidates: Mapping[str, Any] | None = None) -> str:
        if self._finalized or self._pending:
            raise DataContractError("Cannot begin after finalization or before previous completion")
        enumerated = enumerate_candidates(state) if candidates is None else _bind_candidate_set(state, candidates)
        if not enumerated["complete"]:
            raise DataContractError(enumerated["reason"])
        chosen_candidate = materialize_candidate(enumerated, chosen)
        token = f"{self.metadata['run_id']}:{self._sequence:06d}"
        record = {"decision_id": token, "sequence": self._sequence,
                  "run_id": self.metadata["run_id"], "seed": self.metadata["seed"],
                  "seed_group": self.metadata["seed_group"], "state": _copy(state),
                  "candidate_set": enumerated, "chosen": chosen_candidate,
                  "chosen_is_optimal": None, "label_semantics": "observed_policy_action",
                  "policy_provenance": _provenance(policy)}
        self._append("decision_started", record)
        self._pending = record
        self._sequence += 1
        return token

    def complete(self, token: str, next_state: Mapping[str, Any], *,
                 solver_calls: Sequence[Mapping[str, Any]] = (),
                 environment_error: Any = None, execution: Mapping[str, Any] | None = None) -> dict[str, Any]:
        if not self._pending or self._pending["decision_id"] != token:
            raise DataContractError("No matching pending decision")
        if next_state.get("type") == "error" and environment_error is None:
            environment_error = {"kind": "engine_error", "response": _copy(next_state)}
        record = {**self._pending, "next_state": _copy(next_state),
                  "next_state_hash": state_hash(next_state), "solver_calls": _copy(list(solver_calls)),
                  "execution": _copy(execution or {}), "environment_error": _copy(environment_error)}
        self._append("decision_completed", record)
        self._pending = None
        return _copy(record)

    def finalize(self, final_state: Mapping[str, Any], *, termination: str,
                 environment_error: Any = None,
                 terminal_evidence: Mapping[str, Any] | None = None) -> dict[str, Any]:
        if self._finalized:
            raise DataContractError("Run already finalized")
        if termination not in {"engine_terminal", "stopped", "environment_error", "timeout"}:
            raise DataContractError("Unknown termination reason")
        terminal = final_state.get("decision") == "game_over" and type(final_state.get("victory")) is bool
        if termination == "engine_terminal" and not terminal:
            raise DataContractError("Only a real game_over state can supply a natural result")
        if final_state.get("type") == "error" and environment_error is None:
            environment_error = {"kind": "engine_error", "response": _copy(final_state)}
        if termination in {"environment_error", "timeout"} and environment_error is None:
            environment_error = {"kind": termination}
        evidence = _copy(terminal_evidence or {})
        outcome = "environment_error" if environment_error is not None else (
            "victory" if final_state["victory"] else "defeat") if termination == "engine_terminal" else termination
        record = {"run_id": self.metadata["run_id"], "termination": termination,
                  "outcome": outcome, "engine_victory": final_state.get("victory") if terminal else None,
                  "final_state": _copy(final_state), "environment_error": _copy(environment_error),
                  "terminal_evidence": evidence,
                  "unresolved_decision_id": self._pending["decision_id"] if self._pending else None}
        self._append("run_finished", record)
        self._finalized = True
        self.close()
        return _copy(record)

    def close(self) -> None:
        self._log.close()

    def __enter__(self) -> "DecisionJournal":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


def _is_natural_policy(provenance: Mapping[str, Any]) -> bool:
    return (provenance.get("origin") == "natural" and provenance.get("kind") in NON_LLM_KINDS
            and provenance.get("llm_involved") is False)


def _solver_verified(call: Mapping[str, Any]) -> bool:
    """Actual solver response evidence only; a requested profile is insufficient."""
    from solver_evidence import verified_solver_call
    return verified_solver_call(call)


def read_decisions(path: str | Path) -> list[dict[str, Any]]:
    """Join a journal's outcome and run-wide contamination onto every transition.

    No outcome means incomplete, never defeat. Even one LLM/human/recovery
    decision excludes the entire rollout, including decisions made before it.
    Natural outcome is a return under the recorded policy, not action optimality.
    """
    rows = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows or rows[0].get("record_type") != "run_start":
        raise DataContractError("Journal must begin with run_start")
    if any(r.get("schema_version") != SCHEMA_VERSION for r in rows):
        raise DataContractError("Unsupported journal schema")
    if sum(r.get("record_type") == "run_start" for r in rows) != 1:
        raise DataContractError("Multiple runs in one journal")
    metadata = _metadata(rows[0]["metadata"])
    pending = None
    finished = False
    decision_ids = set()
    for row in rows[1:]:
        if finished:
            raise DataContractError("Journal contains records after terminal outcome")
        kind = row.get("record_type")
        if kind in {"decision_started", "decision_completed"}:
            if (row.get("run_id") != metadata["run_id"] or row.get("seed") != metadata["seed"]
                    or row.get("seed_group") != metadata["seed_group"]):
                raise DataContractError("Decision identity does not match its run")
        if kind == "decision_started":
            if pending is not None or row.get("decision_id") in decision_ids:
                raise DataContractError("Overlapping or duplicate decision intents")
            decision_ids.add(row["decision_id"])
            pending = row
        elif kind == "decision_completed":
            if pending is None or pending["decision_id"] != row.get("decision_id"):
                raise DataContractError("Completed decision has no matching ordered intent")
            for key in ("state", "candidate_set", "chosen", "chosen_is_optimal", "policy_provenance"):
                if row.get(key) != pending.get(key):
                    raise DataContractError("Decision completion modified its original intent")
            if row.get("next_state_hash") != state_hash(row["next_state"]):
                raise DataContractError("Next-state integrity check failed")
            pending = None
        elif kind == "run_finished":
            if row.get("run_id") != metadata["run_id"]:
                raise DataContractError("Terminal outcome belongs to a different run")
            if row.get("unresolved_decision_id") != (pending["decision_id"] if pending else None):
                raise DataContractError("Terminal unresolved-decision evidence is inconsistent")
            terminal_state = row.get("final_state", {})
            if row.get("outcome") in {"victory", "defeat"}:
                victory = row["outcome"] == "victory"
                if (row.get("termination") != "engine_terminal" or terminal_state.get("decision") != "game_over"
                        or terminal_state.get("victory") is not victory or row.get("engine_victory") is not victory
                        or row.get("environment_error") is not None):
                    raise DataContractError("Claimed natural result lacks consistent engine-terminal evidence")
            finished = True
        else:
            raise DataContractError(f"Unknown journal record type: {kind!r}")
    starts = [r for r in rows if r.get("record_type") == "decision_started"]
    records = [r for r in rows if r.get("record_type") == "decision_completed"]
    finishes = [r for r in rows if r.get("record_type") == "run_finished"]
    if len(finishes) > 1:
        raise DataContractError("Multiple terminal outcomes")
    final = finishes[0] if finishes else None
    reasons = []
    if not _is_natural_policy(metadata["provenance"]) or any(not _is_natural_policy(r["policy_provenance"]) for r in starts):
        reasons.append("run_contains_non_natural_or_non_training_policy")
    if any(not metadata["versions"][key] for key in ("engine", "solver", "bridge")):
        reasons.append("missing_version_evidence")
    if not final or final["outcome"] not in {"victory", "defeat"}:
        reasons.append("no_clean_terminal_outcome")
    if pending is not None:
        reasons.append("unresolved_decision")
    if any(r.get("environment_error") is not None for r in records) or (final and final.get("environment_error") is not None):
        reasons.append("run_environment_error")
    observed_states = [s for r in records for s in (r["state"], r["next_state"])]
    if final:
        observed_states.append(final["final_state"])
    if any(s.get("context", {}).get("integrity_recovery_used") is True for s in observed_states):
        reasons.append("engine_recovery_contaminated_trajectory")
    calls = [call for r in records for call in r.get("solver_calls", [])]
    no_combat_path = bool(observed_states) and all(
        s.get("context", {}).get("combat_in_progress") is False
        and s.get("context", {}).get("room_type") not in {"Monster", "Elite", "Boss"}
        and s.get("decision") != "combat_play" for s in observed_states)
    if (not calls and not no_combat_path) or any(not _solver_verified(call) for call in calls):
        reasons.append("missing_or_unverified_actual_solver_configuration")
    if final and final["outcome"] == "victory" and metadata["ascension"] >= 10:
        evidence = final.get("terminal_evidence", {})
        if (evidence.get("second_boss_entered") is not True
                or evidence.get("second_boss_victory") is not True
                or not evidence.get("trace_reference")):
            reasons.append("a10_second_boss_victory_unverified")
    output = []
    for record in records:
        # Verify the full set again on read; accidental edits cannot turn a
        # truncated set or a stale chosen action into accepted training data.
        checked = _bind_candidate_set(record["state"], record["candidate_set"])
        actual_chosen = materialize_candidate(checked, record["chosen"]["request"])
        if _json(record["chosen"]) != _json(actual_chosen) or record.get("chosen_is_optimal") is not None:
            raise DataContractError("Invalid observed-action semantics")
        output.append({**record, "metadata": _copy(metadata), "run_outcome": _copy(final),
                       "training_eligible": not reasons, "training_exclusion_reasons": list(reasons),
                       "return_semantics": "observed_run_outcome_under_recorded_followup_policy"})
    return output


def split_by_seed(records: Sequence[Mapping[str, Any]], *, validation_fraction: float = 0.2,
                  test_fraction: float = 0.1, salt: str = "sts2-macro-split-v1") -> dict[str, list[dict[str, Any]]]:
    """Stable grouped split, connecting same run, same seed and branch lineage.

    The same seed is kept together across versions, strategies and difficulties.
    ``metadata.lineage_root_seed`` additionally links constructed branch seeds to
    their original run. Do not tune on the held-out groups. Counts are hash-based
    and therefore need not equal the requested fractions in a small dataset.
    """
    if (not math.isfinite(validation_fraction) or not math.isfinite(test_fraction)
            or validation_fraction < 0 or test_fraction < 0 or validation_fraction + test_fraction >= 1):
        raise DataContractError("Split fractions must be finite, nonnegative and sum to less than 1")
    parent: dict[str, str] = {}

    def find(key: str) -> str:
        parent.setdefault(key, key)
        if parent[key] != key:
            parent[key] = find(parent[key])
        return parent[key]

    def union(a: str, b: str) -> None:
        a, b = find(a), find(b)
        if a != b:
            parent[max(a, b)] = min(a, b)

    keys = []
    declared_roots = set()
    for record in records:
        metadata = record.get("metadata", record)
        seed, run_id = metadata.get("seed"), metadata.get("run_id")
        if not isinstance(seed, str) or not seed or not isinstance(run_id, str) or not run_id:
            raise DataContractError("Every split record needs seed and run_id")
        key = "seed:" + seed
        union(key, "run:" + run_id)
        if root_seed := metadata.get("lineage_root_seed"):
            if not isinstance(root_seed, str):
                raise DataContractError("lineage_root_seed must be a string")
            union(key, "seed:" + root_seed)
            declared_roots.add("seed:" + root_seed)
        keys.append(key)
    # Hash the canonical seed, not the run id: adding another run of the same
    # seed cannot change the assignment just because its name sorts earlier.
    seeds_by_root: dict[str, list[str]] = {}
    for key in parent:
        if key.startswith("seed:"):
            seeds_by_root.setdefault(find(key), []).append(key)
    result: dict[str, list[dict[str, Any]]] = {"train": [], "validation": [], "test": []}
    for record, key in zip(records, keys):
        seed_keys = seeds_by_root[find(key)]
        group = min(declared_roots.intersection(seed_keys) or seed_keys)
        draw = int(hashlib.sha256((salt + "\0" + group).encode()).hexdigest(), 16) / 2**256
        split = "test" if draw < test_fraction else "validation" if draw < test_fraction + validation_fraction else "train"
        result[split].append(_copy(record))
    return result
