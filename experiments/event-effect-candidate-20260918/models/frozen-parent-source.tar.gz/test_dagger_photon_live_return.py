"""Original tasks at complete historical and declared synthetic hand boundaries."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers


class DaggerPhotonLiveReturnTests(unittest.TestCase):
    worker=helpers.LiquidMemoriesTests.worker
    save=helpers.LiquidMemoriesTests.save

    def test_original_full_E_plan_and_joint_corruption_rejection(self):
        root=Path('C:/Users/zhangchr/Documents/code/sts2-solver-bridge')
        batch=root/'outputs/defect-contextual-cem-20260914a'
        name=batch.name+'-g02-c03-s10'
        source=root/'outputs'/name
        receipt=read_json(batch/'generation-02'/(name+'-audit.json'))
        self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
        rows=read_lines(source/'trace.jsonl')
        gate=max(i for i,r in enumerate(rows) if r['request']['cmd']=='solve')
        original=copy.deepcopy(rows[gate])
        label='dagger-photon-full-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label)
        executor,matched,passed=None,0,False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve','combat_meta','choice_meta'}:continue
                before=send(row['request'])
                self.assertEqual(checked_public(before),checked_public(row['response']));matched+=1
            executor=CombatExecutor(send,read_json(source/'manifest.json')['solver_requested_config'])
            real_solve,supplied=executor.solve,False
            def recorded_then_actual(state,budget,used=0,setup=False):
                nonlocal supplied
                if supplied:return real_solve(state,budget,used,setup)
                self.assertEqual(state,before)
                self.assertEqual(setup,original['request'].get('include_turn_setup',False))
                supplied=True;call=copy.deepcopy(original)
                traces.append(copy.deepcopy(call));executor.solve_calls.append(call)
                return call['response']
            executor.solve=recorded_then_actual
            final=executor.advance(before)
            self.assertEqual(executor.solve_calls[0]['response'],original['response'])
            proofs=[p for p in executor.solve_calls[0].get('replay',[]) if p.get('kind')=='original_choice_return_completed'
                and p.get('actual_choice_audit',{}).get('parent',{}).get('card_id')=='DAGGER_THROW']
            self.assertEqual(len(proofs),1)
            proof=proofs[0]
            self.assertEqual(proof['selected_cards'][0]['CardId'],'COLD_SNAP')
            self.assertFalse(proof['remaining_battle_plan_stopped']);self.assertFalse(proof['selection_request_sent'])
            self.assertEqual(proof['reason'],'engine_automatic_mandatory_selection')
            self.assertIn(final['decision'],('card_reward','map_select','game_over'))
            audit=validate_replay_evidence(executor.solve_calls,traces)
            self.assertTrue(audit['verified'])
            binding=next(b for b in audit['bindings'] if b['call_index']==0
                and traces[b['parent_trace_index']]['response'].get('choice_audit',{}).get('parent',{}).get('card_id')=='DAGGER_THROW')
            query=binding['query_trace_index'];parent=binding['parent_trace_index']
            self.assertTrue(traces[parent]['response']['context']['combat_in_progress'])
            changes=[('original_task_completed_successfully',False),('source_is_actual_parent_object',False),
                ('returned_objects_match_original_source',False),('filter_reexecuted_by_observer',True),
                ('raw_source_count_at_entry',2),('raw_source_count_at_return',2),('selector_invocations_after',-1),
                ('selector_pending_after',True),('combat_active_at_entry',False),('combat_active_at_return',False),
                ('is_over_or_ending_at_entry',True),('is_over_or_ending_at_return',True),('filter_is_null',False),
                ('original_returned_collection','CardModel[]'),('min_select',0),('max_select',2)]
            for field,value in changes:
                bc,bt=copy.deepcopy(executor.solve_calls),copy.deepcopy(traces)
                bp=next(p for p in bc[0]['replay'] if p==proof)
                for a in (bp['actual_choice_audit'],bt[parent]['response']['choice_audit'],bt[query]['response']['completion_audit']):
                    a['original_returns'][0][field]=value
                with self.subTest(field=field),self.assertRaises(ValueError):validate_replay_evidence(bc,bt)
            for field in ('CardId','StateKey','UpgradeLevel','SourceOccurrence','OptionOccurrence'):
                bc,bt=copy.deepcopy(executor.solve_calls),copy.deepcopy(traces)
                bp=next(p for p in bc[0]['replay'] if p==proof)
                for a in (bp['actual_choice_audit'],bt[parent]['response']['choice_audit'],bt[query]['response']['completion_audit']):
                    card=a['original_returns'][0]['returned_cards'][0]
                    card[field]=card[field]+1 if type(card[field]) is int else 'UNRELATED'
                with self.subTest(token=field),self.assertRaises(ValueError):validate_replay_evidence(bc,bt)
            bc=copy.deepcopy(executor.solve_calls);bc[0]['replay'].remove(proof)
            with self.assertRaises(ValueError):validate_replay_evidence(bc,traces)
            self.assertTrue(unchanged(receipt['actual_source_evidence']));passed=True
        finally:
            self.save(label,traces,passed=passed,origin='recorded_full_solver_envelope_diagnostic',
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                original_source=receipt['actual_source_evidence'],public_prefix_responses_verified=matched,
                solver_calls=executor.solve_calls if executor else [],hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def boundary(self,card,count):
        label='dagger-photon-boundary-'+card.lower()+'-'+str(count)+'-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);passed=False;action=None;proofs=[]
        try:
            send(cmd='start_run',character='Defect',ascension=10,seed='hand-return-boundary')
            send(cmd='set_player',hp=1000,max_hp=1000,relics=[],potions=[],deck=[card]+['DEFEND_DEFECT']*count)
            before=send(cmd='enter_room',type='combat',encounter='FOGMOG_NORMAL')
            meta=send(cmd='combat_meta')
            actor=next(c for c in before['hand'] if c['id']=='CARD.'+card)
            key=next(c['key'] for c in meta['hand'] if c['index']==actor['index'])
            # Explicit synthetic unit plan, defined from pre-action cards. This
            # is not a solver output and is never included in natural samples.
            cards=[]
            if count:
                index=next(c['index'] for c in before['hand'] if c['id']=='CARD.DEFEND_DEFECT')
                token_key=next(c['key'] for c in meta['hand'] if c['index']==index)
                cards=[{'CardId':'DEFEND_DEFECT','UpgradeLevel':0,'StateKey':token_key,
                    'SourceOccurrence':0,'OptionOccurrence':0}]
            plan={'Effect':'Discard' if card=='DAGGER_THROW' else 'MoveToDrawTop',
                'SourcePile':'Hand','SourceId':'','ContextId':'','Timing':'Action','Cards':cards}
            action={'Kind':'PlayCard','CardId':card,'CardStateKey':key,'CardUpgradeLevel':0,
                'CardStateOccurrence':0,'Turn':before['player_turn'],'ReplayCount':0,
                'TargetIndex':0,'TargetCombatId':meta['enemies'][0]['combat_id'],'Choice':plan}
            request={'cmd':'action','action':'play_card','args':{'card_index':actor['index'],'target_index':0}}
            after=send(request)
            event=after['choice_audit']['original_returns'][0]
            self.assertEqual(event['raw_source_count_at_entry'],count)
            self.assertFalse(event['is_over_or_ending_at_entry'])
            self.assertTrue(event['source_is_actual_parent_object'])
            executor=CombatExecutor(send);executor.last_action_request=request
            executor.solve_calls=[{'test_only_synthetic_plan':True}]
            if count<2:
                self.assertEqual(after['decision'],'combat_play')
                self.assertTrue(event['original_task_completed_successfully'])
                self.assertEqual(event['returned_cards'],cards)
                self.assertEqual(event['original_returned_collection'],'List<CardModel>')
                self.assertEqual(event['selector_invocations_before'],event['selector_invocations_after'])
                self.assertTrue(executor.resolve_original_automatic_choice(before,after,action))
                proofs=executor.solve_calls[0]['replay']
                self.assertEqual(proofs[0]['selected_cards'],cards)
                self.assertFalse(proofs[0]['remaining_battle_plan_stopped'])
                self.assertFalse(proofs[0]['selection_request_sent'])
                self.assertEqual(proofs[0]['reason'],'engine_empty_source' if count==0 else 'engine_automatic_mandatory_selection')
            else:
                self.assertEqual(after['decision'],'card_select')
                self.assertFalse(event['original_task_completed_successfully']);self.assertFalse(event['verified'])
                self.assertTrue(event['selector_pending_after'])
                self.assertFalse(executor.resolve_original_automatic_choice(before,after,action))
                after=send(cmd='action',action='select_cards',args={'indices':'0'})
                self.assertEqual(after['decision'],'combat_play')
            self.assertTrue(after['context']['combat_in_progress'])
            self.assertEqual(after['player_turn'],before['player_turn'])
            passed=True
        finally:
            self.save(label,traces,passed=passed,origin='synthetic_original_hand_boundary',
                constructed_plan_is_not_solver_output=True,synthetic_plan=action,direct_unit_proofs=proofs,
                hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_empty_and_singleton_original_returns(self):
        for card in ('DAGGER_THROW','PHOTON_CUT'):
            for count in (0,1):
                with self.subTest(card=card,count=count):self.boundary(card,count)

    def test_multiple_candidates_keep_real_pending_selection(self):
        for card in ('DAGGER_THROW','PHOTON_CUT'):
            with self.subTest(card=card):self.boundary(card,2)


if __name__=='__main__':unittest.main()
