"""Independent synthetic artifact/one-shot checks; no game or actual-data fit.

The upstream game audit is mocked only where necessary to isolate evaluator
entry checks. This does not claim fabricated game evidence passes that audit.
"""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import train_prefix_ranker as trainer
from decision_data import split_by_seed
from initial_policy import InitialPolicy
from interaction_features import extend_scoring_packet
from run_metadata import file_evidence
import test_train_prefix_ranker as paired_tests


class PrefixArtifactTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="prefix-artifact-synthetic-")
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.gate, self.audit = paired_tests.PrefixTrainingTests().fixture()
        self.audit["complete_candidate_groups"] = 1
        for index in range(100):
            seed = f"synthetic-prefix-artifact-test-{index}"
            if split_by_seed([{"seed": seed, "run_id": self.gate["gate_id"]}])["test"]:
                self.gate["seed"] = seed
                break
        else:
            self.fail("Synthetic held-out seed construction failed")
        self.protocol = {"planned_learner": copy.deepcopy(trainer.LEARNER),
                         "gates": [self.gate], "frozen_sources": [], "historical_sources": []}
        self.protocol_path = self.directory / "protocol.json"
        self.write(self.protocol_path, self.protocol)
        policy = InitialPolicy()
        transform = extend_scoring_packet(self.gate["state"], policy.score_requests(self.gate["state"],
            [row["request"] for row in self.gate["candidates"]]))["interaction_feature_source"]
        root = Path(trainer.__file__).resolve().parent
        names = list(trainer.FEATURE_NAMES)
        # Numerical zero model constructed by hand. No fitting is performed.
        self.model = {"feature_names": names, "means": [0.] * len(names), "scales": [1.] * len(names),
            "weights": [0.] * (len(names) + 1), "feature_min": [-1.] * len(names), "feature_max": [1.] * len(names),
            "format": trainer.VERSION, "planned_learner": copy.deepcopy(trainer.LEARNER),
            "target_semantics": trainer.LEARNER["target"], "fit_count": 1,
            "feature_sources": {name: file_evidence(root / name) for name in trainer.FEATURE_SOURCES},
            "mechanism_facts": copy.deepcopy(policy.mechanism_source), "prior_source": copy.deepcopy(policy.prior.source),
            "feature_transform": transform, "source_protocol": file_evidence(self.protocol_path),
            "runtime_and_collection_sources": [],
            "split_seeds": {"train": [], "validation": [], "test": [self.gate["seed"]]}}
        self.model.update({key: False for key in ("calibrated_probability", "A10_victory_model",
            "automatic_deployment", "natural_run_training", "exact_state_or_rng_clone", "test_used_for_fit_or_tuning")})
        self.model_path = self.directory / "synthetic-model.json"

    @staticmethod
    def write(path, value):
        Path(path).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding="utf-8")

    def register_synthetic_model(self):
        audit_path = self.directory / "TRAINING_AUDIT.json"
        self.write(audit_path, self.audit)
        self.model["training_audit"] = file_evidence(audit_path)
        self.write(self.model_path, self.model)
        trainer.exclusive_receipt(self.directory / "training-fit-receipt.json", {
            "schema_version": trainer.VERSION + ":fit-receipt-v1", "status": "fit_completed",
            "source_protocol": file_evidence(self.protocol_path), "training_audit": file_evidence(audit_path),
            "model_output": str(self.model_path), "planned_learner": copy.deepcopy(trainer.LEARNER),
            "model": file_evidence(self.model_path)})

    def test_complete_current_model_identity_is_accepted(self):
        self.assertIs(trainer.validate_artifact(self.model, self.protocol, self.protocol_path), self.model)

    def test_empty_missing_or_redirected_feature_sources_are_rejected(self):
        mutations = [lambda m: m.update(feature_sources={}),
                     lambda m: m["feature_sources"].pop("interaction_features.py"),
                     lambda m: m["feature_sources"].update(unrecognized={}),
                     lambda m: m["feature_sources"]["interaction_features.py"].update(path="redirected.py")]
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                model = copy.deepcopy(self.model)
                mutate(model)
                with self.assertRaises(ValueError):
                    trainer.validate_artifact(model, self.protocol, self.protocol_path)

    def test_prior_facts_transform_and_collection_drift_are_rejected(self):
        for field in ("prior_source", "mechanism_facts", "feature_transform", "source_protocol",
                      "runtime_and_collection_sources"):
            with self.subTest(field=field):
                model = copy.deepcopy(self.model)
                model[field] = {"forged": True}
                with self.assertRaises(ValueError):
                    trainer.validate_artifact(model, self.protocol, self.protocol_path)

    def test_legacy_format_wrong_feature_order_and_nonpaired_offset_are_rejected(self):
        for mutate in (lambda m: m.update(format="defect-act1-interaction-survival-ridge-v1"),
                       lambda m: m["feature_names"].reverse(),
                       lambda m: m["means"].__setitem__(0, 1.),
                       lambda m: m["weights"].__setitem__(0, 7.),
                       lambda m: m.update(natural_run_training=True),
                       lambda m: m.update(test_used_for_fit_or_tuning=True)):
            with self.subTest(mutate=mutate):
                model = copy.deepcopy(self.model)
                mutate(model)
                with self.assertRaises(ValueError):
                    trainer.validate_artifact(model, self.protocol, self.protocol_path)

    def test_exclusive_receipt_never_overwrites_first_identity(self):
        path = self.directory / "exclusive.json"
        trainer.exclusive_receipt(path, {"first": True})
        before = file_evidence(path)
        with self.assertRaises(FileExistsError):
            trainer.exclusive_receipt(path, {"replaced": True})
        self.assertEqual(file_evidence(path), before)

    def test_changing_output_cannot_bypass_existing_fit_receipt(self):
        trainer.exclusive_receipt(self.directory / "training-fit-receipt.json", {"status": "fit_started"})
        with patch.object(trainer, "fit") as fit, patch.object(trainer, "audit_protocol") as audit:
            for name in ("new-output-one.json", "new-output-two.json"):
                with self.assertRaisesRegex(ValueError, "exclusive training fit"):
                    trainer.train(self.protocol_path, self.directory / name)
            fit.assert_not_called()
            audit.assert_not_called()

    def test_one_test_evaluation_only_even_with_new_output(self):
        self.register_synthetic_model()
        with patch.object(trainer, "audit_protocol", return_value=self.audit) as audit, patch.object(trainer, "fit") as fit:
            report = trainer.compare_frozen_test(self.protocol_path, self.model_path, self.directory / "first-test.json")
            self.assertEqual(report["complete_test_root_seeds"], 1)
            before = file_evidence(self.directory / "test-evaluation-receipt.json")
            with self.assertRaisesRegex(ValueError, "exclusive held-out assessment"):
                trainer.compare_frozen_test(self.protocol_path, self.model_path, self.directory / "second-test.json")
            self.assertEqual(file_evidence(self.directory / "test-evaluation-receipt.json"), before)
            self.assertFalse((self.directory / "second-test.json").exists())
            audit.assert_called_once()
            fit.assert_not_called()

    def test_unregistered_or_modified_model_is_rejected_before_test_labels(self):
        self.register_synthetic_model()
        self.model["weights"][1] = 1.
        self.write(self.model_path, self.model)
        with patch.object(trainer, "audit_protocol") as audit:
            with self.assertRaisesRegex(ValueError, "not registered"):
                trainer.compare_frozen_test(self.protocol_path, self.model_path, self.directory / "test.json")
            audit.assert_not_called()

    def test_changed_collection_audit_is_rejected_before_candidate_evaluation(self):
        self.register_synthetic_model()
        changed = copy.deepcopy(self.audit)
        changed["arms"][0]["observed_label"]["hp"] += 1
        with patch.object(trainer, "audit_protocol", return_value=changed), patch.object(trainer, "gate_observations") as observe:
            with self.assertRaisesRegex(ValueError, "audit changed"):
                trainer.compare_frozen_test(self.protocol_path, self.model_path, self.directory / "test.json")
            observe.assert_not_called()

    def test_model_drift_during_assessment_leaves_failed_receipt_and_no_report(self):
        self.register_synthetic_model()
        original = trainer.gate_observations

        def observed_with_drift(*args, **kwargs):
            result = original(*args, **kwargs)
            self.model["weights"][1] = 1.
            self.write(self.model_path, self.model)
            return result

        with patch.object(trainer, "audit_protocol", return_value=self.audit), \
             patch.object(trainer, "gate_observations", side_effect=observed_with_drift):
            with self.assertRaisesRegex(ValueError, "Input drift"):
                trainer.compare_frozen_test(self.protocol_path, self.model_path, self.directory / "test.json")
        self.assertFalse((self.directory / "test.json").exists())
        receipt = trainer.read_json(self.directory / "test-evaluation-receipt.json")
        self.assertEqual(receipt["status"], "assessment_started")
        with self.assertRaisesRegex(ValueError, "exclusive held-out assessment"):
            trainer.compare_frozen_test(self.protocol_path, self.model_path, self.directory / "replacement-test.json")


if __name__ == "__main__":
    unittest.main()
