import json
import unittest
import uuid
from probe import Bridge, ROOT, replay_basic


class SolverBridgeTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.b = Bridge(self.label)
        self.b.send(cmd="start_run", character="Defect", ascension=10, seed=self._testMethodName)

    def tearDown(self):
        (ROOT / "outputs" / f"{self.label}.json").write_text(
            json.dumps(self.b.rows, ensure_ascii=False, indent=2), encoding="utf-8")
        self.b.close()

    def test_starter_route_matches_engine(self):
        state = self.b.send(cmd="enter_room", type="combat")
        result = self.b.send(cmd="solve", budget_ms=1500)
        self.assertEqual(result["type"], "solver_result", result)
        final = replay_basic(self.b, state, result)
        self.assertEqual(final["decision"], "card_reward")
        self.assertEqual(final["player"]["hp"], result["snapshot"]["PlayerHp"])
        self.assertTrue(result["snapshot"]["AllEnemiesDead"])

    def test_force_potion_and_growth_replay(self):
        self.b.send(cmd="set_player", deck=["GENETIC_ALGORITHM", "ZAP", "DUALCAST", "STRIKE_DEFECT", "STRIKE_DEFECT"], potions=["FIRE_POTION"])
        state = self.b.send(cmd="enter_room", type="combat")
        result = self.b.send(cmd="solve", budget_ms=1500, growth_budgets={"GeneticAlgorithm": 5},
                             potions=[{"slot": 0, "id": "FIRE_POTION", "directive": "Force"}])
        self.assertEqual(result["type"], "solver_result", result)
        self.assertTrue(any(a["Kind"] == "UsePotion" for a in result["actions"]))
        self.assertGreater(result["snapshot"]["GrowthRewards"]["GeneticAlgorithm"], 0)
        final = replay_basic(self.b, state, result)
        self.assertEqual(final["decision"], "card_reward")
        self.assertEqual(final["player"]["hp"], result["snapshot"]["PlayerHp"])
        # The engine can immediately grant a new potion as the battle reward.
        self.assertTrue(any(row.get("decision") == "combat_play" and not row["player"]["potions"] for row in self.b.rows))
        old = next(c for c in state["player"]["deck"] if c["id"].endswith("GENETIC_ALGORITHM"))
        new = next(c for c in final["player"]["deck"] if c["id"].endswith("GENETIC_ALGORITHM"))
        self.assertGreater(new["stats"]["block"], old["stats"]["block"])

    def test_disabled_potion_and_invalid_identity(self):
        self.b.send(cmd="set_player", potions=["FIRE_POTION"])
        self.b.send(cmd="enter_room", type="combat")
        bad = self.b.send(cmd="solve", potions=[{"slot": 0, "id": "WRONG", "directive": "Force"}])
        self.assertEqual(bad["type"], "error")
        result = self.b.send(cmd="solve", budget_ms=1000, potions=[{"slot": 0, "id": "FIRE_POTION", "directive": "Disabled"}])
        self.assertEqual(result["type"], "solver_result", result)
        self.assertFalse(any(a["Kind"] == "UsePotion" for a in result["actions"]))


if __name__ == "__main__":
    unittest.main()
