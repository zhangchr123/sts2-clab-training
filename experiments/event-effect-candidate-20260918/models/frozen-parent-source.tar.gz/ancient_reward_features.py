"""Public ancient-option identity and narrowly verified nominal reward effects.

The observed training vocabulary is not a complete engine catalog. Unknown keys
remain neutral; values are descriptive features, never prescribed preferences.
"""
import json
import math
from pathlib import Path
from decision_data import DataContractError
from initial_policy import card_mechanisms
from run_metadata import file_evidence

ROOT=Path(__file__).resolve().parent
CATALOG_PATH=ROOT/'ancient_reward_catalog.json'
CATALOG=json.loads(CATALOG_PATH.read_text(encoding='utf-8'))
CATALOG_EVIDENCE=file_evidence(CATALOG_PATH)
ENGINE_SHA='14b57dbaee1b58cb919625a662831054fd714b3b75b13b7449eac0e95b98a3e4'
if CATALOG['engine_sha256']!=ENGINE_SHA or len(CATALOG['keys'])!=len(set(CATALOG['keys'])):
    raise DataContractError('Invalid ancient identity vocabulary')
IDENTITIES={key:'ancient_option__'+key.replace('.pages.INITIAL.options.','__') for key in CATALOG['keys']}
SEMANTIC_PARAMETERS=(
    'ancient_nominal_added_cards','ancient_nominal_added_basic_cards','ancient_nominal_added_curses',
    'ancient_nominal_added_apparitions','ancient_nominal_added_wishes','ancient_nominal_added_relax',
    'ancient_nominal_added_apotheosis','ancient_nominal_added_brightest_flame',
    'ancient_nominal_max_hp_loss_fraction','ancient_extra_regular_draw_cards',
    'ancient_own_turn_extra_draw_block','ancient_draw_block_x_known_draw_tag_fraction',
    'ancient_apotheosis_x_unupgraded_fraction')
PARAMETERS=(*IDENTITIES.values(),*SEMANTIC_PARAMETERS)
CONTRACT=dict(version='observed-ancient-options-and-nominal-effects-v1',engine_sha256=ENGINE_SHA,
    catalog=CATALOG_EVIDENCE,identity_scope='99 observed option keys from two closed training generations',
    complete_engine_catalog=False,unknown_options='all_new_features_zero',
    scope='actual_legal_choose_option_at_floor_one_INITIAL_only',
    effect_counts_are_nominal=True,add_card_hooks_not_simulated=True,
    strategic_preferences_not_prescribed=True,draw_tags='limited_existing_initial_policy_identity_tags',
    whole_deck_context='current_public_deck_not_terminal_deck',outcome_labels_used=False)


def integer(variables,name,expected):
    if not isinstance(variables,dict) or type(variables.get(name)) is not int or variables[name]!=expected:
        raise DataContractError('Known ancient public variable differs: '+name)
    return expected


def features(state,row,candidate):
    if row['request']!=candidate['request']:
        raise DataContractError('Ancient feature row/candidate mismatch')
    values=dict.fromkeys(PARAMETERS,0.)
    if state.get('decision')!='event_choice' or row['request'].get('action')!='choose_option':return values
    item=candidate['evidence'];key=item.get('text_key')
    if key not in IDENTITIES:return values
    context=state.get('context',{})
    if context.get('floor')!=1 or context.get('act') not in (1,2,3) or context.get('combat_in_progress') is not False:
        raise DataContractError('Known ancient option outside its public initial-event scope')
    if file_evidence(CATALOG_PATH)!=CATALOG_EVIDENCE:
        raise DataContractError('Ancient identity vocabulary changed after loading')
    if item.get('is_locked') is not False:
        raise DataContractError('Ancient feature requires an actually selectable option')
    values[IDENTITIES[key]]=1.
    variables=item.get('vars',{})
    player=state.get('player',{});deck=player.get('deck')
    if not isinstance(deck,list) or not deck or player.get('deck_size')!=len(deck):
        raise DataContractError('Ancient context needs complete current public deck')
    if key=='VAKUU.pages.INITIAL.options.DISTINGUISHED_CAPE':
        curses=integer(variables,'Curses',2);cards=integer(variables,'Cards',3)
        values.update(ancient_nominal_added_cards=float(curses+cards),
            ancient_nominal_added_curses=float(curses),ancient_nominal_added_apparitions=float(cards))
    elif key=='VAKUU.pages.INITIAL.options.SERE_TALON':
        cards=integer(variables,'Wishes',3);loss=integer(variables,'HpLoss',9)
        maximum=player.get('max_hp')
        if type(maximum) not in (int,float) or not math.isfinite(maximum) or maximum<=0:
            raise DataContractError('Ancient max HP context invalid')
        values.update(ancient_nominal_added_cards=float(cards),ancient_nominal_added_wishes=float(cards),
            ancient_nominal_max_hp_loss_fraction=min(2.,loss/maximum))
    elif key=='VAKUU.pages.INITIAL.options.FIDDLE':
        cards=integer(variables,'Cards',2)
        values.update(ancient_extra_regular_draw_cards=float(cards),ancient_own_turn_extra_draw_block=1.,
            ancient_draw_block_x_known_draw_tag_fraction=sum('draw' in card_mechanisms(c) for c in deck)/len(deck))
    elif key=='PAEL.pages.INITIAL.options.PAELS_HORN':
        values.update(ancient_nominal_added_cards=2.,ancient_nominal_added_relax=2.)
    elif key=='NONUPEIPE.pages.INITIAL.options.JEWELRY_BOX':
        if any(type(c.get('upgraded')) is not bool for c in deck):
            raise DataContractError('Ancient upgrade context missing public upgraded flag')
        values.update(ancient_nominal_added_cards=1.,ancient_nominal_added_apotheosis=1.,
            ancient_apotheosis_x_unupgraded_fraction=sum(not c['upgraded'] for c in deck)/len(deck))
    elif key=='TEZCATARA.pages.INITIAL.options.STORYBOOK':
        values.update(ancient_nominal_added_cards=1.,ancient_nominal_added_brightest_flame=1.)
    elif key=='NEOW.pages.INITIAL.options.LARGE_CAPSULE':
        integer(variables,'Relics',2)
        values.update(ancient_nominal_added_cards=2.,ancient_nominal_added_basic_cards=2.)
    return values
