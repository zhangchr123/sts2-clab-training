"""Fresh searches at original failed choice boundaries must use engine pile order."""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from inspection.trial_cosmetic_projection import project_trial_number
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

class ForcedChoiceOrderTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def original_boundary(self, card):
        if card == 'DREDGE':
            source = Path('D:/sts2-training/staging/seeker-manual-repeat-return/sts2-solver-bridge')
            batch = 'defect-identity-warm-cem-20260915a'
            name = batch + '-generation-03-12-002'
            audit_path = source / 'outputs' / batch / 'generation-03' / (name + '-audit.json')
        else:
            source = Path('D:/sts2-training/staging/wish-original-draw-return/sts2-solver-bridge')
            batch = 'defect-power-pressure-pilot-20260915a'
            name = batch + '-neutral-001'
            audit_path = source / 'outputs' / batch / (name + '-audit.json')
        run = source / 'outputs' / name
        receipt = read_json(audit_path)
        self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
        original = read_lines(run / 'trace.jsonl')
        self.assertEqual(original[-1]['response']['choice_audit']['parent']['card_id'], card)
        label = 'forced-order-fresh-' + card.lower() + '-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        passed, matched, executor = False, 0, None
        differences = []
        try:
            for row in original[:-1]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                actual_public, actual_display = project_trial_number(checked_public(before))
                expected_public, expected_display = project_trial_number(checked_public(row['response']))
                self.assertEqual(actual_public, expected_public)
                if actual_display or expected_display:
                    differences.append({'prefix_index': matched, 'actual': actual_display, 'original': expected_display})
                matched += 1
            executor = CombatExecutor(send, read_json(run / 'manifest.json')['solver_requested_config'])
            # Run the corrected search, not a modified/relabelled historical plan.
            final = executor.advance(before)
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            proofs = [(call, proof) for call in executor.solve_calls for proof in call.get('replay', [])
                if proof.get('actual_choice_audit', {}).get('parent', {}).get('card_id') == card
                and proof.get('kind') == 'original_choice_return_completed']
            self.assertTrue(proofs, 'Fresh search must actually execute the affected automatic selection')
            expected_ids = ['STRIKE_DEFECT', 'COMPILE_DRIVER'] if card == 'DREDGE' else ['SUBROUTINE', 'BEAM_CELL']
            exact = [(call, proof) for call, proof in proofs
                if all(name in [c['CardId'] for c in proof['selected_cards']] for name in expected_ids)]
            self.assertTrue(exact, 'The original heterogeneous pair must be exercised')
            # The corrected Dredge search may first play Claw, adding a third
            # discard. It must retain the original pair's real pile order and
            # match the entire actual return, including any extra played card.
            actual_ids = [c['CardId'] for c in exact[0][1]['selected_cards']]
            self.assertEqual([name for name in actual_ids if name in expected_ids], expected_ids)
            for call, proof in exact:
                event = proof['actual_choice_audit']['original_returns'][0]
                self.assertEqual(event['returned_cards'], proof['selected_cards'])
                self.assertEqual(event['raw_source_count_at_entry'], len(proof['selected_cards']))
                self.assertFalse(proof['selection_request_sent'])
                bad_calls = copy.deepcopy(executor.solve_calls)
                target = next(a for c in bad_calls for a in c['response']['actions']
                    if a.get('CardId') == card and a.get('Choice') and len(a['Choice']['Cards']) == len(proof['selected_cards']))
                target['Choice']['Cards'].reverse()
                with self.assertRaises((ValueError, RuntimeError)):
                    validate_replay_evidence(bad_calls, traces)
            self.assertTrue(unchanged(receipt['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='fresh_corrected_solver_at_original_public_failure_boundary',
                original_failed_run=name, original_sources=receipt['actual_source_evidence'],
                public_prefix_responses_verified=matched, original_envelope_rewritten=False,
                hidden_state_or_rng_equality_claimed=False, all_public_fields_identical_claimed=False,
                diagnostic_only_Trial_display_number_projection=differences,
                solver_calls=executor.solve_calls if executor else [])
            bridge.close()

    def test_dredge_original_pair_fresh_search(self): self.original_boundary('DREDGE')
    def test_hidden_daggers_original_pair_fresh_search(self): self.original_boundary('HIDDEN_DAGGERS')

if __name__ == '__main__': unittest.main(verbosity=2)
