"""Pre-choice get_map evidence for a future observation-only sampling version.

Raw responses are transport audit evidence. Only project_map's whitelist and
route_features' public topology may become model inputs in a later version.
This module makes no query, executes no action and never changes policy state.
"""
from __future__ import annotations

import copy

from decision_data import DataContractError, enumerate_candidates, state_hash
from route_features import VERSION as ROUTE_VERSION, project_map, route_features


VERSION = "pre-choice-public-map-observation-v1"
REQUEST = {"cmd": "get_map"}
CONTEXT_KEYS = ("act", "floor", "ascension")


def _require(condition, message):
    if not condition:
        raise DataContractError(message)


def _hash(value):
    try:
        return state_hash(value)
    except (TypeError, ValueError, OverflowError, RecursionError) as exc:
        raise DataContractError("Map observation requires finite JSON evidence") from exc


def _state_candidates(state):
    _require(isinstance(state, dict) and state.get("type") == "decision"
             and state.get("decision") == "map_select", "Map observation requires an actual map_select state")
    context = state.get("context")
    _require(isinstance(context, dict)
             and all(type(context.get(key)) is int for key in CONTEXT_KEYS)
             and context["act"] in (1, 2, 3) and context["floor"] >= 0 and context["ascension"] == 10
             and context.get("combat_in_progress") is False,
             "Map observation requires explicit noncombat act/floor/A10 state binding")
    actual = enumerate_candidates(state)
    _require(actual.get("complete") is True, "Map observation requires complete current legal candidates")
    return actual


def make_map_observation(state, map_response):
    """Wrap a caller's actual query response, keeping missing graphs explicit.

    A map response from another act/floor/ascension is rejected as misbound.
    An error, absent response, or invalid graph is retained as unavailable
    observation evidence, with all of the original state's legal candidates.
    """
    state_digest, response_digest = _hash(state), _hash(map_response)
    state, response = copy.deepcopy(state), copy.deepcopy(map_response)
    candidates = _state_candidates(state)
    context_verified = isinstance(response, dict) and response.get("type") == "map"
    if context_verified:
        other = response.get("context")
        _require(isinstance(other, dict)
                 and all(type(other.get(key)) is int and other[key] == state["context"][key]
                         for key in CONTEXT_KEYS), "Map response is not bound to the actual act/floor/A10 state")
    query = {"request": copy.deepcopy(REQUEST), "decision_state_hash": state_digest,
             "response_hash": response_digest}
    public, graph_error = None, None
    try:
        _, _, public = project_map(response)
    except (DataContractError, TypeError, AttributeError, KeyError, RecursionError) as exc:
        graph_error = str(exc)
    routes = route_features(state, response, query)
    available = sum(row["features"]["route_available"] == 1 for row in routes["per_candidate"])
    status = "available" if routes["complete"] else "partial" if available else "unavailable"
    return {"version": VERSION, "source": "RunSimulator.GetFullMap", "phase": "before_macro_choice",
        "policy_used": False, "raw_response_usage": "transport_audit_only_not_policy_input",
        "decision_state_hash": state_digest, "request": copy.deepcopy(REQUEST),
        "raw_response": response, "response_hash": response_digest,
        "map_context_verified": context_verified, "candidate_set": candidates,
        "candidate_set_hash": _hash(candidates), "public_map": public,
        "public_map_hash": _hash(public) if public is not None else None,
        "graph_status": {"valid": public is not None, "error": graph_error},
        "route_feature_version": ROUTE_VERSION, "route_features": routes, "status": status}


def validate_map_observation(state, evidence, trace_query=None):
    """Strictly reconstruct evidence; optionally bind it to one actual trace row.

    A supplied trace row needs request, response and decision_state_hash. The
    latter is the sampler's state hash captured immediately before get_map.
    Without a trace, this validates internal consistency, not query execution.
    """
    _require(isinstance(evidence, dict) and evidence.get("version") == VERSION,
             "Unknown or missing map observation schema")
    _require("raw_response" in evidence, "Missing raw get_map response evidence")
    expected = make_map_observation(state, evidence["raw_response"])
    _require(_hash(evidence) == _hash(expected),
             "Map observation differs from its state, response, candidate space or public graph reconstruction")
    if trace_query is not None:
        _require(isinstance(trace_query, dict)
                 and all(key in trace_query for key in ("request", "response", "decision_state_hash")),
                 "Trace query must bind the actual pre-query decision_state_hash")
        _require(_hash(trace_query["request"]) == _hash(REQUEST), "Trace is not the complete get_map request")
        _require(trace_query["decision_state_hash"] == expected["decision_state_hash"],
                 "Trace query belongs to a different pre-query state")
        _require(_hash(trace_query["response"]) == expected["response_hash"],
                 "Trace response differs from the captured get_map response")
        if trace_query["response"] is None:
            _require(isinstance(trace_query.get("transport_error"), str) and bool(trace_query["transport_error"]),
                     "Absent trace response must retain its transport error")
        else:
            _require(trace_query.get("transport_error") is None, "Trace cannot report both a response and transport failure")
    return {"valid": True, "version": VERSION, "trace_verified": trace_query is not None,
        "policy_used": False, "status": expected["status"], "map_context_verified": expected["map_context_verified"],
        "graph_valid": expected["graph_status"]["valid"],
        "candidate_count": expected["candidate_set"]["candidate_count"],
        "route_features_complete": expected["route_features"]["complete"]}
