import copy
import unittest

from solver_evidence import verified_solver_call
from test_decision_data import solver_call


def staged_call(backend="coordinator", handled_failure=False):
    call = solver_call()
    call["request"]["solver_backend"] = backend
    settings = call["response"]["settings"]
    profile = settings["search_profile"]
    stages = []
    for index in range(2 if handled_failure else 1):
        failed = index == 1
        stages.append({"index":index, "search_profile":dict(profile, beam_width=30 * (index + 1)),
                       "expanded_nodes":100, "elapsed_ms":50., "effective_potion_policy":"Disabled",
                       "policy_snapshot":{}, "battle_damage_snapshot":{}, "minimum_potion_uses":0,
                       "maximum_potion_uses":None, "status":"failed" if failed else "completed",
                       "error":"PotionPolicyUnsatisfiedException" if failed else None,
                       "handled_by_coordinator":failed})
    settings.update(solver_backend=backend, configured_search_profile=copy.deepcopy(profile), search_stages=stages,
        search_stage_audit={"verified":True, "hook_verified":True, "top_level_outcome":"solver_result",
                            "started_stage_count":len(stages), "finished_stage_count":len(stages),
                            "failed_stage_count":int(handled_failure), "observed_expanded_nodes":100 * len(stages),
                            "reported_total_expanded_nodes":100 * len(stages), "total_nodes_reconciled":True})
    call["response"]["summary"] = {"TotalExpandedNodes":100 * len(stages)}
    return call


class SolverEvidenceTests(unittest.TestCase):
    def test_legacy_and_recorded_actual_stage_profiles_are_supported(self):
        self.assertTrue(verified_solver_call(solver_call()))
        self.assertTrue(verified_solver_call(staged_call("beam")))
        self.assertTrue(verified_solver_call(staged_call()))

    def test_handled_optional_stage_failure_does_not_invent_top_level_failure(self):
        call = staged_call(handled_failure=True)
        self.assertTrue(verified_solver_call(call))
        call["response"]["settings"]["search_stages"][1]["handled_by_coordinator"] = False
        self.assertFalse(verified_solver_call(call))

    def test_missing_stages_wrong_backend_and_node_mismatch_are_rejected(self):
        mutations = [
            lambda c: c["response"]["settings"].pop("search_stages"),
            lambda c: c["request"].update(solver_backend="beam"),
            lambda c: c["response"]["settings"]["search_stage_audit"].update(observed_expanded_nodes=999),
            lambda c: c["response"]["summary"].update(TotalExpandedNodes=999),
            lambda c: c["response"]["settings"]["search_stages"][0]["search_profile"].update(beam_width=True),
            lambda c: c["response"].update(type="error"),
            lambda c: c["response"]["settings"]["search_stages"][0].update(observation_error="missing field"),
        ]
        for mutate in mutations:
            call = staged_call()
            mutate(call)
            with self.subTest(call=call):
                self.assertFalse(verified_solver_call(call))


if __name__ == "__main__":
    unittest.main()
