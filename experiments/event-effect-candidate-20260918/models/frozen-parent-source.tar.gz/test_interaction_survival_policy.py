"""Synthetic artifacts and states only; temporary source copies test drift."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from decision_data import DataContractError, enumerate_candidates, state_hash
from initial_policy import FEATURE_NAMES as BASE_NAMES, InitialPolicy, POLICY_VERSION as BASE_VERSION
from interaction_features import FEATURE_NAMES, VERSION as TRANSFORM_VERSION, extend_scoring_packet
from interaction_survival_policy import InteractionSurvivalPolicy, VERSION
from selection_policy import SelectionPolicy, validate_selection_evidence
from survival_policy import SurvivalPolicy
from test_selection_policy import selection_state
from test_survival_policy import CONFIG, Draw, current
from train_act_survival import TARGET
import train_interaction_survival as trainer


ROOT = Path(__file__).resolve().parent


class InteractionPolicyTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)

    def artifact(self, *, weights=None, changes=None):
        # No natural data or labels: hand-authored numerical predictor fixture.
        fallback = InitialPolicy(prior_path=None, random_seed="synthetic-wrapper")
        transform = extend_scoring_packet(current(), fallback.score(current()))["interaction_feature_source"]
        model = {"format": trainer.VERSION, "mode": trainer.MODE, "target_semantics": TARGET,
            "feature_policy_version": TRANSFORM_VERSION, "base_feature_policy_version": BASE_VERSION,
            "feature_names": list(FEATURE_NAMES), "feature_transform": transform,
            "feature_transform_sources": trainer._code_sources(trainer.FEATURE_SOURCE_FILES),
            "training_sources": trainer._code_sources(trainer.TRAINING_SOURCE_FILES),
            "feature_prior_sha256": fallback.prior.source["sha256"],
            "feature_prior_source": copy.deepcopy(fallback.prior.source),
            "feature_mechanism_facts": fallback.mechanism_source,
            "means": [0.] * len(FEATURE_NAMES), "scales": [1.] * len(FEATURE_NAMES),
            "weights": [0.] + [float((weights or {}).get(name, 0.)) for name in FEATURE_NAMES],
            "feature_min": [0.] * len(FEATURE_NAMES), "feature_max": [1.] * len(FEATURE_NAMES),
            "deployment_scope": copy.deepcopy(trainer.SCOPE), "regularization": 1.,
            "automatic_deployment": False, "calibrated_probability": False,
            "counterfactual_labels": False, "chosen_action_is_optimal_label": False,
            "test_used_for_fit_or_tuning": False, "synthetic_fixture": True,
            "frozen_followup": {"solver": copy.deepcopy(CONFIG), "policy": fallback.provenance,
                "run_conditions": {"character": "Defect", "ascension": 10, "mode": "standard"},
                "runtime": {}, "sampling_sources": {}, "sampling_limits": {}}}
        model.update(changes or {})
        path = self.directory / "synthetic-interaction-model.json"
        path.write_text(json.dumps(model), encoding="utf-8")
        return path, fallback

    def policy(self, *, weights=None, **kwargs):
        path, fallback = self.artifact(weights=weights)
        return InteractionSurvivalPolicy(path, solver_config=copy.deepcopy(CONFIG), fallback=fallback, **kwargs)

    def test_act1_pure_119_model_and_later_101_rules_without_rng_or_scope_leak(self):
        policy = self.policy(weights={"is_skip": 2.}, epsilon=0)
        state = current()
        before, rng = copy.deepcopy(state), policy.rng.getstate()
        identity = policy.provenance
        packet = policy.score(state)
        self.assertEqual(state, before)
        self.assertEqual(policy.rng.getstate(), rng)
        self.assertEqual(policy.choice_count, 0)
        self.assertEqual(packet["feature_policy_version"], TRANSFORM_VERSION)
        self.assertEqual(packet["base_feature_policy_version"], BASE_VERSION)
        self.assertEqual(packet["effective_scorer"], trainer.VERSION)
        self.assertEqual(packet["model"]["mode"], trainer.MODE)
        self.assertTrue(packet["model"]["active"])
        self.assertIn("interaction_survival_proxy", packet["score_semantics"])
        for row in packet["scores"]:
            self.assertEqual(set(row["features"]), set(FEATURE_NAMES))
            self.assertEqual(len(row["features"]), 119)
            self.assertEqual(row["score"], 2. if row["is_skip"] else 0.)
            self.assertEqual(row["delta_from_skip"], row["score"] - 2.)
            self.assertFalse(row["model_coverage"]["uncertainty_calibrated"])
            self.assertFalse(row["model_coverage"]["unchosen_action_outcome_observed"])
        with patch.object(policy.scorer, "score_requests", side_effect=AssertionError("Act1 scorer escaped")):
            for act in (2, 3):
                state = current(act)
                expected = policy.fallback.score(state)
                later = policy.score(state)
                self.assertEqual(later["feature_policy_version"], BASE_VERSION)
                self.assertEqual(later["effective_scorer"], BASE_VERSION)
                self.assertEqual(later["score_semantics"], expected["score_semantics"])
                self.assertFalse(later["model"]["active"])
                self.assertEqual(later["model"]["mode"], trainer.MODE)
                self.assertNotIn("interaction_feature_source", later)
                for row, rule in zip(later["scores"], expected["scores"]):
                    self.assertEqual(row["features"], rule["features"])
                    self.assertEqual(set(row["features"]), set(BASE_NAMES))
                    self.assertEqual(len(row["features"]), 101)
                    self.assertEqual(row["score"], rule["score"])
                self.assertEqual(policy.provenance, identity)

    def test_transform_provenance_is_complete_stable_and_returned_by_value(self):
        policy = self.policy()
        expected = policy.provenance
        self.assertEqual(expected["id"], VERSION)
        self.assertEqual(expected["version"], policy.sha256)
        self.assertEqual(expected["feature_policy_version"], BASE_VERSION)
        self.assertEqual(expected["active_feature_policy_version"], TRANSFORM_VERSION)
        self.assertEqual(expected["feature_transform"], policy.model["feature_transform"])
        self.assertEqual(expected["feature_transform_sources"], policy.model["feature_transform_sources"])
        self.assertEqual(set(expected["feature_transform_sources"]), set(trainer.FEATURE_SOURCE_FILES))
        mutated = policy.provenance
        mutated["feature_transform"]["feature_names"].clear()
        mutated["feature_transform_sources"].clear()
        policy.score(current(1))
        policy.choose(current(2))
        self.assertEqual(policy.provenance, expected)

    def test_epsilon_and_tie_probabilities_keep_base_explicit_selection_semantics(self):
        policy = self.policy(epsilon=.1)
        policy.rng = Draw(.9, 1)
        chosen = policy.choose(current())
        self.assertFalse(chosen["exploration"]["explored"])
        self.assertEqual(chosen["exploration"]["greedy_tie_count"], 3)
        self.assertAlmostEqual(chosen["exploration"]["chosen_probability"], 1. / 3.)
        self.assertEqual(chosen["policy_provenance"]["id"], VERSION)
        policy.rng = Draw(.01, 2)
        chosen = policy.choose(current())
        self.assertTrue(chosen["exploration"]["explored"])
        self.assertAlmostEqual(chosen["exploration"]["chosen_probability"], 1. / 3.)
        self.assertEqual(chosen["exploration"]["probability_precision"], "nominal_float_threshold")
        self.assertEqual(policy.choice_count, 2)

    def test_implicit_space_retains_full_count_bounded_scores_and_valid_choice_evidence(self):
        base = self.policy(weights={"selected_count": 1.}, seed="synthetic-implicit")
        policy = SelectionPolicy(base, max_evaluations=9)
        identity = policy.provenance
        for act, names, version in ((1, FEATURE_NAMES, TRANSFORM_VERSION), (2, BASE_NAMES, BASE_VERSION)):
            state = selection_state()
            state["context"].update(act=act, ascension=10, integrity_recovery_used=False)
            rng = base.rng.getstate()
            packet = policy.score(state, selection_purpose="acquire")
            self.assertEqual(base.rng.getstate(), rng)
            self.assertEqual(packet["candidate_count"], 3554627472076)
            self.assertEqual(packet["evaluated_candidate_count"], 9)
            self.assertFalse(packet["evaluated_candidates_complete"])
            self.assertEqual(packet["feature_policy_version"], version)
            self.assertTrue(all(set(row["features"]) == set(names) for row in packet["scores"]))
            picked = policy.choose(state, selection_purpose="acquire")
            self.assertTrue(validate_selection_evidence(state, enumerate_candidates(state), picked)["valid"])
            self.assertEqual(picked["policy_provenance"]["id"], VERSION)
            self.assertEqual(policy.provenance, identity)
        self.assertEqual(base.choice_count, 2)

    def test_constructor_and_request_bindings_fail_closed(self):
        path, fallback = self.artifact()
        for kwargs in ({"solver_config": {"solver_backend": "coordinator"}},
                       {"ascension": 9}, {"ascension": True}, {"character": "Ironclad"}):
            with self.subTest(kwargs=kwargs), self.assertRaises(DataContractError):
                InteractionSurvivalPolicy(path, fallback=fallback, **{"solver_config": CONFIG, **kwargs})
        with self.assertRaises(DataContractError):
            SurvivalPolicy(path, solver_config=CONFIG, fallback=fallback)
        policy = InteractionSurvivalPolicy(path, solver_config=CONFIG, fallback=fallback)
        for act in (1, 2):
            with self.assertRaises(DataContractError):
                policy.score_requests(current(act), [{"cmd": "action", "action": "select_card", "index": 999}])
        bad = current()
        bad["context"]["combat_in_progress"] = True
        with self.assertRaises(DataContractError):
            policy.score(bad)

    def test_loaded_model_mutation_is_rejected_in_every_act(self):
        policy = self.policy()
        policy.scorer.model["weights"][0] += 1.
        for act in (1, 2, 3):
            with self.subTest(act=act), self.assertRaisesRegex(DataContractError, "changed after model loading"):
                policy.score(current(act))

    def test_actual_source_drift_in_temporary_mirror_is_rejected_without_touching_root(self):
        path, fallback = self.artifact()
        mirror = self.directory / "source-mirror"
        mirror.mkdir()
        for name in trainer.FEATURE_SOURCE_FILES:
            (mirror / name).write_bytes((ROOT / name).read_bytes())
        spec = importlib.util.spec_from_file_location("isolated_interaction_scorer", mirror / "train_interaction_survival.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class MirroredPolicy(InteractionSurvivalPolicy):
            SCORER_CLASS = module.InteractionSurvivalScorer

        policy = MirroredPolicy(path, solver_config=CONFIG, fallback=fallback)
        policy.score(current())
        copied_source = mirror / "interaction_features.py"
        copied_source.write_bytes(copied_source.read_bytes() + b"\n# synthetic source drift\n")
        with self.assertRaisesRegex(DataContractError, "source code differs"):
            policy.score(current())
        with self.assertRaisesRegex(DataContractError, "source code differs"):
            MirroredPolicy(path, solver_config=CONFIG, fallback=fallback)
        self.assertNotEqual(state_hash(copied_source.read_text()), state_hash((ROOT / copied_source.name).read_text()))


if __name__ == "__main__":
    unittest.main()
