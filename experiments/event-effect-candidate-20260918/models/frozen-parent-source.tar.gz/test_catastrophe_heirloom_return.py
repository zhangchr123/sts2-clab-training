"""Original historical combat and evidence-corruption regressions, never training."""
import copy
import json
from pathlib import Path
import unittest
import uuid
from prefix_interventions import read_json,read_lines,unchanged
from inspection.replay_cheese_event import checked_public
from inspection.trial_cosmetic_projection import project_trial_number
from combat_executor import CombatExecutor
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT.parent.with_name('unpredicted-toasty-setup-replan')/'sts2-solver-bridge'
NAME='defect-identity-local-search-20260915a-training-candidate-08-019'

class CatastropheHeirloomReturn(unittest.TestCase):
    worker=helpers.LiquidMemoriesTests.worker
    save=helpers.LiquidMemoriesTests.save

    def prefix(self):
        audit=read_json(ORIGINAL/'outputs/defect-identity-local-search-20260915a'/(NAME+'-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        rows=read_lines(ORIGINAL/'outputs'/NAME/'trace.jsonl')
        label='catastrophe-heirloom-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);matched=0
        try:
            for row in rows[:541]:
                if row['request']['cmd'] in ('solve','combat_meta','choice_meta'):continue
                state=send(row['request'])
                self.assertEqual(project_trial_number(checked_public(state))[0],project_trial_number(checked_public(row['response']))[0])
                matched+=1
            self.assertEqual(matched,312)
            return bridge,traces,send,state,rows,audit,label
        except BaseException:
            bridge.close();raise

    def run_recorded(self,corrupt):
        bridge,traces,send,state,rows,audit,label=self.prefix();passed=False;observer=None;final=None
        try:
            original=copy.deepcopy(rows[541]);self.assertEqual(len(original['response']['actions']),35)
            class RecordedPlan(CombatExecutor):
                def solve(inner,state,budget,used=0,setup=False):
                    self.assertEqual(len(inner.solve_calls),0,'Original plan unexpectedly requested replacement')
                    call=copy.deepcopy(original);traces.append(copy.deepcopy(call));inner.solve_calls.append(call)
                    return call['response']
            observer=RecordedPlan(send,read_json(ORIGINAL/'outputs'/NAME/'manifest.json')['solver_requested_config'])
            start=len(traces);final=observer.advance(state)
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertFalse(final['context']['integrity_recovery_used'])
            self.assertTrue(validate_replay_evidence(observer.solve_calls,traces)['verified'])
            proofs=[p for p in observer.solve_calls[0]['replay'] if p.get('nested_effect_binding')=='actual_Catastrophe_AutoPlay_task_with_original_HeirloomHammer_child_return']
            self.assertEqual(len(proofs),1)
            proof=proofs[0];event=proof['actual_choice_audit']['original_returns'][0]
            self.assertEqual(event['source_id'],'HEIRLOOM_HAMMER')
            self.assertEqual([c['CardId'] for c in proof['selected_cards']],['BOLAS'])
            self.assertFalse(proof['selection_request_sent'])
            self.assertGreaterEqual(event['raw_source_count_at_entry'],1)
            if corrupt:
                at=next(i for i in range(start,len(traces)) if traces[i]['response'].get('choice_audit')==proof['actual_choice_audit']
                    and traces[i]['request'].get('action')=='play_card')
                before=next(r['response'] for r in reversed(traces[:at]) if 'context' in r['response'])
                after=traces[at]['response'];action=original['response']['actions'][7]
                bad_fields={
                    'source_id':'CATASTROPHE','nested_parent_card_id':'STRIKE_DEFECT',
                    'nested_relation':'unrelated','nested_source_owner_matches_parent':False,
                    'nested_auto_play_callsite':'Unrelated.OnPlay','nested_auto_play_index':99,
                    'nested_auto_play_total_calls':3,'nested_auto_play_source_is_original_object':False,
                    'nested_auto_play_task_completed_successfully':False,
                    'nested_source_card_key':'OTHER+0|','nested_auto_play_source_key_at_entry':'HEIRLOOM_HAMMER+99|',
                    'source_is_actual_parent_object':True,'original_task_completed_successfully':False,
                    'filter_reexecuted_by_observer':True,'filter_is_null':True,
                    'selector_invocations_after':999,'returned_cards':[],'returned_count':0,
                    'raw_source_count_at_return':0,'action_id':True}
                for key,value in bad_fields.items():
                    with self.subTest(corrupt=key):
                        bad=copy.deepcopy(after);bad['choice_audit']['original_returns'][0][key]=value
                        checker=CombatExecutor(lambda **_:dict(type='choice_meta',selection='none',cards=[],completion_audit=bad['choice_audit']))
                        checker.solve_calls=[{}];checker.last_action_request=traces[at]['request']
                        with self.assertRaises(RuntimeError):checker.resolve_original_automatic_choice(before,bad,action)
                for mutation in ('omit','binding','selected'):
                    calls=copy.deepcopy(observer.solve_calls)
                    index=next(i for i,p in enumerate(calls[0]['replay']) if p==proof)
                    if mutation=='omit':calls[0]['replay'].pop(index)
                    elif mutation=='binding':calls[0]['replay'][index]['nested_effect_binding']='unrelated'
                    else:calls[0]['replay'][index]['selected_cards']=[]
                    with self.subTest(replay=mutation),self.assertRaises(ValueError):validate_replay_evidence(calls,traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']));passed=True
        finally:
            self.save(label,traces,passed=passed,diagnostic_only=True,training_sample=False,
                original_sources=audit['actual_source_evidence'],public_prefix_responses=312,
                explicit_recorded_full_plan=True,fresh_search_claimed=False,actual_final=final,
                solver_calls=observer.solve_calls if observer else [],complete_hidden_state_or_rng_equality_claimed=False)
            bridge.close();print(json.dumps({'label':label,'passed':passed,'final_hp':final.get('player',{}).get('hp') if final else None}),flush=True)

    def test_original_thirty_five_action_plan_completes_with_actual_return(self):self.run_recorded(False)
    def test_false_child_returns_and_missing_replay_proof_rejected(self):self.run_recorded(True)

    def test_fresh_original_solver_finishes_combat(self):
        bridge,traces,send,state,rows,audit,label=self.prefix();passed=False;executor=None;final=None
        try:
            executor=CombatExecutor(send,read_json(ORIGINAL/'outputs'/NAME/'manifest.json')['solver_requested_config'])
            final=executor.advance(state)
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertFalse(final['context']['integrity_recovery_used'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
            self.assertTrue(unchanged(audit['actual_source_evidence']));passed=True
        finally:
            self.save(label,traces,passed=passed,diagnostic_only=True,training_sample=False,
                original_sources=audit['actual_source_evidence'],public_prefix_responses=312,actual_final=final,
                solver_calls=executor.solve_calls if executor else [],complete_hidden_state_or_rng_equality_claimed=False)
            bridge.close();print(json.dumps({'label':label,'passed':passed,'fresh_solver':True,
                'final_hp':final.get('player',{}).get('hp') if final else None}),flush=True)

if __name__=='__main__':unittest.main(verbosity=2)
