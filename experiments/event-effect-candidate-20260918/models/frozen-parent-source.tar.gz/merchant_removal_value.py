"""Value the original merchant's actual removal options with the real selection policy."""
import copy
import math
from decision_data import DataContractError, state_hash
from selection_policy import TIE_TOLERANCE

CONTRACT=dict(version='merchant-removal-utility-preview-v1',
    eligibility='original_engine_IsRemovable',selection='same_bound_selection_scorer_without_rng',
    score='best_nonempty_minus_cancel_minus_price_over_150',cancel_tie_entered=False)
ENGINE_CONTRACT='original-merchant-removal-preview-v1'


def require(ok,message):
    if not ok:raise DataContractError('Merchant removal value: '+message)


def selection_state(state):
    preview=state.get('card_removal_preview');player=state.get('player',{});deck=player.get('deck')
    require(state.get('decision')=='shop' and isinstance(preview,dict),'Missing original selection preview')
    require(preview.get('schema_version')==ENGINE_CONTRACT
        and preview.get('source')=='CardModel.IsRemovable;CardSelectCmd.FromDeckForRemoval.ordering'
        and type(preview.get('min_select')) is int and preview['min_select']==0
        and type(preview.get('max_select')) is int and preview['max_select']==1,'Unknown original preview contract')
    require(isinstance(deck,list) and all(type(c.get('is_removable')) is bool for c in deck),
        'Missing original per-card removal eligibility')
    expected=sorted((i for i,c in enumerate(deck) if c['is_removable']),
        key=lambda i:-999999999 if deck[i].get('type')=='Curse' else i)
    indices=preview.get('deck_indices');cards=preview.get('cards')
    require(isinstance(indices,list) and all(type(i) is int for i in indices) and indices==expected,
        'Preview omitted, added or reordered original removable cards')
    require(isinstance(cards,list) and len(cards)==len(indices),'Preview option count differs')
    for i,(card,deck_index) in enumerate(zip(cards,indices)):
        require(type(card.get('index')) is int and card['index']==i,'Preview selection index differs')
        original=deck[deck_index]
        for key in ('id','upgraded','cost','type','stats','description','keywords','after_upgrade'):
            require(card.get(key)==original.get(key),'Preview changed original card '+key)
    require(state.get('context',{}).get('combat_in_progress') is False,'Merchant preview is not noncombat')
    return dict(type='decision',decision='card_select',context=copy.deepcopy(state['context']),
        player=copy.deepcopy(player),cards=copy.deepcopy(cards),min_select=0,max_select=1)


def validate_previews(traces):
    current=None;shops=selections=0
    for row in traces:
        request=row.get('request') or {};response=row.get('response') or {}
        if (request.get('cmd')=='action' and request.get('action')=='remove_card'
                and current and current.get('decision')=='shop' and response.get('decision')=='card_select'):
            actual={k:v for k,v in response.items() if k not in ('choice_audit','play_action')}
            require(selection_state(current)==actual,'Observed original selector differs from the merchant preview')
            selections+=1
        if response.get('type')=='decision':
            if response.get('decision')=='shop' and response.get('card_removal_cost') is not None:
                selection_state(response);shops+=1
            current=response
    return dict(passed=True,shop_previews=shops,actual_selection_matches=selections)


def adjust(policy,state,packet):
    if state.get('decision')!='shop':return packet
    removals=[r for r in packet['scores'] if r['request'].get('action')=='remove_card']
    if not removals:return packet
    require(len(removals)==1,'Duplicate merchant service')
    projected=selection_state(state)
    cost=state.get('card_removal_cost')
    require(type(cost) in (int,float) and math.isfinite(cost) and cost>=0,'Missing original service cost')
    # Bind to the actual wrapper so oversized special decks use exactly the
    # same bounded search as their subsequent real card-selection decision.
    wrapper=getattr(policy,'_merchant_selection_wrapper',None)
    if wrapper is None:
        from selection_policy import SelectionPolicy
        wrapper=SelectionPolicy(policy)
    rng=policy.rng.getstate();choice_count=policy.choice_count
    scored=wrapper.score(projected,selection_purpose='remove')
    require(policy.rng.getstate()==rng and policy.choice_count==choice_count,'Preview consumed action-selection RNG')
    cancel=[r for r in scored['scores'] if r['is_skip']]
    require(len(cancel)==1,'Original cancellation option missing')
    cancel=cancel[0];targets=[r for r in scored['scores'] if not r['is_skip']]
    best=max(targets,key=lambda r:r['score']) if targets else None
    row=removals[0];previous=row['score'];names=policy.artifact['parameter_names']
    delta=best['score']-cancel['score'] if best else None
    beneficial=best is not None and delta>TIE_TOLERANCE
    if best:
        # Preserve an inspectable score decomposition for the selected target.
        features={k:best['search_features'][k]-cancel['search_features'][k] for k in names}
        rule=best['rule_score']-cancel['rule_score']-cost/150.
        residual=sum(policy.artifact['parameters'][k]*features[k] for k in names)
        value=delta-cost/150.
        require(abs(rule+residual-value)<=1e-9,'Preview score decomposition differs')
    else:
        features=dict.fromkeys(names,0.);rule=-1.;residual=0.;value=-1.
    # A free neutral removal must not randomly re-enter a cancellation tie.
    if not beneficial and value>=-1e-6:
        rule += -1e-6-value;value=-1e-6
    row.update(score=value,rule_score=rule,learned_residual=residual,search_features=features,
        merchant_removal_value=dict(contract=copy.deepcopy(CONTRACT),original_macro_score=previous,
            engine_preview_hash=state_hash(state['card_removal_preview']),
            selection_space_size=scored['candidate_count'],evaluated_candidates=len(scored['scores']),
            evaluated_candidates_complete=scored.get('evaluated_candidates_complete'),
            selection_search_parameters=wrapper.parameters,
            target_request=copy.deepcopy(best['request']) if best else None,
            target_score=best['score'] if best else None,cancel_score=cancel['score'],
            target_delta=delta,gold_opportunity_cost=cost/150.,beneficial_target=beneficial,
            scores_are_heuristic_not_outcome_predictions=True),
        reasons=[dict(source=CONTRACT['version'],score=value,
            explanation='Current model removal choice utility relative to cancellation, minus original gold cost')])
    skip=next((r['score'] for r in packet['scores'] if r['is_skip']),None)
    for entry in packet['scores']:entry['delta_from_skip']=None if skip is None else entry['score']-skip
    packet['merchant_removal_entry_contract']=copy.deepcopy(CONTRACT)
    return packet
