"""Independent prefix auditor counterexamples; all inputs are temporary synthetic data."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import audit_prefix_interventions as audit
import prefix_interventions as runner
from combat_executor import DEFAULT_CONFIG
from decision_data import enumerate_candidates, state_hash
from initial_policy import InitialPolicy
from run_metadata import file_evidence
from selection_policy import SelectionPolicy
import test_compare_batches as compare_fixtures
from test_prefix_interventions import prefix, state


def write(path, value):
    path.write_text(json.dumps(value), encoding="utf-8")


def write_lines(path, values):
    path.write_text("".join(json.dumps(value) + "\n" for value in values), encoding="utf-8")


class PrefixAuditTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)

    def fixture(self):
        # Reuse the validated fake solver wire schema, without invoking any solver.
        wire = compare_fixtures.CompareBatchTests()
        wire.root = self.root
        wire.run_fixture("wire", "synthetic", "beam", "defeat")
        solver_trace = runner.read_lines(self.root / "wire/trace.jsonl")[2]
        old = prefix()
        source = self.root / "source.jsonl"
        write_lines(source, old)
        gate = runner.select_gate(old, "synthetic")
        candidate = next(c for c in gate["candidates"] if c["is_skip"])
        arm = {"arm_id": "candidate-skip", "candidate_id": candidate["candidate_id"],
               "request": candidate["request"], "is_duplicate_control": False}
        gate.update(seed="synthetic", gate_id="synthetic-gate", sources={"trace.jsonl": file_evidence(source)},
                    source_solver_config=copy.deepcopy(DEFAULT_CONFIG), arms=[arm])
        protocol = {"schema_version": runner.VERSION, "provenance": "same_seed_action_prefix_intervention",
                    "horizon": "first_actual_next_combat_end_under_frozen_rule_suffix"}
        directory = self.root / "arm"
        directory.mkdir()
        current_map, combat, final = state("map_select"), state("combat_play", floor=3, combat=True), state(floor=3, hp=51)
        policy = SelectionPolicy(InitialPolicy(epsilon=.1, random_seed="synthetic:prefix-next-combat-v1",
                                               origin="prefix_intervention"), max_evaluations=256)
        picked = policy.choose(current_map, candidates=enumerate_candidates(current_map))
        policies = [{"decision_id": "arm:0000", "state": gate["state"],
            "candidate_set": enumerate_candidates(gate["state"]), "selection_context": None,
            "picked": {"request": arm["request"], "origin": "predeclared_intervention"}},
            {"decision_id": "arm:0001", "state": current_map, "candidate_set": enumerate_candidates(current_map),
             "selection_context": None, "picked": picked}]
        traces = [{**copy.deepcopy(row), "phase": "historical_prefix", "historical_trace_index": i,
                   "response_received": True} for i, row in enumerate(old)]
        for row in ({"request": arm["request"], "response": current_map},
                    {"request": picked["request"], "response": combat}, solver_trace,
                    {"request": {"cmd": "action", "action": "end_turn"}, "response": final}):
            traces.append({**copy.deepcopy(row), "phase": "intervention_suffix", "historical_trace_index": None,
                           "response_received": True})
        calls = [{"request": solver_trace["request"], "response": solver_trace["response"]}]
        label = {"horizon": protocol["horizon"], "hp": 51, "max_hp": 75, "gate_hp": 60,
            "combat_metrics": None, "actual_death": False, "boundary_state_hash": state_hash(final),
            "battle_start_state_hash": state_hash(combat), "battle_start_context": combat["context"],
            "context": final["context"], "potions_used": 0}
        result = {"schema_version": runner.VERSION, "gate_id": gate["gate_id"], "seed": gate["seed"], "arm": arm,
            "provenance": protocol["provenance"], "natural_training_eligible": False,
            "full_state_equality_verified": False, "rng_equality_verified": False,
            "frozen_inputs_unchanged": True, "status": "observed_next_combat_boundary", "observed_label": label,
            "prefix_responses_verified": 2, "suffix_start_trace_index": 2, "suffix_macro_decisions": 2}
        write(directory / "declaration.json", {"protocol_sha256": state_hash(protocol), "gate": gate, "arm": arm})
        write_lines(directory / "trace.jsonl", traces)
        write_lines(directory / "policy.jsonl", policies)
        write(directory / "solver-calls.json", calls)
        write(directory / "gate-state.json", gate["state"])
        write(directory / "final-state.json", final)
        result.update(trace_source=file_evidence(directory / "trace.jsonl"), policy_source=file_evidence(directory / "policy.jsonl"))
        write(directory / "result.json", result)
        return protocol, gate, arm, directory

    @staticmethod
    def refresh(directory):
        result = runner.read_json(directory / "result.json")
        result.update(trace_source=file_evidence(directory / "trace.jsonl"), policy_source=file_evidence(directory / "policy.jsonl"))
        write(directory / "result.json", result)

    def test_real_synthetic_trace_recomputes_frozen_suffix_and_observed_boundary(self):
        result = audit.audit_observed_arm(*self.fixture())
        self.assertTrue(result["usable_observation"])
        self.assertEqual(result["observed_label"]["hp"], 51)
        self.assertEqual(result["recomputed_suffix_macro_choices"], 2)
        self.assertEqual(result["original_solver_calls"], 1)

    def test_label_must_match_trace_boundary(self):
        args = self.fixture()
        result = runner.read_json(args[-1] / "result.json")
        result["observed_label"]["hp"] += 1
        write(args[-1] / "result.json", result)
        with self.assertRaisesRegex(ValueError, "label|boundary"):
            audit.audit_observed_arm(*args)

    def test_rehashed_suffix_scores_must_match_frozen_policy(self):
        args = self.fixture()
        path = args[-1] / "policy.jsonl"
        rows = runner.read_lines(path)
        rows[1]["picked"]["scoring"]["scores"][0]["score"] += 1
        write_lines(path, rows)
        self.refresh(args[-1])
        with self.assertRaisesRegex(ValueError, "recomputed frozen rules"):
            audit.audit_observed_arm(*args)

    def test_rehashed_extra_action_after_first_boundary_is_rejected(self):
        args = self.fixture()
        path = args[-1] / "trace.jsonl"
        rows = runner.read_lines(path)
        rows.append(copy.deepcopy(rows[-1]))
        write_lines(path, rows)
        self.refresh(args[-1])
        with self.assertRaisesRegex(ValueError, "beyond first actual combat boundary"):
            audit.audit_observed_arm(*args)

    def test_readonly_metadata_tail_preserves_actual_boundary_label(self):
        args = self.fixture()
        expected = audit.audit_observed_arm(*args)
        path = args[-1] / "trace.jsonl"
        rows = runner.read_lines(path)
        # The original ending action remains the last decision. Queries are
        # retained wire evidence, not another transition or a new battle.
        for command in ("choice_meta", "combat_meta"):
            rows.append({"phase": "intervention_suffix", "historical_trace_index": None,
                "request": {"cmd": command}, "response": {"type": command, "selection": "none"},
                "response_received": True})
            write_lines(path, rows)
            self.refresh(args[-1])
            with self.subTest(command=command):
                actual = audit.audit_observed_arm(*args)
                self.assertTrue(actual["usable_observation"])
                self.assertEqual(actual["observed_label"], expected["observed_label"])
                self.assertEqual(actual["recomputed_suffix_macro_choices"], 2)
                self.assertEqual(actual["original_solver_calls"], 1)

    def test_metadata_tail_does_not_authorize_a_later_action_or_solve(self):
        args = self.fixture()
        path = args[-1] / "trace.jsonl"
        rows = runner.read_lines(path)
        attempts = (copy.deepcopy(rows[-1]), copy.deepcopy(rows[-2]))
        rows.append({"phase": "intervention_suffix", "historical_trace_index": None,
            "request": {"cmd": "choice_meta"}, "response": {"type": "choice_meta", "selection": "none"},
            "response_received": True})
        for attempt in attempts:
            write_lines(path, rows + [attempt])
            self.refresh(args[-1])
            with self.subTest(command=attempt["request"]["cmd"]):
                with self.assertRaisesRegex(ValueError, "beyond first actual combat boundary"):
                    audit.audit_observed_arm(*args)

    def test_metadata_tail_rejects_a_mismatched_or_decision_response_type(self):
        args = self.fixture()
        path = args[-1] / "trace.jsonl"
        rows = runner.read_lines(path)
        for response in ({"type": "combat_meta"}, copy.deepcopy(rows[-1]["response"]),
                         {"type": "error", "error": "synthetic query error"}):
            attempt = {"phase": "intervention_suffix", "historical_trace_index": None,
                "request": {"cmd": "choice_meta"}, "response": response, "response_received": True}
            write_lines(path, rows + [attempt])
            self.refresh(args[-1])
            with self.subTest(response_type=response["type"]):
                with self.assertRaisesRegex(ValueError, "beyond first actual combat boundary"):
                    audit.audit_observed_arm(*args)

    def test_declared_source_cannot_point_to_another_identical_file(self):
        args = self.fixture()
        directory = args[-1]
        alternate = self.root / "unrelated-trace.jsonl"
        alternate.write_bytes((directory / "trace.jsonl").read_bytes())
        result = runner.read_json(directory / "result.json")
        result["trace_source"] = file_evidence(alternate)
        write(directory / "result.json", result)
        with self.assertRaises(ValueError):
            audit.audit_observed_arm(*args)

    def test_completed_trace_cannot_be_relabeled_as_unproved_timeout(self):
        args = self.fixture()
        result = runner.read_json(args[-1] / "result.json")
        result.update(status="timeout", observed_label=None, error="fabricated timeout")
        write(args[-1] / "result.json", result)
        with self.assertRaises(ValueError):
            audit.audit_observed_arm(*args)

    def failed_fixture(self, transport):
        args = self.fixture()
        directory = args[-1]
        traces = runner.read_lines(directory / "trace.jsonl")
        traces[-1].update(response=None if transport else {"type": "error", "error": "synthetic original failure"},
                          response_received=not transport)
        if transport:
            traces[-1]["transport_error"] = "TimeoutError('synthetic receive timeout')"
        write_lines(directory / "trace.jsonl", traces)
        result = runner.read_json(directory / "result.json")
        result.update(status="timeout" if transport else "environment_or_prefix_error", observed_label=None,
                      suffix_macro_decisions=1, error="synthetic original failure",
                      failure_evidence={"kind": "transport_error" if transport else "engine_error",
                                        "actual_trace_index": len(traces) - 1})
        write(directory / "result.json", result)
        write(directory / "final-state.json", traces[-3]["response"])
        self.refresh(directory)
        return args

    def test_actual_original_engine_error_is_retained_without_a_death_label(self):
        result = audit.audit_observed_arm(*self.failed_fixture(False))
        self.assertFalse(result["usable_observation"])
        self.assertIsNone(result["observed_label"])
        self.assertEqual(result["status"], "environment_or_prefix_error")

    def test_actual_transport_failure_is_retained_without_an_observed_label(self):
        result = audit.audit_observed_arm(*self.failed_fixture(True))
        self.assertFalse(result["usable_observation"])
        self.assertIsNone(result["observed_label"])
        self.assertEqual(result["status"], "timeout")

    def test_extra_error_after_actual_boundary_cannot_relabel_a_completed_arm(self):
        args = self.fixture()
        directory = args[-1]
        traces = runner.read_lines(directory / "trace.jsonl")
        error = copy.deepcopy(traces[-1])
        error["response"] = {"type": "error", "error": "added after real horizon"}
        traces.append(error)
        write_lines(directory / "trace.jsonl", traces)
        result = runner.read_json(directory / "result.json")
        result.update(status="environment_or_prefix_error", observed_label=None, error="added after horizon",
                      failure_evidence={"kind": "engine_error", "actual_trace_index": len(traces) - 1})
        write(directory / "result.json", result)
        self.refresh(directory)
        with self.assertRaises(ValueError):
            audit.audit_observed_arm(*args)

    def canceled_fixture(self):
        args = self.fixture()
        directory, config = args[-1], args[1]["source_solver_config"]
        traces = runner.read_lines(directory / "trace.jsonl")
        success = traces[4]
        canceled = copy.deepcopy(success)
        canceled["response"] = {"type": "error", "error": "OperationCanceledException: synthetic cancellation"}
        success["request"]["budget_ms"] = config["retry_budget_ms"]
        settings = success["response"]["settings"]
        for profile in (settings["search_profile"], settings["configured_search_profile"],
                        settings["search_stages"][0]["search_profile"]):
            profile["soft_time_budget_ms"] = config["retry_budget_ms"]
        traces.insert(4, canceled)
        write_lines(directory / "trace.jsonl", traces)
        write(directory / "solver-calls.json", [{"request": row["request"], "response": row["response"]}
                                               for row in traces if row["request"]["cmd"] == "solve"])
        self.refresh(directory)
        return args

    def test_actual_canceled_solve_and_exact_successful_retry_are_retained(self):
        result = audit.audit_observed_arm(*self.canceled_fixture())
        self.assertTrue(result["usable_observation"])
        self.assertEqual(result["original_solver_calls"], 2)

    def test_canceled_retry_cannot_substitute_a_different_request(self):
        args = self.canceled_fixture()
        directory = args[-1]
        traces = runner.read_lines(directory / "trace.jsonl")
        traces[5]["request"]["hp_lost_so_far"] = 99
        write_lines(directory / "trace.jsonl", traces)
        write(directory / "solver-calls.json", [{"request": row["request"], "response": row["response"]}
                                               for row in traces if row["request"]["cmd"] == "solve"])
        self.refresh(directory)
        with self.assertRaisesRegex(ValueError, "exact declared successful retry"):
            audit.audit_observed_arm(*args)

    def test_other_solver_error_cannot_be_called_a_recovered_cancellation(self):
        args = self.canceled_fixture()
        directory = args[-1]
        traces = runner.read_lines(directory / "trace.jsonl")
        traces[4]["response"]["error"] = "NullReferenceException: not a cancellation"
        write_lines(directory / "trace.jsonl", traces)
        write(directory / "solver-calls.json", [{"request": row["request"], "response": row["response"]}
                                               for row in traces if row["request"]["cmd"] == "solve"])
        self.refresh(directory)
        with self.assertRaises(ValueError):
            audit.audit_observed_arm(*args)


if __name__ == "__main__":
    unittest.main()
