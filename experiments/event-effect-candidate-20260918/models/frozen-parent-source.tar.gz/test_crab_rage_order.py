"""Observe all 56 original predicted actions against the 423-prefix actual run."""
import copy
import json
from pathlib import Path
import sys
import unittest
import uuid

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from prefix_interventions import read_json,read_lines,require,unchanged
from run_metadata import file_evidence
from inspection.replay_cheese_event import checked_public
from inspection.trial_cosmetic_projection import project_trial_number
import test_liquid_memories as helpers
from combat_executor import CombatExecutor
from replay_evidence import validate_replay_evidence

ORIGINAL=ROOT.parent.with_name('hologram-original-repeat-glam')/'sts2-solver-bridge'
NAME='defect-identity-step-search-20260915a-training-base-023'

class OriginalCrabPlan(unittest.TestCase):
    worker=helpers.LiquidMemoriesTests.worker
    save=helpers.LiquidMemoriesTests.save

    def test_exact_original_plan_simulated_and_compared(self):
        base=read_json(ORIGINAL/'outputs/step-unexpected-toasty-baseline-e972bf192e.json')
        self.assertTrue(base['passed'] and unchanged(base['original_sources']))
        rows=read_lines(ORIGINAL/'outputs'/NAME/'trace.jsonl');original=rows[722]
        self.assertEqual(len(original['response']['actions']),56)
        label='crab-original-plan-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);passed=False;matched=0;result=None;comparisons=[];cosmetic=[]
        try:
            for item in rows[:722]:
                if item['request']['cmd'] in ('solve','combat_meta','choice_meta'):continue
                state=send(item['request']);a,ad=project_trial_number(checked_public(state));b,bd=project_trial_number(checked_public(item['response']))
                self.assertEqual(a,b)
                if ad or bd:cosmetic.append({'prefix':matched,'actual':ad,'original':bd})
                matched+=1
            request=dict(original['request'],cmd='probe_original_plan',original_actions=original['response']['actions'],
                original_turn_setup_choices=original['response']['turn_setup_choices'])
            result=send(request)
            self.assertEqual(result['type'],'original_plan_probe',result)
            replay=result['replay'];self.assertEqual(replay['original_actions'],original['response']['actions'])
            self.assertEqual((replay['actions_received'],replay['actions_observed']),(56,56))
            self.assertTrue(result['observed_live_branch_audit_unchanged'])
            self.assertEqual(result['observation_scope'],'after_original_root_capture')
            self.assertFalse(result['complete_hidden_state_equality_claimed'])
            primary=[i for i in range(723,len(rows)) if rows[i]['request'].get('action') in ('play_card','use_potion','end_turn')]
            self.assertEqual(len(primary),56)
            for index,(at,frame,action) in enumerate(zip(primary,replay['steps'],original['response']['actions'])):
                stop=primary[index+1] if index+1<len(primary) else len(rows)
                after=[(i,rows[i]['response']) for i in range(at,stop) if 'context' in rows[i]['response']][-1]
                real=after[1];pred=frame['state']
                self.assertEqual(frame['action_index'],index);self.assertEqual(frame['action'],action)
                if 'enemies' not in real:
                    comparisons.append({'action_index':index,'actual_trace_index':after[0],'action':action,
                        'projection_available':False,'reason':'actual pending selector has no enemy projection'})
                    continue
                actual_enemies={e['name'].upper():[e['hp'],e['block']] for e in real['enemies']}
                predicted_enemies={e['id']:[e['hp'],e['block']] for e in pred['enemies'] if not e['dead']}
                # Display names in this original two-enemy encounter equal its IDs ignoring case.
                self.assertTrue(set(actual_enemies)<={'CRUSHER','ROCKET'})
                actual={'player_hp':real['player']['hp'],'player_block':real['player']['block'],
                    'energy':real['energy'],'enemies':actual_enemies}
                predicted={k:pred[k] for k in ('player_hp','player_block','energy')};predicted['enemies']=predicted_enemies
                comparisons.append({'action_index':index,'actual_trace_index':after[0],'action':action,
                    'projection_available':True,'actual':actual,'predicted':predicted,'equal':actual==predicted})
            self.assertTrue(all(r.get('equal') is not False for r in comparisons))
            self.assertFalse(replay['final_snapshot']['AllEnemiesDead'])
            self.assertTrue(replay['final_state']['pending_choice'])
            self.assertEqual(replay['final_state']['enemies'][0]['hp'],23)
            self.assertEqual(replay['steps'][41]['state']['enemies'][0]['strength'],9)
            self.assertEqual(replay['steps'][41]['state']['enemies'][0]['crab_rage'],0)
            self.assertTrue(unchanged(base['original_sources']));passed=True
        finally:
            self.save(label,traces,passed=passed,diagnostic_only=True,training_sample=False,
                original_failed_run=NAME,original_sources=base['original_sources'],public_prefix_responses=matched,
                observation=result,comparisons=comparisons,Trial_display_projection=cosmetic,
                source_code=[file_evidence(ROOT/n) for n in ('Program.cs','OriginalPlanDiagnostic.cs','SolverBridge.csproj')],
                hidden_state_or_rng_equality_claimed=False,solver_requested_plan=original['response'])
            bridge.close()
            differences=[r for r in comparisons if r.get('equal') is False]
            print(json.dumps({'label':label,'passed':passed,'matched_prefix':matched,'different_steps':len(differences),
                'first_difference':differences[0] if differences else None}),flush=True)

    def test_first_hit_kill_then_nested_attack_matches_original_action(self):
        base=read_json(ORIGINAL/'outputs/step-unexpected-toasty-baseline-e972bf192e.json')
        self.assertTrue(base['passed'] and unchanged(base['original_sources']))
        rows=read_lines(ORIGINAL/'outputs'/NAME/'trace.jsonl');original=rows[722]
        label='crab-first-hit-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);passed=False;matched=0;probe=None;actual=None
        try:
            for row in rows[:816]:
                if row['request']['cmd'] in ('solve','combat_meta','choice_meta'):continue
                state=send(row['request'])
                self.assertEqual(project_trial_number(checked_public(state))[0],project_trial_number(checked_public(row['response']))[0])
                matched+=1
            self.assertEqual([e['hp'] for e in state['enemies']],[165,1])
            action=copy.deepcopy(original['response']['actions'][41])
            action.update(TargetIndex=1,TargetCombatId=2,TargetName='ROCKET.name')
            probe=send(dict(original['request'],cmd='probe_original_plan',include_turn_setup=False,
                original_actions=[action],original_turn_setup_choices=[]))
            self.assertEqual(probe['type'],'original_plan_probe',probe)
            self.assertTrue(probe['observed_live_branch_audit_unchanged'])
            self.assertEqual(probe['observation_scope'],'after_original_root_capture')
            actual=send(cmd='action',action='play_card',args={'card_index':0,'target_index':1})
            pred=[e for e in probe['replay']['final_state']['enemies'] if not e['dead']]
            self.assertEqual(len(pred),1);self.assertEqual(len(actual['enemies']),1)
            enemy=actual['enemies'][0]
            self.assertEqual((pred[0]['hp'],pred[0]['block']),(enemy['hp'],enemy['block']))
            self.assertEqual(enemy['hp'],165)
            self.assertEqual(pred[0]['strength'],next(p['amount'] for p in enemy['powers'] if p['name']=='Strength'))
            self.assertEqual(pred[0]['strength'],9);self.assertEqual(pred[0]['crab_rage'],0)
            self.assertEqual(probe['replay']['final_state']['player_hp'],actual['player']['hp'])
            self.assertTrue(unchanged(base['original_sources']));passed=True
        finally:
            self.save(label,traces,passed=passed,diagnostic_only=True,training_sample=False,
                legal_action_intervention='Uproar targets Rocket instead of Crusher; no state edits',
                original_sources=base['original_sources'],public_prefix_responses=matched,probe=probe,actual=actual,
                hidden_state_or_rng_equality_claimed=False)
            bridge.close();print(json.dumps({'label':label,'passed':passed,'matched_prefix':matched}),flush=True)

    def test_fresh_original_solver_finishes_crab_combat_with_real_outcome(self):
        base=read_json(ORIGINAL/'outputs/step-unexpected-toasty-baseline-e972bf192e.json')
        self.assertTrue(base['passed'] and unchanged(base['original_sources']))
        rows=read_lines(ORIGINAL/'outputs'/NAME/'trace.jsonl')
        label='crab-fresh-solver-'+uuid.uuid4().hex[:10]
        bridge,traces,send=self.worker(label);passed=False;matched=0;executor=None;final=None
        try:
            for row in rows[:722]:
                if row['request']['cmd'] in ('solve','combat_meta','choice_meta'):continue
                state=send(row['request'])
                self.assertEqual(project_trial_number(checked_public(state))[0],project_trial_number(checked_public(row['response']))[0])
                matched+=1
            executor=CombatExecutor(send,read_json(ORIGINAL/'outputs'/NAME/'manifest.json')['solver_requested_config'])
            final=executor.advance(state)
            self.assertFalse(final['context']['combat_in_progress'])
            self.assertFalse(final['context']['integrity_recovery_used'])
            self.assertTrue(executor.solve_calls[0]['request']['include_turn_setup'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls,traces)['verified'])
            self.assertTrue(unchanged(base['original_sources']));passed=True
        finally:
            self.save(label,traces,passed=passed,diagnostic_only=True,training_sample=False,
                original_sources=base['original_sources'],public_prefix_responses=matched,actual_final=final,
                solver_calls=executor.solve_calls if executor else [],hidden_state_or_rng_equality_claimed=False)
            bridge.close();print(json.dumps({'label':label,'passed':passed,'matched_prefix':matched,
                'decision':final.get('decision') if final else None,'hp':final.get('player',{}).get('hp') if final else None}),flush=True)

if __name__=='__main__':unittest.main(verbosity=2)
