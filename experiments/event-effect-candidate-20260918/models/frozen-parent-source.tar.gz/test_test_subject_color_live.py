"""Artificial original-engine TestSubject forms; never training observations."""
import copy
import json
import time
import unittest
import uuid

from probe import Bridge, ROOT
from run_metadata import file_evidence


class TestSubjectColorLiveTests(unittest.TestCase):
    def test_original_three_forms_and_nemesis_color_hooks_finish(self):
        label = "test-subject-color-" + uuid.uuid4().hex[:12]
        bridge = Bridge(label)
        traces = []
        forms = set()
        saw_intangible = saw_removed_after = False
        started = time.monotonic()

        def send(**request):
            if time.monotonic() - started > 90:
                self.fail("Bounded fixture deadline exceeded; no action retry")
            response = bridge.send(**request)
            traces.append({"request": copy.deepcopy(request), "response": copy.deepcopy(response)})
            self.assertNotEqual(response.get("type"), "error", response)
            self.assertIsNot(response.get("context", {}).get("integrity_recovery_used"), True)
            return response

        try:
            send(cmd="start_run", character="Defect", ascension=10, seed="test-subject-color-fixture-v1")
            send(cmd="set_player", hp=1000, max_hp=1000, deck=["CLAW"] * 8, relics=[], potions=[])
            state = send(cmd="enter_room", type="combat", encounter="TEST_SUBJECT_BOSS")
            for _ in range(250):
                if state.get("context", {}).get("combat_in_progress") is False:
                    break
                self.assertEqual(state.get("decision"), "combat_play")
                enemies = state.get("enemies", [])
                if enemies:
                    self.assertEqual(len(enemies), 1)
                    enemy = enemies[0]
                    forms.add(enemy["max_hp"])
                    powers = {p["name"] for p in enemy.get("powers", [])}
                    if enemy["max_hp"] == 313:
                        self.assertIn("Nemesis", powers)
                        if "Intangible" in powers:
                            saw_intangible = True
                        elif saw_intangible:
                            saw_removed_after = True
                # Pure mechanical fixture script: play the first available Claw.
                # Once third-form Intangible is seen, advance one real turn to
                # exercise the original removal color callback before killing.
                wait_for_removal = saw_intangible and not saw_removed_after
                # Painful Stabs adds real Wounds; those remain in the engine.
                hand = [c for c in state.get("hand", []) if c["id"].split(".")[-1] == "CLAW"]
                if enemies and hand and not wait_for_removal:
                    card = min(hand, key=lambda c: c["index"])
                    self.assertEqual(card["id"].split(".")[-1], "CLAW")
                    state = send(cmd="action", action="play_card",
                                 args={"card_index": card["index"], "target_index": enemies[0]["index"]})
                else:
                    state = send(cmd="action", action="end_turn")
            self.assertFalse(state["context"]["combat_in_progress"])
            self.assertGreater(state["player"]["hp"], 0)
            self.assertEqual(forms, {111, 212, 313})
            self.assertTrue(saw_intangible)
            self.assertTrue(saw_removed_after)
        finally:
            bridge.close()
            with (ROOT / "outputs" / (label + ".json")).open("x", encoding="utf-8") as stream:
                json.dump({"fixture": True, "training_eligible": False,
                    "provenance": "artificial eight-Claw/high-HP fixture; unmodified original monster effects",
                    "versions": {"engine": file_evidence(ROOT.parent / "sts2-cli/lib/sts2.dll"),
                        "godot_stub": file_evidence(ROOT.parent / "sts2-cli/src/Sts2Headless/bin/Debug/net9.0/GodotSharp.dll"),
                        "stub_source": file_evidence(ROOT.parent / "sts2-cli/src/GodotStubs/UI.cs")},
                    "trace": traces, "observed_max_hp_forms": sorted(forms),
                    "observed_intangible": saw_intangible, "observed_removal_after": saw_removed_after},
                    stream, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    unittest.main()
