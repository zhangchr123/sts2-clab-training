"""Whole historical solver envelopes at original public prefixes; not fresh searches."""
import copy
from pathlib import Path
import sys
import unittest
import uuid
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

ROOT_SOURCE = Path('D:/sts2-training/staging/secret-catastrophe-return/sts2-solver-bridge')


class OriginalFullPlans(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def run_plan(self, suffix, generation, card):
        batch = ROOT_SOURCE / 'outputs/defect-contextual-d8-20260914b'
        name = batch.name + '-' + suffix
        source = ROOT_SOURCE / 'outputs' / name
        audit = read_json(batch / f'generation-{generation:02d}' / (name + '-audit.json'))
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'scavenge-full-' + card.lower() + '-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        executor, matched, passed = None, 0, False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
            real_solve = executor.solve
            supplied = False
            def recorded_then_actual(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied: return real_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded_then_actual
            final = executor.advance(before)
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            proofs = [p for p in executor.solve_calls[0].get('replay', [])
                if p.get('kind') in {'original_choice_return_completed', 'original_choice_continuation_completed'}
                and (p['actual_choice_audit']['parent']['card_id'] == card or
                     p.get('actual_root_audit', {}).get('parent', {}).get('card_id') == card)]
            self.assertEqual(len(proofs), 1)
            proof = proofs[0]
            self.assertFalse(proof.get('selection_request_sent', proof.get('automatic_selection_request_sent')))
            self.assertEqual(proof['kind'], 'original_choice_continuation_completed' if suffix == 'g00-c00-s05' else 'original_choice_return_completed')
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            # Corrupt both retained proof and corresponding original trace so
            # rejection must come from the execution contract, not inequality.
            corruptions = [('original_task_completed_successfully', False),
                ('source_is_actual_parent_object', False), ('filter_is_null', False),
                ('selector_pending_after', True), ('selector_invocations_after', -1)]
            if suffix == 'g00-c00-s05':
                corruptions += [('original_task_pending_at_resume', False),
                    ('selector_task_identity_matches', False),
                    ('original_and_selector_return_same_card_objects', False),
                    ('original_source_count_at_entry', 3), ('selector_pending_at_end', True),
                    ('origin_action_id', -1)]
            for field, value in corruptions:
                def corrupt(data):
                    if isinstance(data, dict):
                        for key in list(data):
                            if key == field: data[key] = value
                            else: corrupt(data[key])
                    elif isinstance(data, list):
                        for item in data: corrupt(item)
                bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                corrupt(bad_calls)
                corrupt(bad_traces)
                with self.subTest(contract_corruption=field), self.assertRaises((ValueError, RuntimeError)):
                    validate_replay_evidence(bad_calls, bad_traces)
            self.assertIn(final['decision'], ('card_reward', 'map_select', 'game_over'))
            for mutation in ('missing', 'submitted', 'identity', 'task', 'counter', 'plan'):
                bad = copy.deepcopy(executor.solve_calls)
                target = next(p for p in bad[0]['replay'] if p == proof)
                if mutation == 'missing': bad[0]['replay'].remove(target)
                elif mutation == 'submitted': target['selection_request_sent'] = True
                elif mutation == 'plan': target['plan']['SourceId'] = 'UNRELATED'
                else:
                    event = target['actual_choice_audit']['original_returns'][0]
                    if mutation == 'identity': event['source_is_actual_parent_object'] = False
                    elif mutation == 'task': event['original_task_completed_successfully'] = False
                    else: event['selector_invocations_after'] += 1
                with self.assertRaises(ValueError): validate_replay_evidence(bad, traces)
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, origin='recorded_full_solver_envelope_diagnostic',
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                public_prefix_responses_verified=matched, original_source=audit['actual_source_evidence'],
                solver_calls=executor.solve_calls if executor else [], hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_original_scavenge_manual_then_singleton_full_plan(self):
        self.run_plan('g00-c00-s05', 0, 'SCAVENGE')

    def test_original_scavenge_two_empty_returns_full_plan(self):
        self.run_plan('g00-c05-s05', 0, 'SCAVENGE')


if __name__ == '__main__': unittest.main()
