"""Original Crystal Sphere effects under explicit blind actions; never training data."""
import json
from collections import Counter
import unittest
import uuid

from probe import Bridge, ROOT


class CrystalSphereTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.b = Bridge(self.label)
        self.requests = []

    def tearDown(self):
        (ROOT / "outputs" / f"{self.label}.json").write_text(json.dumps({
            "provenance": "artificial Crystal Sphere event fixture; not training data",
            "hidden_state_access": False,
            "requests": self.requests,
            "responses": self.b.rows,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        self.b.close()

    def send(self, **request):
        self.requests.append(request)
        state = self.b.send(**request)
        self.assertNotEqual(state.get("type"), "error", state)
        return state

    def start(self, option):
        self.send(cmd="start_run", character="Defect", ascension=10, seed="integrity-crystal-sphere-1")
        self.send(cmd="set_player", gold=300)
        before = self.send(cmd="enter_room", type="event", event="CRYSTAL_SPHERE")
        selected = next(o for o in before["options"] if o["text_key"].endswith("." + option))
        state = self.send(cmd="action", action="choose_option", args={"option_index": selected["index"]})
        self.check_visible(state)
        return before, selected, state

    def check_visible(self, state):
        self.assertEqual(state["decision"], "crystal_sphere", state)
        self.assertEqual(state["grid_size"], {"x": 11, "y": 11})
        self.assertEqual(state["tools"], ["small", "big"])
        self.assertGreater(state["divinations_left"], 0)
        self.assertEqual(len(state["cells"]), 121)
        self.assertEqual(len({(c["x"], c["y"]) for c in state["cells"]}), 121)
        for cell in state["cells"]:
            expected = {"x", "y", "hidden"} if cell["hidden"] else {"x", "y", "hidden", "item_kind"}
            self.assertEqual(set(cell), expected, "Fog-covered cells cannot contain item data")
        for item in state["revealed_items"]:
            self.assertLessEqual(set(item), {"kind", "is_good", "rarity", "large_gold"})
        self.assertTrue(any(c["hidden"] for c in state["cells"]))
        self.assertIs(state["context"]["integrity_recovery_used"], False)

    def click(self, state, x, y, tool):
        self.assertTrue(next(c for c in state["cells"] if (c["x"], c["y"]) == (x, y))["hidden"])
        result = self.send(cmd="action", action="crystal_sphere_reveal", args={"x": x, "y": y, "tool": tool})
        if result.get("decision") == "crystal_sphere":
            self.check_visible(result)
            self.assertEqual(result["divinations_left"], state["divinations_left"] - 1)
            before = {(c["x"], c["y"]) for c in state["cells"] if not c["hidden"]}
            after = {(c["x"], c["y"]) for c in result["cells"] if not c["hidden"]}
            radius = 1 if tool == "big" else 0
            expected = {(cx, cy) for cx in range(max(0, x-radius), min(11, x+radius+1))
                        for cy in range(max(0, y-radius), min(11, y+radius+1))}
            self.assertEqual(after, before | expected)
        return result

    def settle_rewards(self, state):
        selected = []
        for _ in range(8):
            if state.get("decision") != "card_reward":
                break
            self.assertTrue(state["from_event"])
            card = state["cards"][0]
            selected.append(card["id"])
            state = self.send(cmd="action", action="select_card_reward", args={"card_index": card["index"]})
        self.assertEqual(state.get("decision"), "map_select", state)
        self.assertIs(state["context"]["integrity_recovery_used"], False)
        return state, selected

    def test_payment_plan_blind_six_clicks_preserve_debt_and_settle_rewards(self):
        before, _, state = self.start("PAYMENT_PLAN")
        self.assertEqual(state["divinations_left"], 6)
        self.assertEqual(state["player"]["gold"], before["player"]["gold"])
        expected = Counter(c["id"] for c in before["player"]["deck"])
        expected["CARD.DEBT"] += 1
        self.assertEqual(Counter(c["id"] for c in state["player"]["deck"]), expected)
        # Predetermined geometric route; no board Item/position/RNG inspection.
        for x, y in [(2, 2), (5, 2), (8, 2), (2, 5), (5, 5)]:
            state = self.click(state, x, y, "big")
            self.assertEqual(state["player"]["gold"], 300, "Gold remains unsettled until the last click")
            self.assertEqual(sum(c["id"] == "CARD.DOUBT" for c in state["player"]["deck"]), 1)
        expected["CARD.DOUBT"] += 1
        visible_gold = sum(30 if i["large_gold"] else 10 for i in state["revealed_items"] if i["kind"] == "Gold")
        self.assertEqual(visible_gold, 90)
        self.assertEqual(sum(i["kind"] == "CardReward" and i["rarity"] == "Rare" for i in state["revealed_items"]), 1)
        state = self.click(state, 8, 5, "big")
        self.assertEqual(state["decision"], "card_reward", "Original reward choice must wait for an explicit selection")
        self.assertEqual(Counter(c["id"] for c in state["player"]["deck"]), expected)
        self.assertTrue(all(c["rarity"] == "Rare" for c in state["cards"]))
        state, cards = self.settle_rewards(state)
        self.assertEqual(len(cards), 1)
        for card in cards:
            expected[card] += 1
        actual = Counter(c["id"] for c in state["player"]["deck"])
        self.assertEqual(actual, expected)
        # This frozen blind route's final click completes no further item.
        self.assertEqual(state["player"]["gold"], before["player"]["gold"] + visible_gold)
        self.assertEqual(state["player"]["relics"], before["player"]["relics"])
        self.assertEqual(state["player"]["potions"], before["player"]["potions"])

    def test_paid_three_clicks_validate_bounds_and_tool_without_spending(self):
        before, selected, state = self.start("UNCOVER_FUTURE")
        self.assertEqual(state["divinations_left"], 3)
        self.assertEqual(before["player"]["gold"] - state["player"]["gold"], selected["vars"]["UncoverFutureCost"])
        self.assertEqual(before["player"]["deck"], state["player"]["deck"])
        visible = next(c for c in state["cells"] if not c["hidden"])
        for args in [{"x": -1, "y": 0, "tool": "big"}, {"x": 11, "y": 1, "tool": "small"},
                     {"x": 5, "y": 5, "tool": "unknown"}, {"x": True, "y": 5, "tool": "small"},
                     {"x": visible["x"], "y": visible["y"], "tool": "big"}]:
            request = {"cmd": "action", "action": "crystal_sphere_reveal", "args": args}
            self.requests.append(request)
            self.assertEqual(self.b.send(**request)["type"], "error")
        state = self.click(state, 5, 5, "small")
        state = self.click(state, 2, 2, "big")
        state = self.click(state, 8, 2, "big")
        state, _ = self.settle_rewards(state)
        self.assertEqual(state["player"]["gold"], 300 - selected["vars"]["UncoverFutureCost"] + 40)
        expected = Counter(c["id"] for c in before["player"]["deck"])
        expected["CARD.DOUBT"] += 1
        self.assertEqual(Counter(c["id"] for c in state["player"]["deck"]), expected)
        request = {"cmd": "action", "action": "crystal_sphere_reveal", "args": {"x": 5, "y": 5, "tool": "small"}}
        self.requests.append(request)
        self.assertEqual(self.b.send(**request)["type"], "error")

    def test_skipping_original_card_reward_completes_without_awarding_a_card(self):
        before, _, state = self.start("PAYMENT_PLAN")
        for x, y in [(2, 2), (5, 2), (8, 2), (2, 5), (5, 5), (8, 5)]:
            state = self.click(state, x, y, "big")
        self.assertEqual(state["decision"], "card_reward")
        expected = Counter(c["id"] for c in state["player"]["deck"])
        state = self.send(cmd="action", action="skip_card_reward")
        self.assertEqual(state["decision"], "map_select")
        self.assertEqual(Counter(c["id"] for c in state["player"]["deck"]), expected)
        self.assertEqual(state["player"]["gold"], before["player"]["gold"] + 90)


if __name__ == "__main__":
    unittest.main()
