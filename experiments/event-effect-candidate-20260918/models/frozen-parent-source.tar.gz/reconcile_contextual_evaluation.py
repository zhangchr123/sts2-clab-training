"""Recompute a closed paired evaluation from immutable raw run evidence."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from boss_progress import observed_progress
from evaluate_contextual_run import VERSION, summarize, evaluation_order
from prefix_interventions import read_json, read_lines, require, unchanged
from run_metadata import file_evidence
from train_contextual_run import ROOT, write_new


def reconcile(path, output):
    path = Path(path).resolve()
    protocol = read_json(path)
    comparison = read_json(path.parent / 'comparison.json')
    require(protocol['schema_version'] == VERSION and protocol['planned_games'] == 60 and comparison['source_protocol'] == file_evidence(path),
            'Unclosed or mismatched evaluation')
    require(unchanged(protocol['frozen_sources']), 'Frozen evaluation sources changed')
    training = read_json(protocol['source_training_protocol']['path'])
    require(protocol['seeds'] == training['reserved_evaluation_seeds']
        and protocol['order'] == evaluation_order(protocol['seeds'], training['name']), 'Allocation changed')
    completion = read_json(Path(protocol['source_training_protocol']['path']).parent / 'training-completed.json')
    final_generation = read_json(completion['generations'][-1]['path'])
    require(protocol['models']['trained'] == final_generation['best_candidate_artifact'], 'Different selected model')
    zero = read_json(protocol['models']['zero']['path'])
    require(all(v == 0 for v in zero['parameters'].values()), 'Control is not zero parameters')
    records, audit_sources = [], []
    for allocation in protocol['order']:
        label = f"{protocol['name']}-{allocation['arm']}-{allocation['seed_index']:03d}"
        source = path.parent / (label + '-audit.json')
        row = read_json(source)
        run = ROOT / 'outputs' / label
        report, manifest = read_json(run / 'report.json'), read_json(run / 'manifest.json')
        require(row['run_id'] == label and row['seed'] == allocation['seed'] and row['arm'] == allocation['arm'],
                'Missing or swapped arm/seed')
        require(row['report'] == report and row['outcome'] == report['outcome']
            and row['audit_passed'] is True and not row['issues'], 'Failed raw audit or report mismatch')
        require(unchanged(row['actual_source_evidence']), 'Raw audited sources changed')
        require(manifest['seed'] == allocation['seed'] and manifest['character'] == 'Defect'
            and manifest['ascension'] == 10 and manifest['mode'] == 'standard'
            and manifest['solver_requested_config'] == protocol['solver_config']
            and manifest['provenance']['policy_source'] == protocol['models'][allocation['arm']]
            and manifest['provenance']['llm_involved'] is False
            and manifest['provenance']['origin'] == 'natural', 'Actual run scope/model differs from allocation')
        goal = observed_progress(read_lines(run / 'trace.jsonl'), natural=True, expected_seed=allocation['seed'])
        success = report['outcome'] in {'victory', 'defeat'} and not goal['errors'] and goal['natural_goal_success']
        require(goal == row['goal'] and success == row['goal_success'], 'Actual first boss result differs from receipt')
        records.append(row); audit_sources.append(file_evidence(source))
    expected = summarize(records, protocol['seeds'])
    expected['schema_version'] = protocol['schema_version']
    expected.update(source_protocol=file_evidence(path), run_audits=audit_sources)
    require(comparison == expected, 'Comparison does not match all raw outcomes and actual boss evidence')
    require(unchanged(protocol['frozen_sources']), 'Inputs changed during reconciliation')
    result = {'passed': True, 'actual_games': len(records), 'distinct_seeds': len(protocol['seeds']),
        'arms': expected['arms'], 'paired_first_boss_results': expected['paired_first_boss_results'],
        'source_protocol': file_evidence(path), 'source_comparison': file_evidence(path.parent / 'comparison.json'),
        'raw_audit_sources': audit_sources, 'universal_success_proven': False,
        'reconciler_source': file_evidence(Path(__file__).resolve())}
    write_new(output, result)
    return result


if __name__ == '__main__':
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = reconcile(args.protocol, args.output)
    print(json.dumps({k: result[k] for k in ('passed', 'actual_games', 'distinct_seeds', 'arms')}))
