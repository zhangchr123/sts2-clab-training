"""Sum existing single-card residual features for known public multi-card acquisition.

The public pre-selection deck supplies context; previously selected occurrences
add only to the duplicate count. This is a linear approximation, not a simulated
post-acquisition deck, add-to-deck hook, card synergy, or new legal game action.
Unknown/remove/upgrade/transform selectors deliberately do not enter this path.
"""
from card_identity_features import PARAMETERS as ID_PARAMETERS, features as identity_features
from contextual_policy import PARAMETERS as CONTEXT_PARAMETERS, residual_features as contextual_features
from decision_data import DataContractError
from initial_policy import FEATURE_NAMES, card_id

PARAMETERS = (*CONTEXT_PARAMETERS, *ID_PARAMETERS)


def features(state, row, candidate):
    if row['request'] != candidate['request']:
        raise DataContractError('Acquisition row/candidate mismatch')
    action = row['request']['action']
    ordered = action == 'select_cards' and row['features'].get('selection_acquire') == 1.
    if action != 'select_bundle' and not ordered:
        return None
    cards = candidate['evidence']['cards']
    details = row['card_detail']
    if not isinstance(cards, list) or not isinstance(details, list) or len(cards) != len(details):
        raise DataContractError('Acquisition detail must cover every selected card exactly once')
    result = dict.fromkeys(PARAMETERS, 0.)
    seen = {}
    for card, exported in zip(cards, details):
        if ordered:
            if exported.get('card_id') != card.get('id'):
                raise DataContractError('Ordered acquisition detail differs from the selected card')
            detail = exported['card_detail']
        else:
            detail = exported
        values = dict.fromkeys(FEATURE_NAMES, 0.)
        values.update(detail['features'])
        identity = card_id(card)
        values['existing_copies'] += seen.get(identity, 0)
        seen[identity] = seen.get(identity, 0) + 1
        values['prior_association'] = detail['prior']['score']
        for tag in detail['mechanisms']:
            values['mechanism_' + tag] = 1.
        # Reuse the feature extractor's individual-acquisition role only.
        # This descriptor is not emitted or executed as a game request.
        role = {'action': 'select_card_reward'}
        component_row = {'request': role, 'features': values}
        component_candidate = {'request': role, 'evidence': card}
        component = contextual_features(state, component_row, component_candidate)
        component.update(identity_features(component_row, component_candidate))
        if tuple(component) != PARAMETERS:
            raise DataContractError('Acquisition parameter schema drift')
        for name in PARAMETERS:
            result[name] += component[name]
    return result
