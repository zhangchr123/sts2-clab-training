"""Independent public-state interactions for a future observational model.

Preserves all 101 v3 features, legal requests, coverage and scores. This module
does not choose, train, use RNG, set weights, or claim causal/strategic benefit.
The orb count is a strict lower bound: copies of three verified direct Frost
source cards, not all orb sources or future in-combat channels.
"""
from __future__ import annotations

import copy
import math
from collections.abc import Mapping

from decision_data import DataContractError, enumerate_candidates, materialize_candidate, state_hash
from initial_policy import ACTION_NAMES, FEATURE_NAMES as BASE_FEATURE_NAMES, POLICY_VERSION, card_mechanisms
from mechanism_facts import FACTS, verified_source


VERSION = "public-state-candidate-interactions-v1"
DIRECT_FROST_IDS = ("COLD_SNAP", "COOLHEADED", "GLACIER")
HEALTH_TERMS = ("rest_heal", "rest_smith", "map_monster", "map_elite", "map_rest", "base_block_per_cost")
FROST_TERMS = ("sustained_focus", "temporary_focus", "decaying_focus", "orb_capacity")
INTERACTION_NAMES = (
    *["ix_health_deficit_x_" + n for n in HEALTH_TERMS],
    *["ix_direct_frost_source_cards_x_" + n for n in FROST_TERMS],
    "ix_public_spend_fraction_of_gold", "ix_held_potions_x_discard_potion",
    "ix_missing_health", "ix_missing_deck", "ix_missing_gold", "ix_missing_spend",
    "ix_missing_potion_inventory", "ix_orb_source_coverage_partial",
)
FEATURE_NAMES = (*BASE_FEATURE_NAMES, *INTERACTION_NAMES)
ORB_TAGS = {"lightning_source", "frost_source", "dark_source", "plasma_source", "random_orb_source"}


def _require(ok, message):
    if not ok:
        raise DataContractError(message)


def _number(value):
    return float(value) if type(value) in (int, float) and math.isfinite(value) and value >= 0 else None


def _identity(value, category):
    if not isinstance(value, Mapping) or not isinstance(value.get("id"), str):
        return None
    parts = value["id"].split(".")
    if len(parts) > 2 or (len(parts) == 2 and parts[0] != category):
        return None
    identity = parts[-1]
    return identity if identity and all(c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789" for c in identity) else None


def _public_inputs(state):
    player = state.get("player")
    player = player if isinstance(player, Mapping) else {}
    hp, maximum = _number(player.get("hp")), _number(player.get("max_hp"))
    health_known = hp is not None and maximum is not None and maximum > 0 and hp <= maximum
    deck = player.get("deck")
    deck_known = isinstance(deck, list) and all(_identity(c, "CARD") is not None for c in deck)
    # Count deck copies, not channels: Glacier is one source card, despite Frost2.
    frost_count = sum(_identity(c, "CARD") in DIRECT_FROST_IDS for c in deck) if deck_known else None
    unquantified = sorted({_identity(c, "CARD") for c in deck if _identity(c, "CARD") not in DIRECT_FROST_IDS
                           and card_mechanisms(c) & ORB_TAGS}) if deck_known else []
    potions = player.get("potions")
    potions_known = isinstance(potions, list) and all(_identity(p, "POTION") is not None for p in potions)
    if potions_known:
        # Indices are not inputs. Optional aggregate fields only check completeness.
        capacity, empty = player.get("potion_capacity"), player.get("potion_empty_slots")
        if capacity is not None:
            potions_known = type(capacity) is int and capacity >= len(potions)
        if empty is not None:
            potions_known = potions_known and type(empty) is int and empty >= 0
        if capacity is not None and empty is not None and potions_known:
            potions_known = len(potions) + empty == capacity
    return {"health_deficit": 1 - hp/maximum if health_known else None,
            "direct_frost_source_cards": frost_count, "gold": _number(player.get("gold")),
            "held_potions": len(potions) if potions_known else None,
            "unquantified_tagged_orb_source_ids": unquantified}


def _extend_row(row, candidate, inputs):
    base = row["features"]
    action = candidate["request"]["action"]
    _require(isinstance(base, Mapping) and set(base) == set(BASE_FEATURE_NAMES)
             and all(type(v) in (int, float) and math.isfinite(v) for v in base.values()),
             "Interaction extension requires the exact finite 101-feature v3 schema")
    _require(all(base["action_" + name] == float(name == action) for name in ACTION_NAMES)
             and base["is_skip"] == float(candidate["is_skip"]),
             "Base action features disagree with the legal candidate")
    features = copy.deepcopy(base)
    features.update({name: 0. for name in INTERACTION_NAMES})
    missing = ["orb_source_registry_partial_three_direct_frost_ids_only"]
    features["ix_orb_source_coverage_partial"] = 1.
    health, frost = inputs["health_deficit"], inputs["direct_frost_source_cards"]
    for name in HEALTH_TERMS:
        if health is not None:
            features["ix_health_deficit_x_" + name] = health * base[name]
    if health is None:
        features["ix_missing_health"] = 1.
        missing.append("public_hp_and_positive_max_hp")
    for name in FROST_TERMS:
        if frost is not None:
            features["ix_direct_frost_source_cards_x_" + name] = frost * base["mechanism_" + name]
    if frost is None:
        features["ix_missing_deck"] = 1.
        missing.append("complete_public_deck_with_card_ids")
    if inputs["unquantified_tagged_orb_source_ids"]:
        missing.append("tagged_orb_sources_without_verified_channel_quantity")
    spend = 0.
    if action in {"buy_card", "buy_relic", "buy_potion"}:
        spend = _number(candidate["evidence"].get("cost"))
    elif action == "remove_card":
        spend = _number(candidate["evidence"].get("card_removal_cost"))
    # Base v3 omits gold_spend on relic/potion purchases. Read the already public
    # legal candidate's price without changing that base feature or its score.
    if spend is None:
        features["ix_missing_spend"] = 1.
        missing.append("public_candidate_purchase_or_removal_price")
    if inputs["gold"] is None:
        features["ix_missing_gold"] = 1.
        missing.append("public_current_gold")
    elif spend is not None:
        features["ix_public_spend_fraction_of_gold"] = spend / max(1., inputs["gold"])
    if inputs["held_potions"] is None:
        features["ix_missing_potion_inventory"] = 1.
        missing.append("complete_public_potion_inventory")
    else:
        features["ix_held_potions_x_discard_potion"] = inputs["held_potions"] * base["action_discard_potion"]
    _require(all(math.isfinite(features[n]) for n in INTERACTION_NAMES), "Nonfinite interaction result")
    return features, missing, spend


def extend_scoring_packet(state, packet):
    """Extend evaluated legal candidates only; original scores/coverage are kept.

    Accepts either full explicit scoring or a validated subset, including an
    implicit ordered-selection space. It neither enumerates new proposals nor
    upgrades partial evaluation to full. Missing raw fields yield zero products
    plus explicit numeric masks and missing evidence, never guessed quantities.
    """
    _require(isinstance(state, Mapping) and isinstance(packet, dict) and packet.get("state_hash") == state_hash(state),
             "Scoring packet is not bound to this public state")
    _require(packet.get("feature_policy_version", packet.get("policy_version")) == POLICY_VERSION,
             "Interaction extension accepts only base v3 features, not an already extended packet")
    source = verified_source()
    _require(packet.get("mechanism_facts") == source, "Feature mechanism facts differ from the verified engine registry")
    for identity in DIRECT_FROST_IDS:
        channel = FACTS.get(identity, {}).get("channel", {})
        _require(channel.get("orb") == "Frost" and type(channel.get("count")) is int and channel["count"] > 0,
                 "Direct Frost registry changed; version the interaction definition before extending")
    actual = enumerate_candidates(state)
    _require(actual["complete"], actual.get("reason") or "Incomplete legal action space")
    rows = packet.get("scores")
    _require(isinstance(rows, list) and bool(rows), "No evaluated candidate rows")
    _require(all(isinstance(row, Mapping) and isinstance(row.get("candidate_id"), str)
                 and "features" in row for row in rows), "Malformed evaluated candidate row")
    _require(len({r.get("candidate_id") for r in rows}) == len(rows), "Duplicate evaluated candidates")
    candidates = [materialize_candidate(actual, row.get("request")) for row in rows]
    _require(all(row.get("candidate_id") == c["candidate_id"] and row.get("is_skip") is c["is_skip"]
                 for row, c in zip(rows, candidates)), "Evaluated request or candidate identity is invalid")
    count = actual["candidate_count"]
    _require(type(packet.get("candidate_count")) is int and packet["candidate_count"] == count,
             "Candidate space size differs from the real legal space")
    _require(packet.get("evaluated_candidates_complete") is (len(rows) == count),
             "Candidate evaluation coverage differs from the actual evaluated requests")
    result = copy.deepcopy(packet)
    inputs = _public_inputs(state)
    for row, candidate in zip(result["scores"], candidates):
        features, missing, spend = _extend_row(row, candidate, inputs)
        row.update(features=features, interaction_missing=missing,
                   interaction_evidence={"public_inputs": copy.deepcopy(inputs), "public_spend": spend})
    definition = {"version": VERSION, "base_feature_version": POLICY_VERSION,
        "feature_names": list(FEATURE_NAMES), "health_terms": list(HEALTH_TERMS), "frost_terms": list(FROST_TERMS),
        "direct_frost_source_ids": list(DIRECT_FROST_IDS), "frost_count_semantics": "deck_copies_not_channel_quantity",
        "gold_normalization": "public_candidate_spend_divided_by_max_1_current_gold",
        "potion_semantics": "held_count_before_discard_not_potion_value",
        "complete_orb_source_coverage": False,
        "zero_frost_count_semantics": "no_verified_direct_Frost_sources_not_no_orb_sources",
        "missing_products": "zero_plus_explicit_numeric_mask_and_missing_evidence"}
    result.update(feature_policy_version=VERSION, base_feature_policy_version=POLICY_VERSION,
        feature_names=list(FEATURE_NAMES), interaction_feature_source={**definition,
            "definition_sha256": state_hash(definition), "mechanism_facts": copy.deepcopy(source)},
        interaction_semantics="public_state_candidate_products_for_observational_models_no_causal_claim",
        interaction_scores_applied=False)
    return result
