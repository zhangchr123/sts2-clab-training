"""Public circulation descriptors; retain all original 227 features.

Six directed tag-density interactions describe the pre-acquisition deck. They
do not assert effect quantities, usable loops, trigger rates, or learned value.
Known bundles/ordered acquisitions sum descriptors for each selected occurrence;
no post-acquisition deck or add-to-deck hook is simulated.
"""
import math
from collections.abc import Mapping

from card_identity_policy import PARAMETERS as ORIGINAL_PARAMETERS, residual_features as original_features
from decision_data import DataContractError
from initial_policy import card_mechanisms

TAGS = ('draw', 'energy', 'discard_retrieval')
INTERACTIONS = tuple((candidate, deck) for candidate in TAGS for deck in TAGS if candidate != deck)
EXTRA_PARAMETERS = tuple(f'circulation_{a}_with_{b}_density' for a, b in INTERACTIONS)
PARAMETERS = (*ORIGINAL_PARAMETERS, *EXTRA_PARAMETERS)


def _valid_card(card):
    if not isinstance(card, Mapping) or not isinstance(card.get('id'), str) or not card['id']:
        raise DataContractError('Circulation requires identified public cards')
    return card


def extra_features(state, row, candidate):
    if row['request'] != candidate['request']:
        raise DataContractError('Circulation row/candidate mismatch')
    result = dict.fromkeys(EXTRA_PARAMETERS, 0.)
    action = row['request']['action']
    if action in {'select_card_reward', 'buy_card'}:
        cards = [candidate['evidence']]
    elif action == 'select_bundle' or (
            action == 'select_cards' and row['features'].get('selection_acquire') == 1.):
        cards = candidate['evidence']['cards']
        if not isinstance(cards, list):
            raise DataContractError('Circulation acquisition cards must be a list')
    else:
        return result
    if not cards:
        return result
    player = state.get('player', {})
    deck = player.get('deck')
    if not isinstance(deck, list) or not deck:
        raise DataContractError('Circulation requires a nonempty public deck')
    exported_size = player.get('deck_size')
    if exported_size is not None and (type(exported_size) is not int or exported_size != len(deck)):
        raise DataContractError('Circulation public deck size differs')
    deck_tags = [card_mechanisms(_valid_card(c)) for c in deck]
    density = {tag: sum(tag in tags for tags in deck_tags) / len(deck) for tag in TAGS}
    for card in cards:
        tags = card_mechanisms(_valid_card(card))
        for name, (candidate_tag, deck_tag) in zip(EXTRA_PARAMETERS, INTERACTIONS):
            result[name] += float(candidate_tag in tags) * density[deck_tag]
    return result


def features(state, row, candidate):
    original = original_features(state, row, candidate)
    if tuple(original) != ORIGINAL_PARAMETERS:
        raise DataContractError('Original 227-feature schema differs')
    return {**original, **extra_features(state, row, candidate)}


def zero_extend(parameters):
    if set(parameters) != set(ORIGINAL_PARAMETERS) or any(
            type(v) not in (int, float) or not math.isfinite(v) or abs(v) > 4
            for v in parameters.values()):
        raise DataContractError('Invalid original 227-parameter vector')
    return {**{k: parameters[k] for k in ORIGINAL_PARAMETERS}, **dict.fromkeys(EXTRA_PARAMETERS, 0.)}
