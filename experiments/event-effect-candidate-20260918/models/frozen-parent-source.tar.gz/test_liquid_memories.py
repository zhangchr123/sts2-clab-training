"""Actual original-engine potion returns; fixtures are never training samples."""
import copy
import json
import unittest
import uuid

from combat_executor import CombatExecutor
from decision_data import state_hash
from inspection.diagnose_boss_search_budget import replay
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence


class LiquidMemoriesTests(unittest.TestCase):
    def worker(self, label):
        bridge = Bridge(label)
        traces = []
        def send(request=None, phase=None, source_index=None, **kwargs):
            request = kwargs if request is None else request
            response = bridge.send(**request)
            traces.append({'request': copy.deepcopy(request), 'response': copy.deepcopy(response),
                           'phase': phase, 'source_index': source_index})
            self.assertNotEqual(response.get('type'), 'error', response)
            return response
        return bridge, traces, send

    def save(self, label, traces, **extra):
        (ROOT / 'outputs' / (label + '.json')).write_text(json.dumps({
            'training_eligible': False, 'natural_win_rate_sample': False,
            'traces': traces, **extra}, ensure_ascii=False), encoding='utf-8')

    def test_original_failed_prefix_and_exact_recorded_potion_action(self):
        source = ROOT / 'outputs/defect-whole-run-cem-20260914c-g01-c03-s07'
        receipt = read_json(ROOT / 'outputs/defect-whole-run-cem-20260914c/generation-01' /
                            (source.name + '-audit.json'))
        self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        self.assertEqual(rows[89]['response']['discard_pile_count'], 1)
        gate = {'trace_index': 89, 'public_hash': state_hash(checked_public(rows[89]['response']))}
        label = 'liquid-prefix-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        executor = None
        try:
            state, checks = replay(rows, gate, send)
            # The historical solver plan supplies this one diagnostic action.
            # It is not represented as a fresh solve or natural training sample.
            historical = copy.deepcopy(rows[85])
            action = next(a for a in historical['response']['actions']
                          if a.get('Kind') == 'UsePotion' and a.get('PotionId') == 'LIQUID_MEMORIES')
            observer = CombatExecutor(send)
            observer.solve_calls = [historical]
            observer.last_action_request = rows[91]['request']
            after = send(rows[91]['request'], phase='recorded_solver_action', source_index=91)
            self.assertTrue(observer.resolve_original_automatic_choice(state, after, action))
            proof = observer.solve_calls[0]['replay'][0]
            self.assertEqual(proof['actual_choice_audit']['parent']['potion_id'], 'LIQUID_MEMORIES')
            self.assertFalse(proof['selection_request_sent'])
            self.assertIn('energy=False:1', proof['selected_cards'][0]['StateKey'])
            executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
            final = executor.advance(after)
            self.assertIn(final['decision'], {'card_reward', 'game_over', 'map_select'})
            self.assertFalse(final['context']['integrity_recovery_used'])
            self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
            self.save(label, traces, origin='original_public_prefix_diagnostic',
                      prefix_responses_verified=checks, full_state_or_rng_equality_claimed=False,
                      historical_solver_source=receipt['actual_source_evidence'],
                      historical_solve_trace_index=85, historical_potion_choice=action,
                      actual_return_proof_for_recorded_action=proof,
                      solver_calls=executor.solve_calls, passed=True)
        finally:
            bridge.close()

    def test_actual_singleton_pre_cost_return_and_multioption_selector(self):
        for count in (1, 2):
            with self.subTest(discard_count=count):
                label = 'liquid-options-' + str(count) + '-' + uuid.uuid4().hex[:10]
                bridge, traces, send = self.worker(label)
                try:
                    send(cmd='start_run', character='Defect', ascension=10, seed='liquid-options-fixture')
                    send(cmd='set_player', hp=1000, max_hp=1000, deck=['STRIKE_DEFECT'] * 6,
                         relics=[], potions=['LIQUID_MEMORIES'])
                    state = send(cmd='enter_room', type='combat', encounter='SHRINKER_BEETLE_WEAK')
                    for _ in range(count):
                        state = send(cmd='action', action='play_card', args={'card_index': 0, 'target_index': 0})
                    self.assertEqual(state['discard_pile_count'], count)
                    after = send(cmd='action', action='use_potion', args={'potion_index': 0})
                    returns = after['choice_audit']['original_returns']
                    if count == 1:
                        self.assertEqual(after['decision'], 'combat_play')
                        self.assertEqual(len(returns), 1)
                        self.assertEqual(returns[0]['raw_source_count_at_entry'], 1)
                        self.assertEqual(returns[0]['effect_callsite'], 'LiquidMemories.OnUse')
                        self.assertIn('energy=False:1', returns[0]['returned_cards'][0]['StateKey'])
                        self.assertEqual(after['discard_pile_count'], 0)
                    else:
                        self.assertEqual(after['decision'], 'card_select')
                        self.assertEqual(returns, [])
                        self.assertEqual(len(after['cards']), 2)
                        final = send(cmd='action', action='select_cards', args={'indices': '1'})
                        self.assertEqual(final['decision'], 'combat_play')
                        self.assertEqual(final['discard_pile_count'], 1)
                    self.save(label, traces, origin='artificial_fixture', passed=True)
                finally:
                    bridge.close()


if __name__ == '__main__':
    unittest.main()
