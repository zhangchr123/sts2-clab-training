"""Original Echo Form/Neows Fury prefixes with zero card ReplayCount.

Historical full solver envelopes are diagnostic inputs, never natural samples.
"""
import copy
from pathlib import Path
import unittest
import uuid

from combat_executor import CombatExecutor, choice_plans
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

SOURCE = Path('D:/sts2-training/staging/card-identity-residual/sts2-solver-bridge')
NAME = 'defect-identity-cem-20260914a'


class NeowsZeroReplayTests(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def run_original(self, arm, *, baseline=False):
        name = f'{NAME}-generation-00-{arm}-014'
        run = SOURCE / 'outputs' / name
        audit = read_json(SOURCE / 'outputs' / NAME / 'generation-00' / (name + '-audit.json'))
        self.assertEqual(audit['outcome'], 'environment_error')
        self.assertTrue(audit['audit_passed'] and unchanged(audit['actual_source_evidence']))
        rows = read_lines(run / 'trace.jsonl')
        gate = max(i for i, row in enumerate(rows) if row['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        fury = [a for a in original['response']['actions'] if a.get('CardId') == 'NEOWS_FURY']
        self.assertEqual(len(fury), 1)
        self.assertEqual(fury[0]['ReplayCount'], 0)
        self.assertIn('|replay=0|', fury[0]['CardStateKey'])
        self.assertEqual(len(choice_plans(fury[0])), 2)
        label = f'neows-zero-{arm}-' + ('baseline-' if baseline else 'fixed-') + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        executor, matched, passed = None, 0, False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}:
                    continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(run / 'manifest.json')['solver_requested_config'])
            actual_solve = executor.solve
            supplied = False
            def first_recorded(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied:
                    return actual_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = first_recorded
            if baseline:
                with self.assertRaisesRegex(RuntimeError, 'Expected solver choice surface'):
                    executor.advance(before)
                self.assertEqual(executor.last_state['decision'], 'card_reward')
            else:
                final = executor.advance(before)
                self.assertEqual(final['decision'], 'card_reward')
                self.assertFalse(final['context']['combat_in_progress'])
                self.assertEqual(executor.solve_calls[0]['response'], original['response'])
                self.assertTrue(validate_replay_evidence(executor.solve_calls, traces)['verified'])
                proofs = [p for p in executor.solve_calls[0].get('replay', [])
                    if p.get('kind') == 'original_choice_continuation_ended_combat']
                self.assertEqual(len(proofs), 1)
                proof = proofs[0]
                self.assertEqual(proof['remaining_plans_not_executed'], choice_plans(fury[0])[1:])
                self.assertFalse(proof['remaining_selection_request_sent'])
                self.assertTrue(proof['remaining_battle_plan_stopped'])
                self.assertEqual(proof['selected_cards_for_remaining_plans'], [])
                for field, value in [('original_task_completed_successfully', False),
                    ('selector_task_identity_matches', False), ('original_play_cancelled', True),
                    ('original_branch_context_verified', False), ('original_play_action_id', -1),
                    ('source_is_actual_parent_object', False), ('filter_is_null', True),
                    ('selector_invocations_after', -1), ('selector_pending_after', True),
                    ('returned_count', 1), ('original_play_target_combat_id', -1)]:
                    def corrupt(data):
                        if isinstance(data, dict):
                            for key in data:
                                if key == field:
                                    data[key] = value
                                else:
                                    corrupt(data[key])
                        elif isinstance(data, list):
                            for item in data:
                                corrupt(item)
                    bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                    corrupt(bad_calls)
                    corrupt(bad_traces)
                    with self.subTest(field=field), self.assertRaises((ValueError, RuntimeError)):
                        validate_replay_evidence(bad_calls, bad_traces)
                continued = copy.deepcopy(traces)
                continued.append({'request': {'cmd': 'action', 'action': 'end_turn'}, 'response': final})
                with self.assertRaises(ValueError):
                    validate_replay_evidence(executor.solve_calls, continued)
            self.assertTrue(unchanged(audit['actual_source_evidence']))
            passed = True
        finally:
            self.save(label, traces, passed=passed, baseline=baseline,
                origin='recorded_full_original_solver_envelope_diagnostic',
                public_prefix_responses_verified=matched, original_source=audit['actual_source_evidence'],
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                hidden_state_or_rng_equality_claimed=False,
                solver_calls=executor.solve_calls if executor else [])
            bridge.close()

    def test_original_empty_primary_then_ending_repeat(self):
        self.run_original(10)

    def test_original_two_card_primary_then_ending_repeat(self):
        self.run_original(15)


if __name__ == '__main__':
    unittest.main()
