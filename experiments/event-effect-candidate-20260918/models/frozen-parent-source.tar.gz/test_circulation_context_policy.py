"""233-feature loading, acquisition coverage, compatibility and raw-audit contracts."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import card_identity_policy as original
import circulation_context_features as features
import circulation_context_policy as policy
from decision_data import DataContractError
from selection_policy import SelectionPolicy
import sample_runs
from audit_batch import _Audit
from whole_run_audit import validate_whole_run_choices
from test_initial_policy import card, state


class CirculationContextTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=policy.ROOT / 'outputs')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.config = json.loads((policy.ROOT / 'configs/defect-v3-base.json').read_text(encoding='utf-8'))

    def model(self, weights, name='new', old=False, epsilon=.31):
        module = original if old else policy
        cls = original.CardIdentityPolicy if old else policy.CirculationContextPolicy
        path = self.root / (name + '.json')
        path.write_text(json.dumps(module.make_artifact(weights, self.config,
                          training={'synthetic_test_only': True})), encoding='utf-8')
        return SelectionPolicy(cls(path, solver_config=self.config, seed='circulation-test', epsilon=epsilon))

    def current(self):
        current = state([card('HOLOGRAM', block=3), card('TURBO', stats={'energy': 2}),
                         card('SKIM', stats={'cards': 3})])
        current['context'].update(act=2, floor=3, room_type='Event', integrity_recovery_used=False)
        current['player']['deck'] = [card('HOLOGRAM', block=3), card('TURBO', stats={'energy': 2}),
                                    card('SKIM', stats={'cards': 3})]
        return current

    def test_zero_extension_preserves_old_scores_choices_and_rng_across_channels(self):
        weights = {k: (i % 13 - 6) / 3 for i, k in enumerate(original.PARAMETERS)}
        old = self.model(weights, 'old', old=True)
        new = self.model(features.zero_extend(weights))
        self.assertEqual(len(new.base.artifact['parameters']), 233)
        cases = [(self.current(), None)]
        bundle = self.current()
        bundle['bundles'] = [{'index': 0, 'cards': bundle.pop('cards')}]
        bundle['decision'] = 'bundle_select'
        cases.append((bundle, None))
        ordered = self.current()
        ordered.update(decision='card_select', min_select=0, max_select=2)
        cases += [(ordered, p) for p in ('acquire', 'remove', 'transform', 'upgrade', 'enchant', None)]
        for act in (1, 2, 3):
            for current, purpose in cases:
                current['context']['act'] = act
                a = old.choose(current, selection_purpose=purpose)
                b = new.choose(current, selection_purpose=purpose)
                self.assertEqual(a['request'], b['request'])
                self.assertEqual(a['exploration'], b['exploration'])
                for x, y in zip(a['scoring']['scores'], b['scoring']['scores']):
                    self.assertEqual(x['score'], y['score'])
                    self.assertEqual(x['learned_residual'], y['learned_residual'])
                    self.assertEqual(x['search_features'], {k: y['search_features'][k] for k in original.PARAMETERS})

    def test_each_new_parameter_changes_its_actual_score(self):
        current = self.current()
        zero = dict.fromkeys(policy.PARAMETERS, 0.)
        baseline = self.model(zero, 'zero').score(current)['scores']
        for i, name in enumerate(features.EXTRA_PARAMETERS):
            weights = {**zero, name: 4.}
            changed = self.model(weights, 'direction' + str(i)).score(current)['scores']
            affected = 0
            for a, b in zip(baseline, changed):
                self.assertAlmostEqual(b['score'] - a['score'], 4. * b['search_features'][name])
                affected += b['search_features'][name] != 0.
            self.assertGreater(affected, 0)

    def test_bundle_ordered_implicit_and_shop_use_same_public_context(self):
        weights = dict.fromkeys(policy.PARAMETERS, 0.)
        weights['circulation_discard_retrieval_with_energy_density'] = 4.
        model = self.model(weights)
        current = self.current()
        single = model.score(current)['scores'][0]
        bundle = self.current()
        bundle.update(decision='bundle_select', bundles=[{'index': 0, 'cards': [bundle['cards'][0]] * 2}])
        bundle.pop('cards')
        row = model.score(bundle)['scores'][0]
        self.assertAlmostEqual(row['learned_residual'], 2 * single['learned_residual'])
        ordered = self.current()
        ordered.update(decision='card_select', min_select=4, max_select=4,
                       cards=[dict(current['cards'][0], index=i) for i in range(9)])
        bounded = SelectionPolicy(model.base, max_evaluations=12)
        picked = bounded.choose(ordered, selection_purpose='acquire')
        self.assertFalse(picked['scoring']['evaluated_candidates_complete'])
        for row in picked['scoring']['scores']:
            self.assertAlmostEqual(row['learned_residual'], 4 * single['learned_residual'])
            self.assertEqual(row['search_features']['card_acquire'], 4.)
        # Gold price is not used as energy or as a circulation descriptor.
        request = {'action': 'buy_card', 'args': {'card_index': 0}}
        row = {'request': request}
        candidate = {'request': request, 'evidence': {**current['cards'][0], 'cost': 999, 'card_cost': 1}}
        actual = features.extra_features(current, row, candidate)
        self.assertEqual(actual['circulation_discard_retrieval_with_energy_density'], 1 / 3)

    def test_invalid_schema_source_config_scope_and_mutation_rejected(self):
        weights = dict.fromkeys(policy.PARAMETERS, 0.)
        model = self.model(weights)
        for bad in (True, float('nan'), float('inf'), 4.01):
            with self.assertRaises(DataContractError):
                self.model({**weights, features.EXTRA_PARAMETERS[0]: bad}, 'bad')
        path = model.base.path
        artifact = json.loads(path.read_text(encoding='utf-8'))
        for changed in ({**artifact, 'format': original.VERSION},
                        {**artifact, 'parameter_names': list(original.PARAMETERS)},
                        {**artifact, 'solver_requested_config': {}},
                        {**artifact, 'source_files': {}}):
            path.write_text(json.dumps(changed), encoding='utf-8')
            with self.assertRaises(DataContractError):
                policy.CirculationContextPolicy(path, solver_config=self.config, seed='bad')
        path.write_text(json.dumps(artifact), encoding='utf-8')
        with self.assertRaises(DataContractError):
            sample_runs.build_policy('bad', self.config, ascension=9, model_path=path)
        with self.assertRaises(DataContractError):
            original.CardIdentityPolicy(path, solver_config=self.config, seed='old')
        model.base.artifact['parameters'][features.EXTRA_PARAMETERS[0]] = 1.
        with self.assertRaises(DataContractError):
            model.score(self.current())

    def test_missing_deck_and_mismatched_requests_rejected_unknown_tags_explicit(self):
        current = self.current()
        request = {'action': 'select_card_reward', 'args': {'card_index': 0}}
        row = {'request': request}
        candidate = {'request': request, 'evidence': current['cards'][0]}
        for deck, size in [(None, 3), ([], 0), ([{}], 1), (current['player']['deck'], 99)]:
            broken = copy.deepcopy(current)
            broken['player'].update(deck=deck, deck_size=size)
            with self.assertRaises(DataContractError):
                features.extra_features(broken, row, candidate)
        with self.assertRaises(DataContractError):
            features.extra_features(current, row, {**candidate, 'request': {'action': 'skip'}})
        candidate = {**candidate, 'evidence': {'id': 'CARD.UNKNOWN_CIRCULATION_TEST'}}
        self.assertTrue(all(v == 0. for v in features.extra_features(current, row, candidate).values()))

    def test_sampler_and_full_raw_audit_reconstruct_new_features_and_reject_tampering(self):
        weights = dict.fromkeys(policy.PARAMETERS, 0.)
        weights['circulation_discard_retrieval_with_energy_density'] = 3.
        model = self.model(weights, epsilon=0.)
        initial = self.current()
        terminal = copy.deepcopy(initial)
        terminal.update(decision='game_over', victory=False)
        terminal['player']['hp'] = 0
        class FakeBridge:
            def send(self, **request):
                return copy.deepcopy(initial if request['cmd'] == 'start_run' else terminal)
            def close(self):
                pass
        with patch.object(sample_runs, 'ROOT', self.root), patch.object(sample_runs, 'Bridge', return_value=FakeBridge()):
            report = sample_runs.run_one('circulation-synthetic-fixture', 'circulation-synthetic-fixture',
                                         settings=self.config, epsilon=0., model_path=model.base.path, selection_budget=8)
        audit = _Audit(self.root / 'outputs/audit')
        records, _ = audit.run(report)
        self.assertEqual(audit.issues, [])
        self.assertTrue(audit.checks['prefix_actual_natural_run_start'])
        self.assertTrue(audit.checks['prefix_entire_macro_trace_coverage'])
        policies = {r['decision_id']: r for r in map(json.loads,
                    (self.root / 'outputs/circulation-synthetic-fixture/policy.jsonl').read_text(encoding='utf-8').splitlines())}
        self.assertTrue(validate_whole_run_choices(records, policies))
        damaged = copy.deepcopy(policies)
        damaged[records[0]['decision_id']]['scoring']['scores'][0]['search_features'][features.EXTRA_PARAMETERS[0]] += 1.
        with self.assertRaises(DataContractError):
            validate_whole_run_choices(records, damaged)


if __name__ == '__main__':
    unittest.main(verbosity=2)
