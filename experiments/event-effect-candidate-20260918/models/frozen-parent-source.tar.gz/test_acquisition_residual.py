"""Learned card preferences must reach every known acquisition channel."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import card_identity_policy as policy
from card_identity_features import ID_PARAMETERS
from decision_data import DataContractError
from initial_policy import InitialPolicy
from selection_policy import SelectionPolicy
from test_initial_policy import card, state
from test_selection_policy import selection_state


class AcquisitionResidualTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=policy.ROOT / 'outputs')
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)
        self.config = json.loads((policy.ROOT / 'configs/defect-v3-base.json').read_text(encoding='utf-8'))

    def model(self, parameters=None):
        weights = dict.fromkeys(policy.PARAMETERS, 0.)
        weights.update(parameters or {})
        path = self.folder / 'model.json'
        path.write_text(json.dumps(policy.make_artifact(weights, self.config,
            training={'synthetic_test_only': True})), encoding='utf-8')
        return policy.CardIdentityPolicy(path, solver_config=self.config, seed='acquisition-residual', epsilon=0.)

    def bundle(self, cards):
        current = state()
        current['context']['act'] = 2
        current.update(decision='bundle_select', bundles=[{'index': 0, 'cards': cards}])
        return current

    def test_bundle_identity_weight_changes_actual_score(self):
        current = self.bundle([card('CLAW', damage=3)])
        scored = self.model({ID_PARAMETERS['CLAW']: 4.}).score(current)['scores'][0]
        self.assertEqual(scored['learned_residual'], 4.)
        self.assertEqual(scored['search_features'][ID_PARAMETERS['CLAW']], 1.)

    def test_single_card_bundle_equals_all_direct_acquisition_features(self):
        selected = card('GLACIER', block=10, current_upgrade_level=1)
        bundle = self.bundle([selected])
        direct = copy.deepcopy(bundle)
        direct.update(decision='card_reward', cards=[dict(selected, index=0)], can_skip=True)
        del direct['bundles']
        model = self.model({name: (i % 9 - 4) / 2 for i, name in enumerate(policy.PARAMETERS)})
        a = model.score(bundle)['scores'][0]
        b = model.score(direct)['scores'][0]
        self.assertEqual(a['search_features'], b['search_features'])
        self.assertEqual(a['learned_residual'], b['learned_residual'])
        self.assertEqual(len(a['search_features']), 227)

    def test_duplicates_are_counted_within_the_public_selected_sequence(self):
        current = self.bundle([card('CLAW', damage=3), card('CLAW', damage=3), card('GLACIER', block=10)])
        current['player']['deck'].append(card('CLAW', damage=3))
        row = self.model().score(current)['scores'][0]
        features = row['search_features']
        self.assertEqual(features['card_acquire'], 3.)
        self.assertEqual(features[ID_PARAMETERS['CLAW']], 2.)
        self.assertEqual(features['card_duplicate'], 3.)
        self.assertEqual(features['card_frost'], 1.)

    def test_known_ordered_acquisition_receives_features_but_other_purposes_do_not(self):
        current = state([card('CLAW', damage=3), card('GLACIER', block=10)])
        current['context']['act'] = 2
        current.update(decision='card_select', min_select=2, max_select=2)
        model = self.model({'card_acquire': 1., ID_PARAMETERS['CLAW']: 3.})
        scored = model.score(current, selection_purpose='acquire')['scores']
        self.assertEqual([r['learned_residual'] for r in scored], [5., 5.])
        for purpose in (None, 'remove', 'transform', 'upgrade', 'enchant'):
            self.assertTrue(all(r['learned_residual'] == 0. for r in model.score(current, selection_purpose=purpose)['scores']))

    def test_empty_acquisition_keeps_zero_residual(self):
        current = state([card('CLAW', damage=3)])
        current['context']['act'] = 2
        current.update(decision='card_select', min_select=0, max_select=1)
        rows = self.model({'card_acquire': 3.}).score(current, selection_purpose='acquire')['scores']
        empty = next(row for row in rows if row['features']['selected_count'] == 0.)
        self.assertEqual(empty['learned_residual'], 0.)

    def test_implicit_bounded_selection_scores_only_complete_actual_actions(self):
        current = selection_state(n=9, minimum=4, maximum=4)
        current['context'].update(act=2, ascension=10)
        current['player']['deck'] = state()['player']['deck']
        model = SelectionPolicy(self.model({'card_acquire': 1.}), max_evaluations=12)
        chosen = model.choose(current, selection_purpose='acquire')
        packet = chosen['scoring']
        self.assertFalse(packet['evaluated_candidates_complete'])
        self.assertTrue(all(row['search_features']['card_acquire'] == 4. for row in packet['scores']))
        self.assertTrue(all(row['learned_residual'] == 4. for row in packet['scores']))

    def test_damaged_detail_cardinality_is_rejected(self):
        current = self.bundle([card('CLAW', damage=3)])
        from decision_data import enumerate_candidates
        candidate = enumerate_candidates(current)['candidates'][0]
        row = InitialPolicy().score(current)['scores'][0]
        row['card_detail'] = []
        with self.assertRaises(DataContractError):
            policy.residual_features(current, row, candidate)

    def test_v1_artifact_is_not_silently_loaded_as_v2(self):
        model = self.model()
        artifact = json.loads(model.path.read_text(encoding='utf-8'))
        artifact['format'] = 'whole-run-card-identity-residual-v1'
        model.path.write_text(json.dumps(artifact), encoding='utf-8')
        with self.assertRaises(DataContractError):
            policy.CardIdentityPolicy(model.path, solver_config=self.config, seed='version-contract')


if __name__ == '__main__':
    unittest.main()
