"""Stop a predicted nested-choice plan after actual autoplay has already finished."""
import copy
from combat_executor import CombatExecutor, choice_plans


def require(ok,message):
    if not ok: raise RuntimeError('Distilled Chaos replan: '+message)


def proof(before,after,action,meta,action_index,request):
    require(action.get('Kind')=='UsePotion' and action.get('PotionId')=='DISTILLED_CHAOS'
        and bool(choice_plans(action)) and type(action_index) is int and action_index>=0,'Not a planned autoplay choice')
    require(before.get('decision')==after.get('decision')=='combat_play'
        and before.get('context',{}).get('combat_in_progress') is True
        and after.get('context',{}).get('combat_in_progress') is True
        and after['context'].get('integrity_recovery_used') is False,'No active actual play boundary')
    identity=CombatExecutor.setup_state_identity(before)
    require(identity==CombatExecutor.setup_state_identity(after) and type(identity['combat_id']) is int
        and identity['combat_id']>0 and all(v is not None for v in identity.values()),'Battle identity differs')
    require(type(before.get('player_turn')) is int and before['player_turn']>=1
        and before['player_turn']==after.get('player_turn')==action.get('Turn'),'Turn differs')
    audit=after.get('choice_audit',{});parent=audit.get('parent',{})
    require(audit.get('schema_version')=='combat-choice-return-v2' and audit.get('closed') is True
        and type(audit.get('action_id')) is int and audit['action_id']>0,'Potion action audit not closed')
    require(parent.get('action')=='use_potion' and parent.get('potion_id')=='DISTILLED_CHAOS'
        and type(parent.get('potion_slot')) is int and parent['potion_slot']==action.get('PotionSlot')
        and type(parent.get('potion_index')) is int and parent['potion_index']>=0
        and parent.get('combat_id')==identity['combat_id'] and parent.get('player_turn')==before['player_turn']
        and parent.get('combat_active_before') is True and isinstance(parent.get('player_id'),str)
        and bool(parent['player_id']),'Wrong executed potion parent')
    expected={'potion_index':parent['potion_index']}
    if action.get('TargetIndex',-1)>=0: expected['target_index']=action['TargetIndex']
    require(request==dict(cmd='action',action='use_potion',args=expected),'Wrong actual potion request')
    require(meta.get('type')=='choice_meta' and meta.get('selection')=='none' and meta.get('cards')==[]
        and meta.get('setup_choice') is None and meta.get('knowledge_choice') is None
        and meta.get('completion_audit')==audit,'Selection pending or stale completion query')
    return dict(schema_version='actual-distilled-chaos-completed-replan-v1',
        reason='autoplay_returned_to_play_with_no_pending_selection',action_index=action_index,
        action=copy.deepcopy(action),actual_request=copy.deepcopy(request),before_state=copy.deepcopy(before),
        actual_state=copy.deepcopy(after),completion_metadata=copy.deepcopy(meta),
        original_nested_choice_match_claimed=False,remaining_battle_plan_stopped=True,
        selection_submitted=False,next_step_requires_fresh_solve=True)
