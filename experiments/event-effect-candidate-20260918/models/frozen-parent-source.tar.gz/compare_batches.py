"""Paired natural A10 evaluation. Failures remain in every arm's denominator."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re

from decision_data import read_decisions
from solver_evidence import verified_solver_call


BEHAVIOR_SOURCES = ("initial_policy.py", "selection_policy.py", "selection_space.py",
                    "combat_executor.py", "sample_runs.py", "decision_data.py",
                    "selection_context.py", "mechanism_facts.py")
BACKENDS = {"beam", "coordinator"}
SOLVER_FIELDS = {"first_budget_ms", "replan_budget_ms", "setup_budget_ms", "retry_budget_ms",
                 "max_replans", "solver_backend", "potion_policy", "growth_budgets",
                 "act_boss_hp_strategy", "final_boss_hp_strategy", "search_profile"}
PROFILE_LIMITS = {"beam_width": 1000, "max_expanded_nodes": 1000000, "max_card_branches_per_node": 1000,
                  "max_pile_choice_branches_per_action": 1000, "max_hand_choice_branches_per_action": 1000}
CONDITION_FIELDS = {"character", "ascension", "epsilon", "max_seconds", "max_decisions", "selection_budget"}


def wilson95(successes, count):
    if type(count) is not int or type(successes) is not int or not 0 <= successes <= count:
        raise ValueError("Wilson counts must be nonnegative integers with successes <= count")
    if not count:
        return None
    z = 1.959963984540054
    p = successes / count
    denominator = 1 + z * z / count
    center = (p + z * z / (2 * count)) / denominator
    margin = z * math.sqrt(p * (1 - p) / count + z * z / (4 * count * count)) / denominator
    return [max(0., center - margin), min(1., center + margin)]


def load_json(path):
    def bad_constant(value):
        raise ValueError("Nonfinite JSON value: " + value)
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), parse_constant=bad_constant)


def load_jsonl(path):
    return [json.loads(line, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
            for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def finite_nonnegative(value, label):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        raise ValueError(label + " must be a finite nonnegative number")
    return value


def same_json(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def load_protocol(path):
    """Validate complete declarations; hash the exact file bytes, not a re-serialization."""
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate protocol field: " + key)
            result[key] = value
        return result
    path = Path(path).resolve()
    content = path.read_bytes()
    document = json.loads(content.decode("utf-8-sig"), object_pairs_hook=unique_pairs,
                          parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    if not isinstance(document, dict) or document.get("schema_version") != "paired-solver-config-v1":
        raise ValueError("Protocol must use paired-solver-config-v1")
    try:
        created = datetime.fromisoformat(document["created_utc"].replace("Z", "+00:00"))
        if created.tzinfo is None or created.utcoffset() != timezone.utc.utcoffset(created):
            raise ValueError("Protocol created_utc must be explicitly UTC")
        created_unix = finite_nonnegative(created.timestamp(), "protocol created_utc")
        seeds = document["seeds"]
        if (not isinstance(seeds, list) or not seeds or any(not isinstance(s, str) or not s for s in seeds)
                or len(set(seeds)) != len(seeds)):
            raise ValueError("Protocol seeds must be a nonempty unique string list")
        arms = document["arms"]
        if not isinstance(arms, dict) or set(arms) != {"left", "right"}:
            raise ValueError("Protocol must declare left and right arms")
        for name, arm in arms.items():
            if (not isinstance(arm, dict) or not isinstance(arm.get("batch"), str)
                    or re.fullmatch(r"[A-Za-z0-9_-]+", arm["batch"]) is None):
                raise ValueError("Protocol arm requires an exact batch name: " + name)
            config = arm["solver_config"]
            if not isinstance(config, dict) or set(config) != SOLVER_FIELDS:
                raise ValueError("Protocol arm must declare the full supported solver_config: " + name)
            if config["solver_backend"] not in BACKENDS:
                raise ValueError("Invalid protocol solver_backend")
            for key in ("first_budget_ms", "replan_budget_ms", "setup_budget_ms", "retry_budget_ms"):
                if type(config[key]) is not int or not 100 <= config[key] <= 30000:
                    raise ValueError("Invalid protocol search budget: " + key)
            if type(config["max_replans"]) is not int or not 1 <= config["max_replans"] <= 100:
                raise ValueError("Invalid protocol max_replans")
            for key in ("potion_policy", "act_boss_hp_strategy", "final_boss_hp_strategy"):
                if not isinstance(config[key], str) or not config[key]:
                    raise ValueError("Invalid protocol policy: " + key)
            growth = config["growth_budgets"]
            if (not isinstance(growth, dict) or any(not k or type(v) is not int or not 0 <= v <= 1000
                                                   for k, v in growth.items())):
                raise ValueError("Invalid protocol growth_budgets")
            profile = config["search_profile"]
            if (not isinstance(profile, dict) or set(profile) != {*PROFILE_LIMITS, "recover_deferred_turn_frontier"}
                    or type(profile["recover_deferred_turn_frontier"]) is not bool
                    or any(type(profile[k]) is not int or not 1 <= profile[k] <= maximum
                           for k, maximum in PROFILE_LIMITS.items())):
                raise ValueError("Protocol must declare a complete valid search_profile")
        if arms["left"]["batch"] == arms["right"]["batch"]:
            raise ValueError("Protocol arms must use distinct batches")
        conditions = document["conditions"]
        if not isinstance(conditions, dict) or set(conditions) != CONDITION_FIELDS:
            raise ValueError("Protocol must declare all supported common conditions")
        if (not isinstance(conditions["character"], str) or not conditions["character"]
                or type(conditions["ascension"]) is not int or conditions["ascension"] != 10):
            raise ValueError("Protocol requires an explicit character and A10")
        if finite_nonnegative(conditions["epsilon"], "protocol epsilon") > 1:
            raise ValueError("Protocol epsilon must be <= 1")
        for key in ("max_seconds", "max_decisions", "selection_budget"):
            if type(conditions[key]) is not int or conditions[key] <= 0:
                raise ValueError("Invalid protocol condition: " + key)
    except (KeyError, TypeError, AttributeError, OverflowError) as exc:
        raise ValueError("Malformed protocol declaration: " + str(exc)) from exc
    return {"path": str(path), "sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content),
            "created_unix": created_unix, "document": document}


def config_differences(left, right, prefix="solver_config"):
    changes = []
    for key in sorted(left.keys() | right.keys()):
        before, after = left.get(key), right.get(key)
        if isinstance(before, dict) and isinstance(after, dict):
            changes.extend(config_differences(before, after, prefix + "." + key))
        elif not same_json(before, after):
            changes.append({"field": prefix + "." + key, "left": before, "right": after})
    return changes


def policy_identity(value):
    if (not isinstance(value, dict) or value.get("origin") != "natural"
            or value.get("kind") not in {"rules", "model", "search", "exploration"}
            or value.get("llm_involved") is not False or not value.get("id") or not value.get("version")):
        raise ValueError("Run contains a non-natural or LLM/human macro policy")
    return {key: item for key, item in value.items() if key not in {"random_seed", "choice_count"}}


def file_identity(value, label):
    if (not isinstance(value, dict) or not isinstance(value.get("sha256"), str)
            or re.fullmatch(r"[0-9a-fA-F]{64}", value["sha256"]) is None
            or type(value.get("bytes")) is not int or value["bytes"] <= 0):
        raise ValueError("Missing immutable version evidence: " + label)
    return {"sha256": value["sha256"].lower(), "bytes": value["bytes"]}


def manifest_identity(manifest, backend):
    if manifest.get("ascension") != 10 or type(manifest.get("ascension")) is not int:
        raise ValueError("Only actual A10 batches are comparable")
    if (not isinstance(manifest.get("character"), str) or not manifest["character"]
            or manifest.get("mode") != "standard" or manifest.get("branch_restore_enabled") is not False
            or manifest.get("llm_used_for_combat") is not False):
        raise ValueError("Missing standard natural-run identity or no-LLM/no-restore evidence")
    versions = manifest["versions"]
    binaries = {name: file_identity(versions.get(name), name) for name in ("engine", "solver", "cli", "bridge")}
    if "ritsu" in versions:
        binaries["ritsu"] = file_identity(versions["ritsu"], "ritsu")
    if "godot" in versions:
        binaries["godot"] = file_identity(versions["godot"], "godot")
    sources = versions.get("sources", {})
    provenance = policy_identity(manifest["provenance"])
    if (provenance["version"] == "initial-stat-mechanism-v3" or "mechanism_facts" in provenance):
        missing = set(BEHAVIOR_SOURCES) - set(sources)
        if missing:
            raise ValueError("Modern v3 policy is missing behavior source evidence: " + ", ".join(sorted(missing)))
    behavior = {name: file_identity(sources[name], name) for name in BEHAVIOR_SOURCES if name in sources}
    config = dict(manifest["solver_requested_config"])
    if config.pop("solver_backend", "beam") != backend:
        raise ValueError("Mixed or undeclared solver_backend in arm")
    for name in ("first_budget_ms", "replan_budget_ms", "setup_budget_ms", "retry_budget_ms"):
        if type(config.get(name)) is not int or not 100 <= config[name] <= 30000:
            raise ValueError("Missing or invalid declared search budget: " + name)
    if not isinstance(config.get("search_profile"), dict) or not config["search_profile"]:
        raise ValueError("Missing declared search profile")
    sampling = manifest.get("sampling")
    if not isinstance(sampling, dict) or sampling.get("hidden_audit_features_used") is not False:
        raise ValueError("Missing natural sampling / hidden-feature exclusion evidence")
    return {"character": manifest["character"], "ascension": 10, "mode": manifest["mode"],
            "binaries": binaries, "behavior_sources": behavior, "policy": provenance,
            "solver_config_except_backend": config, "sampling": sampling}


def validate_solve(row, config, backend):
    request, response = row["request"], row.get("response")
    if request.get("solver_backend", "beam") != backend:
        raise ValueError("Trace solve used another backend")
    budgets = {config[key] for key in ("first_budget_ms", "replan_budget_ms", "setup_budget_ms", "retry_budget_ms")}
    if type(request.get("budget_ms")) is not int or request["budget_ms"] not in budgets:
        raise ValueError("Trace solve used an undeclared search budget")
    fixed = ("potion_policy", "growth_budgets", "act_boss_hp_strategy", "final_boss_hp_strategy", "search_profile")
    if any(request.get(key) != config.get(key) for key in fixed):
        raise ValueError("Trace solve settings differ from its frozen manifest")
    allowed = {*fixed, "cmd", "solver_backend", "budget_ms", "include_turn_setup", "hp_lost_so_far",
               "sold_hp_committed", "potions_used_so_far"}
    if set(request) - allowed:
        raise ValueError("Trace solve contains undeclared policy settings")
    if isinstance(response, dict) and response.get("type") == "solver_result":
        if not verified_solver_call(row):
            raise ValueError("Actual successful solver configuration is not verified")
        settings = response["settings"]
        profile = {**config["search_profile"], "soft_time_budget_ms": request["budget_ms"]}
        growth = settings.get("growth_budgets")
        expected_growth = config.get("growth_budgets", {})
        growth_matches = (isinstance(growth, dict) and set(expected_growth) <= set(growth)
            and all(type(value) is int and value == expected_growth.get(key, 0) for key, value in growth.items()))
        if (settings["search_profile"] != profile or settings.get("potion_policy") != config["potion_policy"]
                or not growth_matches or settings.get("potions") != []):
            raise ValueError("Actual solver configuration differs from its declared request")


def load_run(directory, listed_report, backend):
    """An invalid run becomes an explicit non-win row, never disappears."""
    result = {"run_id": listed_report.get("run_id"), "seed": listed_report.get("seed"),
              "path": str(directory), "reported_outcome": listed_report.get("outcome"),
              "verified_a10_victory": False, "category": "invalid_evidence", "errors": [],
              "total_run_seconds": None, "solver_calls": None, "solver_request_seconds": None,
              "reported_search_seconds": None, "reported_search_seconds_observed": 0.,
              "missing_search_elapsed_count": None, "solver_error_calls": 0,
              "recovered_solver_error_calls": 0, "max_act_observed": 0,
              "training_eligible_run": False, "training_eligible_decisions": 0,
              "training_exclusion_reasons": [], "report": listed_report}
    identity = None
    try:
        manifest, report = load_json(directory / "manifest.json"), load_json(directory / "report.json")
        result["solver_requested_config"] = manifest.get("solver_requested_config")
        if report != listed_report:
            raise ValueError("Batch report differs from per-run report")
        if any(manifest.get(key) != report.get(key) for key in ("run_id", "seed")):
            raise ValueError("Manifest/report run identity mismatch")
        identity = manifest_identity(manifest, backend)
        result["total_run_seconds"] = finite_nonnegative(report.get("seconds"), "run seconds")
        raw = load_jsonl(directory / "decisions.jsonl")
        result["run_start_unix"] = raw[0].get("recorded_at_unix") if raw else None
        records = read_decisions(directory / "decisions.jsonl")  # Validates journal and candidates, not a filter.
        journal_manifest = raw[0]["metadata"]
        if (any(journal_manifest.get(key) != manifest.get(key) for key in ("run_id", "seed"))
                or manifest_identity(journal_manifest, backend) != identity):
            raise ValueError("Journal metadata differs from immutable manifest")
        for entry in raw:
            if entry.get("record_type") == "decision_started" and policy_identity(entry["policy_provenance"]) != identity["policy"]:
                raise ValueError("Macro behavior policy changed during the run")
        finished = [r for r in raw if r.get("record_type") == "run_finished"]
        if len(finished) != 1:
            raise ValueError("Missing final run outcome (incomplete run)")
        final = finished[0]
        result["journal_outcome"] = final.get("outcome")
        if final.get("outcome") != report.get("outcome") or final.get("environment_error") != report.get("error"):
            raise ValueError("Report outcome/error differs from journal")
        trace = load_jsonl(directory / "trace.jsonl")
        starts = [r for r in trace if r.get("request", {}).get("cmd") == "start_run"]
        if len(starts) != 1 or starts[0]["request"] != {"cmd": "start_run", "character": manifest["character"], "ascension": 10, "seed": manifest["seed"]}:
            raise ValueError("Trace lacks a unique matching natural start_run")
        allowed_commands = {"start_run", "action", "solve", "combat_meta", "choice_meta"}
        if any(r.get("request", {}).get("cmd") not in allowed_commands for r in trace):
            raise ValueError("Trace contains fixture/restore/undeclared commands")
        solves = [r for r in trace if r["request"]["cmd"] == "solve"]
        for row in solves:
            validate_solve(row, manifest["solver_requested_config"], backend)
        result["solver_calls"] = len(solves)
        if type(report.get("solver_calls")) is not int or report["solver_calls"] != len(solves):
            raise ValueError("Reported solver-call count differs from trace (including failures)")
        result["solver_request_seconds"] = sum(finite_nonnegative(r.get("seconds"), "solver request seconds") for r in solves)
        elapsed = [r.get("response", {}).get("elapsed_ms") if isinstance(r.get("response"), dict) else None for r in solves]
        present = [finite_nonnegative(value, "solver elapsed_ms") / 1000 for value in elapsed if value is not None]
        result["reported_search_seconds_observed"] = sum(present)
        result["missing_search_elapsed_count"] = elapsed.count(None)
        result["reported_search_seconds"] = sum(present) if None not in elapsed else None
        result["solver_error_calls"] = sum(not isinstance(r.get("response"), dict) or r["response"].get("type") == "error" for r in solves)
        states = [r["response"] for r in trace if isinstance(r.get("response"), dict) and r["response"].get("type") == "decision"]
        acts = [s.get("context", {}).get("act") for s in states]
        result["max_act_observed"] = max([a for a in acts if type(a) is int and 1 <= a <= 3], default=0)
        result["training_eligible_decisions"] = sum(r["training_eligible"] for r in records)
        result["training_eligible_run"] = bool(records) and all(r["training_eligible"] for r in records)
        result["training_exclusion_reasons"] = sorted({reason for r in records for reason in r["training_exclusion_reasons"]})
        outcome = final.get("outcome")
        if outcome in {"environment_error", "timeout", "stopped"}:
            # Journal outcome may be environment_error when the recorded
            # environment_error describes a timeout. Preserve both raw values.
            result["category"] = "timeout" if final.get("termination") == "timeout" else outcome
            result["termination"] = final.get("termination")
        elif outcome in {"victory", "defeat"}:
            terminal = final["final_state"]
            if not states or states[-1] != terminal or load_json(directory / "state.json") != terminal:
                raise ValueError("Natural terminal is not the final actual trace/state response")
            if (terminal.get("context", {}).get("combat_in_progress") is not False
                    or terminal.get("context", {}).get("ascension") != 10
                    or any(s.get("context", {}).get("integrity_recovery_used") is True for s in states)):
                raise ValueError("Natural terminal contains active combat or recovery")
            if outcome == "defeat":
                if terminal.get("player", {}).get("hp") != 0:
                    raise ValueError("Natural defeat has no actual zero-HP terminal")
                result["category"] = "defeat"
            else:
                evidence, context = final.get("terminal_evidence", {}), terminal.get("context", {})
                second_states = [s for s in states[:-1] if s.get("decision") == "combat_play"
                    and s.get("context", {}).get("is_second_boss") is True
                    and s.get("context", {}).get("combat_in_progress") is True
                    and s.get("context", {}).get("act") == 3 and s.get("context", {}).get("room_type") == "Boss"]
                if (not second_states or evidence.get("second_boss_entered") is not True
                        or evidence.get("second_boss_victory") is not True or not evidence.get("trace_reference")
                        or context.get("is_second_boss") is not True or context.get("act") != 3
                        or context.get("room_type") != "Boss" or not context.get("encounter_id")
                        or context["encounter_id"] != second_states[-1]["context"].get("encounter_id")
                        or type(terminal.get("player", {}).get("hp")) is not int or terminal["player"]["hp"] <= 0):
                    raise ValueError("A10 victory lacks matching real second-boss entry and terminal evidence")
                result.update(category="victory", verified_a10_victory=True)
            result["recovered_solver_error_calls"] = result["solver_error_calls"]
        else:
            raise ValueError("Unknown run outcome")
    except (OSError, ValueError, TypeError, KeyError, IndexError, AttributeError) as exc:
        result["errors"].append(str(exc))
        result.update(category="invalid_evidence", verified_a10_victory=False)
    return result, identity


def load_arm(path, backend):
    path = Path(path).resolve()
    errors, rows, identities = [], [], []
    try:
        reports = load_json(path / "reports.json")
        if not isinstance(reports, list) or not reports:
            raise ValueError("Batch reports must be a nonempty list")
        try:
            summary = load_json(path / "summary.json")
            if summary.get("runs") != len(reports) or summary.get("reports") != reports:
                raise ValueError("Batch summary is incomplete or differs from reports")
        except (OSError, ValueError, AttributeError) as exc:
            errors.append(str(exc))
        for report in reports:
            if (not isinstance(report, dict) or not isinstance(report.get("run_id"), str)
                    or re.fullmatch(r"[A-Za-z0-9_-]+", report["run_id"]) is None
                    or not isinstance(report.get("seed"), str) or not report["seed"]):
                errors.append("Invalid report run_id/seed")
                rows.append({"seed": None, "run_id": None, "category": "invalid_evidence",
                             "verified_a10_victory": False, "errors": ["Invalid report identity"], "report": report})
                continue
            row, identity = load_run(path.parent / report["run_id"], report, backend)
            rows.append(row)
            errors.extend(f"{report['run_id']}: {error}" for error in row["errors"])
            if identity is not None:
                identities.append(identity)
        seeds = [r.get("seed") for r in rows]
        if len(set(seeds)) != len(seeds):
            errors.append("Duplicate seed in arm; no seed may be silently deduplicated")
        if identities and any(i != identities[0] for i in identities[1:]):
            errors.append("Mixed character/version/policy/search/sampling configuration within arm")
    except (OSError, ValueError, TypeError) as exc:
        errors.append(str(exc))
    return {"path": str(path), "declared_backend": backend, "runs": rows, "errors": errors,
            "identity": identities[0] if identities else None}


def summarize(rows):
    count = len(rows)
    wins = sum(r.get("verified_a10_victory") is True for r in rows)
    categories = Counter(r["category"] for r in rows)
    def total(field):
        values = [r.get(field) for r in rows]
        return sum(values) if all(v is not None for v in values) else None
    duration = total("total_run_seconds")
    return {"runs_in_denominator": count, "verified_a10_victories": wins,
            "end_to_end_win_rate": wins / count if count else None, "wilson_95": wilson95(wins, count),
            "outcome_counts": dict(categories), "natural_defeats": categories["defeat"],
            "missing_runs": categories["missing_run"],
            "environment_errors": categories["environment_error"], "timeouts": categories["timeout"],
            "environment_error_or_timeout_rate": (categories["environment_error"] + categories["timeout"]) / count if count else None,
            "act_reach": {str(act): {"count": sum(r.get("max_act_observed", 0) >= act for r in rows),
                "rate": sum(r.get("max_act_observed", 0) >= act for r in rows) / count if count else None} for act in (1, 2, 3)},
            "total_run_seconds": duration, "solver_calls": total("solver_calls"),
            "solver_request_seconds": total("solver_request_seconds"),
            "reported_search_seconds": total("reported_search_seconds"),
            "reported_search_seconds_observed": total("reported_search_seconds_observed"),
            "missing_search_elapsed_count": total("missing_search_elapsed_count"),
            "solver_error_calls": sum(r.get("solver_error_calls", 0) for r in rows),
            "runs_with_solver_errors": sum(r.get("solver_error_calls", 0) > 0 for r in rows),
            "recovered_solver_error_calls": sum(r.get("recovered_solver_error_calls", 0) for r in rows),
            "runs_with_recovered_solver_errors": sum(r.get("recovered_solver_error_calls", 0) > 0 for r in rows),
            "non_training_eligible_runs": sum(r.get("training_eligible_run") is not True for r in rows),
            "training_eligible_decisions": sum(r.get("training_eligible_decisions", 0) for r in rows),
            "seconds_per_verified_victory": duration / wins if wins and duration is not None else None,
            "seconds_per_victory_unavailable_reason": "no_verified_victories" if not wins else "missing_duration" if duration is None else None}


def validate_protocol_arm(arm, declaration, protocol):
    document = protocol["document"]
    if Path(arm["path"]).name != declaration["batch"]:
        arm["errors"].append("Batch name differs from predeclared protocol arm")
    observed = {r["seed"] for r in arm["runs"] if r.get("seed") is not None}
    expected = set(document["seeds"])
    missing, unexpected = sorted(expected - observed), sorted(observed - expected)
    if missing or unexpected:
        arm["errors"].append("Seed set differs from predeclared protocol; missing or extra seeds cannot be dropped")
    identity = arm["identity"]
    if identity is not None:
        conditions = {k: identity[k] for k in ("character", "ascension")}
        conditions.update({k: identity["sampling"].get(k) for k in CONDITION_FIELDS - {"character", "ascension"}})
        if not same_json(conditions, document["conditions"]):
            arm["errors"].append("Common conditions differ from predeclared protocol")
    timestamps, chronology_errors = [], []
    for row in arm["runs"]:
        if not same_json(row.get("solver_requested_config"), declaration["solver_config"]):
            arm["errors"].append(f"{row['run_id']}: Solver config differs from predeclared protocol arm")
        try:
            stamp = finite_nonnegative(row.get("run_start_unix"), "run_start recorded_at_unix")
            timestamps.append(stamp)
            if stamp <= protocol["created_unix"]:
                raise ValueError("Protocol creation must precede every journal run_start")
        except ValueError as exc:
            chronology_errors.append(f"{row.get('run_id')}: {exc}")
    arm["errors"].extend(chronology_errors)
    # The protocol supplies the intended denominator even if both batch files omit a seed.
    for seed in missing:
        arm["runs"].append({"run_id": None, "seed": seed, "category": "missing_run",
                            "verified_a10_victory": False, "errors": ["Predeclared seed has no run report"],
                            "training_eligible_run": False, "max_act_observed": 0})
    arm["protocol_verification"] = {"missing_seeds": missing, "unexpected_seeds": unexpected,
        "chronology_verified": bool(timestamps) and not chronology_errors and not missing,
        "chronology_errors": chronology_errors, "runs_with_timestamp": len(timestamps),
        "earliest_run_start_unix": min(timestamps) if timestamps else None}


def verify_execution_plan(protocol, arms):
    """Optional pre-run hash anchor written by the experiment runner, never inferred from mtime."""
    path = Path(protocol["path"]).parent / "execution-plan.json"
    if not path.exists():
        return None, []
    evidence, errors = {"path": str(path), "pre_run_protocol_hash_verified": False}, []
    try:
        content = path.read_bytes()
        plan = load_json(path)
        evidence.update(sha256=hashlib.sha256(content).hexdigest(), bytes=len(content), document=plan)
        if file_identity(plan.get("protocol"), "execution-plan protocol") != {
                "sha256": protocol["sha256"], "bytes": protocol["bytes"]}:
            raise ValueError("Execution plan protocol hash/size differs from the supplied protocol")
        created = datetime.fromisoformat(plan["created_utc"].replace("Z", "+00:00"))
        if created.tzinfo is None or created.utcoffset() != timezone.utc.utcoffset(created):
            raise ValueError("Execution plan created_utc must be explicitly UTC")
        stamp = finite_nonnegative(created.timestamp(), "execution plan created_utc")
        starts = [finite_nonnegative(row.get("run_start_unix"), "run_start recorded_at_unix")
                  for arm in arms for row in arm["runs"]]
        if not starts or not protocol["created_unix"] <= stamp < min(starts):
            raise ValueError("Execution plan must record the protocol hash before every run_start")
        evidence["pre_run_protocol_hash_verified"] = True
    except (OSError, ValueError, KeyError, TypeError, AttributeError, OverflowError) as exc:
        errors.append(str(exc))
    return evidence, errors


def compare_batches(left_path, right_path, *, left_backend=None, right_backend=None, protocol=None):
    declaration = load_protocol(protocol) if protocol is not None else None
    if declaration:
        declared_arms = declaration["document"]["arms"]
        declared_left, declared_right = (declared_arms[k]["solver_config"]["solver_backend"] for k in ("left", "right"))
        if ((left_backend is not None and left_backend != declared_left)
                or (right_backend is not None and right_backend != declared_right)):
            raise ValueError("CLI backend conflicts with protocol declaration")
        left_backend, right_backend = declared_left, declared_right
    if left_backend not in BACKENDS or right_backend not in BACKENDS:
        raise ValueError("Declare beam/coordinator for each arm before comparison")
    left, right = load_arm(left_path, left_backend), load_arm(right_path, right_backend)
    if declaration:
        for name, arm in (("left", left), ("right", right)):
            validate_protocol_arm(arm, declared_arms[name], declaration)
    errors = [f"{name}: {e}" for name, arm in (("left", left), ("right", right)) for e in arm["errors"]]
    plan_evidence = None
    if declaration:
        plan_evidence, plan_errors = verify_execution_plan(declaration, (left, right))
        errors.extend(plan_errors)
    identities = [{k: v for k, v in arm["identity"].items()
                   if not declaration or k != "solver_config_except_backend"}
                  if arm["identity"] is not None else None for arm in (left, right)]
    if identities[0] is None or identities[1] is None or identities[0] != identities[1]:
        errors.append("Arms differ beyond the predeclared solver configuration or lack complete identity evidence")
    lmap = {r["seed"]: r for r in left["runs"] if r.get("seed") is not None}
    rmap = {r["seed"]: r for r in right["runs"] if r.get("seed") is not None}
    observed_left = {seed for seed, row in lmap.items() if row["category"] != "missing_run"}
    observed_right = {seed for seed, row in rmap.items() if row["category"] != "missing_run"}
    missing_left, missing_right = sorted(observed_right - observed_left), sorted(observed_left - observed_right)
    if missing_left or missing_right:
        errors.append("Missing paired seeds; paired effect is not comparable")
    paired = None
    if not errors:
        both_win = left_only = right_only = neither = 0
        for seed in lmap:
            a, b = lmap[seed]["verified_a10_victory"], rmap[seed]["verified_a10_victory"]
            both_win += a and b
            left_only += a and not b
            right_only += b and not a
            neither += not a and not b
        paired = {"pairs": len(lmap), "both_win": both_win, "neither_wins": neither,
                  "left_wins_right_does_not": left_only, "right_wins_left_does_not": right_only,
                  "discordant_pairs": left_only + right_only,
                  "win_rate_difference_right_minus_left": (right_only - left_only) / len(lmap)}
    return {"schema_version": "paired-natural-a10-v1", "comparable": not errors, "errors": errors,
            "declared_only_difference": None if declaration else {"field": "solver_backend", "left": left_backend, "right": right_backend},
            "protocol": declaration,
            "execution_plan": plan_evidence,
            "declared_solver_config_differences": config_differences(declared_arms["left"]["solver_config"],
                declared_arms["right"]["solver_config"]) if declaration else None,
            "predeclaration_chronology_verified": all(arm["protocol_verification"]["chronology_verified"]
                for arm in (left, right)) if declaration else None,
            "protocol_evidence_semantics": "SHA256 identifies the exact protocol file; chronology compares its declared created_utc with every journal run_start recorded_at_unix, not filesystem mtime or an independent timestamp authority." if declaration else None,
            "semantics": "All listed seeds remain in arm denominators, including errors/timeouts; no training-eligibility filtering. Descriptive estimates, not an improvement claim.",
            "timing_semantics": "total_run_seconds sums complete per-run wall durations; solver_request_seconds includes failed calls and transport/capture; missing reported elapsed is null, never zero-filled.",
            "missing_paired_seeds": {"left": missing_left, "right": missing_right},
            "left": {**left, "summary": summarize(left["runs"])},
            "right": {**right, "summary": summarize(right["runs"])}, "paired": paired,
            "per_seed": [{"seed": seed, "left": lmap.get(seed), "right": rmap.get(seed)} for seed in sorted(lmap.keys() | rmap.keys())]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("left", type=Path)
    parser.add_argument("right", type=Path)
    parser.add_argument("--left-backend", choices=sorted(BACKENDS))
    parser.add_argument("--right-backend", choices=sorted(BACKENDS))
    parser.add_argument("--protocol", type=Path, help="Predeclared paired-solver-config-v1 JSON; supplies both arm configs")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = compare_batches(args.left, args.right, left_backend=args.left_backend, right_backend=args.right_backend,
                                 protocol=args.protocol)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    rendered = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered)
    raise SystemExit(0 if result["comparable"] else 2)


if __name__ == "__main__":
    main()
