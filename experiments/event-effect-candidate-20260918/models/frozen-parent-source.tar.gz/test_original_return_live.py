"""Original engine/solver at copied natural public prefixes; diagnostic, never training.

Old logs are immutable. All actual prefix responses must agree except the
read-only choice_audit and play_action envelopes. This is not state/RNG restoration.
"""
import copy
import json
import unittest
import uuid

from combat_executor import CombatExecutor, solver_config
from probe import Bridge, ROOT
from replay_evidence import validate_replay_evidence
from run_metadata import file_evidence


def visible(value):
    if "play_action" in value:
        receipt=value["play_action"]
        if (not isinstance(receipt,dict) or set(receipt)!={"schema_version","outcome","action_id","card_id",
                "target_combat_id","state","completion_task_status","cancellation_observed","on_play_entered"}
                or receipt["schema_version"]!="original-play-action-v1" or receipt["cancellation_observed"] is not False
                or receipt["on_play_entered"] is not True or receipt["outcome"] not in {"completed","awaiting_selection"}
                or receipt["outcome"]=="completed" and (receipt["state"]!="Finished" or receipt["completion_task_status"]!="RanToCompletion")):
            raise ValueError("Unknown or failed play-action observer envelope")
    return {k:v for k,v in value.items() if k not in {"choice_audit", "play_action"}}


class OriginalReturnLiveTests(unittest.TestCase):
    def run_prefix(self, run_id, solve_line, source_id, *, through_line=None, first_budget_ms=None,
                   recorded_action_line=None):
        label="original-return-"+source_id.lower()+"-"+uuid.uuid4().hex[:12]
        path=ROOT/"outputs"/run_id/"trace.jsonl"
        old=[json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
        trace=[];calls=[];matched=0
        evidence={"provenance":"same_seed_public_prefix_diagnostic", "training_eligible":False,
            "llm_actions":False,"full_state_equality_verified":False,"rng_equality_verified":False,
            "historical_source":file_evidence(path),"configuration_source_solve_line":solve_line,
            "prefix_through_line":through_line or solve_line-1,"fixture_first_budget_ms":first_budget_ms,
            "ignored_public_fields":["choice_audit","play_action"],
            "versions":{k:file_evidence(p) for k,p in {
                "engine":ROOT.parent/"sts2-cli/lib/sts2.dll", "solver":ROOT/"lib/CombatSolver.dll",
                "bridge":ROOT/"runtime/host/bin/Debug/net9.0/SolverBridge.dll",
                "cli":ROOT.parent/"sts2-cli/src/Sts2Headless/bin/Debug/net9.0/Sts2Headless.dll",
                "executor":ROOT/"combat_executor.py","replay_evidence":ROOT/"replay_evidence.py"}.items()}}
        bridge=Bridge(label)
        def send(**request):
            response=bridge.send(**request)
            trace.append({"request":copy.deepcopy(request),"response":copy.deepcopy(response)})
            self.assertNotEqual(response.get("type"),"error",response)
            return response
        try:
            state=None
            for line,row in enumerate(old[:through_line or solve_line-1],1):
                request=row["request"]
                if request["cmd"] in {"solve","combat_meta","choice_meta","branch_audit"}:continue
                self.assertIn(request["cmd"],{"start_run","action","enter_room"})
                actual=send(**request)
                self.assertEqual(visible(actual),visible(row["response"]),f"public prefix differs at line {line}")
                matched+=1
                if actual.get("type")=="decision":state=actual
            self.assertEqual(state["decision"],"combat_play")
            requested=old[solve_line-1]["request"]
            config=solver_config()
            for key in config:
                if key in requested:config[key]=copy.deepcopy(requested[key])
            config["first_budget_ms"]=first_budget_ms or requested["budget_ms"]
            recorded_proofs=[]
            if recorded_action_line is not None:
                # A fresh search need not choose the card under test. Execute the
                # original solver's recorded action at its exact public prefix,
                # with a fresh fingerprint check, then resume normal solving.
                self.assertEqual(recorded_action_line,(through_line or solve_line-1)+1)
                recorded=old[recorded_action_line-1]
                self.assertEqual(recorded["request"]["cmd"],"action")
                self.assertEqual(recorded["request"]["action"],"play_card")
                actions=[a for a in old[solve_line-1]["response"]["actions"]
                         if a.get("Kind")=="PlayCard" and a.get("CardId")==source_id]
                self.assertEqual(len(actions),1)
                action=copy.deepcopy(actions[0])
                meta=send(cmd="combat_meta")
                card=next(c for c in meta["hand"] if c["index"]==recorded["request"]["args"]["card_index"])
                self.assertEqual(card["key"],action["CardStateKey"])
                after=send(**recorded["request"])
                self.assertEqual(visible(after),visible(recorded["response"]))
                observer=CombatExecutor(send,config)
                observer.solve_calls=[copy.deepcopy(old[solve_line-1])]
                observer.last_action_request=copy.deepcopy(recorded["request"])
                self.assertTrue(observer.resolve_original_automatic_choice(state,after,action))
                recorded_proofs=copy.deepcopy(observer.solve_calls[0]["replay"])
                evidence.update(recorded_original_solver_action_line=recorded_action_line,
                    recorded_original_solver_action=action,actual_recorded_action_proofs=recorded_proofs)
                state=after
            executor=CombatExecutor(send,config)
            try:final=executor.advance(state)
            finally:calls=executor.solve_calls
            proofs=recorded_proofs+[p for c in calls for p in c.get("replay",[]) if p["kind"]=="original_choice_return_completed"]
            wanted=[p for p in proofs if p["actual_choice_audit"]["original_returns"][0]["source_id"]==source_id]
            self.assertTrue(wanted,source_id)
            validated=validate_replay_evidence(calls,trace)
            evidence["replay_validation"]=validated
            return wanted,final
        finally:
            bridge.close()
            evidence.update(trace=trace,solver_calls=calls,verified_public_prefix_responses=matched)
            (ROOT/"outputs"/(label+".json")).write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding="utf-8")

    def test_glam_hologram_original_singleton_then_empty(self):
        proofs,_=self.run_prefix("defect-ix119-model-20260913a-0002",213,"HOLOGRAM",
            through_line=235,recorded_action_line=236)
        self.assertTrue(any(len(p["actual_choice_audit"]["original_returns"])==2 for p in proofs))

    def test_touch_filtered_singleton_changes_cost_after_fingerprint(self):
        proofs,_=self.run_prefix("defect-ix119-rule-20260913a-0007",458,"TOUCH_OF_INSANITY",through_line=470,first_budget_ms=15000)
        event=proofs[0]["actual_choice_audit"]["original_returns"][0]
        self.assertEqual(event["returned_cards"][0]["CardId"],"ICE_LANCE")
        self.assertIn("energy=False:3",event["returned_cards"][0]["StateKey"])
        self.assertGreaterEqual(event["raw_source_count_at_entry"],1)

    def test_scavenge_empty_hand_preserves_original_remaining_effect(self):
        proofs,_=self.run_prefix("defect-ix119-model-20260913a-0013",377,"SCAVENGE",through_line=386,
                                 recorded_action_line=387)
        self.assertTrue(any(p["reason"]=="engine_empty_source" for p in proofs))

    def test_dagger_throw_original_ending_stops_unexecuted_discard(self):
        proofs,final=self.run_prefix("defect-ix119-rule-20260913a-0017",30,"DAGGER_THROW")
        self.assertTrue(proofs[-1]["remaining_battle_plan_stopped"])
        self.assertEqual(final["decision"],"card_reward")

    def test_touch_original_filter_excludes_free_card_from_two_raw_cards(self):
        self.mechanism_fixture("touch")

    def test_hologram_two_options_keeps_real_pending_selection(self):
        self.mechanism_fixture("pending")

    def mechanism_fixture(self, kind):
        label="original-return-mechanism-"+kind+"-"+uuid.uuid4().hex[:12]
        bridge=Bridge(label);trace=[]
        def send(**request):
            response=bridge.send(**request)
            trace.append({"request":copy.deepcopy(request),"response":copy.deepcopy(response)})
            self.assertNotEqual(response.get("type"),"error",response)
            return response
        try:
            send(cmd="start_run",character="Defect",ascension=10,seed="original-return-mechanism-v1")
            send(cmd="set_player",hp=1000,max_hp=1000,relics=[],
                deck=["ICE_LANCE","CLAW"] if kind=="touch" else ["STRIKE_DEFECT","DEFEND_DEFECT","HOLOGRAM"],
                potions=["TOUCH_OF_INSANITY"] if kind=="touch" else [])
            state=send(cmd="enter_room",type="combat",encounter="SHRINKER_BEETLE_WEAK")
            if kind=="touch":
                self.assertEqual(len(state["hand"]),2)
                state=send(cmd="action",action="use_potion",args={"potion_index":0})
                event=state["choice_audit"]["original_returns"][0]
                self.assertTrue(event["verified"])
                self.assertEqual(event["raw_source_count_at_entry"],2)
                self.assertEqual(event["returned_count"],1)
                self.assertEqual(event["returned_cards"][0]["CardId"],"ICE_LANCE")
                self.assertIn("energy=False:3",event["returned_cards"][0]["StateKey"])
                self.assertFalse(event["filter_reexecuted_by_observer"])
                self.assertEqual(event["selector_invocations_before"],event["selector_invocations_after"])
                self.assertEqual([c["cost"] for c in state["hand"] if c["id"]=="CARD.ICE_LANCE"],[0])
                meta=send(cmd="choice_meta")
                self.assertEqual(meta["selection"],"none")
                self.assertEqual(meta["completion_audit"],state["choice_audit"])
            else:
                for card_id in ("STRIKE_DEFECT","DEFEND_DEFECT","HOLOGRAM"):
                    index=next(c["index"] for c in state["hand"] if c["id"]=="CARD."+card_id)
                    args={"card_index":index}
                    if card_id=="STRIKE_DEFECT":args["target_index"]=0
                    state=send(cmd="action",action="play_card",args=args)
                self.assertEqual(state["decision"],"card_select")
                self.assertEqual(len(state["cards"]),2)
                event=state["choice_audit"]["original_returns"][0]
                self.assertFalse(event["verified"])
                self.assertFalse(event["original_task_completed_successfully"])
                self.assertGreater(event["selector_invocations_after"],event["selector_invocations_before"])
                meta=send(cmd="choice_meta")
                index=next(c["index"] for c in meta["cards"] if c["id"]=="STRIKE_DEFECT")
                state=send(cmd="action",action="select_cards",args={"indices":str(index)})
                self.assertEqual(state["decision"],"combat_play")
                self.assertIn("CARD.STRIKE_DEFECT",[c["id"] for c in state["hand"]])
        finally:
            bridge.close()
            (ROOT/"outputs"/(label+".json")).write_text(json.dumps({"provenance":"artificial_mechanism_fixture",
                "training_eligible":False,"solver_used":False,"original_effects_only":True,
                "versions":{"engine":file_evidence(ROOT.parent/"sts2-cli/lib/sts2.dll"),
                    "cli":file_evidence(ROOT.parent/"sts2-cli/src/Sts2Headless/bin/Debug/net9.0/Sts2Headless.dll"),
                    "bridge":file_evidence(ROOT/"runtime/host/bin/Debug/net9.0/SolverBridge.dll")},"trace":trace},
                ensure_ascii=False,indent=2),encoding="utf-8")


if __name__=="__main__":unittest.main()
