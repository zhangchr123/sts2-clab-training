"""Authenticate an actual next-turn Toasty selection absent from an old plan."""
import copy
from combat_executor import CombatExecutor,choice_plans

def require(value,message):
    if not value:raise RuntimeError('Unpredicted setup: '+message)

def fields(data,expected,message):
    require(isinstance(data,dict) and all(type(data.get(k)) is type(v) and data[k]==v for k,v in expected.items()),message)

def proof(before,state,action,meta,action_index):
    fields(action,{'Kind':'EndTurn','Turn':before.get('player_turn')},'original action is not this turn end')
    require(type(action_index) is int and action_index>=0 and not choice_plans(action),'planned choice cannot be discarded')
    require(type(before.get('player_turn')) is int and before['player_turn']>=1,'missing original player turn')
    fields(before,{'decision':'combat_play'},'prior state is not combat play')
    fields(state,{'decision':'card_select','min_select':1,'max_select':1},'not a single actual pending selection')
    require(before.get('context',{}).get('combat_in_progress') is True and
        state.get('context',{}).get('combat_in_progress') is True,'combat is not active')
    identity=CombatExecutor.setup_state_identity(before)
    require(identity==CombatExecutor.setup_state_identity(state) and type(identity['combat_id']) is int and
        identity['combat_id']>=1 and all(v is not None for v in identity.values()),'combat identity changed')
    fields(meta,{'type':'choice_meta','selection':'card_select','knowledge_choice':None},'wrong pending choice query')
    origin=meta.get('setup_origin');CombatExecutor.verify_setup_origin(origin,phase='Start')
    turn=before['player_turn']+1;capture=origin['capture_id'];player=origin['player_id']
    fields(origin,{'captured_turn':turn,'live_player_turn':turn},'not the actual next player turn')
    fields(meta.get('setup_choice'),{'schema_version':'toasty-mittens-setup-choice-v1','capture_id':capture,
        'source_method':'CardSelectCmd.FromHand','source_id':'TOASTY_MITTENS','source_is_current_live_relic':True,
        'original_task_pending':True,'player_id':player,'player_turn':turn,'effect':'Exhaust','source_pile':'Hand',
        'timing':'PlayerTurnStart','context_id':'','min_select':1,'max_select':1,'filter_is_null':True},'unbound actual Toasty task')
    cards=meta.get('cards');actual_cards=state.get('cards')
    require(isinstance(cards,list) and isinstance(actual_cards,list) and len(cards)==len(actual_cards)>=2,
        'missing actual multi-card pending hand')
    for i,card in enumerate(cards):
        fields(card,{'index':i},'noncanonical actual option index')
        require(type(card.get('upgrade_level')) is int and card['upgrade_level']>=0 and
            all(isinstance(card.get(k),str) and card[k] for k in ('id','key')),'missing actual choice fingerprint')
    audit=state.get('choice_audit');fields(audit,{'schema_version':'combat-choice-return-v2','closed':True,
        'events':[],'original_returns':[]},'end-turn audit is incomplete')
    require(meta.get('completion_audit')==audit and type(audit.get('action_id')) is int and audit['action_id']>=1,
        'stale actual end-turn completion audit')
    parent=audit.get('parent')
    fields(parent,{'action':'end_turn','card_index':-1,'card_id':None,'card_key':None,'player_id':player,
        'combat_id':identity['combat_id'],'player_turn':before['player_turn'],'combat_active_before':True,
        'potion_index':-1,'potion_slot':-1,'potion_id':None},'wrong original end-turn parent')
    end=meta.get('turn_end_origin')
    fields(end,{'schema_version':'original-end-turn-tasks-v1','action_id':audit['action_id'],
        'parent':parent,'closed':True,'setup_origin':origin,'setup_capture_before':capture-1},'missing original end-turn task owner')
    before_task=end.get('before_action');counter=before_task.get('selector_invocations') if isinstance(before_task,dict) else None
    require(type(counter) is int and counter>=0,'missing original selector counter')
    fields(before_task,{'same_original_combat':True,'player_turn':before['player_turn'],'player_phase':'Play',
        'combat_active':True,'combat_ending':False,'selector_invocations':counter,'selector_pending':False},'invalid pre-action task state')
    after_task={'same_original_combat':True,'player_turn':turn,'player_phase':'Start',
        'combat_active':True,'combat_ending':False,'selector_invocations':counter+1,'selector_pending':True}
    fields(end.get('after_action'),after_task,'original end turn did not create this pending selector')
    calls=end.get('calls');kinds=('CombatManager.SetupPlayerTurn','ToastyMittens.AfterPlayerTurnStart','ToastyMittens.CardSelectCmd.FromHand')
    require(isinstance(calls,list) and len(calls)==3,'unexpected original task sequence')
    for i,(call,kind) in enumerate(zip(calls,kinds)):
        fields(call,{'index':i,'kind':kind,'setup_capture_id':capture,'original_task_completed_successfully':False,
            'original_task_status':'WaitingForActivation'},'original task identity/completion differs')
        fields(call.get('entry'),{**after_task,'selector_invocations':counter,'selector_pending':False},'original task did not begin before this selector')
        fields(call.get('at_method_return'),after_task,'original task is no longer waiting on this selector')
        if i>0:fields(call,{'source_is_original_player_object':True},'wrong original player object')
    fields(calls[2],{'filter_is_null':True,'min_select':1,'max_select':1,'require_manual_confirmation':False,
        'raw_hand_count':len(cards)},'original FromHand arguments changed')
    return {'schema_version':'actual-unpredicted-turn-setup-replan-v1','reason':'original_end_turn_created_unplanned_toasty_setup',
        'action_index':action_index,'action':copy.deepcopy(action),'before_state':copy.deepcopy(before),
        'actual_pending_state':copy.deepcopy(state),'actual_choice_metadata':copy.deepcopy(meta),
        'remaining_battle_plan_stopped':True,'selection_submitted':False,'next_step_requires_fresh_setup_solve':True}
