"""Offline candidate for one observed training death; no games or runtime edits."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

HERE = Path('D:/sts2-training/inspection')
ROOT = HERE.parent / 'staging/replay-parent-order-311/sts2-solver-bridge'
RUN = ROOT / 'outputs/defect-public-route-order-search-20260916a-training-route_strong-027'
OUT = Path('E:/sts2-training-archives/inspection/cheese-nominal-cost-20260916')
CANDIDATE = HERE / 'cheese-nominal-cost-candidate/event_cost_features.py'
sys.path.insert(0, str(Path(__file__).resolve().parent))
from decision_data import DataContractError, materialize_candidate
import event_cost_features as candidate
old_spec = importlib.util.spec_from_file_location('cheese_original_costs', ROOT/'event_cost_features.py')
original = importlib.util.module_from_spec(old_spec); old_spec.loader.exec_module(original)
import event_risk_guard as guard
from run_metadata import file_evidence

SEARCH = 'ROOM_FULL_OF_CHEESE.pages.INITIAL.options.SEARCH'
GORGE = 'ROOM_FULL_OF_CHEESE.pages.INITIAL.options.GORGE'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def lines(path):
    return [json.loads(s) for s in path.read_text(encoding='utf-8-sig').splitlines()]


def write_new(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


def load_case():
    packets = lines(RUN / 'policy.jsonl')
    packet = packets[-1]
    records = [r for r in lines(RUN / 'decisions.jsonl')
               if r.get('record_type') == 'decision_completed' and r['decision_id'] == packet['decision_id']]
    assert len(records) == 1
    record = records[0]
    candidates = {r['candidate_id']: materialize_candidate(record['candidate_set'], r['request'])
                  for r in packet['scoring']['scores']}
    weights = read(Path(packet['scoring']['search_policy_source']['path']))['parameters']
    return record, packet['scoring'], candidates, weights


def rescore(state, packet, candidates, weights):
    result = copy.deepcopy(packet)
    for row in result['scores']:
        extra = candidate.extra_features(state, row, candidates[row['candidate_id']])
        old = row['search_features']
        change = sum(weights[k] * (extra[k] - old[k]) for k in extra)
        row['search_features'].update(extra)
        row['score'] += change
        row['learned_residual'] += change
    with patch.object(guard, 'CONTRACTS', candidate.CONTRACTS):
        return guard.adjust(state, result, candidates, weights)


class CheeseCostTests(unittest.TestCase):
    def test_exact_original_death_and_missing_cost_mapping(self):
        self.assertEqual(record['state']['player']['hp'], 14)
        self.assertEqual(record['next_state']['player']['hp'], 0)
        self.assertEqual(record['chosen']['request']['args']['option_index'], 1)
        self.assertEqual({c['evidence']['text_key'] for c in candidates.values()}, {GORGE, SEARCH})
        self.assertNotIn(SEARCH, original.CONTRACTS)
        self.assertEqual([r['score'] for r in scoring['scores']], [0., 0.])

    def test_original_case_changes_tie_to_zero_cost_option(self):
        changed = rescore(record['state'], scoring, candidates, weights)
        best = max(changed['scores'], key=lambda r: r['score'])
        self.assertEqual(best['request']['args']['option_index'], 0)
        costly = next(r for r in changed['scores'] if r['request']['args']['option_index'] == 1)
        self.assertTrue(costly['event_risk_guard']['hard_blocked'])
        self.assertFalse(costly['event_risk_guard']['actual_damage_or_guaranteed_death_claimed'])

    def test_shared_damage_var_does_not_make_gorge_cost_hp(self):
        for row in scoring['scores']:
            c = candidates[row['candidate_id']]
            self.assertEqual(c['evidence']['vars']['Damage'], 14)
            features = candidate.extra_features(record['state'], row, c)
            expected = 1. if c['evidence']['text_key'] == SEARCH else 0.
            self.assertEqual(features['event_nominal_hp_cost_per_current_hp'], expected)

    def test_healthy_hp_penalizes_cost_without_hard_block(self):
        state = copy.deepcopy(record['state']); state['player']['hp'] = 15
        changed = rescore(state, scoring, candidates, weights)
        costly = next(r for r in changed['scores'] if r['request']['args']['option_index'] == 1)
        self.assertFalse(costly['event_risk_guard']['hard_blocked'])
        self.assertGreater(costly['event_risk_guard']['nominal_cost_penalty'], 0.)

    def test_missing_or_blocked_zero_cost_option_does_not_block_every_choice(self):
        for mode in ('missing', 'blocked'):
            packet = copy.deepcopy(scoring)
            if mode == 'missing':
                packet['scores'] = [r for r in packet['scores'] if r['request']['args']['option_index'] == 1]
            else:
                zero = next(r for r in packet['scores'] if r['request']['args']['option_index'] == 0)
                zero['deck_discipline']['hard_blocked'] = True
                zero['score'] = -1e100
            changed = rescore(record['state'], packet, candidates, weights)
            costly = next(r for r in changed['scores'] if r['request']['args']['option_index'] == 1)
            self.assertFalse(costly['event_risk_guard']['hard_blocked'])

    def test_unknown_and_invalid_variables_are_not_inferred(self):
        costly = next(r for r in scoring['scores'] if r['request']['args']['option_index'] == 1)
        for invalid in (None, True, -1, float('nan')):
            c = copy.deepcopy(candidates[costly['candidate_id']]); c['evidence']['vars']['Damage'] = invalid
            with self.assertRaises(DataContractError):
                candidate.extra_features(record['state'], costly, c)
        c['evidence']['text_key'] = 'UNKNOWN.pages.INITIAL.options.SEARCH'
        self.assertEqual(set(candidate.extra_features(record['state'], costly, c).values()), {0.})

    def test_only_two_contracts_added_and_311_schema_other_features_preserved(self):
        self.assertEqual(set(candidate.CONTRACTS) - set(original.CONTRACTS), {SEARCH, GORGE})
        for key, value in original.CONTRACTS.items():
            self.assertEqual(candidate.CONTRACTS[key], value)
        changed = rescore(record['state'], scoring, candidates, weights)
        for before, after in zip(scoring['scores'], changed['scores']):
            self.assertEqual(len(after['search_features']), 311)
            for key, value in before['search_features'].items():
                if key not in original.EXTRA_PARAMETERS:
                    self.assertEqual(after['search_features'][key], value)
            self.assertEqual(before['rule_score'], after['rule_score'])



    def test_actual_staged_policy_factory_and_choose_block_nominal_fatal_search(self):
        import tempfile
        from public_route_policy import make_artifact, PublicRoutePolicy
        config = read(RUN/'manifest.json')['solver_requested_config']
        artifact = make_artifact(weights, config, training={'purpose':'isolated_original_event_regression'})
        with tempfile.TemporaryDirectory(prefix='cheese-policy-check-') as folder:
            path = Path(folder)/'model.json'; write_new(path, artifact)
            policy = PublicRoutePolicy(path, solver_config=config, seed='offline-cheese-regression')
            answer = policy.choose(copy.deepcopy(record['state']))
        self.assertEqual(answer['request']['args']['option_index'], 0)
        rows = answer['scoring']['scores']
        self.assertEqual(len(rows), 2)
        costly = next(r for r in rows if r['request']['args']['option_index'] == 1)
        self.assertTrue(costly['event_risk_guard']['hard_blocked'])
        self.assertEqual(costly['search_features']['event_nominal_cost_reaches_current_hp'], 1.)
        self.assertEqual(len(costly['search_features']), 311)


record, scoring, candidates, weights = load_case()
if __name__ == '__main__':
    unittest.main(verbosity=2)
