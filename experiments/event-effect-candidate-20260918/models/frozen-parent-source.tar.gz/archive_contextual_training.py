"""Archive a completed, reconciled CEM runtime before applying engine fixes.

Does not select parameters, consume reserved seeds, or change training files.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prefix_interventions import read_json, require, unchanged
from run_metadata import file_evidence
from train_contextual_run import METHOD, VERSION, WARM_VERSION, write_new


def closed_inputs(protocol_path):
    protocol_path = Path(protocol_path).resolve()
    folder = protocol_path.parent
    protocol = read_json(protocol_path)
    require(protocol['schema_version'] in {VERSION, WARM_VERSION}
            and protocol['method'] == METHOD, 'Unsupported training protocol')
    completion_path = folder / 'training-completed.json'
    completion = read_json(completion_path)
    summaries = completion['generations']
    require(len(summaries) == len(protocol['training_seeds']) > 0,
            'All planned generations must finish before archiving')
    receipts = [file_evidence(protocol_path), file_evidence(completion_path)]
    for generation, evidence in enumerate(summaries):
        generation_folder = folder / f'generation-{generation:02d}'
        summary_path = generation_folder / 'summary.json'
        require(file_evidence(summary_path) == evidence, 'Wrong or changed generation summary')
        summary = read_json(summary_path)
        check_path = generation_folder / 'RECONCILIATION.json'
        check = read_json(check_path)
        expected = len(protocol['training_seeds'][generation])
        require(check['passed'] is True and check['generation'] == generation
                and check['source_protocol'] == file_evidence(protocol_path)
                and check['source_summary'] == evidence
                and check['actual_games'] == 17 * expected,
                'Complete matching reconciliation required')
        require(summary['generation'] == generation and len(summary['evaluations']) == 17
                and all(r['actual_games'] == r['planned_games'] == expected
                        for r in summary['evaluations']), 'Incomplete generation population')
        require(check['evaluations_recomputed_from_original_traces'] == summary['evaluations'],
                'Reconciled returns do not match generation')
        audits = check['run_audit_sources']
        require(len(audits) == 17 * expected and len({r['path'] for r in audits}) == len(audits)
                and unchanged(audits), 'Missing or changed run audit')
        for audit in audits:
            row = read_json(audit['path'])
            require(row['audit_passed'] is True and not row['issues']
                    and unchanged(row['actual_source_evidence']), 'Raw run evidence changed')
        allocation = read_json(summary['source_allocation']['path'])
        require(unchanged([summary['source_allocation']] + allocation['artifacts']),
                'Allocation or candidate model changed')
        receipts += [evidence, file_evidence(check_path), summary['source_allocation']]
        receipts += allocation['artifacts'] + audits
    require(unchanged(protocol['frozen_sources'] + receipts),
            'Frozen training runtime or receipts changed')
    return protocol, receipts


def archive(protocol_path):
    protocol_path = Path(protocol_path).resolve()
    protocol, supplements = closed_inputs(protocol_path)
    folder = protocol_path.parent
    destination = folder / 'closed-runtime-archive.zip'
    receipt_path = folder / 'closed-runtime-archive.json'
    require(not destination.exists() and not receipt_path.exists(), 'Archive already exists')
    records, receipt_records = [], []
    with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED) as bundle:
        for group, sources, target in [('frozen', protocol['frozen_sources'], records),
                                       ('receipts', supplements, receipt_records)]:
            for index, row in enumerate(sources):
                data = Path(row['path']).read_bytes()
                require(len(data) == row['bytes']
                        and hashlib.sha256(data).hexdigest() == row['sha256'],
                        'Source changed during archive')
                member = f'{group}/{index:04d}/{Path(row["path"]).name}'
                bundle.writestr(member, data)
                target.append({**row, 'archive_member': member})
        bundle.writestr('sources.json', json.dumps(records, indent=2))
        bundle.writestr('supplemental-sources.json', json.dumps(receipt_records, indent=2))
    with zipfile.ZipFile(destination) as bundle:
        for row in records + receipt_records:
            data = bundle.read(row['archive_member'])
            require(len(data) == row['bytes']
                    and hashlib.sha256(data).hexdigest() == row['sha256'],
                    'Archive readback differs from authenticated source')
    require(unchanged(protocol['frozen_sources'] + supplements), 'Source drift while archiving')
    receipt = {'archive': str(destination), 'sha256': file_evidence(destination)['sha256'],
               'frozen_sources_verified': len(records), 'sources': records,
               'supplements': receipt_records, 'source_protocol': file_evidence(protocol_path),
               'archive_readback_verified': True, 'training_complete': True,
               'reserved_evaluation_performed_by_archive': False,
               'archiver_source': file_evidence(Path(__file__).resolve())}
    write_new(receipt_path, receipt)
    return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', required=True, type=Path)
    result = archive(parser.parse_args().protocol)
    print(json.dumps({k: result[k] for k in ('archive', 'sha256', 'frozen_sources_verified')}))
