"""Export candidate scores for a future cheap-LLM advisor; never execute or call an LLM."""
import argparse
import json
from pathlib import Path

from initial_policy import InitialPolicy
from decision_data import enumerate_candidates
from selection_policy import SelectionPolicy
from train_ranker import SmallValuePolicy
from run_metadata import atomic_json


def advice(state, model_path=None, selection_purpose=None, selection_budget=256):
    base = SmallValuePolicy(model_path, epsilon=0) if model_path else InitialPolicy(epsilon=0)
    policy = SelectionPolicy(base, max_evaluations=selection_budget)
    scoring = policy.score(state, selection_purpose=selection_purpose)
    return {"schema": "sts2.candidate_advice.v3", "state_hash": scoring["state_hash"],
        "decision": state["decision"], "scores": scoring["scores"],
        "candidate_space": enumerate_candidates(state),
        "evaluated_candidates_complete": scoring.get("evaluated_candidates_complete", True),
        "search": scoring.get("selection_search"),
        "model": scoring.get("model"), "prior_source": scoring.get("prior_source"),
        "feature_policy_version": scoring.get("feature_policy_version", scoring.get("policy_version")),
        "mechanism_facts": scoring["mechanism_facts"],
        "selection_purpose": scoring.get("selection_purpose"),
        "score_semantics": scoring["score_semantics"], "calibrated_win_probability": False,
        "explanation_source": "auditable rule/feature evidence; not a model reasoning trace",
        "execution": "none", "llm_may_choose_any_legal_candidate": True,
        "deployment_trajectories_allowed_for_training": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", required=True, type=Path)
    parser.add_argument("--model", type=Path)
    parser.add_argument("--selection-purpose", choices=("upgrade", "remove", "transform", "enchant", "acquire"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--selection-budget", type=int, default=256)
    args = parser.parse_args()
    result = advice(json.loads(args.state.read_text(encoding="utf-8-sig")), args.model, args.selection_purpose, args.selection_budget)
    if args.output:
        atomic_json(args.output, result)
    else:
        print(json.dumps(result, ensure_ascii=True))


if __name__ == "__main__":
    main()
