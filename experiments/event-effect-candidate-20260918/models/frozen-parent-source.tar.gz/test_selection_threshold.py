"""Isolated threshold contracts and same-state scorer equivalence, not win rates."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import contextual_policy
from decision_data import (DEFAULT_ENUMERATION_LIMIT, LEGACY_ADAPTER_VERSION,
                           _bind_candidate_set, enumerate_candidates)
from selection_policy import SelectionPolicy, validate_selection_evidence
from test_selection_policy import selection_state

ORIGINAL = Path(r'C:\Users\zhangchr\Documents\code\sts2-solver-bridge')


class ThresholdTests(unittest.TestCase):
    def test_old_explicit_record_reconstructs_above_new_default(self):
        current = selection_state(n=8, minimum=4, maximum=4)
        modern = enumerate_candidates(current, max_candidates=100000)
        self.assertEqual(modern['candidate_count'], 1680)
        self.assertEqual(enumerate_candidates(current)['representation'], 'ordered_selection_implicit_v1')
        self.assertEqual(_bind_candidate_set(current, modern), modern)
        legacy = {k: v for k, v in modern.items()
                  if k not in {'representation', 'candidate_count', 'enumeration_limit'}}
        legacy['adapter_version'] = LEGACY_ADAPTER_VERSION
        self.assertEqual(_bind_candidate_set(current, legacy), legacy)

    def test_natural_default_path_matches_diagnostic_without_runtime_patches(self):
        diagnostic = ORIGINAL / 'outputs/diagnostic-selection-threshold-20260914a'
        current = json.loads((diagnostic / 'state.json').read_text(encoding='utf-8'))
        expected = json.loads((diagnostic / 'budget-256.json').read_text(encoding='utf-8'))
        declaration = json.loads((diagnostic / 'protocol.json').read_text(encoding='utf-8'))
        old = json.loads(Path(declaration['original_model']['path']).read_text(encoding='utf-8'))
        # New artifact explicitly binds the isolated source files; old model bytes stay untouched.
        artifact = contextual_policy.make_artifact(old['parameters'], old['solver_requested_config'],
            training={'diagnostic_only': True, 'weights_from': declaration['original_model']})
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent.parent) as temp:
            path = Path(temp) / 'diagnostic-model.json'
            path.write_text(json.dumps(artifact), encoding='utf-8')
            base = contextual_policy.ContextualPolicy(path, solver_config=old['solver_requested_config'],
                seed='threshold-integration-fixture', epsilon=0.)
            policy = SelectionPolicy(base)
            candidates = enumerate_candidates(current)
            self.assertEqual(DEFAULT_ENUMERATION_LIMIT, 256)
            self.assertEqual(candidates['candidate_count'], 93024)
            self.assertEqual(candidates['enumeration_limit'], 256)
            before = base.rng.getstate()
            packet = policy.score(current, selection_purpose='upgrade')
            self.assertEqual(base.rng.getstate(), before)
            fields = ('request', 'score', 'features', 'search_features', 'learned_residual', 'rule_score')
            self.assertEqual([{k: r[k] for k in fields} for r in packet['scores']],
                             [{k: r[k] for k in fields} for r in expected['scores']])
            self.assertEqual(len(packet['scores']), 256)
            picked = policy.choose(current, candidates, selection_purpose='upgrade')
            self.assertTrue(validate_selection_evidence(current, candidates, picked))
            self.assertLessEqual(len(picked['scoring']['scores']), 256)
            self.assertEqual(max(r['score'] for r in picked['scoring']['scores']),
                             max(r['score'] for r in expected['scores']))
            tampered = copy.deepcopy(candidates)
            tampered['candidate_count'] -= 1
            with self.assertRaises(ValueError):
                validate_selection_evidence(current, tampered, picked)


if __name__ == '__main__':
    unittest.main(verbosity=2)
