import copy
import json
from pathlib import Path
import tempfile
import unittest
from test_initial_policy import card,state
from decision_data import DataContractError
import event_risk_policy as p
import deck_discipline as discipline

class EventRiskPolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=p.ROOT/'outputs');self.addCleanup(self.temp.cleanup)
        self.config=json.loads((p.ROOT/'configs/defect-v3-base.json').read_text(encoding='utf-8'))
        weights=dict.fromkeys(p.PARAMETERS,4.)
        self.path=Path(self.temp.name)/'model.json'
        self.path.write_text(json.dumps(p.make_artifact(weights,self.config,training={'synthetic':True})),encoding='utf-8')
    def model(self):return p.EventRiskSelectionPolicy(p.EventRiskPolicy(self.path,solver_config=self.config,seed='compact-tests',epsilon=0.))
    def current(self,n):
        s=state([card('BALL_LIGHTNING',damage=7),card('DEFRAGMENT',stats={'focuspower':1})]);s['context']['act']=2
        s['player'].update(deck=[card('DEFEND_DEFECT',block=5)]*n,deck_size=n)
        return s
    def test_rewards_shop_bundle_and_ordered_acquisition_obey_hard_cap(self):
        m=self.model();s=self.current(36)
        self.assertEqual(m.choose(s)['request']['action'],'skip_card_reward')
        shop=copy.deepcopy(s);shop.update(decision='shop',relics=[],potions=[],card_removal_available=False,can_leave=True)
        shop['player']['potions']=[]
        shop['cards']=[dict(shop['cards'][0],index=0,cost=1,card_cost=1,can_purchase=True)]
        self.assertNotEqual(m.choose(shop)['request']['action'],'buy_card')
        bundle=self.current(35);bundle.update(decision='bundle_select',bundles=[{'index':0,'cards':[card('BALL_LIGHTNING',damage=7)]*2}]);bundle.pop('cards')
        self.assertTrue(next(r for r in m.score(bundle)['scores'] if r['request']['action']=='select_bundle')['deck_discipline']['hard_blocked'])
        ordered=self.current(36);ordered.update(decision='card_select',min_select=0,max_select=4,
            cards=[dict(card('BALL_LIGHTNING',damage=7),index=i) for i in range(12)])
        chosen=m.choose(ordered,selection_purpose='acquire')
        row=next(r for r in chosen['scoring']['scores'] if r['candidate_id']==chosen['candidate_id'])
        self.assertEqual(row['deck_discipline']['direct_added_cards'],0)
        ordered.update(min_select=4,max_select=4)
        with self.assertRaises(DataContractError):m.choose(ordered,selection_purpose='acquire')
    def test_soft_cost_is_stronger_after_25_without_changing_residual_weights(self):
        m=self.model();scores=[]
        for n in (19,24,25,30):
            r=m.score(self.current(n))['scores'][0];scores.append(r['deck_discipline']['penalty'])
            self.assertEqual(r['score'],r['deck_discipline']['score_before']-r['deck_discipline']['penalty'])
            self.assertEqual(len(r['search_features']),289)
        self.assertEqual(scores,[1.,3.,14.,24.])
        self.assertEqual(m.base.artifact['parameters'],dict.fromkeys(p.PARAMETERS,4.))
        with self.assertRaises(DataContractError):p.EventRiskPolicy(self.path,solver_config=self.config,seed='x',epsilon=.1)
    def test_special_build_relaxes_whole_run_and_mirror_requires_actual_growth(self):
        for source in ('BING_BONG','CLONE'):
            m=self.model();s=self.current(40)
            if source=='BING_BONG':s['player']['relics']=[{'id':'RELIC.BING_BONG'}]
            else:s['player']['deck'][0]=dict(s['player']['deck'][0],enchantment='克隆 / Clone')
            m.choose(s)
            ordinary=self.current(40)
            self.assertTrue(all(not r['deck_discipline']['hard_blocked'] for r in m.score(ordinary)['scores']))
        for grown in (False,True):
            m=self.model();event=self.current(20);event.update(decision='event_choice',options=[{'index':0,'is_locked':False,'text_key':discipline.MIRROR}])
            m.choose(event);result=m.choose(self.current(41 if grown else 20))
            expected=['REFLECTIONS_SHATTER'] if grown else []
            self.assertEqual(result['scoring']['scores'][0]['deck_discipline']['special_builds'],expected)
    def test_removal_upgrade_transform_and_enchant_are_not_card_acquisitions(self):
        m=self.model();s=self.current(36);s.update(decision='card_select',min_select=1,max_select=1)
        for purpose in ('remove','upgrade','transform','enchant',None):
            r=m.choose(s,selection_purpose=purpose)
            self.assertTrue(all(x['deck_discipline']['direct_added_cards']==0 for x in r['scoring']['scores']))
        data=json.loads(self.path.read_text());data['deck_contract']['ordinary_hard_maximum']=999
        self.path.write_text(json.dumps(data),encoding='utf-8')
        with self.assertRaises(DataContractError):self.model()

if __name__=='__main__':unittest.main()
