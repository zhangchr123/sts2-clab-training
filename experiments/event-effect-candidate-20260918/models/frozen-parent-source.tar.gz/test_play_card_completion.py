"""Original action-completion contract and artificial Feral fixtures; no training labels."""
import copy
import json
import pathlib
import subprocess
import tempfile
import time
import unittest
import uuid

from probe import Bridge, ROOT
from run_metadata import file_evidence


class PlayCardCompletionPureTests(unittest.TestCase):
    """Execute the exact production C# method against action-lifecycle test doubles."""

    @classmethod
    def setUpClass(cls):
        cls.directory = tempfile.TemporaryDirectory(prefix="sts2-play-action-contract-")
        cls.addClassCleanup(cls.directory.cleanup)
        folder = pathlib.Path(cls.directory.name)
        source = (ROOT.parent / "sts2-cli/src/Sts2Headless/RunSimulator.cs").read_text(encoding="utf-8")
        start = source.index("    private Dictionary<string, object?> DoPlayCard(")
        end = source.index("    // STS2 build 23372702 removed CombatManager.IsPlayPhase", start)
        method = source[start:end]
        harness = (ROOT / "inspection/play_action_contract_harness.cs").read_text(encoding="utf-8")
        (folder / "Program.cs").write_text(harness.replace("    // INSERT_PRODUCTION_METHOD", method), encoding="utf-8")
        (folder / "Contract.csproj").write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup>'
            '<OutputType>Exe</OutputType><TargetFramework>net9.0</TargetFramework>'
            '<ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable>'
            '</PropertyGroup></Project>', encoding="utf-8")
        build = subprocess.run(["dotnet", "build", "--nologo", "-v:q", str(folder / "Contract.csproj")],
                               capture_output=True, text=True, encoding="utf-8", timeout=60)
        if build.returncode:
            raise AssertionError(build.stdout + build.stderr)
        cls.dll = folder / "bin/Debug/net9.0/Contract.dll"

    def run_case(self, mode):
        result = subprocess.run(["dotnet", str(self.dll), mode], capture_output=True,
                                text=True, encoding="utf-8", timeout=10, check=True)
        row = json.loads(result.stdout)
        self.assertTrue(row["test_original_card_still_at_zero"])
        self.assertEqual(row["test_enqueues"], 0 if mode == "unplayable" else 1)
        return row

    def test_completed_play_with_unchanged_hand_is_success(self):
        row = self.run_case("completed")
        self.assertEqual(row["type"], "decision")
        self.assertEqual(row["play_action"]["outcome"], "completed")

    def test_delayed_specific_action_is_pumped_until_complete(self):
        row = self.run_case("delayed")
        self.assertEqual(row["play_action"]["outcome"], "completed")
        self.assertEqual(row["test_pumps"], 2)

    def test_cancellation_survives_finished_state_overwrite(self):
        row = self.run_case("canceled_then_finished")
        self.assertEqual(row["type"], "error")
        self.assertEqual(row["play_action"]["state"], "Finished")
        self.assertTrue(row["play_action"]["cancellation_observed"])

    def test_action_queue_and_completion_faults_remain_errors(self):
        for mode in ("faulted_then_finished", "queue_fault", "queue_canceled", "completion_fault", "completion_canceled"):
            with self.subTest(mode=mode):
                self.assertEqual(self.run_case(mode)["type"], "error")

    def test_noop_before_onplay_is_not_success(self):
        row = self.run_case("not_played")
        self.assertEqual(row["play_action"]["outcome"], "not_played")
        self.assertEqual(row["type"], "error")

    def test_pending_choice_does_not_claim_completion(self):
        row = self.run_case("pending")
        self.assertEqual(row["decision"], "card_select")
        self.assertEqual(row["play_action"]["outcome"], "awaiting_selection")
        self.assertNotEqual(row["play_action"]["completion_task_status"], "RanToCompletion")

    def test_timeout_is_error_and_does_not_retry(self):
        row = self.run_case("timeout")
        self.assertEqual(row["type"], "error")
        self.assertEqual(row["play_action"]["outcome"], "timeout")

    def test_unplayable_card_never_enqueues(self):
        self.assertEqual(self.run_case("unplayable")["type"], "error")


class FeralCardReturnLiveTests(unittest.TestCase):
    def run_feral_fixture(self, attack_id):
        label = "feral-return-" + attack_id.lower() + "-" + uuid.uuid4().hex[:12]
        bridge = Bridge(label)
        trace = []
        start = time.monotonic()

        def send(**request):
            self.assertLess(time.monotonic() - start, 45, "Fixture deadline; never resend an action")
            response = bridge.send(**request)
            trace.append({"request": copy.deepcopy(request), "response": copy.deepcopy(response)})
            self.assertNotEqual(response.get("type"), "error", response)
            return response

        try:
            send(cmd="start_run", character="Defect", ascension=10, seed="feral-return-fixture-v1")
            setup = send(cmd="set_player", hp=1000, max_hp=1000, deck=["FERAL", attack_id], relics=[], potions=[])
            self.assertEqual([c["id"].split(".")[-1] for c in setup["player"]["deck"]], ["FERAL", attack_id])
            state = send(cmd="enter_room", type="combat", encounter="NIBBITS_NORMAL")
            self.assertEqual(len(state["hand"]), 2)
            feral = next(c for c in state["hand"] if c["id"] == "CARD.FERAL")
            state = send(cmd="action", action="play_card", args={"card_index": feral["index"]})
            self.assertEqual(state["play_action"]["outcome"], "completed")
            self.assertEqual(len(state["hand"]), 1)
            self.assertEqual(state["hand"][0]["id"], "CARD." + attack_id)
            enemy = next(e for e in state["enemies"] if e["intends_attack"])
            enemy_index, before_hp = enemy["index"], enemy["hp"]
            before_damage = state["hand"][0]["stats"]["damage"]
            energy = state["energy"]
            returned = send(cmd="action", action="play_card", args={"card_index": 0, "target_index": enemy_index})
            self.assertEqual(returned["play_action"]["outcome"], "completed")
            self.assertEqual(returned["play_action"]["completion_task_status"], "RanToCompletion")
            self.assertFalse(returned["play_action"]["cancellation_observed"])
            self.assertEqual(len(returned["hand"]), 1)
            self.assertEqual(returned["hand"][0]["index"], 0)
            self.assertEqual(returned["hand"][0]["id"], "CARD." + attack_id)
            self.assertEqual(returned["energy"], energy)
            self.assertEqual(returned["enemies"][enemy_index]["hp"], before_hp - before_damage)
            if attack_id == "CLAW":
                self.assertEqual(returned["hand"][0]["stats"]["damage"], before_damage + 2)
            else:
                self.assertEqual(next(p["amount"] for p in returned["enemies"][enemy_index]["powers"] if p["name"] == "Weak"), 1)
            again_damage = returned["hand"][0]["stats"]["damage"]
            consumed = send(cmd="action", action="play_card", args={"card_index": 0, "target_index": enemy_index})
            self.assertEqual(consumed["play_action"]["outcome"], "completed")
            self.assertEqual(consumed["hand"], [])
            self.assertEqual(consumed["enemies"][enemy_index]["hp"], before_hp - before_damage - again_damage)
            rejected_request = {"cmd": "action", "action": "play_card", "args": {"card_index": 0, "target_index": enemy_index}}
            rejected = bridge.send(**rejected_request)
            trace.append({"request": rejected_request, "response": rejected})
            self.assertEqual(rejected["type"], "error")
            self.assertIn("Invalid card index", rejected["message"])
        finally:
            bridge.close()
            with (ROOT / "outputs" / (label + ".json")).open("x", encoding="utf-8") as stream:
                json.dump({"diagnostic_fixture": True, "training_eligible": False,
                    "not_current_state_clone": True, "no_solver_used": True,
                    "provenance": "artificial two-card original-engine Feral return; original damage/growth/weak/quota retained",
                    "sources": {"engine": file_evidence(ROOT.parent / "sts2-cli/lib/sts2.dll"),
                        "cli_source": file_evidence(ROOT.parent / "sts2-cli/src/Sts2Headless/RunSimulator.cs")},
                    "trace": trace}, stream, ensure_ascii=False, indent=2)

    def test_claw_returns_at_same_index_with_real_damage_and_growth(self):
        self.run_feral_fixture("CLAW")

    def test_go_for_the_eyes_returns_at_same_index_with_real_damage_and_weak(self):
        self.run_feral_fixture("GO_FOR_THE_EYES")


if __name__ == "__main__":
    unittest.main()
