"""Public Doll Room costs, complete scoring, and original-engine low-HP prefix checks."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
import uuid

from initial_policy import InitialPolicy
from decision_data import DataContractError, state_hash
from probe import Bridge, ROOT
from inspection.replay_cheese_event import checked_public, IGNORED_COMMANDS
import card_identity_policy as identity

SOURCE = Path('D:/sts2-training/staging/seeker-manual-repeat-return/sts2-solver-bridge/outputs')
NAME = 'defect-identity-warm-cem-20260915a'
PREFIX = 'DOLL_ROOM.pages.INITIAL.options.'


def original(candidate):
    run = SOURCE / f'{NAME}-generation-00-{candidate}-000'
    rows = [json.loads(line) for line in (run / 'trace.jsonl').read_text(encoding='utf-8').splitlines()]
    index = next(i for i, row in enumerate(rows) if row['response'].get('event_name') == 'Doll Room'
                 and any(o.get('text_key') == PREFIX + 'EXAMINE' for o in row['response'].get('options', [])))
    return run, rows, index


class DollRoomPolicyTests(unittest.TestCase):
    def test_exact_option_specific_public_variables_and_complete_candidates(self):
        _, rows, index = original(0)
        state = rows[index]['response']
        policy = InitialPolicy(epsilon=0.)
        scores = policy.score(state)['scores']
        self.assertEqual(len(scores), 3)
        self.assertGreater(scores[0]['score'], scores[1]['score'])
        self.assertGreater(scores[1]['score'], scores[2]['score'])
        self.assertEqual([r['card_detail']['nominal_hp_cost'] for r in scores], [0, 5, 15])
        self.assertTrue(all(r['card_detail']['actual_hp_loss_claimed'] is False for r in scores))
        for seed in range(12):
            self.assertEqual(InitialPolicy(epsilon=0., random_seed=seed).choose(state)['request']['args']['option_index'], 0)

    def test_unknown_keys_and_unknown_quantities_are_not_guessed(self):
        _, rows, index = original(0)
        state = copy.deepcopy(rows[index]['response'])
        for option in state['options']:
            option['text_key'] = option['text_key'].replace('DOLL_ROOM', 'UNKNOWN_EVENT')
        self.assertEqual([r['score'] for r in InitialPolicy().score(state)['scores']], [0., 0., 0.])
        state = copy.deepcopy(rows[index]['response'])
        del state['options'][2]['vars']['ExamineHpLoss']
        with self.assertRaises(DataContractError):
            InitialPolicy().score(state)

    def test_actual_227_parameters_keep_cost_ordering(self):
        _, rows, index = original(0)
        state = rows[index]['response']
        old = json.loads((SOURCE / NAME / 'models-00/candidate-10.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory(dir=ROOT / 'outputs') as temporary:
            path = Path(temporary) / 'model.json'
            current = identity.make_artifact(old['parameters'], old['solver_requested_config'],
                                             training={'diagnostic_only': True})
            self.assertEqual(current['parameters'], old['parameters'])
            self.assertEqual(len(current['parameters']), 227)
            path.write_text(json.dumps(current), encoding='utf-8')
            policy = identity.CardIdentityPolicy(path, solver_config=current['solver_requested_config'], seed='doll')
            self.assertEqual(policy.choose(state)['request']['args']['option_index'], 0)

    def test_both_original_low_hp_prefixes_survive_chosen_option(self):
        for candidate in (0, 5):
            with self.subTest(candidate=candidate):
                run, rows, index = original(candidate)
                self.assertEqual(rows[index]['response']['player']['hp'], 13)
                self.assertEqual(rows[-1]['response']['player']['hp'], 0)
                self.assertEqual(rows[-1]['request']['args']['option_index'], 2)
                label = 'doll-room-public-prefix-' + uuid.uuid4().hex[:10]
                bridge, replay = Bridge(label), []
                try:
                    for before in rows[:index + 1]:
                        request = before['request']
                        if request['cmd'] in IGNORED_COMMANDS:
                            continue
                        self.assertIn(request['cmd'], ('start_run', 'action'))
                        state = bridge.send(**request)
                        replay.append({'request': request, 'response': state})
                        self.assertEqual(state_hash(checked_public(state)), state_hash(checked_public(before['response'])))
                    choice = InitialPolicy(epsilon=0.).choose(state)
                    self.assertEqual(choice['request']['args']['option_index'], 0)
                    after = bridge.send(**choice['request'])
                    replay.append({'request': choice['request'], 'response': after})
                    self.assertNotEqual(after.get('type'), 'error')
                    self.assertEqual(after['player']['hp'], 13)
                    self.assertNotEqual(after.get('decision'), 'game_over')
                    self.assertFalse(after['context']['integrity_recovery_used'])
                finally:
                    bridge.close()
                    (ROOT / 'outputs' / (label + '.json')).write_text(json.dumps({
                        'source_run': str(run), 'origin': 'historical_prefix_diagnostic',
                        'natural_training_eligible': False, 'full_hidden_state_or_rng_equality_claimed': False,
                        'trace': replay}, ensure_ascii=False), encoding='utf-8')


if __name__ == '__main__':
    unittest.main()
