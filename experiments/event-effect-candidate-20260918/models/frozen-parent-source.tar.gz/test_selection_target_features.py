"""Recorded-game compatibility and an actionable learned target preference."""
import copy
import json
import math
from pathlib import Path
import sys
import unittest

HERE=Path('D:/sts2-training/inspection')
RUNTIME=HERE.parent/'staging/toasty-ending-optional-loop/sts2-solver-bridge'
# The standalone prototype uses the validated predecessor; stage copies already
# have their own runtime imports and must not redirect back to the predecessor.
if Path(__file__).resolve().parent==HERE:sys.path.insert(0,str(RUNTIME))
import selection_target_features as f
from decision_data import DataContractError,materialize_candidate
from prefix_interventions import read_json,read_lines

class SelectionTargetFeaturesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        proof=read_json(HERE/'COMPACT_SELECTION_BLIND_SPOT_20260915.json')
        cls.example=next(e for e in proof['examples'] if e['purpose']=='remove' and 'CARD.DUALCAST' in e['chosen'])
        folder=RUNTIME/'outputs'/cls.example['run_id']
        cls.records=[r for r in read_lines(folder/'decisions.jsonl') if r.get('record_type')=='decision_completed']
        cls.record=next(r for r in cls.records if r['decision_id']==cls.example['decision_id'])
        cls.packets={r['decision_id']:r for r in read_lines(folder/'policy.jsonl')}
        cls.packet=cls.packets[cls.record['decision_id']]

    def test_original_265_values_and_zero_extended_scores_remain_exact(self):
        source=self.packet['scoring']['search_policy_source']['path'];weights=read_json(source)['parameters'];new=f.zero_extend(weights)
        self.assertEqual({k:new[k] for k in f.ORIGINAL_PARAMETERS},weights)
        self.assertEqual(len(new),289)
        for row in self.packet['scoring']['scores']:
            c=materialize_candidate(self.record['candidate_set'],row['request']);values=f.features(self.record['state'],row,c)
            self.assertEqual({k:values[k] for k in f.ORIGINAL_PARAMETERS},row['search_features'])
            self.assertEqual(sum(weights[k]*row['search_features'][k] for k in weights),sum(new[k]*values[k] for k in new))

    def test_learned_weights_can_change_real_dualcast_removal_to_scored_strike(self):
        rows=[]
        for row in self.packet['scoring']['scores']:
            c=materialize_candidate(self.record['candidate_set'],row['request']);v=f.features(self.record['state'],row,c)
            adjusted=row['score']+4*v['remove_target_starter_attack']-4*v['remove_target_starter_orb_evoke']
            rows.append((adjusted,[card['id'] for card in c['evidence']['cards']]))
            self.assertTrue(all(v[k]==0 for k in f.EXTRA_PARAMETERS if k.startswith('transform_')))
        best=max(score for score,_ in rows)
        self.assertTrue(all(ids==['CARD.STRIKE_DEFECT'] for score,ids in rows if abs(score-best)<1e-12))

    def test_reward_decisions_do_not_activate_removal_or_transform_parameters(self):
        r=next(r for r in self.records if r['state']['decision']=='card_reward');p=self.packets[r['decision_id']]
        for row in p['scoring']['scores']:
            c=materialize_candidate(r['candidate_set'],row['request']);v=f.features(r['state'],row,c)
            self.assertEqual({k:v[k] for k in f.ORIGINAL_PARAMETERS},row['search_features'])
            self.assertTrue(all(v[k]==0 for k in f.EXTRA_PARAMETERS))

    def test_conflicting_roles_and_invalid_weights_cannot_silently_enter_model(self):
        row=copy.deepcopy(self.packet['scoring']['scores'][0]);c=materialize_candidate(self.record['candidate_set'],row['request'])
        row['features'].update(selection_remove=1.,selection_transform=1.)
        with self.assertRaises(DataContractError):f.features(self.record['state'],row,c)
        base=dict.fromkeys(f.ORIGINAL_PARAMETERS,0.)
        for bad in (True,math.nan,math.inf,4.1):
            p=dict(base);p[f.ORIGINAL_PARAMETERS[0]]=bad
            with self.assertRaises(DataContractError):f.zero_extend(p)

if __name__=='__main__':unittest.main(verbosity=2)
