"""Real DLL upgrade metadata and canonical-preview boundary; not training data."""
from collections import Counter
import json
import unittest
import uuid

from probe import Bridge, ROOT


class UpgradePreviewTests(unittest.TestCase):
    def setUp(self):
        self.label = self._testMethodName + "-" + uuid.uuid4().hex[:12]
        self.b = Bridge(self.label)
        self.requests = []
        self.send(cmd="start_run", character="Defect", ascension=10, seed="upgrade-preview-fixture")

    def tearDown(self):
        (ROOT / "outputs" / (self.label + ".json")).write_text(json.dumps({
            "provenance": "artificial upgrade-preview real-engine fixture; not training data",
            "requests": self.requests, "responses": self.b.rows,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        self.b.close()

    def send(self, **request):
        self.requests.append(request)
        response = self.b.send(**request)
        self.assertNotEqual(response.get("type"), "error", response)
        return response

    def check(self, card, level=None, upgradable=None):
        self.assertEqual(card["upgrade_preview_basis"], "canonical_plus_upgrade_level")
        self.assertIs(card["upgrade_preview_instance_modifiers_copied"], False)
        if level is not None:
            self.assertEqual(card["current_upgrade_level"], level)
        if upgradable is not None:
            self.assertIs(card["is_upgradable"], upgradable)
        status = card["upgrade_preview_status"]
        self.assertIn(status, {"available", "not_upgradable", "error"})
        if status == "available":
            self.assertIs(card["is_upgradable"], True)
            self.assertIsInstance(card["after_upgrade"], dict)
            self.assertNotIn("upgrade_preview_error", card)
        elif status == "not_upgradable":
            self.assertIs(card["is_upgradable"], False)
            self.assertIsNone(card["after_upgrade"])
            self.assertNotIn("upgrade_preview_error", card)
        else:
            self.assertIsNone(card["after_upgrade"])
            self.assertTrue(card["upgrade_preview_error"]["type"])

    def test_deck_and_smith_surface_distinguish_unupgraded_upgraded_and_unupgradable(self):
        state = self.send(cmd="enter_room", type="rest_site")
        original_deck = state["player"]["deck"]
        for card in original_deck:
            self.check(card, 0)
        zap = next(c for c in original_deck if c["id"] == "CARD.ZAP")
        bane = next(c for c in original_deck if c["id"] == "CARD.ASCENDERS_BANE")
        self.check(zap, 0, True)
        self.assertEqual(zap["upgrade_preview_status"], "available")
        self.assertEqual(zap["after_upgrade"]["cost"], 0)
        self.check(bane, 0, False)
        self.assertEqual(bane["upgrade_preview_status"], "not_upgradable")
        smith = next(o for o in state["options"] if o["option_id"] == "SMITH" and o["is_enabled"])
        state = self.send(cmd="action", action="choose_option", args={"option_index": smith["index"]})
        self.assertEqual(state["decision"], "card_select")
        for card in state["cards"]:
            self.check(card, 0, True)
        selected = next(c for c in state["cards"] if c["id"] == "CARD.ZAP")
        state = self.send(cmd="action", action="select_cards", args={"indices": str(selected["index"])})
        self.assertEqual(state["decision"], "map_select")
        upgraded = next(c for c in state["player"]["deck"] if c["id"] == "CARD.ZAP")
        self.check(upgraded, 1, False)
        self.assertEqual(upgraded["upgrade_preview_status"], "not_upgradable")
        self.assertEqual(upgraded["cost"], zap["after_upgrade"]["cost"])
        self.assertEqual(Counter(c["id"] for c in state["player"]["deck"]), Counter(c["id"] for c in original_deck))
        self.assertEqual(self.send(cmd="set_player")["player"]["deck"], state["player"]["deck"],
                         "Reading preview metadata must not mutate the live deck")

    def test_permanent_genetic_growth_is_not_misrepresented_as_copied_into_preview(self):
        self.send(cmd="set_player", deck=["GENETIC_ALGORITHM", "ZAP", "DUALCAST", "STRIKE_DEFECT", "DEFEND_DEFECT"])
        state = self.send(cmd="enter_room", type="combat", encounter="SHRINKER_BEETLE_WEAK")
        original = next(c for c in state["player"]["deck"] if c["id"] == "CARD.GENETIC_ALGORITHM")
        self.check(original, 0, True)
        self.assertEqual(original["stats"]["block"], 1)
        hand_card = next(c for c in state["hand"] if c["id"] == "CARD.GENETIC_ALGORITHM")
        state = self.send(cmd="action", action="play_card", args={"card_index": hand_card["index"]})
        grown = next(c for c in state["player"]["deck"] if c["id"] == "CARD.GENETIC_ALGORITHM")
        self.check(grown, 0, True)
        self.assertEqual(grown["stats"]["block"], 4, "Original engine permanently grows Genetic Algorithm by 3")
        self.assertEqual(grown["after_upgrade"]["stats"]["block"], 1,
                         "This is a canonical preview; live permanent growth is explicitly outside its basis")
        self.assertEqual(grown["after_upgrade"], original["after_upgrade"])
        self.assertEqual(grown["after_upgrade"]["stats"]["increase"], 4)
        readback = self.send(cmd="set_player")["player"]["deck"]
        self.assertEqual(next(c for c in readback if c["id"] == grown["id"]), grown)


if __name__ == "__main__":
    unittest.main()
