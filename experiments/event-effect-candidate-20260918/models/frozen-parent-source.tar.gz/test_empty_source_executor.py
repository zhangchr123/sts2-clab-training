"""Pure tests for original empty-source completion; no engine is started."""
import copy
import unittest

import combat_executor as staged
import replay_evidence as replay
import test_combat_executor as fixtures
import test_replay_evidence as replay_fixtures


def fixture():
    before, ending, action = fixtures.EndingChoiceTests().fixture()
    after = copy.deepcopy(before)
    before["discard_pile_count"] = after["discard_pile_count"] = 0
    after["choice_audit"] = copy.deepcopy(ending["choice_audit"])
    audit = after["choice_audit"]
    audit.update(schema_version="combat-choice-return-v2",
        coverage="FromCombatPile.IsEnding_or_NeowsFury.empty_source.synchronous_empty_return_only")
    audit["events"][0].update(reason="empty_source_pile", is_ending_at_entry=False,
        combat_active_at_entry=True, combat_active_at_return=True,
        source_pile_count_at_entry=0, source_pile_count_at_return=0,
        min_select=0, max_select=2, require_manual_confirmation=True,
        selector_is_headless=True, selector_pending_before=False, selector_pending_after=False)
    action["Choice"]["Cards"] = []
    action["TargetIndex"] = -1
    meta = {"type": "choice_meta", "selection": "none", "cards": [], "completion_audit": copy.deepcopy(audit)}
    return before, after, action, meta


def replay_fixture():
    before, after, action, meta = fixture()
    end = {"Kind": "EndTurn", "Turn": 1}
    terminal = fixtures.state("game_over", active=False)
    result = fixtures.solved([action, end])
    combat_meta = {"type": "combat_meta", "hand": [{"index": 2, "key": "neow"}], "enemies": []}
    engine = fixtures.FakeEngine([result, combat_meta, after, meta, terminal])
    trace = [{"request": {"cmd": "start_run"}, "response": copy.deepcopy(before)}]
    def send(**request):
        response = engine(**request)
        trace.append({"request": copy.deepcopy(request), "response": copy.deepcopy(response)})
        return response
    executor = staged.CombatExecutor(send)
    returned = executor.advance(before)
    return executor, engine, trace, returned


class EmptySourceExecutorTests(unittest.TestCase):
    def test_actual_empty_return_continues_next_original_action_without_select_or_replan(self):
        executor, engine, trace, returned = replay_fixture()
        self.assertEqual(returned["decision"], "game_over")
        self.assertEqual([r["action"] for r in engine.requests if r.get("cmd") == "action"], ["play_card", "end_turn"])
        self.assertEqual(sum(r.get("cmd") == "solve" for r in engine.requests), 1)
        proof = executor.solve_calls[0]["replay"][0]
        self.assertEqual(proof["kind"], "planned_empty_choice_completed")
        self.assertEqual(proof["plan"]["Cards"], [])
        self.assertIs(proof["remaining_battle_plan_stopped"], False)
        old = copy.deepcopy((executor.solve_calls, trace))
        self.assertEqual(replay.validate_replay_evidence(executor.solve_calls, trace)["replay_count"], 1)
        self.assertEqual((executor.solve_calls, trace), old)

    def test_unknown_empty_nonempty_token_nested_other_parent_and_absent_audit_fail_closed(self):
        for mutation in ("token", "nested", "nested_before", "other_parent", "missing_audit", "ending", "selection", "replay"):
            before, after, action, meta = fixture()
            if mutation == "token": action["Choice"]["Cards"] = [fixtures.token("x")]
            if mutation == "nested": action["NestedChoices"] = [copy.deepcopy(action["Choice"])]
            if mutation == "nested_before": action["NestedChoicesBeforePrimary"] = 1
            if mutation == "other_parent": action["CardId"] = "SEEKER"
            if mutation == "missing_audit": after.pop("choice_audit")
            if mutation == "ending": after["context"]["combat_in_progress"] = False
            if mutation == "selection": after["decision"] = "card_select"
            if mutation == "replay": action["ReplayCount"] = 1
            engine = fixtures.FakeEngine([meta])
            executor = staged.CombatExecutor(engine)
            executor.last_action_request = {"cmd": "action", "action": "play_card", "args": {"card_index": 2}}
            executor.solve_calls = [{}]
            with self.subTest(mutation=mutation):
                self.assertFalse(executor.resolve_empty_source_choice(before, after, action))
                self.assertEqual(engine.requests, [])
                self.assertNotIn("replay", executor.solve_calls[0])

    def test_original_return_pile_selector_and_parent_bindings_are_mandatory(self):
        mutations = [
            ("event", "combat_active_at_entry", False), ("event", "combat_active_at_return", False),
            ("event", "source_pile_count_at_entry", 1), ("event", "source_pile_count_at_return", False),
            ("event", "min_select", 1), ("event", "max_select", 0), ("event", "require_manual_confirmation", False),
            ("event", "selector_is_headless", False), ("event", "selector_pending_before", True),
            ("event", "selector_pending_after", True), ("event", "selector_invocations_after", 5),
            ("event", "original_task_completed_successfully", False), ("event", "original_returned_empty_array", False),
            ("event", "selected_cards", ["x"]), ("parent", "card_key", "different"),
            ("parent", "card_index", 5), ("parent", "player_turn", 2), ("parent", "combat_id", 4),
            ("audit", "schema_version", "combat-choice-return-v1"), ("audit", "events", []),
        ]
        for section, key, value in mutations:
            before, after, action, meta = fixture()
            audit = after["choice_audit"]
            target = audit if section == "audit" else audit["parent"] if section == "parent" else audit["events"][0]
            target[key] = value
            meta["completion_audit"] = copy.deepcopy(audit)
            executor = staged.CombatExecutor(fixtures.FakeEngine([meta]))
            executor.last_action_request = {"cmd": "action", "action": "play_card", "args": {"card_index": 2}}
            executor.solve_calls = [{}]
            with self.subTest(section=section, key=key), self.assertRaises(RuntimeError):
                executor.resolve_empty_source_choice(before, after, action)
            self.assertEqual(executor.send.requests, [{"cmd": "choice_meta"}])
            self.assertNotIn("replay", executor.solve_calls[0])

    def test_empty_return_trace_annotations_cannot_be_missing_tampered_or_detached(self):
        for mutation in ("missing", "unknown", "extra", "plan", "source_count", "parent_key", "next_solve", "stop", "pending"):
            executor, engine, traces, _ = replay_fixture()
            calls = executor.solve_calls
            proof = calls[0]["replay"][0]
            if mutation == "missing": calls[0].pop("replay")
            if mutation == "unknown": proof["kind"] = "skip_any_empty_token"
            if mutation == "extra": proof["unchecked"] = True
            if mutation == "plan": proof["plan"]["SourcePile"] = "Draw"
            if mutation == "source_count":
                for audit in (proof["actual_choice_audit"], traces[3]["response"]["choice_audit"], traces[4]["response"]["completion_audit"]):
                    audit["events"][0]["source_pile_count_at_entry"] = 1
            if mutation == "parent_key": traces[2]["response"]["hand"][0]["key"] = "another-card"
            if mutation == "next_solve":
                extra = copy.deepcopy(replay.solver_projection(calls)[0])
                calls.append(extra)
                traces.insert(4, copy.deepcopy(extra))
            if mutation == "stop": proof["remaining_battle_plan_stopped"] = True
            if mutation == "pending": traces[4]["response"]["selection"] = "card_select"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                replay.validate_replay_evidence(calls, traces)

    def test_existing_ending_and_knowledge_pure_suites_remain_valid(self):
        for build in (replay_fixtures.ending_fixture, replay_fixtures.knowledge_fixture):
            calls, trace = build()
            self.assertTrue(replay.validate_replay_evidence(calls, trace)["verified"])



if __name__ == "__main__":
    unittest.main()
