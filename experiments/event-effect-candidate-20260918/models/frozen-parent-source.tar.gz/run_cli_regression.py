"""Run the required five games per character with fresh isolated regression logs."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parent
CHARACTERS = ("Ironclad", "Silent", "Defect", "Regent", "Necrobinder")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    out = args.output or ROOT / "outputs" / ("cli-regression-" + uuid.uuid4().hex[:12])
    out = out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    cli = ROOT.parent / "sts2-cli"
    # Imported original game_log would prune its default logs. Redirect before
    # play_full_run creates any logger; each destination is newly created.
    script = ("import sys, game_log, play_full_run; "
              "game_log.LOG_DIR = sys.argv[1]; "
              "sys.argv = ['play_full_run.py', '5', sys.argv[2]]; "
              "sys.exit(play_full_run.main())")

    def run(character):
        directory = out / character
        directory.mkdir()
        start = time.monotonic()
        completed = subprocess.run([sys.executable, "-c", script, str(directory), character],
            cwd=cli / "python", capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
        log = directory / "regression.log"
        log.write_text(completed.stdout + completed.stderr, encoding="utf-8")
        summary = next((line for line in completed.stdout.splitlines() if line.startswith("Wins:")), "Missing summary")
        result = {"character": character, "returncode": completed.returncode,
                  "elapsed_seconds": round(time.monotonic() - start, 2), "log": str(log), "summary": summary}
        print(json.dumps(result), flush=True)
        return result

    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(run, CHARACTERS))
    passed = all(r["returncode"] == 0 and "Completed: 5/5" in r["summary"] for r in results)
    (out / "summary.json").write_text(json.dumps({
        "provenance": "existing random agent CLI environment regression; not training data",
        "passed": passed, "results": results}, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(out), "passed": passed}), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
