"""Uncropped historical solves and original pending-task boundaries; not natural samples."""
import copy
from pathlib import Path
import unittest
import uuid
from combat_executor import CombatExecutor
from inspection.replay_cheese_event import checked_public
from prefix_interventions import read_json, read_lines, unchanged
from replay_evidence import validate_replay_evidence
import test_liquid_memories as helpers

SOURCE_ROOT = Path('D:/sts2-training/staging/secret-catastrophe-return/sts2-solver-bridge')


class CosmicHandTrickReturns(unittest.TestCase):
    worker = helpers.LiquidMemoriesTests.worker
    save = helpers.LiquidMemoriesTests.save

    def run_original(self, generation, candidate, seed, card, manual=False, mutations=False):
        batch = SOURCE_ROOT / 'outputs/defect-contextual-d8-20260914b'
        name = f'{batch.name}-g{generation:02d}-c{candidate:02d}-s{seed:02d}'
        source = SOURCE_ROOT / 'outputs' / name
        receipt = read_json(batch / f'generation-{generation:02d}' / (name + '-audit.json'))
        self.assertTrue(receipt['audit_passed'] and unchanged(receipt['actual_source_evidence']))
        rows = read_lines(source / 'trace.jsonl')
        gate = max(i for i, r in enumerate(rows) if r['request']['cmd'] == 'solve')
        original = copy.deepcopy(rows[gate])
        label = 'cosmic-hand-full-' + str(candidate) + '-' + uuid.uuid4().hex[:10]
        bridge, traces, send = self.worker(label)
        executor, matched, passed = None, 0, False
        try:
            for row in rows[:gate]:
                if row['request']['cmd'] in {'solve', 'combat_meta', 'choice_meta'}: continue
                before = send(row['request'])
                self.assertEqual(checked_public(before), checked_public(row['response']))
                matched += 1
            executor = CombatExecutor(send, read_json(source / 'manifest.json')['solver_requested_config'])
            real_solve = executor.solve
            supplied = False
            def recorded_then_actual(state, budget, used=0, setup=False):
                nonlocal supplied
                if supplied: return real_solve(state, budget, used, setup)
                self.assertEqual(state, before)
                self.assertFalse(setup)
                supplied = True
                call = copy.deepcopy(original)
                traces.append(copy.deepcopy(call))
                executor.solve_calls.append(call)
                return call['response']
            executor.solve = recorded_then_actual
            final = executor.advance(before)
            self.assertEqual(executor.solve_calls[0]['response'], original['response'])
            kind = 'original_choice_continuation_completed' if manual else 'original_choice_return_completed'
            proofs = [p for p in executor.solve_calls[0].get('replay', []) if p.get('kind') == kind
                and (p.get('actual_root_audit') if manual else p.get('actual_choice_audit'))['parent']['card_id'] == card]
            self.assertTrue(proofs)
            proof = proofs[0]
            self.assertEqual(proof['selected_cards'][0]['CardId'], 'DEFEND_DEFECT' if card == 'HAND_TRICK' else 'OMNISLICE')
            if card == 'HAND_TRICK' and not manual:
                self.assertEqual(proof['additional_original_empty_returns'][0]['returned_cards'], [])
                self.assertEqual(proof['actual_original_play_completion']['state'], 'Finished')
            if manual:
                self.assertTrue(proof['manual_selection_request_sent'])
                self.assertFalse(proof['automatic_selection_request_sent'])
            verified = validate_replay_evidence(executor.solve_calls, traces)
            self.assertTrue(verified['verified'])
            self.assertIn(final['decision'], ('card_reward', 'map_select', 'game_over'))
            if mutations:
                binding = next(b for b in verified['bindings'] if b['call_index'] == 0 and b['kind'] == kind
                    and traces[b['parent_trace_index']]['response']['choice_audit']['parent']['card_id'] == card)
                query = binding['query_trace_index']
                changes = [('event','original_task_completed_successfully',False), ('event','filter_reexecuted_by_observer',True),
                    ('event','selector_invocations_after',-1), ('event','source_is_actual_parent_object',False)]
                if card == 'HAND_TRICK': changes.append(('event','raw_source_count_at_return',-1))
                if manual:
                    changes += [('continuation','original_play_task_completed_successfully',False),
                        ('continuation','original_play_cancelled',True), ('continuation','original_branch_context_verified',False),
                        ('continuation','original_play_action_id',-1), ('continuation','selector_task_identity_matches',False),
                        ('continuation','original_and_selector_return_same_card_objects',False)]
                for where, field, value in changes:
                    bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                    bp = next(p for p in bad_calls[0]['replay'] if p == proof)
                    for record in (bp['actual_choice_audit'], bad_traces[query-1]['response']['choice_audit'],
                            bad_traces[query]['response']['completion_audit']):
                        target = record['original_returns'][0] if where == 'event' else record['hand_trick_continuation']
                        target[field] = value
                    with self.subTest(field=field), self.assertRaises(ValueError): validate_replay_evidence(bad_calls,bad_traces)
                for field in ('CardId','StateKey','UpgradeLevel','SourceOccurrence','OptionOccurrence'):
                    bad_calls, bad_traces = copy.deepcopy(executor.solve_calls), copy.deepcopy(traces)
                    bp = next(p for p in bad_calls[0]['replay'] if p == proof)
                    for record in (bp['actual_choice_audit'],bad_traces[query-1]['response']['choice_audit'],bad_traces[query]['response']['completion_audit']):
                        token=record['original_returns'][0]['returned_cards'][0]
                        token[field] = token[field]+1 if type(token[field]) is int else 'UNRELATED'
                    with self.assertRaises(ValueError):validate_replay_evidence(bad_calls,bad_traces)
                bad_calls=copy.deepcopy(executor.solve_calls);bad_calls[0]['replay'].remove(proof)
                with self.assertRaises(ValueError):validate_replay_evidence(bad_calls,traces)
            self.assertTrue(unchanged(receipt['actual_source_evidence']))
            passed=True
        finally:
            self.save(label,traces,passed=passed,origin='recorded_full_solver_envelope_diagnostic',
                first_solve_is_recorded_full_original_envelope_not_new_search=True,
                original_source=receipt['actual_source_evidence'],original_run=name,
                public_prefix_responses_verified=matched,solver_calls=executor.solve_calls if executor else [],
                hidden_state_or_rng_equality_claimed=False)
            bridge.close()

    def test_cosmic_original_plan(self): self.run_original(2,14,23,'COSMIC_INDIFFERENCE',mutations=True)
    def test_hand_trick_automatic_then_original_empty(self): self.run_original(3,0,11,'HAND_TRICK',mutations=True)
    def test_hand_trick_manual_c02(self): self.run_original(3,2,11,'HAND_TRICK',manual=True,mutations=True)
    def test_hand_trick_manual_c04(self): self.run_original(3,4,11,'HAND_TRICK',manual=True)
    def test_hand_trick_manual_c13(self): self.run_original(3,13,11,'HAND_TRICK',manual=True)
    def test_hand_trick_manual_c15(self): self.run_original(3,15,11,'HAND_TRICK',manual=True)

    def test_cosmic_original_empty_singleton_and_manual_pair(self):
        for count in (0,1,2):
            label='cosmic-hand-boundary-'+str(count)+'-'+uuid.uuid4().hex[:10]
            bridge,traces,send=self.worker(label);passed=False
            try:
                send(cmd='start_run',character='Defect',ascension=10,seed='cosmic-boundary')
                send(cmd='set_player',hp=1000,max_hp=1000,relics=[],potions=[],deck=['COSMIC_INDIFFERENCE']+['GO_FOR_THE_EYES']*4)
                state=send(cmd='enter_room',type='combat',encounter='FOGMOG_NORMAL')
                for _ in range(count):
                    card=next(c for c in state['hand'] if c['id']=='CARD.GO_FOR_THE_EYES')
                    state=send(cmd='action',action='play_card',args={'card_index':card['index'],'target_index':0})
                self.assertEqual(state['discard_pile_count'],count)
                card=next(c for c in state['hand'] if c['id']=='CARD.COSMIC_INDIFFERENCE')
                after=send(cmd='action',action='play_card',args={'card_index':card['index']})
                event=after['choice_audit']['original_returns'][0]
                self.assertEqual(event['raw_source_count_at_entry'],count)
                if count==2:
                    self.assertEqual(after['decision'],'card_select');self.assertEqual(len(after['cards']),2)
                    self.assertFalse(event['verified']);self.assertFalse(event['original_task_completed_successfully'])
                    self.assertEqual(send(cmd='action',action='select_cards',args={'indices':'0'})['decision'],'combat_play')
                else:
                    self.assertEqual(after['decision'],'combat_play');self.assertTrue(event['verified'])
                    self.assertEqual(event['returned_count'],count)
                    if count:self.assertEqual(event['returned_cards'][0]['CardId'],'GO_FOR_THE_EYES')
                passed=True
            finally:
                self.save(label,traces,passed=passed,origin='synthetic_original_pile_boundary',raw_discard_cards=count,
                    hidden_state_or_rng_equality_claimed=False)
                bridge.close()


if __name__=='__main__':unittest.main()
